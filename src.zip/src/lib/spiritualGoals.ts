export type GoalCategory = 'quran' | 'dhikr' | 'charity' | 'prayer' | 'sunnah' | 'general';

export interface SpiritualGoal {
  id: string;
  title: string;
  category: GoalCategory;
  isCustom?: boolean;
}

export const PRESET_GOAL_SUGGESTIONS: Array<{ title: string; category: GoalCategory }> = [
  { title: 'Read one page of Quran', category: 'quran' },
  { title: 'Morning Adhkar', category: 'dhikr' },
  { title: 'Donate to charity', category: 'charity' },
  { title: 'Evening Adhkar & Protection Duas', category: 'dhikr' },
  { title: 'Recite Ayat al-Kursi after prayers', category: 'quran' },
  { title: 'Pray 2 Raka’ah Duha / Tahajjud', category: 'prayer' },
  { title: 'Send 100 Salawat upon the Prophet ﷺ', category: 'sunnah' },
  { title: 'Ask for forgiveness (100x Istighfar)', category: 'dhikr' }
];

export const DEFAULT_SPIRITUAL_GOALS: SpiritualGoal[] = [
  { id: 'goal-quran-page', title: 'Read one page of Quran', category: 'quran' },
  { id: 'goal-morning-adhkar', title: 'Morning Adhkar', category: 'dhikr' },
  { id: 'goal-charity-sadaqah', title: 'Donate to charity', category: 'charity' },
  { id: 'goal-ayat-kursi', title: 'Recite Ayat al-Kursi', category: 'quran' }
];

const GOALS_LIST_KEY = 'noor_spiritual_goals_list';
const GOALS_COMPLETIONS_KEY = 'noor_spiritual_goals_completions';

export function getTodayDateString(date: Date = new Date()): string {
  return date.toDateString();
}

export function getSpiritualGoals(): SpiritualGoal[] {
  if (typeof localStorage === 'undefined') return DEFAULT_SPIRITUAL_GOALS;
  try {
    const raw = localStorage.getItem(GOALS_LIST_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
    // Also check legacy dailyGoals if present
    const legacy = localStorage.getItem('dailyGoals');
    if (legacy) {
      const parsedLegacy = JSON.parse(legacy);
      if (Array.isArray(parsedLegacy) && parsedLegacy.length > 0) {
        return parsedLegacy.map(item => ({
          id: item.id || `goal-${Date.now()}-${Math.random()}`,
          title: item.text || item.title || 'Spiritual Goal',
          category: 'general' as GoalCategory,
          isCustom: true
        }));
      }
    }
  } catch (err) {
    console.warn('[SpiritualGoals] Error loading goals list:', err);
  }
  return DEFAULT_SPIRITUAL_GOALS;
}

export function saveSpiritualGoals(goals: SpiritualGoal[]): void {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(GOALS_LIST_KEY, JSON.stringify(goals));
    // Keep legacy dailyGoals synced
    localStorage.setItem('dailyGoals', JSON.stringify(goals.map(g => ({
      id: g.id,
      text: g.title,
      completed: false
    }))));
    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      window.dispatchEvent(new CustomEvent('spiritual-goals-updated', { detail: { goals } }));
    }
  } catch (err) {
    console.warn('[SpiritualGoals] Error saving goals list:', err);
  }
}

export function getGoalCompletionsForDate(dateStr: string = getTodayDateString()): Record<string, boolean> {
  if (typeof localStorage === 'undefined') return {};
  try {
    const raw = localStorage.getItem(`${GOALS_COMPLETIONS_KEY}_${dateStr}`);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.warn('[SpiritualGoals] Error reading completions:', err);
  }
  return {};
}

export function saveGoalCompletionsForDate(dateStr: string, completions: Record<string, boolean>): void {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(`${GOALS_COMPLETIONS_KEY}_${dateStr}`, JSON.stringify(completions));
    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      window.dispatchEvent(new CustomEvent('spiritual-goals-completed-changed', {
        detail: { dateStr, completions }
      }));
    }
  } catch (err) {
    console.warn('[SpiritualGoals] Error saving completions:', err);
  }
}

export function toggleSpiritualGoal(
  goalId: string,
  dateStr: string = getTodayDateString()
): { completed: boolean; completedCount: number; totalCount: number; percentage: number } {
  const currentCompletions = getGoalCompletionsForDate(dateStr);
  const nextCompleted = !currentCompletions[goalId];
  const updatedCompletions = {
    ...currentCompletions,
    [goalId]: nextCompleted
  };

  saveGoalCompletionsForDate(dateStr, updatedCompletions);

  const goals = getSpiritualGoals();
  const completedCount = goals.filter(g => !!updatedCompletions[g.id]).length;
  const totalCount = goals.length;
  const percentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return { completed: nextCompleted, completedCount, totalCount, percentage };
}

export function addSpiritualGoal(title: string, category: GoalCategory = 'general'): SpiritualGoal {
  const trimmed = title.trim();
  const newGoal: SpiritualGoal = {
    id: `goal-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    title: trimmed,
    category,
    isCustom: true
  };

  const current = getSpiritualGoals();
  const updated = [...current, newGoal];
  saveSpiritualGoals(updated);
  return newGoal;
}

export function removeSpiritualGoal(goalId: string): void {
  const current = getSpiritualGoals();
  const updated = current.filter(g => g.id !== goalId);
  saveSpiritualGoals(updated);
}

export function setAllGoalsForDate(dateStr: string, completeAll: boolean): void {
  const goals = getSpiritualGoals();
  const updated: Record<string, boolean> = {};
  goals.forEach(g => {
    updated[g.id] = completeAll;
  });
  saveGoalCompletionsForDate(dateStr, updated);
}

export function calculateGoalsProgress(dateStr: string = getTodayDateString()): {
  completedCount: number;
  totalCount: number;
  percentage: number;
} {
  const goals = getSpiritualGoals();
  const completions = getGoalCompletionsForDate(dateStr);
  const completedCount = goals.filter(g => !!completions[g.id]).length;
  const totalCount = goals.length;
  const percentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return { completedCount, totalCount, percentage };
}
