import { allDuas, DuaItem } from '../data/duas';
import { 
  getNotificationPermission, 
  requestNotificationPermission, 
  isNotificationSupported 
} from './notifications';
import { parseTimeToMinutes } from './prayerScheduler';

export interface DailyDuaPreferences {
  enabled: boolean;
  time: string; // "HH:MM" 24h format (e.g. "08:30")
  category: string; // "all" | category id
  soundEnabled: boolean;
}

export const DEFAULT_DAILY_DUA_PREFERENCES: DailyDuaPreferences = {
  enabled: true,
  time: '09:00', // Default 9:00 AM daily motivational reminder
  category: 'all',
  soundEnabled: true
};

const STORAGE_KEY = 'noor_daily_dua_notification_prefs';
export const duaNotifiedMap: Record<string, string> = {};

export function getDailyDuaPreferences(): DailyDuaPreferences {
  if (typeof localStorage === 'undefined') return DEFAULT_DAILY_DUA_PREFERENCES;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        enabled: parsed.enabled ?? DEFAULT_DAILY_DUA_PREFERENCES.enabled,
        time: parsed.time || DEFAULT_DAILY_DUA_PREFERENCES.time,
        category: parsed.category || DEFAULT_DAILY_DUA_PREFERENCES.category,
        soundEnabled: parsed.soundEnabled ?? DEFAULT_DAILY_DUA_PREFERENCES.soundEnabled
      };
    }
  } catch (err) {
    console.warn('[DailyDuaScheduler] Error parsing preferences:', err);
  }
  return DEFAULT_DAILY_DUA_PREFERENCES;
}

export function saveDailyDuaPreferences(prefs: DailyDuaPreferences): void {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      window.dispatchEvent(new CustomEvent('daily-dua-notifications-updated', { detail: prefs }));
    }
  } catch (err) {
    console.warn('[DailyDuaScheduler] Error saving preferences:', err);
  }
}

/**
 * Deterministically retrieves a motivational daily Dua for a given date and category
 */
export function getMotivationalDuaForDate(date: Date = new Date(), category: string = 'all'): DuaItem {
  const pool = (category && category !== 'all') 
    ? allDuas.filter(d => d.category === category)
    : allDuas;

  const validPool = pool.length > 0 ? pool : allDuas;
  const dayOfYear = Math.floor((date.getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / 86400000);
  return validPool[Math.abs(dayOfYear) % validPool.length];
}

/**
 * Checks if the notification should fire based on configured time and current time
 */
export function evaluateDailyDuaNotificationTrigger(options: {
  targetTimeStr: string;
  currentTotalMinutes: number;
  isEnabled: boolean;
  hasNotifiedToday: boolean;
}): boolean {
  const { targetTimeStr, currentTotalMinutes, isEnabled, hasNotifiedToday } = options;
  if (!isEnabled || hasNotifiedToday) return false;

  const targetMinutes = parseTimeToMinutes(targetTimeStr);
  return currentTotalMinutes === targetMinutes;
}

/**
 * Dispatches a native browser notification containing the motivational Dua
 */
export function showDailyDuaNotification(dua: DuaItem, soundEnabled: boolean = true): boolean {
  if (!isNotificationSupported()) return false;
  if (getNotificationPermission() !== 'granted') return false;

  try {
    const title = `✨ Daily Motivational Dua · ${dua.title}`;
    const truncatedMeaning = dua.meaning.length > 130 
      ? dua.meaning.slice(0, 127) + '...' 
      : dua.meaning;

    const body = `"${truncatedMeaning}"\n📖 ${dua.reference || 'Quran & Sunnah'}`;

    const notification = new Notification(title, {
      body,
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      tag: `daily-dua-${Date.now()}`,
      silent: !soundEnabled
    });

    notification.onclick = () => {
      if (typeof window !== 'undefined') {
        window.focus();
        window.location.href = '/duas';
      }
    };

    return true;
  } catch (err) {
    console.warn('[DailyDuaScheduler] Error triggering notification:', err);
    return false;
  }
}

/**
 * Dispatches a test daily Dua notification to verify browser permissions & audio
 */
export async function sendTestDailyDuaNotification(): Promise<boolean> {
  if (!isNotificationSupported()) return false;

  let permission = getNotificationPermission();
  if (permission !== 'granted') {
    const granted = await requestNotificationPermission();
    if (!granted) return false;
  }

  const prefs = getDailyDuaPreferences();
  const sampleDua = getMotivationalDuaForDate(new Date(), prefs.category);
  return showDailyDuaNotification(sampleDua, prefs.soundEnabled);
}

/**
 * Worker check executed every 30s in background
 */
export function checkAndTriggerDailyDua(): void {
  if (getNotificationPermission() !== 'granted') return;

  const prefs = getDailyDuaPreferences();
  if (!prefs.enabled) return;

  const now = new Date();
  const todayDateStr = now.toDateString();
  const currentTotalMinutes = now.getHours() * 60 + now.getMinutes();
  const notifiedKey = `${todayDateStr}_daily_dua`;

  const shouldTrigger = evaluateDailyDuaNotificationTrigger({
    targetTimeStr: prefs.time,
    currentTotalMinutes,
    isEnabled: prefs.enabled,
    hasNotifiedToday: duaNotifiedMap[notifiedKey] === todayDateStr
  });

  if (shouldTrigger) {
    duaNotifiedMap[notifiedKey] = todayDateStr;
    const dua = getMotivationalDuaForDate(now, prefs.category);
    showDailyDuaNotification(dua, prefs.soundEnabled);
  }
}
