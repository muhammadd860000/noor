import FlexSearch from 'flexsearch';
import { surahs } from '../data/surahs';
import { normalizeArabic, normalizeLatin, Surah } from './quranSearch';

// Rich English translations and offline search keywords for Surahs
export const SURAH_TRANSLATIONS_AND_KEYWORDS: Record<number, { englishTranslation: string; keywords: string; revelationType: 'Meccan' | 'Medinan'; ayahs: number }> = {
  1: { englishTranslation: "The Opening", keywords: "fatiha opening umm al quran prayer alhamd rahmah mother of book7 verses", revelationType: "Meccan", ayahs: 7 },
  2: { englishTranslation: "The Cow", keywords: "baqarah cow ayatul kursi throne verse baqara adam moses musa pharaoh ibrahim kaaba fasting ramadan zakat talut jalut286 verses", revelationType: "Medinan", ayahs: 286 },
  3: { englishTranslation: "Family of Imran", keywords: "ali imran maryam mary isa jesusuhud battle zakariya imran319 verses", revelationType: "Medinan", ayahs: 200 },
  4: { englishTranslation: "The Women", keywords: "nisa women orphans inheritance marriage dowry justice hypocrites", revelationType: "Medinan", ayahs: 176 },
  5: { englishTranslation: "The Table Spread", keywords: "maidah food halal food covenant cain abel maida table spread", revelationType: "Medinan", ayahs: 120 },
  6: { englishTranslation: "The Cattle", keywords: "anam cattle monotheism tawheed creation ibrahim", revelationType: "Meccan", ayahs: 165 },
  7: { englishTranslation: "The Heights", keywords: "araf heights adam iblis satan musa magicians 77 verses", revelationType: "Meccan", ayahs: 206 },
  8: { englishTranslation: "The Spoils of War", keywords: "anfal spoils battle of badr victory angels spoils war", revelationType: "Medinan", ayahs: 75 },
  9: { englishTranslation: "The Repentance", keywords: "tawbah repentance baraah tabuk treaty charity zakat bismillah missing", revelationType: "Medinan", ayahs: 129 },
  10: { englishTranslation: "Jonah", keywords: "yunus jonah whale ocean patience pharaoh drowning", revelationType: "Meccan", ayahs: 109 },
  11: { englishTranslation: "Hud", keywords: "hud prophet ad nation ark of nuh noah shuayb saleh", revelationType: "Meccan", ayahs: 123 },
  12: { englishTranslation: "Joseph", keywords: "yusuf joseph dream brothers palace ruler egypt best story beauty", revelationType: "Meccan", ayahs: 111 },
  13: { englishTranslation: "The Thunder", keywords: "rad thunder praise of allah hearts rest remembrance dhikr", revelationType: "Medinan", ayahs: 43 },
  14: { englishTranslation: "Abraham", keywords: "ibrahim abraham prayer kaaba makkah gratitude light darkness", revelationType: "Meccan", ayahs: 52 },
  15: { englishTranslation: "The Rocky Tract", keywords: "hijr rocky tract hijr al quran protection iblis angels", revelationType: "Meccan", ayahs: 99 },
  16: { englishTranslation: "The Bee", keywords: "nahl bee honey blessings of allah creation mountains rivers", revelationType: "Meccan", ayahs: 128 },
  17: { englishTranslation: "The Night Journey", keywords: "isra night journey isra wal miraj aqsa mosque parents honor 17", revelationType: "Meccan", ayahs: 111 },
  18: { englishTranslation: "The Cave", keywords: "kahf cave sleepers youth dog khidr musa dhu al qarnayn gog magog ya'juj ma'juj friday surah", revelationType: "Meccan", ayahs: 110 },
  19: { englishTranslation: "Mary", keywords: "maryam mary jesus isa zakariya yahya john baptism virgin birth", revelationType: "Meccan", ayahs: 98 },
  20: { englishTranslation: "Ta-Ha", keywords: "taha moses burning bush staff pharaoh rod magicians valley of tuwa", revelationType: "Meccan", ayahs: 135 },
  21: { englishTranslation: "The Prophets", keywords: "anbiya prophets ibrahim idol fire sulaiman dawood yunus ayyub job", revelationType: "Meccan", ayahs: 112 },
  22: { englishTranslation: "The Pilgrimage", keywords: "hajj pilgrimage kaaba sacrifice qurbani ihram tawaf sa'i day of judgment", revelationType: "Medinan", ayahs: 78 },
  23: { englishTranslation: "The Believers", keywords: "muminun believers khushu prayer paradise firdaus chastity", revelationType: "Meccan", ayahs: 118 },
  24: { englishTranslation: "The Light", keywords: "nur light ayat an nur modesty hijab aishah slander an nur", revelationType: "Medinan", ayahs: 64 },
  25: { englishTranslation: "The Criterion", keywords: "furqan criterion truth falsehood servants of Ar-Rahman walking humbly", revelationType: "Meccan", ayahs: 77 },
  26: { englishTranslation: "The Poets", keywords: "shuara poets musa pharaoh ibrahim nuh hud saleh lut shuayb", revelationType: "Meccan", ayahs: 227 },
  27: { englishTranslation: "The Ant", keywords: "naml ant solomon sulaiman queen of sheba bilqis ant army hoopoe bird", revelationType: "Meccan", ayahs: 93 },
  28: { englishTranslation: "The Stories", keywords: "qasas stories moses infancy midian qarun korah wealth", revelationType: "Meccan", ayahs: 88 },
  29: { englishTranslation: "The Spider", keywords: "ankabut spider web trials faith parents struggle jihad", revelationType: "Meccan", ayahs: 69 },
  30: { englishTranslation: "The Romans", keywords: "rum romans victory prophecy love mercy between spouses", revelationType: "Meccan", ayahs: 60 },
  31: { englishTranslation: "Luqman", keywords: "luqman wisdom advice to son gratitude parents modesty in walking", revelationType: "Meccan", ayahs: 34 },
  32: { englishTranslation: "The Prostration", keywords: "sajdah prostration night prayer tahajjud creation clay", revelationType: "Meccan", ayahs: 30 },
  33: { englishTranslation: "The Combined Forces", keywords: "ahzab confederates battle of trench ahzab wives of prophet veil", revelationType: "Medinan", ayahs: 73 },
  34: { englishTranslation: "Sheba", keywords: "saba sheba david solomon iron armor jinns flood", revelationType: "Meccan", ayahs: 54 },
  35: { englishTranslation: "The Originator", keywords: "fatir originator angels wings creation power mercy", revelationType: "Meccan", ayahs: 45 },
  36: { englishTranslation: "Ya-Sin", keywords: "yasin yaseen heart of quran resurrected city messenger dead revived", revelationType: "Meccan", ayahs: 83 },
  37: { englishTranslation: "Those Ranged in Ranks", keywords: "saffat ranks angels ibrahim sacrifice of son ismail iliyas lut", revelationType: "Meccan", ayahs: 182 },
  38: { englishTranslation: "Sad", keywords: "sad david solomon job ayyub trial patience angels adam iblis", revelationType: "Meccan", ayahs: 88 },
  39: { englishTranslation: "The Troops", keywords: "zumar troops repentance sincererity despair not of mercy gates of paradise", revelationType: "Meccan", ayahs: 75 },
  40: { englishTranslation: "The Forgiver", keywords: "ghafir forgiver believer from pharaoh family supplication du'a answered", revelationType: "Meccan", ayahs: 85 },
  41: { englishTranslation: "Explained in Detail", keywords: "fussilat detailed explanation good deed repels evil enemies turn friends", revelationType: "Meccan", ayahs: 54 },
  42: { englishTranslation: "The Consultation", keywords: "shura consultation shura consultation unity forgiveness trust", revelationType: "Meccan", ayahs: 53 },
  43: { englishTranslation: "The Ornaments of Gold", keywords: "zukhruf gold ornaments jesus son of mary abraham tawheed", revelationType: "Meccan", ayahs: 89 },
  44: { englishTranslation: "The Smoke", keywords: "dukhan smoke laylatul qadr blessed night pharaoh punishment", revelationType: "Meccan", ayahs: 59 },
  45: { englishTranslation: "The Crouching", keywords: "jathiyah crouching judgment day nations kneeling signs in universe", revelationType: "Meccan", ayahs: 37 },
  46: { englishTranslation: "The Curved Sand-hills", keywords: "ahqaf sand hills ad nation prophet hud parents kindness at 40 years", revelationType: "Meccan", ayahs: 35 },
  47: { englishTranslation: "Muhammad", keywords: "muhammad prophet victory warfare good deeds rewarded peace", revelationType: "Medinan", ayahs: 38 },
  48: { englishTranslation: "The Victory", keywords: "fath victory hudaybiyyah treaty forgiveness tranquility sakinah pledge", revelationType: "Medinan", ayahs: 29 },
  49: { englishTranslation: "The Rooms", keywords: "hujurat rooms manners brotherhood no mocking no backbiting piety taqwa", revelationType: "Medinan", ayahs: 18 },
  50: { englishTranslation: "Qaf", keywords: "qaf resurrection recording angels death agony trumpet blast gardens", revelationType: "Meccan", ayahs: 45 },
  51: { englishTranslation: "The Winnowing Winds", keywords: "dhariyat winds creation of jinns and humans to worship abraham guest angels", revelationType: "Meccan", ayahs: 60 },
  52: { englishTranslation: "The Mount", keywords: "tur mount sinai paradise bliss family reunited in jannah", revelationType: "Meccan", ayahs: 49 },
  53: { englishTranslation: "The Star", keywords: "najm star miraj angel gabriel sidrat al muntaha boundary lote tree", revelationType: "Meccan", ayahs: 62 },
  54: { englishTranslation: "The Moon", keywords: "qamar moon splitting of moon qamar warning easy to remember quran", revelationType: "Meccan", ayahs: 55 },
  55: { englishTranslation: "The Beneficent", keywords: "rahman beneficent which of the favors of your Lord will you deny ar-rahman jannah", revelationType: "Medinan", ayahs: 78 },
  56: { englishTranslation: "The Inevitable", keywords: "waqiah event inevitable day of judgment three groups foremost right left hand", revelationType: "Meccan", ayahs: 96 },
  57: { englishTranslation: "The Iron", keywords: "hadid iron light of believers spending for cause of Allah scale balance", revelationType: "Medinan", ayahs: 29 },
  58: { englishTranslation: "The Pleading Woman", keywords: "mujadila pleading woman khawlah secret counsels whisperings", revelationType: "Medinan", ayahs: 22 },
  59: { englishTranslation: "The Exile", keywords: "hashr exile banu nadir gathering beautiful names of Allah asmaul husna", revelationType: "Medinan", ayahs: 24 },
  60: { englishTranslation: "She that is to be examined", keywords: "mumtahanah examined woman loyalty affection abraham example", revelationType: "Medinan", ayahs: 13 },
  61: { englishTranslation: "The Ranks", keywords: "saff ranks battle array jesus prophecy of ahmad muhammad victory", revelationType: "Medinan", ayahs: 14 },
  62: { englishTranslation: "The Congregation, Friday", keywords: "jumuah friday prayer friday sermon leave business trade for prayer", revelationType: "Medinan", ayahs: 11 },
  63: { englishTranslation: "The Hypocrites", keywords: "munafiqun hypocrites lies don't let wealth distract from remembrance", revelationType: "Medinan", ayahs: 11 },
  64: { englishTranslation: "Mutual Disillusion", keywords: "taghabun mutual loss gain day of gathering wealth and children trial", revelationType: "Medinan", ayahs: 18 },
  65: { englishTranslation: "The Divorce", keywords: "talaq divorce iddah waiting period provision from unexpected sources tawakkul", revelationType: "Medinan", ayahs: 12 },
  66: { englishTranslation: "The Prohibition", keywords: "tahrim prohibition wives of prophet repentance tahrim pharaoh wife asiya maryam", revelationType: "Medinan", ayahs: 12 },
  67: { englishTranslation: "The Sovereignty", keywords: "mulk sovereignty protection from grave punishment creation of stars sovereignty mulk", revelationType: "Meccan", ayahs: 30 },
  68: { englishTranslation: "The Pen", keywords: "qalam pen nun exalted character character of prophet garden story", revelationType: "Meccan", ayahs: 52 },
  69: { englishTranslation: "The Inevitable Truth", keywords: "haqqah inevitable truth destruction of ad thamud book in right hand", revelationType: "Meccan", ayahs: 52 },
  70: { englishTranslation: "The Ascending Stairways", keywords: "maarij stairways day length 50000 years patience prayer charity", revelationType: "Meccan", ayahs: 44 },
  71: { englishTranslation: "Noah", keywords: "nuh noah 950 years preaching night and day rain forgiveness clouds ark", revelationType: "Meccan", ayahs: 28 },
  72: { englishTranslation: "The Jinn", keywords: "jinn jinn listened to quran tawheed protection unseen", revelationType: "Meccan", ayahs: 28 },
  73: { englishTranslation: "The Enshrouded One", keywords: "muzzammil wrapped one night prayer tahajjud recitation with tartil", revelationType: "Meccan", ayahs: 20 },
  74: { englishTranslation: "The Cloaked One", keywords: "muddaththir cloaked one arise and warn purify garments glorify Lord", revelationType: "Meccan", ayahs: 56 },
  75: { englishTranslation: "The Resurrection", keywords: "qiyamah resurrection self accusing soul move tongue quickly scale", revelationType: "Meccan", ayahs: 40 },
  76: { englishTranslation: "Man / Time", keywords: "insan human time story of creation feeding poor orphans captive for love of Allah", revelationType: "Medinan", ayahs: 31 },
  77: { englishTranslation: "Those Sent Forth", keywords: "mursalat winds sent forth woe on that day to the deniers", revelationType: "Meccan", ayahs: 50 },
  78: { englishTranslation: "The Great News", keywords: "naba news resurrection mountains pegs earth cradle cups in paradise", revelationType: "Meccan", ayahs: 40 },
  79: { englishTranslation: "Those Who Drag Forth", keywords: "naziat extractors moses pharaoh trumpets terrifying blast", revelationType: "Meccan", ayahs: 46 },
  80: { englishTranslation: "He Frowned", keywords: "abasa frowned blind man ibn umm maktum reminder grain grapes olive palm", revelationType: "Meccan", ayahs: 42 },
  81: { englishTranslation: "The Overthrowing", keywords: "takwir folding up sun folded stars fall infant girl buried alive scroll opened", revelationType: "Meccan", ayahs: 29 },
  82: { englishTranslation: "The Cleaving", keywords: "infitar cleaving sky split open noble recording angels kiraman katibin", revelationType: "Meccan", ayahs: 19 },
  83: { englishTranslation: "The Defrauding", keywords: "mutaffifin cheats measure balance defrauding illiyyun register of righteous", revelationType: "Meccan", ayahs: 36 },
  84: { englishTranslation: "The Splitting Asunder", keywords: "inshiqaq splitting sky earth stretched out book behind back", revelationType: "Meccan", ayahs: 25 },
  85: { englishTranslation: "The Mansions of the Stars", keywords: "buruj constellations ditch people of trench ashāb al-ukhdūd believers burned", revelationType: "Meccan", ayahs: 22 },
  86: { englishTranslation: "The Nightcomer", keywords: "tariq night star piercing star creation fluid soul guardian", revelationType: "Meccan", ayahs: 17 },
  87: { englishTranslation: "The Most High", keywords: "ala most high glorify name of Most High scroll of abraham and moses", revelationType: "Meccan", ayahs: 19 },
  88: { englishTranslation: "The Overwhelming Event", keywords: "ghashiyah overwhelming day humiliating faces joyous faces camels sky mountains", revelationType: "Meccan", ayahs: 26 },
  89: { englishTranslation: "The Dawn", keywords: "fajr dawn ten nights ad thamud iram of pillars tranquil soul nafs mutmainnah", revelationType: "Meccan", ayahs: 30 },
  90: { englishTranslation: "The City", keywords: "balad city makkah city free captive feed on day of hunger two paths steep path", revelationType: "Meccan", ayahs: 20 },
  91: { englishTranslation: "The Sun", keywords: "shams sun moon day night soul purified succeed soul corrupted ruined thamud camel", revelationType: "Meccan", ayahs: 15 },
  92: { englishTranslation: "The Night", keywords: "layl night day giving for Allah ease hardship abu bakr", revelationType: "Meccan", ayahs: 21 },
  93: { englishTranslation: "The Morning Hours", keywords: "duha morning forenoon your Lord has not forsaken you orphan guidance poverty rich", revelationType: "Meccan", ayahs: 11 },
  94: { englishTranslation: "The Relief", keywords: "inshirah relief expansion chest burden lifted with hardship comes ease", revelationType: "Meccan", ayahs: 8 },
  95: { englishTranslation: "The Fig", keywords: "tin fig olive mount sinai makkah best stature human lowest of low", revelationType: "Meccan", ayahs: 8 },
  96: { englishTranslation: "The Clot", keywords: "alaq clot read iqra first revelation cave hira pen knowledge abu jahl", revelationType: "Meccan", ayahs: 19 },
  97: { englishTranslation: "The Night of Decree", keywords: "qadr decree laylatul qadr night better than 1000 months angels peace until dawn", revelationType: "Meccan", ayahs: 5 },
  98: { englishTranslation: "The Clear Proof", keywords: "bayyinah clear proof scripture sincerity pure religion best of creatures", revelationType: "Medinan", ayahs: 8 },
  99: { englishTranslation: "The Earthquake", keywords: "zalzalah earthquake earth shakes out burdens atom weight of good atom weight of evil", revelationType: "Medinan", ayahs: 8 },
  100: { englishTranslation: "The Courser", keywords: "adiyat horses snorting charging horses human ungrateful for Lord", revelationType: "Meccan", ayahs: 11 },
  101: { englishTranslation: "The Calamity", keywords: "qariah calamity striking day heavy scales light scales hawiyah abyss", revelationType: "Meccan", ayahs: 11 },
  102: { englishTranslation: "The Rivalry in World Increase", keywords: "takathur competition rivalry wealth graves question about blessings naim", revelationType: "Meccan", ayahs: 8 },
  103: { englishTranslation: "The Declining Day", keywords: "asr time declining afternoon loss except who believe good deeds truth patience", revelationType: "Meccan", ayahs: 3 },
  104: { englishTranslation: "The Slanderer", keywords: "humazah slanderer backbiter counting wealth crushing fire hutamah", revelationType: "Meccan", ayahs: 9 },
  105: { englishTranslation: "The Elephant", keywords: "fil elephant abrahah army birds ababil stones of baked clay chewed straw", revelationType: "Meccan", ayahs: 5 },
  106: { englishTranslation: "Quraysh", keywords: "quraysh trade winter summer caravan worship Lord of this House food security", revelationType: "Meccan", ayahs: 4 },
  107: { englishTranslation: "Small Kindnesses", keywords: "maun small kindnesses denies religion repels orphan heedless in prayer showing off", revelationType: "Meccan", ayahs: 7 },
  108: { englishTranslation: "The Abundance", keywords: "kawthar abundance river in paradise pray to your Lord sacrifice opponent cut off", revelationType: "Meccan", ayahs: 3 },
  109: { englishTranslation: "The Disbelievers", keywords: "kafirun disbelievers I do not worship what you worship to you your religion to me mine", revelationType: "Meccan", ayahs: 6 },
  110: { englishTranslation: "The Divine Support", keywords: "nasr victory divine help entering religion of Allah crowds praise forgiveness", revelationType: "Medinan", ayahs: 3 },
  111: { englishTranslation: "The Palm Fibre", keywords: "masad palm fibre abu lahab ruined hands flame fire wife wood carrier rope", revelationType: "Meccan", ayahs: 5 },
  112: { englishTranslation: "The Sincerity", keywords: "ikhlas sincerity tawheed Allah is One eternal samad no son no father equal to none", revelationType: "Meccan", ayahs: 4 },
  113: { englishTranslation: "The Daybreak", keywords: "falaq daybreak dawn seek refuge created evil darkness envy sorcery knots", revelationType: "Meccan", ayahs: 5 },
  114: { englishTranslation: "Mankind", keywords: "nas mankind people Lord King God whispers of satan jinn and mankind", revelationType: "Meccan", ayahs: 6 },
};

export interface FlexSearchRecord {
  id: number;
  name: string;
  arabic: string;
  normalizedArabic: string;
  normalizedName: string;
  englishTranslation: string;
  revelationType: string;
  keywords: string;
  numAyahs: number;
}

class FlexQuranIndexManager {
  private documentIndex: any = null;
  private isInitialized = false;

  public initializeIndex() {
    if (this.isInitialized) return;

    try {
      // FlexSearch Document Index configuration
      this.documentIndex = new FlexSearch.Document({
        document: {
          id: 'id',
          index: [
            'name',
            'normalizedName',
            'arabic',
            'normalizedArabic',
            'englishTranslation',
            'revelationType',
            'keywords'
          ]
        },
        tokenize: 'forward',
        resolution: 9,
        cache: true
      });

      // Populate document index with all 114 Surahs
      surahs.forEach((s) => {
        const meta = SURAH_TRANSLATIONS_AND_KEYWORDS[s.id] || {
          englishTranslation: '',
          keywords: '',
          revelationType: 'Meccan',
          ayahs: 0
        };

        const doc: FlexSearchRecord = {
          id: s.id,
          name: s.name,
          arabic: s.arabic,
          normalizedArabic: normalizeArabic(s.arabic),
          normalizedName: normalizeLatin(s.name),
          englishTranslation: meta.englishTranslation,
          revelationType: meta.revelationType,
          keywords: meta.keywords,
          numAyahs: meta.ayahs
        };

        this.documentIndex.add(doc);
      });

      this.isInitialized = true;
    } catch (err) {
      console.warn('[FlexQuranIndexManager] Index init error:', err);
    }
  }

  public search(query: string): number[] {
    if (!this.isInitialized) {
      this.initializeIndex();
    }

    if (!query || !query.trim() || !this.documentIndex) return [];

    const cleanQuery = query.trim();

    try {
      // Execute FlexSearch multi-field search
      const results = this.documentIndex.search(cleanQuery, {
        enrich: false,
        limit: 114
      });

      // Extract unique Surah IDs matching across fields
      const matchedIdsSet = new Set<number>();
      results.forEach((fieldResult: any) => {
        if (fieldResult.result && Array.isArray(fieldResult.result)) {
          fieldResult.result.forEach((id: number) => matchedIdsSet.add(id));
        }
      });

      return Array.from(matchedIdsSet);
    } catch (err) {
      console.warn('[FlexQuranIndexManager] Search error:', err);
      return [];
    }
  }
}

export const quranFlexManager = new FlexQuranIndexManager();
