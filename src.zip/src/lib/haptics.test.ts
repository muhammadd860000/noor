import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import {
  triggerHaptic,
  triggerButtonClickHaptic,
  triggerTasbeehHaptic,
  isMobileDevice
} from './haptics';

describe('Haptics Utility - Mobile Detection & Vibration', () => {
  const originalNavigator = global.navigator;
  const originalWindow = global.window;

  beforeEach(() => {
    vi.restoreAllMocks();
  });

  afterEach(() => {
    // Restore
    Object.defineProperty(global, 'navigator', {
      value: originalNavigator,
      configurable: true,
      writable: true
    });
  });

  it('detects desktop non-touch devices correctly and returns false', () => {
    Object.defineProperty(global, 'navigator', {
      value: {
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        maxTouchPoints: 0
      },
      configurable: true,
      writable: true
    });

    expect(isMobileDevice()).toBe(false);
  });

  it('detects mobile devices via mobile UserAgent', () => {
    Object.defineProperty(global, 'navigator', {
      value: {
        userAgent: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        maxTouchPoints: 5,
        vibrate: vi.fn().mockReturnValue(true)
      },
      configurable: true,
      writable: true
    });

    expect(isMobileDevice()).toBe(true);
  });

  it('calls navigator.vibrate with standard pulse on mobile button clicks', () => {
    const mockVibrate = vi.fn().mockReturnValue(true);
    Object.defineProperty(global, 'navigator', {
      value: {
        userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148',
        maxTouchPoints: 5,
        vibrate: mockVibrate
      },
      configurable: true,
      writable: true
    });

    const result = triggerButtonClickHaptic();
    expect(result).toBe(true);
    expect(mockVibrate).toHaveBeenCalledWith(12);
  });

  it('does NOT call navigator.vibrate on desktop environment', () => {
    const mockVibrate = vi.fn().mockReturnValue(true);
    Object.defineProperty(global, 'navigator', {
      value: {
        userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)',
        maxTouchPoints: 0,
        vibrate: mockVibrate
      },
      configurable: true,
      writable: true
    });

    const result = triggerHaptic(20);
    expect(result).toBe(false);
    expect(mockVibrate).not.toHaveBeenCalled();
  });

  it('dispatches milestone celebration pattern when Tasbeeh hits target (e.g. 33)', () => {
    const mockVibrate = vi.fn().mockReturnValue(true);
    Object.defineProperty(global, 'navigator', {
      value: {
        userAgent: 'Android Mobile',
        maxTouchPoints: 1,
        vibrate: mockVibrate
      },
      configurable: true,
      writable: true
    });

    // Count = 33 with target 33
    triggerTasbeehHaptic(33, 33);
    expect(mockVibrate).toHaveBeenCalledWith([35, 45, 35]);

    // Count = 1 (normal tap)
    triggerTasbeehHaptic(1, 33);
    expect(mockVibrate).toHaveBeenCalledWith(15);
  });
});
