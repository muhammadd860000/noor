import { getFromDB, saveToDB } from './db';

export const PRAYER_NAMES = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'] as const;
export type PrayerName = typeof PRAYER_NAMES[number];

export interface DayPrayerLog {
  date: Date;
  dateStr: string; // "Wed Sep 30 2026" (matching toDateString())
  isoDate: string; // "2026-09-30"
  dayShort: string; // "Mon", "Tue"
  dayFull: string; // "Monday"
  dateNum: number; // 30
  prayers: Record<string, boolean>;
  completedCount: number;
  totalPossible: 5;
  percentage: number;
  isToday: boolean;
}

export interface WeeklyPrayerSummary {
  weekDays: DayPrayerLog[];
  totalCompleted: number;
  totalPossible: number;
  weeklyPercentage: number;
  perfectDaysCount: number;
  currentStreak: number;
}

/**
 * Returns prayer status record for a specific date string
 */
export function getPrayerLogForDate(dateStr: string): Record<string, boolean> {
  if (typeof localStorage === 'undefined') return {};
  try {
    const raw = localStorage.getItem(`dailyPrayers_${dateStr}`);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.warn('[PrayerLog] Error reading storage for date:', dateStr, err);
  }
  return {};
}

/**
 * Saves prayer log for a specific date to local storage and IndexedDB
 */
export async function savePrayerLogForDate(dateStr: string, prayers: Record<string, boolean>): Promise<void> {
  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.setItem(`dailyPrayers_${dateStr}`, JSON.stringify(prayers));
    } catch (err) {
      console.warn('[PrayerLog] Error saving to localStorage:', err);
    }
  }

  try {
    await saveToDB('prayer', { date: dateStr, prayers });
  } catch (err) {
    // Ignore db fallback errors
  }

  if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
    window.dispatchEvent(
      new CustomEvent('prayer-status-changed', {
        detail: { date: dateStr, prayers }
      })
    );
  }
}

/**
 * Marks a specific prayer as completed for today
 */
export async function markPrayerCompleted(prayerName: string, completed: boolean = true): Promise<Record<string, boolean>> {
  const todayStr = new Date().toDateString();
  const current = getPrayerLogForDate(todayStr);
  const updated = { ...current, [prayerName]: completed };
  await savePrayerLogForDate(todayStr, updated);
  return updated;
}

/**
 * Returns current estimated prayer name based on hour
 */
export function getCurrentPrayerName(): string {
  const hour = new Date().getHours();
  if (hour >= 4 && hour < 12) return 'Fajr';
  if (hour >= 12 && hour < 15) return 'Dhuhr';
  if (hour >= 15 && hour < 18) return 'Asr';
  if (hour >= 18 && hour < 20) return 'Maghrib';
  return 'Isha';
}

/**
 * Toggles a prayer's completed state for a given date
 */
export async function togglePrayerLog(
  dateStr: string,
  prayer: string
): Promise<{ updatedPrayers: Record<string, boolean>; isCompleted: boolean }> {
  const current = getPrayerLogForDate(dateStr);
  const isCompleted = !current[prayer];
  const updatedPrayers = {
    ...current,
    [prayer]: isCompleted
  };

  await savePrayerLogForDate(dateStr, updatedPrayers);
  return { updatedPrayers, isCompleted };
}

/**
 * Marks all 5 prayers as completed or incomplete for a given date
 */
export async function setAllPrayersForDate(
  dateStr: string,
  completed: boolean
): Promise<Record<string, boolean>> {
  const updated: Record<string, boolean> = {};
  PRAYER_NAMES.forEach(p => {
    updated[p] = completed;
  });

  await savePrayerLogForDate(dateStr, updated);
  return updated;
}

/**
 * Generates the 7-day week schedule and consistency analytics
 */
export function getWeeklyPrayerSummary(referenceDate: Date = new Date()): WeeklyPrayerSummary {
  const weekDays: DayPrayerLog[] = [];
  const todayDateStr = new Date().toDateString();

  // Find Monday of the current week (or rolling 7 days)
  const current = new Date(referenceDate);
  const dayOfWeek = current.getDay(); // 0 = Sun, 1 = Mon, ..., 6 = Sat
  const distanceToMonday = (dayOfWeek + 6) % 7; // Monday as first day of week
  
  const monday = new Date(current);
  monday.setDate(current.getDate() - distanceToMonday);

  let totalCompleted = 0;
  let perfectDaysCount = 0;

  for (let i = 0; i < 7; i++) {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);

    const dateStr = d.toDateString();
    const isoDate = d.toISOString().slice(0, 10);
    const dayShort = d.toLocaleDateString('en-US', { weekday: 'short' });
    const dayFull = d.toLocaleDateString('en-US', { weekday: 'long' });
    const dateNum = d.getDate();

    const prayers = getPrayerLogForDate(dateStr);
    const completedCount = PRAYER_NAMES.filter(p => !!prayers[p]).length;
    const percentage = Math.round((completedCount / 5) * 100);
    const isToday = dateStr === todayDateStr;

    totalCompleted += completedCount;
    if (completedCount === 5) {
      perfectDaysCount += 1;
    }

    weekDays.push({
      date: d,
      dateStr,
      isoDate,
      dayShort,
      dayFull,
      dateNum,
      prayers,
      completedCount,
      totalPossible: 5,
      percentage,
      isToday
    });
  }

  const totalPossible = weekDays.length * 5;
  const weeklyPercentage = totalPossible > 0 ? Math.round((totalCompleted / totalPossible) * 100) : 0;

  // Compute consecutive day streak ending on today or yesterday
  let currentStreak = 0;
  for (let i = weekDays.length - 1; i >= 0; i--) {
    const day = weekDays[i];
    if (day.date > new Date()) continue; // Skip future days
    if (day.completedCount > 0) {
      currentStreak += 1;
    } else {
      break;
    }
  }

  return {
    weekDays,
    totalCompleted,
    totalPossible,
    weeklyPercentage,
    perfectDaysCount,
    currentStreak
  };
}
