import { describe, it, expect } from 'vitest';
import { 
  searchSurahs, 
  extractSurahNumber, 
  normalizeArabic, 
  normalizeLatin, 
  Surah 
} from './quranSearch';
import { surahs } from '../data/surahs';

describe('Quran Surah Search Engine', () => {
  it('finds Surahs by exact number', () => {
    const results = searchSurahs(surahs, '36');
    expect(results.length).toBe(1);
    expect(results[0].name).toBe('Ya-Sin');
    expect(results[0].id).toBe(36);
  });

  it('finds Surahs with prefix numbers like "Surah 18" or "#114"', () => {
    const r1 = searchSurahs(surahs, 'Surah 18');
    expect(r1.length).toBe(1);
    expect(r1[0].name).toBe('Al-Kahf');

    const r2 = searchSurahs(surahs, '#114');
    expect(r2.length).toBe(1);
    expect(r2[0].name).toBe('An-Nas');
  });

  it('finds Surahs by English name ignoring case, hyphens and apostrophes', () => {
    const r1 = searchSurahs(surahs, 'fatihah');
    expect(r1.some(s => s.name === 'Al-Fatihah')).toBe(true);

    const r2 = searchSurahs(surahs, 'baqarah');
    expect(r2.some(s => s.name === 'Al-Baqarah')).toBe(true);

    const r3 = searchSurahs(surahs, 'rahman');
    expect(r3.some(s => s.name === 'Ar-Rahman')).toBe(true);

    const r4 = searchSurahs(surahs, 'ali imran');
    expect(r4.some(s => s.name === "Ali 'Imran")).toBe(true);
  });

  it('finds Surahs by Arabic script ignoring tashkeel and alef differences', () => {
    const r1 = searchSurahs(surahs, 'الفاتحة');
    expect(r1.some(s => s.id === 1)).toBe(true);

    const r2 = searchSurahs(surahs, 'يس');
    expect(r2.some(s => s.id === 36)).toBe(true);

    const r3 = searchSurahs(surahs, 'الرحمن');
    expect(r3.some(s => s.id === 55)).toBe(true);
  });

  it('returns all Surahs when query is empty', () => {
    const results = searchSurahs(surahs, '   ');
    expect(results.length).toBe(surahs.length);
  });

  it('returns empty array when no Surahs match query', () => {
    const results = searchSurahs(surahs, 'xyznonexistentsurah999');
    expect(results.length).toBe(0);
  });
});
