/**
 * Pure calculation functions and utilities for Islamic Zakat & Charity calculations
 */

export interface ZakatAssetsInput {
  cashInHand?: number;
  cashInBank?: number;
  goldSilverValue?: number;
  investments?: number;
  businessMerchandise?: number;
  loansOwedToYou?: number;
  immediateDebts?: number;
}

export interface ZakatCalculationResult {
  totalGrossAssets: number;
  totalDebts: number;
  netZakatableWealth: number;
  currentNisab: number;
  isNisabReached: boolean;
  zakatDue: number;
}

export type NisabStandard = 'gold' | 'silver';

/**
 * Calculates total gross zakatable wealth
 */
export function calculateGrossAssets(assets: ZakatAssetsInput): number {
  return (
    (assets.cashInHand || 0) +
    (assets.cashInBank || 0) +
    (assets.goldSilverValue || 0) +
    (assets.investments || 0) +
    (assets.businessMerchandise || 0) +
    (assets.loansOwedToYou || 0)
  );
}

/**
 * Calculates net zakatable wealth after deducting immediate liabilities
 */
export function calculateNetZakatableWealth(assets: ZakatAssetsInput): number {
  const gross = calculateGrossAssets(assets);
  const debts = assets.immediateDebts || 0;
  return Math.max(0, gross - debts);
}

/**
 * Computes Zakat al-Mal (2.5% or 1/40th) with Nisab threshold verification
 * @param assets Current asset breakdown
 * @param standard Gold or Silver standard
 * @param goldNisab Gold nisab threshold value in local currency (e.g. 85g gold value)
 * @param silverNisab Silver nisab threshold value in local currency (e.g. 595g silver value)
 */
export function calculateZakat(
  assets: ZakatAssetsInput,
  standard: NisabStandard,
  goldNisab: number,
  silverNisab: number
): ZakatCalculationResult {
  const totalGrossAssets = calculateGrossAssets(assets);
  const totalDebts = Math.max(0, assets.immediateDebts || 0);
  const netZakatableWealth = Math.max(0, totalGrossAssets - totalDebts);

  const currentNisab = standard === 'gold' ? goldNisab : silverNisab;
  const isNisabReached = netZakatableWealth >= currentNisab && currentNisab > 0;
  
  // Exact 2.5% rate rounded to 2 decimal places
  const zakatDue = isNisabReached
    ? Math.round(netZakatableWealth * 0.025 * 100) / 100
    : 0;

  return {
    totalGrossAssets,
    totalDebts,
    netZakatableWealth,
    currentNisab,
    isNisabReached,
    zakatDue
  };
}

export interface ContributionItem {
  id: string;
  type: 'zakat' | 'sadaqah' | 'zakat_fitr' | 'waqf';
  amount: number;
  cause: string;
  projectName?: string;
  recipient: string;
  date: string; // YYYY-MM-DD
  notes?: string;
}

export interface AnnualCharitySummary {
  totalGiven: number;
  zakatPaid: number;
  sadaqahPaid: number;
  waqfPaid: number;
  zakatFitrPaid: number;
  goalProgressPct: number;
  zakatRemaining: number;
  zakatProgressPct: number;
}

/**
 * Calculates annual charity progress and remaining zakat due
 */
export function calculateAnnualCharitySummary(
  contributions: ContributionItem[],
  targetYear: number,
  annualGoal: number,
  zakatDue: number
): AnnualCharitySummary {
  let totalGiven = 0;
  let zakatPaid = 0;
  let sadaqahPaid = 0;
  let waqfPaid = 0;
  let zakatFitrPaid = 0;

  contributions.forEach(item => {
    const itemYear = new Date(item.date).getFullYear();
    if (itemYear === targetYear) {
      totalGiven += item.amount;
      if (item.type === 'zakat') {
        zakatPaid += item.amount;
      } else if (item.type === 'sadaqah') {
        sadaqahPaid += item.amount;
      } else if (item.type === 'waqf') {
        waqfPaid += item.amount;
      } else if (item.type === 'zakat_fitr') {
        zakatFitrPaid += item.amount;
      }
    }
  });

  const goalProgressPct = annualGoal > 0
    ? Math.min(100, Math.round((totalGiven / annualGoal) * 100))
    : 0;

  const zakatRemaining = Math.max(0, zakatDue - zakatPaid);
  const zakatProgressPct = zakatDue > 0
    ? Math.min(100, Math.round((zakatPaid / zakatDue) * 100))
    : 100;

  return {
    totalGiven,
    zakatPaid,
    sadaqahPaid,
    waqfPaid,
    zakatFitrPaid,
    goalProgressPct,
    zakatRemaining,
    zakatProgressPct
  };
}

export interface SadaqahJariyahProjectItem {
  id: string;
  title: string;
  targetAmount: number;
  currentAmount: number;
  status: 'in_progress' | 'completed';
}

/**
 * Calculates aggregated project endowment metrics
 */
export function calculateJariyahMetrics(projects: SadaqahJariyahProjectItem[]) {
  let totalTarget = 0;
  let totalFunded = 0;
  let completedCount = 0;
  let inProgressCount = 0;

  projects.forEach(p => {
    totalTarget += p.targetAmount;
    totalFunded += p.currentAmount;
    if (p.status === 'completed' || p.currentAmount >= p.targetAmount) {
      completedCount++;
    } else {
      inProgressCount++;
    }
  });

  const overallPct = totalTarget > 0
    ? Math.min(100, Math.round((totalFunded / totalTarget) * 100))
    : 0;
  const remainingToRaise = Math.max(0, totalTarget - totalFunded);

  return {
    totalTarget,
    totalFunded,
    completedCount,
    inProgressCount,
    overallPct,
    remainingToRaise
  };
}
