import { describe, it, expect } from 'vitest';
import {
  calculateGrossAssets,
  calculateNetZakatableWealth,
  calculateZakat,
  calculateAnnualCharitySummary,
  calculateJariyahMetrics,
  ZakatAssetsInput,
  ContributionItem,
  SadaqahJariyahProjectItem
} from './zakatCalculator';

describe('Zakat Calculator - Wealth & Asset Calculations', () => {
  it('correctly aggregates gross assets across all asset categories', () => {
    const assets: ZakatAssetsInput = {
      cashInHand: 1500,
      cashInBank: 8500,
      goldSilverValue: 4000,
      investments: 6000,
      businessMerchandise: 5000,
      loansOwedToYou: 1000
    };

    const gross = calculateGrossAssets(assets);
    expect(gross).toBe(26000);
  });

  it('handles missing/undefined asset fields gracefully without NaN', () => {
    const assets: ZakatAssetsInput = {
      cashInHand: 500
    };

    const gross = calculateGrossAssets(assets);
    expect(gross).toBe(500);
  });

  it('correctly calculates net zakatable wealth by deducting immediate debts', () => {
    const assets: ZakatAssetsInput = {
      cashInHand: 2000,
      cashInBank: 10000,
      immediateDebts: 3000
    };

    const net = calculateNetZakatableWealth(assets);
    expect(net).toBe(9000);
  });

  it('prevents negative net wealth when debts exceed gross assets', () => {
    const assets: ZakatAssetsInput = {
      cashInHand: 1000,
      immediateDebts: 5000
    };

    const net = calculateNetZakatableWealth(assets);
    expect(net).toBe(0);
  });
});

describe('Zakat Calculator - Nisab & 2.5% Rate Calculations', () => {
  const goldNisab = 6200; // ~85g of Gold
  const silverNisab = 550; // ~595g of Silver

  it('calculates exact 2.5% (1/40th) when wealth reaches Gold Nisab threshold', () => {
    const assets: ZakatAssetsInput = {
      cashInBank: 10000,
      immediateDebts: 0
    };

    const result = calculateZakat(assets, 'gold', goldNisab, silverNisab);
    expect(result.isNisabReached).toBe(true);
    expect(result.currentNisab).toBe(goldNisab);
    expect(result.netZakatableWealth).toBe(10000);
    expect(result.zakatDue).toBe(250); // 10,000 * 0.025 = 250
  });

  it('returns 0 zakat due when net wealth is below Gold Nisab threshold', () => {
    const assets: ZakatAssetsInput = {
      cashInBank: 5000,
      immediateDebts: 0
    };

    const result = calculateZakat(assets, 'gold', goldNisab, silverNisab);
    expect(result.isNisabReached).toBe(false);
    expect(result.zakatDue).toBe(0);
  });

  it('correctly evaluates Silver Nisab standard when selected', () => {
    const assets: ZakatAssetsInput = {
      cashInBank: 2000,
      immediateDebts: 0
    };

    // Below Gold (6200), but Above Silver (550)
    const goldResult = calculateZakat(assets, 'gold', goldNisab, silverNisab);
    const silverResult = calculateZakat(assets, 'silver', goldNisab, silverNisab);

    expect(goldResult.isNisabReached).toBe(false);
    expect(goldResult.zakatDue).toBe(0);

    expect(silverResult.isNisabReached).toBe(true);
    expect(silverResult.currentNisab).toBe(silverNisab);
    expect(silverResult.zakatDue).toBe(50); // 2000 * 0.025 = 50
  });

  it('maintains 2 decimal places precision for non-integer currency amounts', () => {
    const assets: ZakatAssetsInput = {
      cashInBank: 7555.75,
      immediateDebts: 120.50
    };

    const result = calculateZakat(assets, 'gold', goldNisab, silverNisab);
    const expectedNet = 7555.75 - 120.50; // 7435.25
    const expectedZakat = Math.round(expectedNet * 0.025 * 100) / 100; // 185.88

    expect(result.netZakatableWealth).toBe(expectedNet);
    expect(result.zakatDue).toBe(expectedZakat);
    expect(result.zakatDue).toBe(185.88);
  });
});

describe('Zakat Calculator - Annual Charity & Sadaqah Jariyah Metrics', () => {
  it('correctly aggregates annual giving by charity category', () => {
    const targetYear = 2026;
    const contributions: ContributionItem[] = [
      { id: '1', type: 'zakat', amount: 500, cause: 'Orphans', recipient: 'Relief Org', date: '2026-03-15' },
      { id: '2', type: 'sadaqah', amount: 150, cause: 'Food Pantry', recipient: 'Local Masjid', date: '2026-04-10' },
      { id: '3', type: 'waqf', amount: 350, cause: 'Water Well', recipient: 'Clean Water', date: '2026-05-01' },
      { id: '4', type: 'zakat_fitr', amount: 50, cause: 'Fitrana', recipient: 'Community', date: '2026-04-28' },
      // Previous year contribution (should be excluded from 2026 annual total)
      { id: '5', type: 'zakat', amount: 800, cause: 'Past Zakat', recipient: 'Charity', date: '2025-11-20' }
    ];

    const summary = calculateAnnualCharitySummary(contributions, targetYear, 2000, 1000);

    expect(summary.totalGiven).toBe(1050); // 500 + 150 + 350 + 50
    expect(summary.zakatPaid).toBe(500);
    expect(summary.sadaqahPaid).toBe(150);
    expect(summary.waqfPaid).toBe(350);
    expect(summary.zakatFitrPaid).toBe(50);
    expect(summary.zakatRemaining).toBe(500); // 1000 - 500
    expect(summary.zakatProgressPct).toBe(50); // 50%
    expect(summary.goalProgressPct).toBe(53); // Math.round(1050 / 2000 * 100) = 53%
  });

  it('calculates Sadaqah Jariyah endowment completion metrics accurately', () => {
    const projects: SadaqahJariyahProjectItem[] = [
      { id: 'p1', title: 'Solar Water Well', targetAmount: 1800, currentAmount: 1800, status: 'completed' },
      { id: 'p2', title: 'Village Masjid', targetAmount: 3000, currentAmount: 1500, status: 'in_progress' },
      { id: 'p3', title: 'Quran Waqf', targetAmount: 600, currentAmount: 200, status: 'in_progress' }
    ];

    const metrics = calculateJariyahMetrics(projects);

    expect(metrics.totalTarget).toBe(5400); // 1800 + 3000 + 600
    expect(metrics.totalFunded).toBe(3500); // 1800 + 1500 + 200
    expect(metrics.completedCount).toBe(1);
    expect(metrics.inProgressCount).toBe(2);
    expect(metrics.overallPct).toBe(65); // Math.round(3500 / 5400 * 100) = 65%
    expect(metrics.remainingToRaise).toBe(1900); // 5400 - 3500
  });
});
