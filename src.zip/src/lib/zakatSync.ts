import { 
  getPendingSyncQueue, 
  removeSyncQueueItem, 
  queueSyncAction, 
  cacheZakatContributions, 
  getCachedZakatContributions,
  ZakatContributionRecord,
  SyncQueueItem
} from './db';

export type SyncState = 'synced' | 'pending' | 'syncing' | 'offline';

const SYNC_TAG = 'noor-zakat-sync';
const LAST_SYNC_KEY = 'noor_last_zakat_sync_timestamp';

export interface SyncStatusInfo {
  state: SyncState;
  pendingCount: number;
  lastSyncedAt: number | null;
}

let isSyncInProgress = false;
const listeners: Array<(status: SyncStatusInfo) => void> = [];

export function getLastSyncTime(): number | null {
  if (typeof localStorage === 'undefined') return null;
  const saved = localStorage.getItem(LAST_SYNC_KEY);
  return saved ? parseInt(saved, 10) : null;
}

export function subscribeToSyncStatus(listener: (status: SyncStatusInfo) => void): () => void {
  listeners.push(listener);
  // Emit current state immediately
  getSyncStatus().then(listener);
  return () => {
    const idx = listeners.indexOf(listener);
    if (idx !== -1) listeners.splice(idx, 1);
  };
}

async function notifyListeners() {
  const status = await getSyncStatus();
  listeners.forEach(fn => fn(status));
}

export async function getSyncStatus(): Promise<SyncStatusInfo> {
  const isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;
  const pending = await getPendingSyncQueue();
  const lastSyncedAt = getLastSyncTime();

  if (isSyncInProgress) {
    return { state: 'syncing', pendingCount: pending.length, lastSyncedAt };
  }
  if (!isOnline) {
    return { state: 'offline', pendingCount: pending.length, lastSyncedAt };
  }
  if (pending.length > 0) {
    return { state: 'pending', pendingCount: pending.length, lastSyncedAt };
  }
  return { state: 'synced', pendingCount: 0, lastSyncedAt };
}

/**
 * Queues a record to be synced as soon as internet connectivity is available
 */
export async function queueRecordForSync(
  record: ZakatContributionRecord, 
  action: 'insert' | 'update' | 'delete' = 'insert'
) {
  const queueItem: SyncQueueItem = {
    id: `sync_${record.id}_${Date.now()}`,
    action,
    entity: record.type === 'zakat' ? 'zakat' : 'sadaqah',
    payload: {
      ...record,
      syncStatus: 'pending_sync'
    },
    timestamp: Date.now(),
    retryCount: 0
  };

  await queueSyncAction(queueItem);

  // Request background sync from Service Worker if supported
  if (typeof window !== 'undefined' && 'serviceWorker' in navigator && 'SyncManager' in window) {
    try {
      const reg = await navigator.serviceWorker.ready;
      if ('sync' in reg) {
        await (reg as any).sync.register(SYNC_TAG);
      }
    } catch (err) {
      console.warn('[BackgroundSync] Registration error:', err);
    }
  }

  // If online right now, attempt sync
  if (typeof navigator !== 'undefined' && navigator.onLine) {
    await processSyncQueue();
  } else {
    await notifyListeners();
  }
}

/**
 * Processes all pending synchronization items in the queue
 */
export async function processSyncQueue(): Promise<{ success: boolean; syncedCount: number }> {
  if (isSyncInProgress) return { success: true, syncedCount: 0 };
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    await notifyListeners();
    return { success: false, syncedCount: 0 };
  }

  isSyncInProgress = true;
  await notifyListeners();

  try {
    const queue = await getPendingSyncQueue();
    let syncedCount = 0;

    for (const item of queue) {
      try {
        // Mark as synced in local IndexedDB store
        const cached = await getCachedZakatContributions();
        const updated = cached.map(c => {
          if (c.id === item.payload.id) {
            return { ...c, syncStatus: 'synced' as const };
          }
          return c;
        });
        await cacheZakatContributions(updated);

        // Remove from pending queue
        await removeSyncQueueItem(item.id);
        syncedCount++;
      } catch (itemErr) {
        console.warn('[Sync] Failed to process item:', item.id, itemErr);
      }
    }

    const now = Date.now();
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(LAST_SYNC_KEY, now.toString());
    }

    return { success: true, syncedCount };
  } finally {
    isSyncInProgress = false;
    await notifyListeners();
  }
}

/**
 * Initializes automatic background synchronization triggers (online/offline events, interval, Service Worker messages)
 */
export function initBackgroundSync() {
  if (typeof window === 'undefined') return;

  const handleOnline = () => {
    console.log('[BackgroundSync] Connectivity restored. Synchronizing pending Zakat & Sadaqah records...');
    processSyncQueue();
  };

  const handleOffline = () => {
    notifyListeners();
  };

  window.addEventListener('online', handleOnline);
  window.addEventListener('offline', handleOffline);

  // Listen for Service Worker background sync postMessage events
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('message', (event) => {
      if (event.data?.type === 'SYNC_ZAKAT_RECORDS') {
        processSyncQueue();
      }
    });
  }

  // Initial check on load
  if (navigator.onLine) {
    processSyncQueue();
  }

  return () => {
    window.removeEventListener('online', handleOnline);
    window.removeEventListener('offline', handleOffline);
  };
}
