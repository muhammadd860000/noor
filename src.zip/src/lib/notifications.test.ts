import { describe, it, expect, beforeEach, vi } from 'vitest';
import { 
  getPrayerNotificationPreferences, 
  savePrayerNotificationPreferences, 
  toggleSpecificPrayerNotification,
  DEFAULT_PRAYER_NOTIFICATIONS,
  isNotificationSupported,
  getNotificationPermission
} from './notifications';

const mockStorage: Record<string, string> = {};

describe('Prayer Notification Preferences & Individual Toggles', () => {
  beforeEach(() => {
    Object.keys(mockStorage).forEach(k => delete mockStorage[k]);

    if (typeof globalThis.localStorage === 'undefined') {
      (globalThis as any).localStorage = {
        getItem: (key: string) => mockStorage[key] || null,
        setItem: (key: string, val: string) => { mockStorage[key] = val; },
        removeItem: (key: string) => { delete mockStorage[key]; },
        clear: () => { Object.keys(mockStorage).forEach(k => delete mockStorage[k]); }
      };
    } else {
      localStorage.clear();
    }
  });

  it('retrieves default notification preferences with standard 5 daily prayers', () => {
    const prefs = getPrayerNotificationPreferences();
    expect(prefs).toBeDefined();
    expect(prefs.enabledPrayers.Fajr).toBe(true);
    expect(prefs.enabledPrayers.Dhuhr).toBe(true);
    expect(prefs.enabledPrayers.Asr).toBe(true);
    expect(prefs.enabledPrayers.Maghrib).toBe(true);
    expect(prefs.enabledPrayers.Isha).toBe(true);
    expect(prefs.soundEnabled).toBe(true);
    expect(prefs.timing).toBe('both');
  });

  it('saves and updates individual prayer alert toggles in local storage', () => {
    const current = getPrayerNotificationPreferences();
    // Toggle Fajr off and Asr off
    const updated = {
      ...current,
      enabledPrayers: {
        ...current.enabledPrayers,
        Fajr: false,
        Asr: false
      }
    };
    savePrayerNotificationPreferences(updated);

    const reloaded = getPrayerNotificationPreferences();
    expect(reloaded.enabledPrayers.Fajr).toBe(false);
    expect(reloaded.enabledPrayers.Asr).toBe(false);
    expect(reloaded.enabledPrayers.Dhuhr).toBe(true);
    expect(reloaded.enabledPrayers.Maghrib).toBe(true);
    expect(reloaded.enabledPrayers.Isha).toBe(true);
  });

  it('allows toggling specific timing preferences (exact, 10min_before, both)', () => {
    const current = getPrayerNotificationPreferences();
    savePrayerNotificationPreferences({
      ...current,
      timing: '10min_before'
    });

    const reloaded = getPrayerNotificationPreferences();
    expect(reloaded.timing).toBe('10min_before');
  });
});
