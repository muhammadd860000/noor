import { describe, it, expect, beforeEach, vi } from 'vitest';
import { 
  saveReflectionEntry, 
  getReflectionEntry, 
  getAllReflectionEntries, 
  deleteReflectionEntry, 
  ReflectionRecord 
} from '../lib/db';
import * as dbModule from '../lib/db';

const mockStorage: Record<string, string> = {};

describe('IndexedDB Reflection Storage Engine', () => {
  beforeEach(() => {
    Object.keys(mockStorage).forEach(k => delete mockStorage[k]);

    if (typeof globalThis.localStorage === 'undefined') {
      (globalThis as any).localStorage = {
        getItem: (key: string) => mockStorage[key] || null,
        setItem: (key: string, val: string) => { mockStorage[key] = val; },
        removeItem: (key: string) => { delete mockStorage[key]; },
        clear: () => { Object.keys(mockStorage).forEach(k => delete mockStorage[k]); }
      };
    } else {
      localStorage.clear();
    }
  });

  it('saves and retrieves a reflection entry', async () => {
    const sample: ReflectionRecord = {
      id: 'ref_2026_09_30',
      date: '2026-09-30',
      scriptureType: 'quran',
      arabic: 'فَاذْكُرُونِي أَذْكُرْكُمْ',
      translation: 'So remember Me; I will remember you.',
      source: 'Surah Al-Baqarah 2:152',
      theme: 'Remembrance',
      journalText: 'Today I practiced mindfulness during prayer.',
      mood: 'peaceful',
      intention: 'Dhikr after each Salah',
      timestamp: Date.now()
    };

    await saveReflectionEntry(sample);

    const all = await getAllReflectionEntries();
    expect(all.length).toBeGreaterThanOrEqual(1);
    expect(all[0].journalText).toBe('Today I practiced mindfulness during prayer.');

    const single = await getReflectionEntry(sample.id);
    expect(single).toBeDefined();
    expect(single?.source).toBe('Surah Al-Baqarah 2:152');
  });

  it('deletes a reflection entry from storage', async () => {
    const sample: ReflectionRecord = {
      id: 'ref_del_test',
      date: '2026-09-30',
      scriptureType: 'hadith',
      arabic: 'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ',
      translation: 'Actions are judged by intentions.',
      source: 'Sahih al-Bukhari 1',
      journalText: 'Reflecting on purity of intention.',
      timestamp: Date.now()
    };

    await saveReflectionEntry(sample);
    await deleteReflectionEntry(sample.id);

    const all = await getAllReflectionEntries();
    const found = all.find(item => item.id === sample.id);
    expect(found).toBeUndefined();
  });
});
