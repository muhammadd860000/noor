import { describe, it, expect } from 'vitest';
import {
  saveMorningIntention,
  getMorningIntention,
  getReflectionStreak
} from './dailyReflectionTracker';
import { getDailyMorningReflection, morningReflectionsList } from '../data/morningReflections';

class MockStorage {
  private data: Record<string, string> = {};

  getItem(key: string): string | null {
    return this.data[key] ?? null;
  }

  setItem(key: string, value: string) {
    this.data[key] = value;
  }

  removeItem(key: string) {
    delete this.data[key];
  }
}

describe('Daily Morning Reflection & Intention Centering', () => {
  it('provides rich Islamic reflection prompts with thought-provoking questions and intentions', () => {
    expect(morningReflectionsList.length).toBeGreaterThan(0);
    const item = morningReflectionsList[0];
    expect(item.theme).toBeDefined();
    expect(item.wisdom.length).toBeGreaterThan(20);
    expect(item.reflectionQuestion.length).toBeGreaterThan(15);
    expect(item.actionableIntention.length).toBeGreaterThan(10);
    expect(item.source).toBeDefined();
  });

  it('deterministically selects a daily reflection for a given date', () => {
    const date1 = new Date('2026-09-28T07:00:00');
    const reflection = getDailyMorningReflection(date1);
    expect(reflection).toBeDefined();
    expect(reflection.title).toBeDefined();
  });

  it('saves morning user intentions to storage and tracks streak', () => {
    const mockStorage = new MockStorage();
    const today = '2026-09-28';

    expect(getMorningIntention(today, mockStorage)).toBeNull();
    expect(getReflectionStreak(mockStorage)).toBe(0);

    const success = saveMorningIntention(
      today,
      'niyyah-pure-purpose',
      'I intend to work with excellence and treat my colleagues with compassion today.',
      mockStorage
    );

    expect(success).toBe(true);
    const saved = getMorningIntention(today, mockStorage);
    expect(saved).not.toBeNull();
    expect(saved?.intentionText).toBe('I intend to work with excellence and treat my colleagues with compassion today.');
    expect(saved?.isReflected).toBe(true);
    expect(getReflectionStreak(mockStorage)).toBe(1);
  });
});
