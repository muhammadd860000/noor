import { showNotification, getNotificationPermission, requestNotificationPermission } from './notifications';

export interface SunnahContextAlert {
  id: string;
  category: 'heat_dhuhr' | 'rain_dua' | 'predawn_sky' | 'friday_hour' | 'sunset_maghrib';
  title: string;
  arabicDua?: string;
  hadithRef: string;
  message: string;
  sunnahLesson: string;
}

export interface SunnahNotificationPreferences {
  enabled: boolean;
  alertTypes: {
    heat_dhuhr: boolean;
    rain_dua: boolean;
    predawn_sky: boolean;
    friday_hour: boolean;
    sunset_maghrib: boolean;
  };
}

export const DEFAULT_SUNNAH_PREFS: SunnahNotificationPreferences = {
  enabled: true,
  alertTypes: {
    heat_dhuhr: true,
    rain_dua: true,
    predawn_sky: true,
    friday_hour: true,
    sunset_maghrib: true,
  },
};

const STORAGE_KEY = 'noor_sunnah_context_notifications';

export const getSunnahPreferences = (): SunnahNotificationPreferences => {
  if (typeof localStorage === 'undefined') return DEFAULT_SUNNAH_PREFS;
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        enabled: parsed.enabled ?? true,
        alertTypes: { ...DEFAULT_SUNNAH_PREFS.alertTypes, ...(parsed.alertTypes || {}) },
      };
    }
  } catch (err) {
    console.warn('[SunnahScheduler] Error loading preferences:', err);
  }
  return DEFAULT_SUNNAH_PREFS;
};

export const saveSunnahPreferences = (prefs: SunnahNotificationPreferences): void => {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      window.dispatchEvent(new CustomEvent('sunnah-notifications-updated', { detail: prefs }));
    }
  } catch (err) {
    console.warn('[SunnahScheduler] Error saving preferences:', err);
  }
};

/**
 * Fetch context weather (temperature, condition, rain) using free Open-Meteo API
 */
export async function fetchCurrentContext(lat?: number, lon?: number): Promise<{
  temperatureC: number;
  isRaining: boolean;
  weatherDescription: string;
  cityName: string;
}> {
  const defaultLat = lat || 21.4225; // Default Makkah latitude or user location
  const defaultLon = lon || 39.8262;

  try {
    const res = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${defaultLat}&longitude=${defaultLon}&current_weather=true`
    );
    if (res.ok) {
      const data = await res.json();
      const current = data.current_weather;
      const weatherCode = current?.weathercode || 0;
      const temp = current?.temperature || 25;

      // WMO Weather interpretation codes (http://www.nodc.noaa.gov/GTS/docs/wmo306_v1_2011_code4677.pdf)
      const isRaining = [51, 53, 55, 61, 63, 65, 80, 81, 82, 95, 96, 99].includes(weatherCode);

      let weatherDesc = 'Clear Skies';
      if (isRaining) weatherDesc = 'Rainy Conditions';
      else if (weatherCode >= 1 && weatherCode <= 3) weatherDesc = 'Partly Cloudy';
      else if (temp >= 32) weatherDesc = 'Extreme Midday Heat';

      return {
        temperatureC: temp,
        isRaining,
        weatherDescription: weatherDesc,
        cityName: lat ? 'Current Location' : 'Makkah Al-Mukarramah',
      };
    }
  } catch (err) {
    console.warn('[SunnahScheduler] Weather fetch fallback used:', err);
  }

  return {
    temperatureC: 28,
    isRaining: false,
    weatherDescription: 'Warm & Clear',
    cityName: 'Current Location',
  };
}

/**
 * Computes Sunnah Context Alert based on current time, sun position, and weather
 */
export function generateSunnahAlert(
  temperatureC: number,
  isRaining: boolean,
  cityName: string
): SunnahContextAlert {
  const now = new Date();
  const hour = now.getHours();
  const day = now.getDay(); // 5 = Friday

  // Case 1: Rainy Weather -> Sunnah of Rain Dua
  if (isRaining) {
    return {
      id: 'rain_dua',
      category: 'rain_dua',
      title: '🌧️ Sunnah Context: Rain in ' + cityName,
      arabicDua: 'اللَّهُمَّ صَيِّباً نَافِعاً',
      hadithRef: 'Sahih al-Bukhari 1032',
      message: 'Rain is falling in ' + cityName + '. Recite: "Allahumma sayyiban nafi\'an" (O Allah, make it a beneficial rain).',
      sunnahLesson: 'Supplications recited during rainfall are among those answered by Allah.',
    };
  }

  // Case 2: Midday Sun Zenith / Dhuhr Cooling (Ibrad) when hot
  if (hour >= 11 && hour <= 14) {
    const isHot = temperatureC >= 30;
    return {
      id: 'heat_dhuhr',
      category: 'heat_dhuhr',
      title: '☀️ Sunnah Context: Dhuhr Sun Zenith (' + temperatureC + '°C)',
      hadithRef: 'Sahih al-Bukhari 536',
      message: isHot
        ? `Sun is at zenith with intense heat (${temperatureC}°C). Remember the Sunnah of Ibrad: "Cool down the Dhuhr prayer during severe heat."`
        : `Sun has passed the meridian in ${cityName}. Dhuhr time window has begun as the sun tilts westward.`,
      sunnahLesson: 'Observing prayer in alignment with the natural movement of the sun strengthens awareness of the Creator.',
    };
  }

  // Case 3: Friday Afternoon (Sa'at al-Istijabah)
  if (day === 5 && hour >= 15 && hour <= 18) {
    return {
      id: 'friday_hour',
      category: 'friday_hour',
      title: '✨ Sunnah Context: Friday Afternoon Hour of Acceptance',
      arabicDua: 'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ',
      hadithRef: 'Sunan Abi Dawud 1048',
      message: 'Friday afternoon before Maghrib. The Prophet ﷺ noted a special hour on Friday where no Muslim asks Allah for good except that He gives it.',
      sunnahLesson: 'Devote the final hour before sunset on Friday exclusively to Du\'a and Salawat.',
    };
  }

  // Case 4: Pre-dawn / Last Third of Night (3 AM - 5 AM)
  if (hour >= 2 && hour <= 5) {
    return {
      id: 'predawn_sky',
      category: 'predawn_sky',
      title: '🌌 Sunnah Context: Last Third of the Night',
      arabicDua: 'أَسْتَغْفِرُ اللَّهَ العَظِيمَ وَأَتُوبُ إِلَيْهِ',
      hadithRef: 'Sahih al-Bukhari 1145',
      message: 'Quiet pre-dawn sky in ' + cityName + '. Our Lord descends to the lowest heaven asking: "Who calls upon Me that I may answer him?"',
      sunnahLesson: 'The pre-dawn hour (Sahar) is the most intimate time for Istighfar and Tahajjud.',
    };
  }

  // Default: Sunset / Maghrib Sunnah Alert
  return {
    id: 'sunset_maghrib',
    category: 'sunset_maghrib',
    title: '🌅 Sunnah Context: Sunset & Maghrib Transition',
    hadithRef: 'Sahih Muslim 640',
    message: 'The sun is setting in ' + cityName + '. Remember the Sunnah of hastening to pray Maghrib and reciting evening Adhkar.',
    sunnahLesson: 'Transition from day to night with praise, seeking refuge in Allah from dusk\'s darkness.',
  };
}

/**
 * Triggers a live system push notification with context-aware Sunnah alert
 */
export async function triggerLiveSunnahContextAlert(lat?: number, lon?: number): Promise<boolean> {
  const granted = getNotificationPermission() === 'granted' || (await requestNotificationPermission());
  if (!granted) return false;

  const context = await fetchCurrentContext(lat, lon);
  const alert = generateSunnahAlert(context.temperatureC, context.isRaining, context.cityName);

  await showNotification(alert.title, {
    body: `${alert.message}\n\n📖 Sunnah Insight (${alert.hadithRef}): ${alert.sunnahLesson}`,
    tag: `sunnah-context-alert-${Date.now()}`,
    requireInteraction: true,
  });

  return true;
}
