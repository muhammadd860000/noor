export type NotificationPermissionState = 'granted' | 'denied' | 'default' | 'unsupported';

export interface PrayerNotificationPreferences {
  enabledPrayers: Record<string, boolean>;
  timing: 'exact' | '10min_before' | 'both';
  soundEnabled: boolean;
}

export const DEFAULT_PRAYER_NOTIFICATIONS: PrayerNotificationPreferences = {
  enabledPrayers: {
    Fajr: true,
    Sunrise: false,
    Dhuhr: true,
    Asr: true,
    Maghrib: true,
    Isha: true,
  },
  timing: 'both',
  soundEnabled: true,
};

export const isNotificationSupported = (): boolean => {
  return typeof window !== 'undefined' && 'Notification' in window;
};

export const getNotificationPermission = (): NotificationPermissionState => {
  if (!isNotificationSupported()) return 'unsupported';
  return Notification.permission;
};

export const requestNotificationPermission = async (): Promise<boolean> => {
  if (!isNotificationSupported()) return false;
  try {
    const permission = await Notification.requestPermission();
    window.dispatchEvent(new CustomEvent('notification-permission-changed', { detail: { permission } }));
    return permission === 'granted';
  } catch (err) {
    console.warn('[Notifications] Error requesting permission:', err);
    return false;
  }
};

const STORAGE_KEY = 'prayerNotificationPreferences';
const LEGACY_STORAGE_KEY = 'prayerReminders';

export const getPrayerNotificationPreferences = (): PrayerNotificationPreferences => {
  if (typeof localStorage === 'undefined') return DEFAULT_PRAYER_NOTIFICATIONS;

  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        enabledPrayers: { ...DEFAULT_PRAYER_NOTIFICATIONS.enabledPrayers, ...(parsed.enabledPrayers || parsed) },
        timing: parsed.timing || 'both',
        soundEnabled: parsed.soundEnabled ?? true,
      };
    }

    // Check legacy storage
    const legacy = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (legacy) {
      const parsedLegacy = JSON.parse(legacy);
      return {
        enabledPrayers: { ...DEFAULT_PRAYER_NOTIFICATIONS.enabledPrayers, ...parsedLegacy },
        timing: 'both',
        soundEnabled: true,
      };
    }
  } catch (err) {
    console.warn('[Notifications] Failed to parse preferences:', err);
  }

  return DEFAULT_PRAYER_NOTIFICATIONS;
};

export const savePrayerNotificationPreferences = (prefs: PrayerNotificationPreferences): void => {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
    // Keep legacy key synced for backward compatibility
    localStorage.setItem(LEGACY_STORAGE_KEY, JSON.stringify(prefs.enabledPrayers));
    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      window.dispatchEvent(new CustomEvent('prayer-notifications-updated', { detail: prefs }));
    }
  } catch (err) {
    console.warn('[Notifications] Failed to save preferences:', err);
  }
};

export const toggleSpecificPrayerNotification = async (
  prayerName: string
): Promise<{ success: boolean; newState: boolean; permissionGranted: boolean }> => {
  const current = getPrayerNotificationPreferences();
  const willEnable = !current.enabledPrayers[prayerName];

  let permissionGranted = getNotificationPermission() === 'granted';

  if (willEnable && !permissionGranted) {
    permissionGranted = await requestNotificationPermission();
    if (!permissionGranted) {
      return { success: false, newState: false, permissionGranted: false };
    }
  }

  const updated: PrayerNotificationPreferences = {
    ...current,
    enabledPrayers: {
      ...current.enabledPrayers,
      [prayerName]: willEnable,
    },
  };

  savePrayerNotificationPreferences(updated);
  return { success: true, newState: willEnable, permissionGranted };
};

export const playNotificationChime = () => {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    
    // Play a gentle two-tone harmonic notification chime
    const now = ctx.currentTime;
    
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    gain1.gain.setValueAtTime(0.12, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.6);

    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(880, now + 0.15); // A5
    gain2.gain.setValueAtTime(0.12, now + 0.15);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.85);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.15);
    osc2.stop(now + 0.85);
  } catch (err) {
    // Audio context may be restricted before user interaction
  }
};

export const showNotification = async (title: string, options: NotificationOptions = {}) => {
  if (!isNotificationSupported() || Notification.permission !== 'granted') return;

  const defaultOptions: NotificationOptions = {
    icon: '/icon.svg',
    badge: '/icon.svg',
    tag: 'noor-prayer-notification',
    ...options,
  };

  // Play audio chime if sound is enabled
  const prefs = getPrayerNotificationPreferences();
  if (prefs.soundEnabled) {
    playNotificationChime();
  }

  // Use ServiceWorkerRegistration if available for PWA mobile compatibility
  try {
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      const reg = await navigator.serviceWorker.ready;
      if (reg && reg.showNotification) {
        await reg.showNotification(title, defaultOptions);
        return;
      }
    }
  } catch (e) {
    // Fall back to standard Notification constructor
  }

  try {
    const notification = new Notification(title, defaultOptions);
    notification.onclick = () => {
      window.focus();
      if (typeof window !== 'undefined' && window.location.hash !== '#/prayer') {
        window.location.hash = '#/prayer';
      }
      notification.close();
    };
  } catch (err) {
    console.warn('[Notifications] Failed to display notification:', err);
  }
};

export const showPrayerNotification = (
  prayerName: string,
  time: string,
  isAdvanceWarning: boolean = false
) => {
  const prefs = getPrayerNotificationPreferences();
  if (!prefs.enabledPrayers[prayerName]) return;

  if (isAdvanceWarning) {
    showNotification(`⏰ Upcoming Prayer: ${prayerName}`, {
      body: `10 minutes until ${prayerName} prayer (${time}). Prepare for Salah.`,
      tag: `prayer-warning-${prayerName}-${new Date().toDateString()}`,
    });
  } else {
    showNotification(`🕌 Prayer Time: ${prayerName}`, {
      body: `It is now time for ${prayerName} prayer (${time}). حي على الصلاة - حي على الفلاح`,
      tag: `prayer-adhan-${prayerName}-${new Date().toDateString()}`,
      requireInteraction: true,
    });
  }
};

export const sendTestPrayerNotification = async (): Promise<boolean> => {
  const hasPermission = getNotificationPermission() === 'granted' || (await requestNotificationPermission());
  if (!hasPermission) return false;

  showNotification(`🕌 Noor Notification Test`, {
    body: `Prayer push notifications are active! You will be notified for your selected prayer times.`,
    tag: `test-notification-${Date.now()}`,
  });
  return true;
};
