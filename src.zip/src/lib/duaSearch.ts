/**
 * Pure search, indexing, and filtering engine for Islamic Duas & Supplications
 */

import { DuaItem } from '../data/duas';

export interface FilterDuasOptions {
  query?: string;
  category?: string;
  bookmarkedIds?: string[];
}

export interface PopularSearchTag {
  label: string;
  query: string;
  arabic: string;
  iconName?: string;
}

export const POPULAR_DUA_SEARCH_TAGS: PopularSearchTag[] = [
  { label: 'Morning & Evening', query: 'morning', arabic: 'الصباح والمساء' },
  { label: 'Protection & Evil Eye', query: 'protection', arabic: 'الحفظ والوقاية' },
  { label: 'Forgiveness & Repentance', query: 'forgiveness', arabic: 'الاستغفار والتوبة' },
  { label: 'Distress & Anxiety', query: 'distress', arabic: 'الهم والحزن' },
  { label: 'Parents & Family', query: 'parents', arabic: 'الوالدين والأهل' },
  { label: 'Travel & Journey', query: 'travel', arabic: 'السفر والركوب' },
  { label: 'Eating & Food', query: 'food', arabic: 'الطعام والشراب' },
  { label: 'Waking & Sleep', query: 'sleep', arabic: 'النوم والاستيقاظ' }
];

/**
 * Normalizes Arabic string by removing diacritics (harakat/tashkeel) for resilient search matching
 */
export function removeArabicTashkeel(text: string): string {
  if (!text) return '';
  return text.replace(/[\u064B-\u065F\u0670\u06D6-\u06DC\u06DF-\u06E8\u06EA-\u06ED]/g, '');
}

/**
 * Evaluates whether a Dua item matches the query tokens
 */
export function matchDuaQuery(dua: DuaItem, query: string): boolean {
  if (!query || !query.trim()) return true;

  const rawTokens = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (rawTokens.length === 0) return true;

  const titleLower = dua.title.toLowerCase();
  const meaningLower = dua.meaning.toLowerCase();
  const translitLower = dua.transliteration.toLowerCase();
  const refLower = dua.reference.toLowerCase();
  const categoryLower = (dua.categoryName || '').toLowerCase();
  const urdu = dua.urdu || '';
  const arabicPlain = removeArabicTashkeel(dua.arabic || '');
  const benefitLower = (dua.benefit || '').toLowerCase();

  // Check if every token matches at least one field
  return rawTokens.every(token => {
    const plainToken = removeArabicTashkeel(token);
    return (
      titleLower.includes(token) ||
      meaningLower.includes(token) ||
      translitLower.includes(token) ||
      refLower.includes(token) ||
      categoryLower.includes(token) ||
      benefitLower.includes(token) ||
      urdu.includes(token) ||
      dua.arabic.includes(token) ||
      arabicPlain.includes(plainToken)
    );
  });
}

/**
 * Filters a collection of Duas based on search query, category, and bookmarks
 */
export function filterDuas(duas: DuaItem[], options: FilterDuasOptions): DuaItem[] {
  const { query = '', category = 'all', bookmarkedIds = [] } = options;

  return duas.filter(dua => {
    // 1. Category / Bookmarks Filter
    if (category === 'favorites') {
      if (!bookmarkedIds.includes(dua.id)) return false;
    } else if (category && category !== 'all') {
      if (dua.category !== category) return false;
    }

    // 2. Query Search Match
    return matchDuaQuery(dua, query);
  });
}
