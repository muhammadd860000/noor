import { describe, it, expect } from 'vitest';
import { ISLAMIC_AFFIRMATIONS, getDailyAffirmation } from '../data/affirmations';

describe('Islamic Affirmations Engine', () => {
  it('contains valid and authentic Islamic affirmations list', () => {
    expect(ISLAMIC_AFFIRMATIONS.length).toBeGreaterThanOrEqual(10);
    ISLAMIC_AFFIRMATIONS.forEach(item => {
      expect(item.id).toBeDefined();
      expect(item.affirmation.length).toBeGreaterThan(15);
      expect(item.source).toBeDefined();
      expect(item.theme).toBeDefined();
      expect(item.practicalAction).toBeDefined();
    });
  });

  it('determines a valid daily affirmation for any given date', () => {
    const today = getDailyAffirmation(new Date('2026-09-30T12:00:00Z'));
    expect(today).toBeDefined();
    expect(today.id).toBeDefined();
    expect(today.affirmation).toBeDefined();
  });

  it('covers essential spiritual themes like Tawakkul, Peace, Gratitude, and Patience', () => {
    const themes = ISLAMIC_AFFIRMATIONS.map(a => a.theme);
    expect(themes).toContain('Tawakkul & Trust');
    expect(themes).toContain('Patience & Strength');
    expect(themes).toContain('Gratitude & Abundance');
    expect(themes).toContain('Peace & Tranquility');
  });
});
