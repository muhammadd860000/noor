import { describe, it, expect, beforeEach } from 'vitest';
import { 
  recordQuizAttempt, 
  getQuizLeaderboardStats, 
  calculatePoints, 
  getRankForPoints, 
  clearQuizHistory,
  QUIZ_RANKS
} from './quizLeaderboard';

const mockStorage: Record<string, string> = {};

describe('Quiz Leaderboard Engine', () => {
  beforeEach(() => {
    Object.keys(mockStorage).forEach(k => delete mockStorage[k]);

    if (typeof globalThis.localStorage === 'undefined') {
      (globalThis as any).localStorage = {
        getItem: (key: string) => mockStorage[key] || null,
        setItem: (key: string, val: string) => { mockStorage[key] = val; },
        removeItem: (key: string) => { delete mockStorage[key]; },
        clear: () => { Object.keys(mockStorage).forEach(k => delete mockStorage[k]); }
      };
    } else {
      localStorage.clear();
    }
  });

  it('calculates score points and perfect score bonuses accurately', () => {
    // Normal 3 out of 5 in practice
    const pts1 = calculatePoints(3, 5, 'practice');
    expect(pts1).toBe(300);

    // Perfect 5 out of 5 in daily mode (500 + 150 perfect bonus + 50 daily bonus = 700)
    const pts2 = calculatePoints(5, 5, 'daily');
    expect(pts2).toBe(700);
  });

  it('records quiz attempts and compiles cumulative statistics correctly', () => {
    recordQuizAttempt('daily', 'Quran', 5, 5);
    recordQuizAttempt('practice', 'Seerah', 3, 5);

    const stats = getQuizLeaderboardStats();
    expect(stats.totalQuizzesTaken).toBe(2);
    expect(stats.totalQuestionsAnswered).toBe(10);
    expect(stats.totalCorrect).toBe(8);
    expect(stats.overallAccuracyPct).toBe(80);
    expect(stats.perfectScoresCount).toBe(1);
    expect(stats.cumulativeScore).toBeGreaterThan(500);
    expect(stats.history.length).toBe(2);
  });

  it('advances rank titles as cumulative points increase', () => {
    const novice = getRankForPoints(100);
    expect(novice.current.title).toBe('Seeker of Knowledge');

    const diligent = getRankForPoints(600);
    expect(diligent.current.title).toBe('Diligent Student');

    const scholar = getRankForPoints(4000);
    expect(scholar.current.title).toBe('Scholar in Training');

    const grandAlim = getRankForPoints(15000);
    expect(grandAlim.current.title).toBe('Grand Alim');
  });

  it('clears quiz history on request', () => {
    recordQuizAttempt('daily', 'Quran', 5, 5);
    expect(getQuizLeaderboardStats().totalQuizzesTaken).toBe(1);

    clearQuizHistory();
    expect(getQuizLeaderboardStats().totalQuizzesTaken).toBe(0);
    expect(getQuizLeaderboardStats().cumulativeScore).toBe(0);
  });
});
