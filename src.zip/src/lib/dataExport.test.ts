import { describe, it, expect, beforeEach } from 'vitest';
import { collectBackupData, downloadBackupFile, restoreBackupData } from './dataExport';

describe('Local Storage Data Backup & Export Engine', () => {
  let mockStorage: Record<string, string> = {};

  const storageMock = {
    getItem: (key: string) => mockStorage[key] || null,
    setItem: (key: string, val: string) => { mockStorage[key] = val; },
    removeItem: (key: string) => { delete mockStorage[key]; },
    key: (index: number) => Object.keys(mockStorage)[index] || null,
    get length() { return Object.keys(mockStorage).length; }
  };

  beforeEach(() => {
    mockStorage = {};
  });

  it('collects reflection journals, Zakat records, spiritual goals, and prayer logs into structured JSON', () => {
    mockStorage['noor_zakat_assets'] = JSON.stringify({ cash: 5000 });
    mockStorage['noor_charity_contributions'] = JSON.stringify([
      { id: '1', amount: 100, cause: 'Local Orphanage', date: '2026-09-30' }
    ]);
    mockStorage['noor_spiritual_journal_entries'] = JSON.stringify([
      { id: 'j1', date: '2026-09-30', content: 'Felt deep tranquility during Tahajjud prayer.' }
    ]);
    mockStorage['dailyPrayers_Wed Sep 30 2026'] = JSON.stringify({ Fajr: true, Dhuhr: true });
    mockStorage['noor_spiritual_goals_list'] = JSON.stringify([
      { id: 'g1', title: 'Read one page of Quran', category: 'quran' }
    ]);

    const backup = collectBackupData(storageMock);

    expect(backup.version).toBe('2.0.0');
    expect(backup.app).toBe('Noor Islamic Suite');
    expect(backup.zakat.assets).toEqual({ cash: 5000 });
    expect(backup.zakat.contributions.length).toBe(1);
    expect(backup.reflections.journalEntries.length).toBe(1);
    expect(backup.prayer.historyByDate['Wed Sep 30 2026']).toEqual({ Fajr: true, Dhuhr: true });
    expect(backup.goals.spiritualGoalsList.length).toBe(1);
    expect(backup.meta.totalJournalEntries).toBe(1);
    expect(backup.meta.totalCharityEntries).toBe(1);
    expect(backup.meta.totalPrayerDaysTracked).toBe(1);
  });

  it('restores exported JSON backup data back into storage', () => {
    const backupPayload = {
      version: '2.0.0',
      exportDate: '2026-09-30T10:00:00.000Z',
      app: 'Noor Islamic Suite',
      reflections: {
        journalEntries: [{ id: 'j-restored', content: 'Peaceful day' }],
        morningIntentions: {},
        streak: 5
      },
      zakat: {
        assets: { cash: 10000 },
        contributions: [{ id: 'c1', amount: 250 }],
        sadaqahJariyahProjects: [],
        annualGoal: 1000,
        nisabStandard: 'silver'
      },
      prayer: {
        historyByDate: {
          'Wed Sep 30 2026': { Fajr: true, Dhuhr: true, Asr: true, Maghrib: true, Isha: true }
        },
        streak: 7,
        notificationPreferences: null,
        dailyDuaPreferences: null,
        location: null
      },
      goals: {
        spiritualGoalsList: [{ id: 'g1', title: 'Morning Adhkar' }],
        completionsByDate: {}
      },
      quranAndDuas: {
        bookmarkedDuas: ['dua-1'],
        lastReadSurah: null,
        recentRead: []
      },
      tasbeeh: { count: 33, dhikr: 'Alhamdulillah', dailyDhikrCounts: null },
      meta: {
        totalJournalEntries: 1,
        totalCharityEntries: 1,
        totalPrayerDaysTracked: 1,
        totalSpiritualGoals: 1
      }
    };

    const result = restoreBackupData(JSON.stringify(backupPayload), storageMock);
    expect(result.success).toBe(true);
    expect(result.counts.prayers).toBe(1);
    expect(result.counts.journals).toBe(1);
    expect(result.counts.zakatEntries).toBe(1);

    expect(storageMock.getItem('noor_spiritual_journal_entries')).toContain('j-restored');
    expect(storageMock.getItem('dailyPrayers_Wed Sep 30 2026')).toContain('Fajr');
    expect(storageMock.getItem('noor_giving_annual_goal')).toBe('1000');
  });
});
