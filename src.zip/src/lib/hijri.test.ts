import { describe, it, expect, beforeEach } from 'vitest';
import { 
  calculateHijriDate, 
  HIJRI_MONTHS, 
  ISLAMIC_ANNUAL_EVENTS,
  getStoredHijriOffset,
  setStoredHijriOffset
} from './hijri';

const mockStorage: Record<string, string> = {};

describe('Hijri Date Calculation Utility', () => {
  beforeEach(() => {
    Object.keys(mockStorage).forEach(k => delete mockStorage[k]);

    if (typeof globalThis.localStorage === 'undefined') {
      (globalThis as any).localStorage = {
        getItem: (key: string) => mockStorage[key] || null,
        setItem: (key: string, val: string) => { mockStorage[key] = val; },
        removeItem: (key: string) => { delete mockStorage[key]; },
        clear: () => { Object.keys(mockStorage).forEach(k => delete mockStorage[k]); }
      };
    } else {
      localStorage.clear();
    }
  });

  it('calculates a valid Hijri date structure for current date', () => {
    const result = calculateHijriDate(new Date('2026-09-30T12:00:00Z'), 0);
    expect(result.day).toBeGreaterThanOrEqual(1);
    expect(result.day).toBeLessThanOrEqual(30);
    expect(result.month).toBeGreaterThanOrEqual(1);
    expect(result.month).toBeLessThanOrEqual(12);
    expect(result.year).toBeGreaterThanOrEqual(1445);
    expect(result.monthName).toBeDefined();
    expect(result.formattedEn).toContain('AH');
    expect(result.formattedAr).toContain('هـ');
  });

  it('applies positive and negative moon sighting offsets correctly', () => {
    const base = new Date('2026-09-30T12:00:00Z');
    const normal = calculateHijriDate(base, 0);
    const plusOne = calculateHijriDate(base, 1);
    const minusOne = calculateHijriDate(base, -1);

    expect(plusOne.offsetDays).toBe(1);
    expect(minusOne.offsetDays).toBe(-1);
    expect(plusOne.adjustedDate.getDate()).not.toBe(minusOne.adjustedDate.getDate());
  });

  it('identifies sacred months correctly (Muharram, Rajab, Dhu al-Qi\'dah, Dhu al-Hijjah)', () => {
    const muharram = HIJRI_MONTHS.find(m => m.id === 1);
    const safar = HIJRI_MONTHS.find(m => m.id === 2);
    const rajab = HIJRI_MONTHS.find(m => m.id === 7);
    const dhuHijjah = HIJRI_MONTHS.find(m => m.id === 12);

    expect(muharram?.isSacred).toBe(true);
    expect(safar?.isSacred).toBe(false);
    expect(rajab?.isSacred).toBe(true);
    expect(dhuHijjah?.isSacred).toBe(true);
  });

  it('detects White Days (Ayyam al-Beed: 13, 14, 15)', () => {
    const day14Result = { ...calculateHijriDate(new Date(), 0), day: 14 };
    expect(day14Result.day >= 13 && day14Result.day <= 15).toBe(true);
  });

  it('saves and retrieves stored hijri offset in localStorage', () => {
    expect(getStoredHijriOffset()).toBe(0);
    setStoredHijriOffset(1);
    expect(getStoredHijriOffset()).toBe(1);
    setStoredHijriOffset(-1);
    expect(getStoredHijriOffset()).toBe(-1);
  });
});
