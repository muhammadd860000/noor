import { quranFlexManager, SURAH_TRANSLATIONS_AND_KEYWORDS } from './quranFlexIndex';

export interface Surah {
  id: number;
  name: string;
  arabic: string;
  englishNameTranslation?: string;
  revelationType?: 'Meccan' | 'Medinan' | string;
  numberOfAyahs?: number;
}

/**
 * Normalizes Arabic text by removing vowels, tashkeel, and unifying alef/yaa variations
 */
export function normalizeArabic(text: string): string {
  if (!text) return '';
  return text
    // Remove Arabic diacritics / tashkeel
    .replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]/g, '')
    // Normalize Alef variations (أ, إ, آ, ٱ -> ا)
    .replace(/[أإآٱ]/g, 'ا')
    // Normalize Taa Marbuta (ة -> ه)
    .replace(/ة/g, 'ه')
    // Normalize Yaa / Alef Maqsura (ى -> ي)
    .replace(/ى/g, 'ي')
    .trim();
}

/**
 * Normalizes English/transliterated text by stripping hyphens, apostrophes, and spaces
 */
export function normalizeLatin(text: string): string {
  if (!text) return '';
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove accents
    .replace(/[^a-z0-9]/g, '') // Remove hyphens, apostrophes, spaces
    .trim();
}

/**
 * Extracts possible surah number from search query (e.g. "36", "Surah 18", "#114", "s 2")
 */
export function extractSurahNumber(query: string): number | null {
  const trimmed = query.trim();
  
  // Direct integer check (1 to 114)
  const numDirect = parseInt(trimmed, 10);
  if (!isNaN(numDirect) && numDirect >= 1 && numDirect <= 114 && numDirect.toString() === trimmed) {
    return numDirect;
  }

  // Regex for "surah 36", "s36", "s 36", "#36", "surah #36"
  const match = trimmed.match(/^(?:surah|surat|soorah|s|chapter|ch)?\s*#?\s*(\d{1,3})$/i);
  if (match && match[1]) {
    const num = parseInt(match[1], 10);
    if (num >= 1 && num <= 114) {
      return num;
    }
  }

  return null;
}

/**
 * Comprehensive surah search matching by ID, English Name, English Meaning, and FlexSearch full-text index
 */
export function searchSurahs(surahList: Surah[], query: string, metadataMap?: Record<number, any>): Surah[] {
  const cleanQuery = query.trim();
  if (!cleanQuery) return surahList;

  // 1. Check if user typed a specific Surah number
  const directNum = extractSurahNumber(cleanQuery);
  if (directNum !== null) {
    const matched = surahList.filter(s => s.id === directNum);
    if (matched.length > 0) return matched;
  }

  // 2. Query client-side FlexSearch full-text index
  const flexMatchedIds = quranFlexManager.search(cleanQuery);
  const flexMatchedSet = new Set(flexMatchedIds);

  const normQueryLatin = normalizeLatin(cleanQuery);
  const normQueryArabic = normalizeArabic(cleanQuery);

  return surahList.filter((surah) => {
    // Check FlexSearch full-text index hit
    if (flexMatchedSet.has(surah.id)) {
      return true;
    }

    // Number prefix match (e.g. typing "1" shows 1, 10, 11, 100...)
    if (surah.id.toString().includes(cleanQuery)) {
      return true;
    }

    // Name match with transliteration tolerance (e.g. "fatiha" matches "Al-Fatihah", "baqara" matches "Al-Baqarah")
    const normSurahName = normalizeLatin(surah.name);
    if (normQueryLatin && normSurahName.includes(normQueryLatin)) {
      return true;
    }

    // Arabic name match with tashkeel tolerance (e.g. "الكهف" or "كهف")
    const normSurahArabic = normalizeArabic(surah.arabic);
    if (normQueryArabic && normSurahArabic.includes(normQueryArabic)) {
      return true;
    }

    // Check offline translation & keywords map
    const metaKeywords = SURAH_TRANSLATIONS_AND_KEYWORDS[surah.id];
    if (metaKeywords) {
      if (normalizeLatin(metaKeywords.englishTranslation).includes(normQueryLatin)) {
        return true;
      }
      if (metaKeywords.keywords.toLowerCase().includes(cleanQuery.toLowerCase())) {
        return true;
      }
    }

    // Check optional English translation from metadata if available
    if (metadataMap && metadataMap[surah.id]) {
      const meta = metadataMap[surah.id];
      if (meta.englishName && normalizeLatin(meta.englishName).includes(normQueryLatin)) {
        return true;
      }
      if (meta.englishNameTranslation && normalizeLatin(meta.englishNameTranslation).includes(normQueryLatin)) {
        return true;
      }
    }

    return false;
  });
}
