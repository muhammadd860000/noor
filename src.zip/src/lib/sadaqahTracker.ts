export interface SadaqahItem {
  id: string;
  amount: number;
  note: string;
  date: string;
  timestamp: number;
}

export function getSadaqahContributions(): SadaqahItem[] {
  if (typeof localStorage === 'undefined') return [];
  try {
    const raw = localStorage.getItem('noor_charity_contributions');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function addSadaqahDonation(amount: number, note: string = 'Sadaqah Contribution'): SadaqahItem {
  const existing = getSadaqahContributions();
  const newItem: SadaqahItem = {
    id: `sad-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    amount,
    note,
    date: new Date().toISOString().split('T')[0],
    timestamp: Date.now()
  };

  const updated = [newItem, ...existing];
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem('noor_charity_contributions', JSON.stringify(updated));
    window.dispatchEvent(new Event('storage'));
  }
  return newItem;
}
