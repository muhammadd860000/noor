/**
 * Utilities for exporting and restoring user Islamic data, reflection journals,
 * Zakat records, spiritual goals, and prayer logs as a structured JSON backup.
 */

export interface StorageLike {
  getItem(key: string): string | null;
  setItem?(key: string, value: string): void;
  key?(index: number): string | null;
  length?: number;
}

export interface NoorExportData {
  version: string;
  exportDate: string;
  app: string;
  reflections: {
    journalEntries: any[];
    morningIntentions: Record<string, any>;
    streak: number;
  };
  zakat: {
    assets: any;
    contributions: any[];
    sadaqahJariyahProjects: any[];
    annualGoal: number | null;
    nisabStandard: string | null;
  };
  prayer: {
    historyByDate: Record<string, Record<string, boolean>>;
    streak: number;
    notificationPreferences: any;
    dailyDuaPreferences: any;
    location: any;
  };
  goals: {
    spiritualGoalsList: any[];
    completionsByDate: Record<string, Record<string, boolean>>;
  };
  quranAndDuas: {
    bookmarkedDuas: string[];
    lastReadSurah: any;
    recentRead: any[];
  };
  tasbeeh: {
    count: number;
    dhikr: string;
    dailyDhikrCounts: any;
  };
  meta: {
    totalJournalEntries: number;
    totalCharityEntries: number;
    totalPrayerDaysTracked: number;
    totalSpiritualGoals: number;
  };
  rawLocalStorage?: Record<string, string>;
}

/**
 * Collects all relevant user state from localStorage and structures it for export
 */
export function collectBackupData(storage?: StorageLike): NoorExportData {
  const store = storage || (typeof window !== 'undefined' && typeof window.localStorage !== 'undefined' ? window.localStorage : (typeof localStorage !== 'undefined' ? localStorage : null));

  // 1. Reflection Journals & Morning Intentions
  let journalEntries: any[] = [];
  const morningIntentions: Record<string, any> = {};
  let reflectionStreak = 0;

  try {
    if (store) {
      const rawJournal = store.getItem('noor_spiritual_journal_entries');
      if (rawJournal) journalEntries = JSON.parse(rawJournal);

      reflectionStreak = parseInt(store.getItem('dailyReflection_streak') || '0', 10);
    }
  } catch (e) {
    console.warn('[DataExport] Error parsing journal entries:', e);
  }

  // 2. Zakat & Charity Data
  let zakatAssets = null;
  let contributions: any[] = [];
  let sadaqahJariyahProjects: any[] = [];
  let annualGoal: number | null = null;
  let nisabStandard: string | null = null;

  try {
    if (store) {
      const rawAssets = store.getItem('noor_zakat_assets');
      if (rawAssets) zakatAssets = JSON.parse(rawAssets);

      const rawContribs = store.getItem('noor_charity_contributions');
      if (rawContribs) contributions = JSON.parse(rawContribs);

      const rawProjects = store.getItem('noor_sadaqah_jariyah_projects');
      if (rawProjects) sadaqahJariyahProjects = JSON.parse(rawProjects);

      const rawGoal = store.getItem('noor_giving_annual_goal');
      if (rawGoal) annualGoal = parseFloat(rawGoal);

      nisabStandard = store.getItem('noor_nisab_standard');
    }
  } catch (e) {
    console.warn('[DataExport] Error extracting zakat storage data:', e);
  }

  // 3. Prayer Tracking & Notifications Data
  const historyByDate: Record<string, Record<string, boolean>> = {};
  let prayerStreak = 0;
  let notificationPreferences = null;
  let dailyDuaPreferences = null;
  let location = null;

  // 4. Spiritual Goals & Completions
  let spiritualGoalsList: any[] = [];
  const goalCompletionsByDate: Record<string, Record<string, boolean>> = {};

  // 5. Quran, Duas & Tasbeeh
  let bookmarkedDuas: string[] = [];
  let lastReadSurah = null;
  let recentRead: any[] = [];
  let tasbeehCount = 0;
  let tasbeehDhikr = 'SubhanAllah';
  let dailyDhikrCounts = null;

  const rawDump: Record<string, string> = {};

  try {
    if (store && store.length && typeof store.key === 'function') {
      for (let i = 0; i < store.length; i++) {
        const storageKey: string | null = store.key(i);
        if (!storageKey) continue;
        const val = store.getItem(storageKey);
        if (val !== null) rawDump[storageKey] = val;

        // Daily prayer logs
        if (storageKey.startsWith('dailyPrayers_')) {
          const dateStr = storageKey.replace('dailyPrayers_', '');
          try {
            if (val) historyByDate[dateStr] = JSON.parse(val);
          } catch {}
        }

        // Daily reflection intention logs
        if (storageKey.startsWith('dailyReflection_intention_')) {
          const dateStr = storageKey.replace('dailyReflection_intention_', '');
          try {
            if (val) morningIntentions[dateStr] = JSON.parse(val);
          } catch {}
        }

        // Spiritual Goal completions
        if (storageKey.startsWith('noor_spiritual_goals_completions_')) {
          const dateStr = storageKey.replace('noor_spiritual_goals_completions_', '');
          try {
            if (val) goalCompletionsByDate[dateStr] = JSON.parse(val);
          } catch {}
        }
      }
    }

    if (store) {
      prayerStreak = parseInt(store.getItem('streak') || '0', 10);
      
      const rawPrefs = store.getItem('prayerNotificationPreferences');
      if (rawPrefs) notificationPreferences = JSON.parse(rawPrefs);

      const rawDuaPrefs = store.getItem('noor_daily_dua_notification_prefs');
      if (rawDuaPrefs) dailyDuaPreferences = JSON.parse(rawDuaPrefs);

      const rawLoc = store.getItem('prayerLocation');
      if (rawLoc) location = JSON.parse(rawLoc);

      const rawGoals = store.getItem('noor_spiritual_goals_list');
      if (rawGoals) spiritualGoalsList = JSON.parse(rawGoals);

      const rawBookmarks = store.getItem('bookmarkedDuas');
      if (rawBookmarks) bookmarkedDuas = JSON.parse(rawBookmarks);

      const rawLastRead = store.getItem('lastReadSurah');
      if (rawLastRead) lastReadSurah = JSON.parse(rawLastRead);

      const rawRecent = store.getItem('recentRead');
      if (rawRecent) recentRead = JSON.parse(rawRecent);

      tasbeehCount = parseInt(store.getItem('tasbeehCount') || '0', 10);
      tasbeehDhikr = store.getItem('tasbeehDhikr') || 'SubhanAllah';

      const rawDhikr = store.getItem('dailyDhikrCounts');
      if (rawDhikr) dailyDhikrCounts = JSON.parse(rawDhikr);
    }
  } catch (e) {
    console.warn('[DataExport] Error collecting full storage dump:', e);
  }

  return {
    version: '2.0.0',
    exportDate: new Date().toISOString(),
    app: 'Noor Islamic Suite',
    reflections: {
      journalEntries,
      morningIntentions,
      streak: reflectionStreak
    },
    zakat: {
      assets: zakatAssets,
      contributions,
      sadaqahJariyahProjects,
      annualGoal,
      nisabStandard
    },
    prayer: {
      historyByDate,
      streak: prayerStreak,
      notificationPreferences,
      dailyDuaPreferences,
      location
    },
    goals: {
      spiritualGoalsList,
      completionsByDate: goalCompletionsByDate
    },
    quranAndDuas: {
      bookmarkedDuas,
      lastReadSurah,
      recentRead
    },
    tasbeeh: {
      count: tasbeehCount,
      dhikr: tasbeehDhikr,
      dailyDhikrCounts
    },
    meta: {
      totalJournalEntries: journalEntries.length + Object.keys(morningIntentions).length,
      totalCharityEntries: contributions.length,
      totalPrayerDaysTracked: Object.keys(historyByDate).length,
      totalSpiritualGoals: spiritualGoalsList.length
    },
    rawLocalStorage: rawDump
  };
}

/**
 * Triggers a browser download of the exported JSON backup file
 */
export function downloadBackupFile(data: NoorExportData, filename?: string): boolean {
  try {
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const dateStr = new Date().toISOString().slice(0, 10);
    const finalName = filename || `noor-islamic-backup-${dateStr}.json`;

    const link = document.createElement('a');
    link.href = url;
    link.download = finalName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    return true;
  } catch (err) {
    console.error('[DataExport] Failed to trigger backup download:', err);
    return false;
  }
}

/**
 * Restores user data from a previously exported JSON backup
 */
export function restoreBackupData(
  jsonData: string | NoorExportData,
  storage?: StorageLike
): { success: boolean; message: string; counts: { prayers: number; journals: number; zakatEntries: number } } {
  const store = storage || (typeof window !== 'undefined' && typeof window.localStorage !== 'undefined' ? window.localStorage : (typeof localStorage !== 'undefined' ? localStorage : null));
  if (!store || typeof store.setItem !== 'function') {
    return { success: false, message: 'Storage unavailable', counts: { prayers: 0, journals: 0, zakatEntries: 0 } };
  }

  try {
    let parsed: NoorExportData;
    if (typeof jsonData === 'string') {
      parsed = JSON.parse(jsonData);
    } else {
      parsed = jsonData;
    }

    if (!parsed || (!parsed.prayer && !parsed.rawLocalStorage && !parsed.zakat)) {
      return { success: false, message: 'Invalid backup file format', counts: { prayers: 0, journals: 0, zakatEntries: 0 } };
    }

    // 1. If rawLocalStorage exists, restore full dictionary
    if (parsed.rawLocalStorage && typeof parsed.rawLocalStorage === 'object') {
      for (const [k, v] of Object.entries(parsed.rawLocalStorage)) {
        if (typeof v === 'string') {
          store.setItem(k, v);
        }
      }
    }

    // 2. Explicitly restore Structured sections for forwards/backwards compatibility
    if (parsed.reflections?.journalEntries) {
      store.setItem('noor_spiritual_journal_entries', JSON.stringify(parsed.reflections.journalEntries));
    }

    if (parsed.zakat) {
      if (parsed.zakat.assets) store.setItem('noor_zakat_assets', JSON.stringify(parsed.zakat.assets));
      if (parsed.zakat.contributions) store.setItem('noor_charity_contributions', JSON.stringify(parsed.zakat.contributions));
      if (parsed.zakat.sadaqahJariyahProjects) store.setItem('noor_sadaqah_jariyah_projects', JSON.stringify(parsed.zakat.sadaqahJariyahProjects));
      if (parsed.zakat.annualGoal !== null) store.setItem('noor_giving_annual_goal', parsed.zakat.annualGoal.toString());
      if (parsed.zakat.nisabStandard) store.setItem('noor_nisab_standard', parsed.zakat.nisabStandard);
    }

    if (parsed.prayer?.historyByDate) {
      for (const [dateStr, prayers] of Object.entries(parsed.prayer.historyByDate)) {
        store.setItem(`dailyPrayers_${dateStr}`, JSON.stringify(prayers));
      }
    }

    if (parsed.goals?.spiritualGoalsList) {
      store.setItem('noor_spiritual_goals_list', JSON.stringify(parsed.goals.spiritualGoalsList));
    }

    const prayerCount = Object.keys(parsed.prayer?.historyByDate || {}).length;
    const journalCount = (parsed.reflections?.journalEntries || []).length;
    const zakatCount = (parsed.zakat?.contributions || []).length;

    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      window.dispatchEvent(new CustomEvent('prayer-status-changed', { detail: {} }));
      window.dispatchEvent(new CustomEvent('spiritual-goals-updated', { detail: {} }));
    }

    return {
      success: true,
      message: 'Backup restored successfully',
      counts: {
        prayers: prayerCount,
        journals: journalCount,
        zakatEntries: zakatCount
      }
    };
  } catch (err: any) {
    return {
      success: false,
      message: err?.message || 'Failed to parse JSON backup file',
      counts: { prayers: 0, journals: 0, zakatEntries: 0 }
    };
  }
}
