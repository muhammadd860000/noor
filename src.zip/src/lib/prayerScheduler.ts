import { showPrayerNotification, getPrayerNotificationPreferences, getNotificationPermission } from './notifications';
import { checkAndTriggerDailyDua } from './dailyDuaScheduler';

// Cache to prevent duplicate notifications during the same minute or day
export const notifiedMap: Record<string, string> = {};

/**
 * Parses time string (e.g. "05:24", "13:45", "18:30 (EST)") into total minutes from midnight
 */
export function parseTimeToMinutes(timeStr: string): number {
  if (!timeStr) return 0;
  // Strip any timezone or extra labels (e.g. "18:30 (PKT)")
  const cleanTime = timeStr.trim().split(' ')[0];
  const parts = cleanTime.split(':').map(Number);
  if (parts.length < 2 || isNaN(parts[0]) || isNaN(parts[1])) return 0;
  return parts[0] * 60 + parts[1];
}

/**
 * Calculates minute difference between prayer time and current time
 */
export function calculateMinutesDifference(prayerTimeStr: string, currentTotalMinutes: number): number {
  const prayerMinutes = parseTimeToMinutes(prayerTimeStr);
  return prayerMinutes - currentTotalMinutes;
}

/**
 * Evaluates whether prayer warning or exact notification should be dispatched
 */
export function evaluatePrayerNotificationTrigger(options: {
  prayerTimeStr: string;
  currentTotalMinutes: number;
  timingPref: 'exact' | '10min_before' | 'both';
  isPrayerEnabled: boolean;
  hasNotifiedWarningToday: boolean;
  hasNotifiedExactToday: boolean;
}): { triggerWarning: boolean; triggerExact: boolean } {
  const {
    prayerTimeStr,
    currentTotalMinutes,
    timingPref,
    isPrayerEnabled,
    hasNotifiedWarningToday,
    hasNotifiedExactToday
  } = options;

  if (!isPrayerEnabled) {
    return { triggerWarning: false, triggerExact: false };
  }

  const diff = calculateMinutesDifference(prayerTimeStr, currentTotalMinutes);

  const triggerWarning =
    (timingPref === '10min_before' || timingPref === 'both') &&
    diff === 10 &&
    !hasNotifiedWarningToday;

  const triggerExact =
    (timingPref === 'exact' || timingPref === 'both') &&
    diff === 0 &&
    !hasNotifiedExactToday;

  return { triggerWarning, triggerExact };
}

export const startPrayerScheduler = () => {
  let isRunning = false;

  const checkPrayerTimes = async () => {
    if (isRunning) return;
    if (getNotificationPermission() !== 'granted') return;

    isRunning = true;
    try {
      const prefs = getPrayerNotificationPreferences();
      const now = new Date();
      const todayDateStr = now.toDateString();
      const currentHours = now.getHours();
      const currentMinutes = now.getMinutes();
      const currentTotalMinutes = currentHours * 60 + currentMinutes;

      // Try reading cached prayer times first
      let timings: Record<string, string> | null = null;
      try {
        const cached = localStorage.getItem('cachedPrayerTimes');
        if (cached) {
          timings = JSON.parse(cached);
        }
      } catch (e) {
        // ignore
      }

      // If no cached timings, check saved location to fetch
      if (!timings) {
        const savedLocation = localStorage.getItem('prayerLocation');
        if (savedLocation) {
          try {
            const { city, country } = JSON.parse(savedLocation);
            const dateStr = now.toISOString().slice(0, 10);
            const res = await fetch(`https://api.aladhan.com/v1/timingsByCity/${dateStr}?city=${encodeURIComponent(city)}&country=${encodeURIComponent(country)}&method=2`);
            const data = await res.json();
            if (data.code === 200 && data.data?.timings) {
              timings = data.data.timings;
              localStorage.setItem('cachedPrayerTimes', JSON.stringify(timings));
            }
          } catch (e) {
            // ignore network errors
          }
        }
      }

      if (!timings) return;

      const prayerKeys = ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

      for (const prayer of prayerKeys) {
        const isPrayerEnabled = !!prefs.enabledPrayers[prayer];
        const timeStr = timings[prayer];
        if (!timeStr) continue;

        const warningKey = `${todayDateStr}_${prayer}_warning`;
        const exactKey = `${todayDateStr}_${prayer}_exact`;

        const { triggerWarning, triggerExact } = evaluatePrayerNotificationTrigger({
          prayerTimeStr: timeStr,
          currentTotalMinutes,
          timingPref: prefs.timing,
          isPrayerEnabled,
          hasNotifiedWarningToday: notifiedMap[warningKey] === todayDateStr,
          hasNotifiedExactToday: notifiedMap[exactKey] === todayDateStr
        });

        if (triggerWarning) {
          notifiedMap[warningKey] = todayDateStr;
          showPrayerNotification(prayer, timeStr, true);
        }

        if (triggerExact) {
          notifiedMap[exactKey] = todayDateStr;
          showPrayerNotification(prayer, timeStr, false);
        }
      }

      // Check and dispatch scheduled Daily Motivational Dua
      checkAndTriggerDailyDua();
    } catch (err) {
      console.warn('[PrayerScheduler] Error checking prayer schedule:', err);
    } finally {
      isRunning = false;
    }
  };

  // Run on startup
  checkPrayerTimes();

  // Run every 30 seconds to catch exact minute transitions reliably
  const intervalId = setInterval(checkPrayerTimes, 30000);
  return () => clearInterval(intervalId);
};
