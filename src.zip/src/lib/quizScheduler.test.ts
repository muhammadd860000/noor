import { describe, it, expect, beforeEach } from 'vitest';
import { 
  getQuizReminderPreferences, 
  saveQuizReminderPreferences, 
  evaluateQuizReminderTrigger, 
  DEFAULT_QUIZ_REMINDER_PREFERENCES 
} from './quizScheduler';

const mockStorage: Record<string, string> = {};

describe('Daily Islamic Quiz Notification Scheduler', () => {
  beforeEach(() => {
    Object.keys(mockStorage).forEach(k => delete mockStorage[k]);

    if (typeof globalThis.localStorage === 'undefined') {
      (globalThis as any).localStorage = {
        getItem: (key: string) => mockStorage[key] || null,
        setItem: (key: string, val: string) => { mockStorage[key] = val; },
        removeItem: (key: string) => { delete mockStorage[key]; },
        clear: () => { Object.keys(mockStorage).forEach(k => delete mockStorage[k]); }
      };
    } else {
      localStorage.clear();
    }
  });

  it('loads default quiz reminder preferences if none stored', () => {
    const prefs = getQuizReminderPreferences();
    expect(prefs.enabled).toBe(true);
    expect(prefs.time).toBe('20:00');
    expect(prefs.soundEnabled).toBe(true);
  });

  it('saves and reloads custom quiz reminder preferences', () => {
    saveQuizReminderPreferences({
      enabled: true,
      time: '19:30',
      soundEnabled: false
    });

    const prefs = getQuizReminderPreferences();
    expect(prefs.time).toBe('19:30');
    expect(prefs.soundEnabled).toBe(false);
  });

  it('triggers notification only when current time matches target time and not already notified', () => {
    // 20:00 is 1200 minutes from midnight
    const shouldFireExact = evaluateQuizReminderTrigger({
      targetTimeStr: '20:00',
      currentTotalMinutes: 1200,
      isEnabled: true,
      hasNotifiedToday: false
    });
    expect(shouldFireExact).toBe(true);

    const shouldNotFireDifferentTime = evaluateQuizReminderTrigger({
      targetTimeStr: '20:00',
      currentTotalMinutes: 1205,
      isEnabled: true,
      hasNotifiedToday: false
    });
    expect(shouldNotFireDifferentTime).toBe(false);

    const shouldNotFireIfDisabled = evaluateQuizReminderTrigger({
      targetTimeStr: '20:00',
      currentTotalMinutes: 1200,
      isEnabled: false,
      hasNotifiedToday: false
    });
    expect(shouldNotFireIfDisabled).toBe(false);

    const shouldNotFireIfAlreadyNotified = evaluateQuizReminderTrigger({
      targetTimeStr: '20:00',
      currentTotalMinutes: 1200,
      isEnabled: true,
      hasNotifiedToday: true
    });
    expect(shouldNotFireIfAlreadyNotified).toBe(false);
  });
});
