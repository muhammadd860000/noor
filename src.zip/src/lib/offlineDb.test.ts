import { describe, it, expect, beforeEach } from 'vitest';
import {
  QuranBookmarkRecord,
  ZakatContributionRecord
} from './db';

// In-memory mock IndexedDB strategy for Node test environments
class MockIDBStore<T extends { id: string | number }> {
  private items: Map<string | number, T> = new Map();

  async put(item: T): Promise<void> {
    this.items.set(item.id, item);
  }

  async get(id: string | number): Promise<T | undefined> {
    return this.items.get(id);
  }

  async getAll(): Promise<T[]> {
    return Array.from(this.items.values());
  }

  async delete(id: string | number): Promise<void> {
    this.items.delete(id);
  }

  async clear(): Promise<void> {
    this.items.clear();
  }
}

describe('Service Worker & IndexedDB Offline Data Storage Strategy', () => {
  let zakatStore: MockIDBStore<ZakatContributionRecord>;
  let bookmarksStore: MockIDBStore<QuranBookmarkRecord>;

  beforeEach(() => {
    zakatStore = new MockIDBStore<ZakatContributionRecord>();
    bookmarksStore = new MockIDBStore<QuranBookmarkRecord>();
  });

  it('persists and retrieves Zakat history for offline access', async () => {
    const contribution: ZakatContributionRecord = {
      id: 'zakat-test-1',
      type: 'zakat',
      amount: 750,
      currency: '$',
      cause: 'Orphan Sponsorship',
      recipient: 'Global Relief',
      date: '2026-09-28',
      notes: 'Discharged annual obligatory Zakat',
      timestamp: Date.now()
    };

    await zakatStore.put(contribution);

    const retrieved = await zakatStore.get('zakat-test-1');
    expect(retrieved).toBeDefined();
    expect(retrieved?.amount).toBe(750);
    expect(retrieved?.cause).toBe('Orphan Sponsorship');

    const allRecords = await zakatStore.getAll();
    expect(allRecords.length).toBe(1);
  });

  it('persists and retrieves Quran bookmarks for offline reading', async () => {
    const bookmark1: QuranBookmarkRecord = {
      id: 255,
      globalNumber: 255,
      surahId: 2,
      surahName: 'Al-Baqarah',
      ayahNumber: 255,
      text: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ',
      translation: 'Allah - there is no deity except Him, the Ever-Living, the Sustainer of all existence.',
      timestamp: Date.now()
    };

    const bookmark2: QuranBookmarkRecord = {
      id: 286,
      globalNumber: 286,
      surahId: 2,
      surahName: 'Al-Baqarah',
      ayahNumber: 286,
      text: 'لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا',
      translation: 'Allah does not burden a soul beyond that it can bear...',
      timestamp: Date.now()
    };

    await bookmarksStore.put(bookmark1);
    await bookmarksStore.put(bookmark2);

    const allBookmarks = await bookmarksStore.getAll();
    expect(allBookmarks.length).toBe(2);
    expect(allBookmarks.some(b => b.globalNumber === 255)).toBe(true);
    expect(allBookmarks.some(b => b.globalNumber === 286)).toBe(true);

    // Deletion
    await bookmarksStore.delete(255);
    const updated = await bookmarksStore.getAll();
    expect(updated.length).toBe(1);
    expect(updated[0].globalNumber).toBe(286);
  });
});
