export interface HijriMonthMeta {
  id: number;
  name: string;
  arabic: string;
  isSacred: boolean;
  isRamadan?: boolean;
  isHajj?: boolean;
  description: string;
}

export const HIJRI_MONTHS: HijriMonthMeta[] = [
  { id: 1, name: 'Muharram', arabic: 'مُحَرَّم', isSacred: true, description: 'First month of the Islamic year; contains the Day of Ashura (10th Muharram).' },
  { id: 2, name: 'Safar', arabic: 'صَفَر', isSacred: false, description: 'Second month; time for renewed devotion and spiritual growth.' },
  { id: 3, name: 'Rabi\' al-Awwal', arabic: 'رَبِيع الأَوَّل', isSacred: false, description: 'Third month; blessed month commemorating the birth of Prophet Muhammad (ﷺ).' },
  { id: 4, name: 'Rabi\' al-Thani', arabic: 'رَبِيع الآخِر', isSacred: false, description: 'Fourth month; following the spring season of remembrance.' },
  { id: 5, name: 'Jumada al-Ula', arabic: 'جُمَادَى الأُولَى', isSacred: false, description: 'Fifth month of the Hijri lunar calendar.' },
  { id: 6, name: 'Jumada al-Akhirah', arabic: 'جُمَادَى الآخِرَة', isSacred: false, description: 'Sixth month; mid-point of the Islamic calendar year.' },
  { id: 7, name: 'Rajab', arabic: 'رَجَب', isSacred: true, description: 'Sacred month; commemorates Al-Isra\' wal-Mi\'raj (The Night Journey).' },
  { id: 8, name: 'Sha\'ban', arabic: 'شَعْبَان', isSacred: false, description: 'Month of raising deeds to Allah and spiritual preparation for Ramadan.' },
  { id: 9, name: 'Ramadan', arabic: 'رَمَضَان', isSacred: true, isRamadan: true, description: 'The blessed month of fasting, revelation of the Quran, and Laylat al-Qadr.' },
  { id: 10, name: 'Shawwal', arabic: 'شَوَّال', isSacred: false, description: 'Tenth month; begins with Eid al-Fitr and carries the 6 Sunnah fasting days.' },
  { id: 11, name: 'Dhu al-Qi\'dah', arabic: 'ذُو القَعْدَة', isSacred: true, description: 'Sacred month; month of peace and readiness for the Hajj pilgrimage.' },
  { id: 12, name: 'Dhu al-Hijjah', arabic: 'ذُو الحِجَّة', isSacred: true, isHajj: true, description: 'Sacred month of Hajj, the Day of Arafah (9th), and Eid al-Adha (10th).' }
];

export interface IslamicEvent {
  title: string;
  arabicTitle: string;
  day: number;
  month: number;
  description: string;
  type: 'major_eid' | 'fasting_sunnah' | 'historical_night' | 'white_days';
}

export const ISLAMIC_ANNUAL_EVENTS: IslamicEvent[] = [
  { day: 1, month: 1, title: 'Islamic New Year', arabicTitle: 'رأس السنة الهجرية', description: 'First day of the new Hijri lunar calendar year.', type: 'historical_night' },
  { day: 9, month: 1, title: 'Tasu\'a (9th Muharram)', arabicTitle: 'تاسوعاء', description: 'Recommended Sunnah fast preceding Ashura.', type: 'fasting_sunnah' },
  { day: 10, month: 1, title: 'Day of Ashura', arabicTitle: 'يوم عاشوراء', description: 'Commemoration of Prophet Musa (AS) and the liberation of Bani Isra\'il.', type: 'fasting_sunnah' },
  { day: 12, month: 3, title: 'Mawlid an-Nabi (12th Rabi\' al-Awwal)', arabicTitle: 'المولد النبوي الشريف', description: 'Commemoration of the birth of the Prophet Muhammad (ﷺ).', type: 'historical_night' },
  { day: 27, month: 7, title: 'Al-Isra\' wal-Mi\'raj', arabicTitle: 'الإسراء والمعراج', description: 'The miraculous Night Journey and Ascension of the Prophet (ﷺ).', type: 'historical_night' },
  { day: 15, month: 8, title: 'Mid-Sha\'ban (Laylat al-Bara\'ah)', arabicTitle: 'ليلة النصف من شعبان', description: 'Night of forgiveness and preparation for Ramadan.', type: 'historical_night' },
  { day: 1, month: 9, title: 'First Day of Ramadan', arabicTitle: 'أول أيام شهر رمضان المبارك', description: 'Start of the obligatory fasting month of Ramadan.', type: 'major_eid' },
  { day: 27, month: 9, title: 'Laylat al-Qadr (Anticipated)', arabicTitle: 'ليلة القدر المباركة', description: 'The Night of Decree and Power, better than a thousand months.', type: 'historical_night' },
  { day: 1, month: 10, title: 'Eid al-Fitr', arabicTitle: 'عيد الفطر المبارك', description: 'Celebration of the completion of Ramadan fasting.', type: 'major_eid' },
  { day: 8, month: 12, title: 'Day of Tarwiyah (8th Dhu al-Hijjah)', arabicTitle: 'يوم التروية', description: 'Pilgrims travel to Mina for the beginning of Hajj rites.', type: 'historical_night' },
  { day: 9, month: 12, title: 'Day of Arafah', arabicTitle: 'يوم عرفة', description: 'Pinnacle of Hajj; expiates sins of previous and coming year for non-pilgrims.', type: 'fasting_sunnah' },
  { day: 10, month: 12, title: 'Eid al-Adha', arabicTitle: 'عيد الأضحى المبارك', description: 'Festival of Sacrifice honoring Prophet Ibrahim (AS).', type: 'major_eid' }
];

export interface HijriDateResult {
  day: number;
  month: number;
  year: number;
  monthName: string;
  monthArabic: string;
  isSacred: boolean;
  isRamadan: boolean;
  isHajj: boolean;
  isWhiteDay: boolean; // 13th, 14th, 15th
  isFriday: boolean;
  formattedEn: string;
  formattedAr: string;
  upcomingOrCurrentEvent?: IslamicEvent;
  adjustedDate: Date;
  offsetDays: number;
}

export function getStoredHijriOffset(): number {
  if (typeof localStorage === 'undefined') return 0;
  try {
    const val = localStorage.getItem('hijri_date_offset');
    return val ? parseInt(val, 10) : 0;
  } catch {
    return 0;
  }
}

export function setStoredHijriOffset(offset: number) {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem('hijri_date_offset', String(offset));
  } catch (err) {
    console.warn('Failed to save Hijri offset:', err);
  }
}

/**
 * Calculates accurate Hijri Date using Umm al-Qura lunar calendar standard and optional sighting offset
 */
export function calculateHijriDate(baseDate: Date = new Date(), offsetDays: number = getStoredHijriOffset()): HijriDateResult {
  const adjusted = new Date(baseDate);
  if (offsetDays !== 0) {
    adjusted.setDate(adjusted.getDate() + offsetDays);
  }

  let d = 1;
  let m = 1;
  let y = 1448;

  try {
    // Primary calculation via Umm al-Qura standard Intl API
    const formatter = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'numeric',
      year: 'numeric'
    });

    const parts = formatter.formatToParts(adjusted);
    m = parseInt(parts.find(p => p.type === 'month')?.value || '1', 10);
    d = parseInt(parts.find(p => p.type === 'day')?.value || '1', 10);
    y = parseInt(parts.find(p => p.type === 'year')?.value || '1448', 10);
  } catch {
    // Fallback mathematical Julian-to-Hijri algorithm if Intl islamic-umalqura unavailable
    const julian = Math.floor(adjusted.getTime() / 86400000) + 2440587.5;
    const l = Math.floor(julian - 1948440 + 10632);
    const n = Math.floor((l - 1) / 10631);
    const l2 = l - 10631 * n + 354;
    const j = Math.floor((10985 - l2) / 5316) * Math.floor((50 * l2) / 17719) + Math.floor(l2 / 5670) * Math.floor((43 * l2) / 15238);
    const l3 = l2 - Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) - Math.floor(j / 16) * Math.floor((15238 * j) / 43) + 29;
    m = Math.floor((24 * l3) / 709);
    d = l3 - Math.floor((709 * m) / 24);
    y = 30 * n + j - 30;
  }

  // Bound month to 1-12
  const safeMonth = Math.min(Math.max(m, 1), 12);
  const monthMeta = HIJRI_MONTHS.find(item => item.id === safeMonth) || HIJRI_MONTHS[0];

  // Arabic Number formatter
  const toArabicNumerals = (num: number) => {
    return String(num).replace(/[0-9]/g, (digit) => '٠١٢٣٤٥٦٧٨٩'[parseInt(digit, 10)]);
  };

  const isWhiteDay = d >= 13 && d <= 15;
  const isFriday = adjusted.getDay() === 5;

  // Check matching Islamic event
  const currentEvent = ISLAMIC_ANNUAL_EVENTS.find(e => e.month === safeMonth && e.day === d);
  const upcomingEvent = !currentEvent 
    ? ISLAMIC_ANNUAL_EVENTS.find(e => e.month === safeMonth && e.day > d && e.day <= d + 3)
    : undefined;

  const eventResult = currentEvent || upcomingEvent;

  return {
    day: d,
    month: safeMonth,
    year: y,
    monthName: monthMeta.name,
    monthArabic: monthMeta.arabic,
    isSacred: monthMeta.isSacred,
    isRamadan: !!monthMeta.isRamadan,
    isHajj: !!monthMeta.isHajj,
    isWhiteDay,
    isFriday,
    formattedEn: `${d} ${monthMeta.name} ${y} AH`,
    formattedAr: `${toArabicNumerals(d)} ${monthMeta.arabic} ${toArabicNumerals(y)} هـ`,
    upcomingOrCurrentEvent: eventResult,
    adjustedDate: adjusted,
    offsetDays
  };
}
