export interface QuizScoreRecord {
  id: string;
  mode: 'daily' | 'practice';
  category: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  pointsEarned: number;
  timestamp: number;
  dateStr: string;
}

export interface QuizRank {
  title: string;
  arabicTitle: string;
  minPoints: number;
  badgeColor: string;
  description: string;
}

export const QUIZ_RANKS: QuizRank[] = [
  { title: 'Seeker of Knowledge', arabicTitle: 'طالب العلم', minPoints: 0, badgeColor: 'text-slate-400 bg-slate-800 border-slate-700', description: 'Beginning the noble journey of Islamic learning.' },
  { title: 'Diligent Student', arabicTitle: 'مُجْتَهِد', minPoints: 500, badgeColor: 'text-amber-400 bg-amber-950/80 border-amber-800/60', description: 'Consistently reviewing and testing understanding.' },
  { title: 'Knowledge Explorer', arabicTitle: 'باحث المعرفة', minPoints: 1500, badgeColor: 'text-emerald-400 bg-emerald-950/80 border-emerald-800/60', description: 'Gaining breadth across Quran, Hadith, Seerah, and Islamic history.' },
  { title: 'Scholar in Training', arabicTitle: 'متفقه في الدين', minPoints: 3500, badgeColor: 'text-blue-400 bg-blue-950/80 border-blue-800/60', description: 'Deep comprehension of foundational Islamic principles.' },
  { title: 'Master of Seerah & Quran', arabicTitle: 'عالِم متمكن', minPoints: 7000, badgeColor: 'text-purple-400 bg-purple-950/80 border-purple-800/60', description: 'Distinguished Islamic mastery and high precision.' },
  { title: 'Grand Alim', arabicTitle: 'العالم الجليل', minPoints: 12000, badgeColor: 'text-amber-300 bg-amber-500/20 border-amber-500/40', description: 'Exemplary dedication and knowledge across all subjects.' }
];

export interface QuizLeaderboardStats {
  totalQuizzesTaken: number;
  totalQuestionsAnswered: number;
  totalCorrect: number;
  overallAccuracyPct: number;
  cumulativeScore: number;
  highestScore: number;
  perfectScoresCount: number;
  currentStreak: number;
  bestStreak: number;
  currentRank: QuizRank;
  nextRank: QuizRank | null;
  progressToNextRankPct: number;
  history: QuizScoreRecord[];
}

const STORAGE_KEY = 'noor_quiz_leaderboard_history';
const STREAK_KEY = 'noor_quiz_streak_data';

export function getStoredQuizHistory(): QuizScoreRecord[] {
  if (typeof localStorage === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    console.warn('[QuizLeaderboard] Error reading history:', err);
    return [];
  }
}

export function saveStoredQuizHistory(history: QuizScoreRecord[]): void {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  } catch (err) {
    console.warn('[QuizLeaderboard] Error saving history:', err);
  }
}

export function calculatePoints(score: number, totalQuestions: number, mode: 'daily' | 'practice'): number {
  if (totalQuestions <= 0) return 0;
  // 100 base points per correct answer
  const basePoints = score * 100;
  // 50% bonus if 100% correct
  const perfectBonus = score === totalQuestions && totalQuestions > 0 ? 150 : 0;
  // 25% mode bonus for daily challenge
  const modeBonus = mode === 'daily' ? 50 : 0;
  return basePoints + perfectBonus + modeBonus;
}

export function getRankForPoints(points: number): { current: QuizRank; next: QuizRank | null; progressPct: number } {
  let currentRank = QUIZ_RANKS[0];
  let nextRank: QuizRank | null = QUIZ_RANKS[1] || null;

  for (let i = QUIZ_RANKS.length - 1; i >= 0; i--) {
    if (points >= QUIZ_RANKS[i].minPoints) {
      currentRank = QUIZ_RANKS[i];
      nextRank = QUIZ_RANKS[i + 1] || null;
      break;
    }
  }

  let progressPct = 100;
  if (nextRank) {
    const range = nextRank.minPoints - currentRank.minPoints;
    const currentProgress = points - currentRank.minPoints;
    progressPct = Math.min(100, Math.max(0, Math.round((currentProgress / (range || 1)) * 100)));
  }

  return { current: currentRank, next: nextRank, progressPct };
}

export function recordQuizAttempt(
  mode: 'daily' | 'practice',
  category: string,
  score: number,
  totalQuestions: number
): QuizScoreRecord {
  const percentage = totalQuestions > 0 ? Math.round((score / totalQuestions) * 100) : 0;
  const pointsEarned = calculatePoints(score, totalQuestions, mode);
  const now = new Date();
  const dateStr = now.toISOString().split('T')[0];

  const newRecord: QuizScoreRecord = {
    id: `quiz_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    mode,
    category,
    score,
    totalQuestions,
    percentage,
    pointsEarned,
    timestamp: now.getTime(),
    dateStr
  };

  const history = getStoredQuizHistory();
  const updatedHistory = [newRecord, ...history];
  saveStoredQuizHistory(updatedHistory);

  // Update streaks
  updateQuizStreak(dateStr);

  return newRecord;
}

function updateQuizStreak(todayDateStr: string): void {
  if (typeof localStorage === 'undefined') return;
  try {
    const raw = localStorage.getItem(STREAK_KEY);
    const streakData = raw ? JSON.parse(raw) : { currentStreak: 0, bestStreak: 0, lastDate: '' };

    if (streakData.lastDate === todayDateStr) {
      // Already recorded today
      return;
    }

    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    let currentStreak = streakData.currentStreak || 0;
    let bestStreak = streakData.bestStreak || 0;

    if (streakData.lastDate === yesterdayStr) {
      currentStreak += 1;
    } else {
      currentStreak = 1;
    }

    if (currentStreak > bestStreak) {
      bestStreak = currentStreak;
    }

    localStorage.setItem(
      STREAK_KEY,
      JSON.stringify({
        currentStreak,
        bestStreak,
        lastDate: todayDateStr
      })
    );
  } catch (err) {
    console.warn('[QuizLeaderboard] Error updating streak:', err);
  }
}

export function getQuizLeaderboardStats(): QuizLeaderboardStats {
  const history = getStoredQuizHistory();

  let totalQuestionsAnswered = 0;
  let totalCorrect = 0;
  let cumulativeScore = 0;
  let highestScore = 0;
  let perfectScoresCount = 0;

  history.forEach(item => {
    totalQuestionsAnswered += item.totalQuestions;
    totalCorrect += item.score;
    cumulativeScore += item.pointsEarned;
    if (item.score > highestScore) highestScore = item.score;
    if (item.score === item.totalQuestions && item.totalQuestions > 0) {
      perfectScoresCount += 1;
    }
  });

  const overallAccuracyPct = totalQuestionsAnswered > 0 
    ? Math.round((totalCorrect / totalQuestionsAnswered) * 100) 
    : 0;

  let currentStreak = 0;
  let bestStreak = 0;

  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem(STREAK_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        currentStreak = parsed.currentStreak || 0;
        bestStreak = parsed.bestStreak || 0;
      }
    } catch {
      // ignore
    }
  }

  const { current, next, progressPct } = getRankForPoints(cumulativeScore);

  return {
    totalQuizzesTaken: history.length,
    totalQuestionsAnswered,
    totalCorrect,
    overallAccuracyPct,
    cumulativeScore,
    highestScore,
    perfectScoresCount,
    currentStreak,
    bestStreak,
    currentRank: current,
    nextRank: next,
    progressToNextRankPct: progressPct,
    history
  };
}

export function clearQuizHistory(): void {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(STREAK_KEY);
  } catch (err) {
    console.warn('[QuizLeaderboard] Error clearing history:', err);
  }
}
