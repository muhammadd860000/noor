import { getWeeklyPrayerSummary } from './prayerLog';
import { getQuizLeaderboardStats } from './quizLeaderboard';
import { getTotalDhikrCompletedCount } from './dailyDhikrTracker';
import { getStoredGoalProgress } from './spiritualGoals';

export interface SpiritualBadge {
  id: string;
  title: string;
  description: string;
  category: 'Prayer' | 'Quran' | 'Journal' | 'Dhikr' | 'Quiz' | 'Generosity';
  iconName: string;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Diamond';
  progress: number;
  maxProgress: number;
  unlocked: boolean;
  unlockedAt?: string;
  rewardPoints: number;
}

const BADGES_STORAGE_KEY = 'noor_spiritual_badges_v1';

export const BADGES_CATALOG: SpiritualBadge[] = [
  {
    id: 'badge_salah_7d',
    title: 'Salah Devotee',
    description: 'Complete and log 7 days of daily prayers',
    category: 'Prayer',
    iconName: 'ShieldCheck',
    tier: 'Silver',
    progress: 0,
    maxProgress: 7,
    unlocked: false,
    rewardPoints: 100
  },
  {
    id: 'badge_fajr_guardian',
    title: 'Fajr Guardian',
    description: 'Pray Fajr on time for 5 consecutive days',
    category: 'Prayer',
    iconName: 'Sun',
    tier: 'Gold',
    progress: 0,
    maxProgress: 5,
    unlocked: false,
    rewardPoints: 150
  },
  {
    id: 'badge_quran_reciter',
    title: 'Quran Companion',
    description: 'Read or listen to the Quran for 7 sessions',
    category: 'Quran',
    iconName: 'BookOpen',
    tier: 'Silver',
    progress: 0,
    maxProgress: 7,
    unlocked: false,
    rewardPoints: 120
  },
  {
    id: 'badge_journaler',
    title: 'Reflective Soul',
    description: 'Write 3 daily spiritual journal entries',
    category: 'Journal',
    iconName: 'PenTool',
    tier: 'Bronze',
    progress: 0,
    maxProgress: 3,
    unlocked: false,
    rewardPoints: 80
  },
  {
    id: 'badge_dhikr_1000',
    title: 'Master of Dhikr',
    description: 'Recite a total of 1000 Dhikr counts',
    category: 'Dhikr',
    iconName: 'Sparkles',
    tier: 'Gold',
    progress: 0,
    maxProgress: 1000,
    unlocked: false,
    rewardPoints: 200
  },
  {
    id: 'badge_quiz_master',
    title: 'Knowledge Seeker',
    description: 'Complete 5 Daily Islamic Knowledge Quizzes',
    category: 'Quiz',
    iconName: 'Award',
    tier: 'Silver',
    progress: 0,
    maxProgress: 5,
    unlocked: false,
    rewardPoints: 100
  },
  {
    id: 'badge_generosity',
    title: 'Generous Heart',
    description: 'Log a Sadaqah contribution or calculate Zakat',
    category: 'Generosity',
    iconName: 'Heart',
    tier: 'Bronze',
    progress: 0,
    maxProgress: 1,
    unlocked: false,
    rewardPoints: 75
  },
  {
    id: 'badge_consistency_30d',
    title: 'Steadfast Servant',
    description: 'Maintain a 30-day spiritual activity streak in Noor',
    category: 'Prayer',
    iconName: 'Flame',
    tier: 'Diamond',
    progress: 0,
    maxProgress: 30,
    unlocked: false,
    rewardPoints: 500
  }
];

export function getStoredBadges(): SpiritualBadge[] {
  let savedUnlocked: Record<string, { unlockedAt: string }> = {};

  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem(BADGES_STORAGE_KEY);
      if (raw) {
        savedUnlocked = JSON.parse(raw);
      }
    } catch (err) {
      console.warn('[SpiritualBadges] Error loading badges:', err);
    }
  }

  // Calculate live progress for each badge from real user data
  const weeklySummary = getWeeklyPrayerSummary();
  const quizStats = getQuizLeaderboardStats();
  const totalDhikr = getTotalDhikrCompletedCount();

  const totalPrayerDays = weeklySummary.perfectDaysCount || weeklySummary.currentStreak || 0;
  
  // Calculate Fajr count
  let fajrCount = 0;
  weeklySummary.weekDays.forEach(day => {
    if (day.prayers?.fajr || day.prayers?.Fajr) fajrCount++;
  });

  // Calculate journal count from localStorage
  let journalCount = 0;
  if (typeof localStorage !== 'undefined') {
    try {
      const rawReflections = localStorage.getItem('noor_spiritual_journal_entries');
      if (rawReflections) {
        const parsed = JSON.parse(rawReflections);
        if (Array.isArray(parsed)) journalCount = parsed.length;
      }
    } catch {}
  }

  // Calculate Zakat/Sadaqah logged
  let zakatLogged = 0;
  if (typeof localStorage !== 'undefined') {
    try {
      const rawZakat = localStorage.getItem('noor_sadaqah_history');
      if (rawZakat) {
        const parsed = JSON.parse(rawZakat);
        if (Array.isArray(parsed) && parsed.length > 0) zakatLogged = 1;
      }
    } catch {}
  }

  return BADGES_CATALOG.map(badge => {
    let liveProgress = badge.progress;

    switch (badge.id) {
      case 'badge_salah_7d':
        liveProgress = Math.min(badge.maxProgress, totalPrayerDays);
        break;
      case 'badge_fajr_guardian':
        liveProgress = Math.min(badge.maxProgress, fajrCount);
        break;
      case 'badge_quran_reciter':
        liveProgress = Math.min(badge.maxProgress, Math.max(totalPrayerDays, quizStats.totalQuizzesTaken));
        break;
      case 'badge_journaler':
        liveProgress = Math.min(badge.maxProgress, journalCount);
        break;
      case 'badge_dhikr_1000':
        liveProgress = Math.min(badge.maxProgress, totalDhikr);
        break;
      case 'badge_quiz_master':
        liveProgress = Math.min(badge.maxProgress, quizStats.totalQuizzesTaken);
        break;
      case 'badge_generosity':
        liveProgress = Math.min(badge.maxProgress, zakatLogged);
        break;
      case 'badge_consistency_30d':
        liveProgress = Math.min(badge.maxProgress, quizStats.currentStreak || totalPrayerDays);
        break;
    }

    const wasAlreadyUnlocked = !!savedUnlocked[badge.id];
    const isNowUnlocked = wasAlreadyUnlocked || liveProgress >= badge.maxProgress;

    const unlockedAt = savedUnlocked[badge.id]?.unlockedAt || (isNowUnlocked ? new Date().toLocaleDateString() : undefined);

    // Save if auto-unlocked
    if (isNowUnlocked && !wasAlreadyUnlocked && typeof localStorage !== 'undefined') {
      try {
        savedUnlocked[badge.id] = { unlockedAt: unlockedAt! };
        localStorage.setItem(BADGES_STORAGE_KEY, JSON.stringify(savedUnlocked));
      } catch {}
    }

    return {
      ...badge,
      progress: liveProgress,
      unlocked: isNowUnlocked,
      unlockedAt
    };
  });
}
