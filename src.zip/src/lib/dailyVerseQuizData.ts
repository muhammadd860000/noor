export interface VerseQuizItem {
  id: number;
  surahNumber: number;
  surahName: string;
  arabic: string;
  translation: string;
  ayahNumber: number;
  options: string[];
}

export const dailyVerseQuizPool: VerseQuizItem[] = [
  {
    id: 1,
    surahNumber: 1,
    surahName: "Al-Fatihah",
    arabic: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
    translation: "In the name of Allah, the Entirely Merciful, the Especially Merciful.",
    ayahNumber: 1,
    options: ["Al-Fatihah", "Al-Baqarah", "An-Nas", "Al-Ikhlas"]
  },
  {
    id: 2,
    surahNumber: 2,
    surahName: "Al-Baqarah",
    arabic: "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ",
    translation: "Allah - there is no deity except Him, the Ever-Living, the Sustainer of all existence.",
    ayahNumber: 255, // Ayat al-Kursi snippet
    options: ["Ali 'Imran", "Al-Baqarah", "Al-An'am", "Yunus"]
  },
  {
    id: 3,
    surahNumber: 36,
    surahName: "Ya-Sin",
    arabic: "يس وَالْقُرْآنِ الْحَكِيمِ",
    translation: "Ya, Sin. By the wise Quran.",
    ayahNumber: 1,
    options: ["Ta-Ha", "Ya-Sin", "Al-Mulk", "Al-Waqi'ah"]
  },
  {
    id: 4,
    surahNumber: 18,
    surahName: "Al-Kahf",
    arabic: "الْحَمْدُ لِلَّهِ الَّذِي أَنْزَلَ عَلَى عَبْدِهِ الْكِتَابَ",
    translation: "Praise be to Allah, who has sent down upon His Servant the Book and has not made therein any deviance.",
    ayahNumber: 1,
    options: ["Al-Kahf", "Maryam", "Al-Furqan", "Fatir"]
  },
  {
    id: 5,
    surahNumber: 55,
    surahName: "Ar-Rahman",
    arabic: "الرَّحْمَٰنُ عَلَّمَ الْقُرْآنَ",
    translation: "The Most Merciful. Taught the Quran.",
    ayahNumber: 1,
    options: ["Al-Mulk", "Ar-Rahman", "Al-Qamar", "Al-Waqi'ah"]
  },
  {
    id: 6,
    surahNumber: 67,
    surahName: "Al-Mulk",
    arabic: "تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
    translation: "Blessed is He in whose hand is dominion, and He is over all things competent.",
    ayahNumber: 1,
    options: ["Al-Mulk", "Al-Jinn", "Nuh", "Al-Haqqah"]
  },
  {
    id: 7,
    surahNumber: 112,
    surahName: "Al-Ikhlas",
    arabic: "قُلْ هُوَ اللَّهُ أَحَدٌ",
    translation: "Say, 'He is Allah, [who is] One.'",
    ayahNumber: 1,
    options: ["An-Nas", "Al-Falaq", "Al-Ikhlas", "Al-Kafirun"]
  },
  {
    id: 8,
    surahNumber: 114,
    surahName: "An-Nas",
    arabic: "قُلْ أَعُوذُ بِرَبِّ النَّاسِ",
    translation: "Say, 'I seek refuge in the Lord of mankind.'",
    ayahNumber: 1,
    options: ["An-Nas", "Al-Falaq", "Al-Masad", "Al-Nasr"]
  }
];

export function getDailyVerseQuizForDate(date: Date = new Date()): VerseQuizItem {
  const dayOfYear = Math.floor((date.getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / 86400000);
  return dailyVerseQuizPool[Math.abs(dayOfYear) % dailyVerseQuizPool.length];
}
