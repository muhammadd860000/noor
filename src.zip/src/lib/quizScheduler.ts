import { 
  getNotificationPermission, 
  requestNotificationPermission, 
  isNotificationSupported 
} from './notifications';
import { parseTimeToMinutes } from './prayerScheduler';

export interface QuizReminderPreferences {
  enabled: boolean;
  time: string; // "HH:MM" 24h format (e.g. "20:00")
  soundEnabled: boolean;
}

export const DEFAULT_QUIZ_REMINDER_PREFERENCES: QuizReminderPreferences = {
  enabled: true,
  time: '20:00', // Default 8:00 PM evening quiz reminder
  soundEnabled: true
};

const STORAGE_KEY = 'noor_quiz_reminder_prefs';
export const quizNotifiedMap: Record<string, string> = {};

export function getQuizReminderPreferences(): QuizReminderPreferences {
  if (typeof localStorage === 'undefined') return DEFAULT_QUIZ_REMINDER_PREFERENCES;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        enabled: parsed.enabled ?? DEFAULT_QUIZ_REMINDER_PREFERENCES.enabled,
        time: parsed.time || DEFAULT_QUIZ_REMINDER_PREFERENCES.time,
        soundEnabled: parsed.soundEnabled ?? DEFAULT_QUIZ_REMINDER_PREFERENCES.soundEnabled
      };
    }
  } catch (err) {
    console.warn('[QuizScheduler] Error parsing preferences:', err);
  }
  return DEFAULT_QUIZ_REMINDER_PREFERENCES;
}

export function saveQuizReminderPreferences(prefs: QuizReminderPreferences): void {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      window.dispatchEvent(new CustomEvent('quiz-reminder-prefs-updated', { detail: prefs }));
    }
  } catch (err) {
    console.warn('[QuizScheduler] Error saving preferences:', err);
  }
}

/**
 * Checks if the quiz notification should fire based on configured time and current minute
 */
export function evaluateQuizReminderTrigger(options: {
  targetTimeStr: string;
  currentTotalMinutes: number;
  isEnabled: boolean;
  hasNotifiedToday: boolean;
}): boolean {
  const { targetTimeStr, currentTotalMinutes, isEnabled, hasNotifiedToday } = options;
  if (!isEnabled || hasNotifiedToday) return false;

  const targetMinutes = parseTimeToMinutes(targetTimeStr);
  return currentTotalMinutes === targetMinutes;
}

/**
 * Dispatches a native browser notification reminding user to take today's quiz
 */
export function showDailyQuizNotification(soundEnabled: boolean = true): boolean {
  if (!isNotificationSupported()) return false;
  if (getNotificationPermission() !== 'granted') return false;

  try {
    const title = '🧠 Daily Islamic Quiz Time!';
    const body = 'Test your Islamic knowledge, maintain your daily quiz streak, and climb the leaderboard today!';

    const notification = new Notification(title, {
      body,
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      tag: 'noor-daily-quiz-reminder',
      requireInteraction: false
    });

    notification.onclick = () => {
      window.focus();
      if (typeof window !== 'undefined' && window.location) {
        window.location.hash = '#/quiz';
      }
      notification.close();
    };

    if (soundEnabled && typeof window !== 'undefined' && 'AudioContext' in window) {
      try {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5 note
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.35); // A5 note
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.35);
      } catch {
        // audio context optional
      }
    }

    return true;
  } catch (err) {
    console.error('[QuizScheduler] Failed to dispatch quiz notification:', err);
    return false;
  }
}
