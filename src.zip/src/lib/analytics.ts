export const logAnalytics = (event: string, details?: any) => {
  const log = JSON.parse(localStorage.getItem('userAnalytics') || '[]');
  log.push({
    event,
    timestamp: Date.now(),
    details
  });
  localStorage.setItem('userAnalytics', JSON.stringify(log.slice(-100))); // Keep last 100
};
