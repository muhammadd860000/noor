import { showNotification, getNotificationPermission, requestNotificationPermission } from './notifications';
import { parseTimeToMinutes } from './prayerScheduler';

export interface FocusPrayerPreferences {
  enabled: boolean;
  focusThresholdMinutes: number; // e.g., 20 minutes of continuous app usage
  approachingWindowMinutes: number; // e.g., next prayer within 25 minutes
  soundEnabled: boolean;
}

export const DEFAULT_FOCUS_PRAYER_PREFS: FocusPrayerPreferences = {
  enabled: true,
  focusThresholdMinutes: 20,
  approachingWindowMinutes: 25,
  soundEnabled: true,
};

const STORAGE_KEY = 'noor_focus_prayer_preferences';
const SESSION_KEY = 'noor_focus_session_start';

export function getFocusPrayerPreferences(): FocusPrayerPreferences {
  if (typeof localStorage === 'undefined') return DEFAULT_FOCUS_PRAYER_PREFS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...DEFAULT_FOCUS_PRAYER_PREFS,
        ...parsed,
      };
    }
  } catch (err) {
    console.warn('[FocusPrayer] Error loading prefs:', err);
  }
  return DEFAULT_FOCUS_PRAYER_PREFS;
}

export function saveFocusPrayerPreferences(prefs: FocusPrayerPreferences): void {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      window.dispatchEvent(new CustomEvent('focus-prayer-prefs-updated', { detail: prefs }));
    }
  } catch (err) {
    console.warn('[FocusPrayer] Error saving prefs:', err);
  }
}

/**
/ Get current focus duration in minutes for active session
*/
export function getActiveFocusMinutes(): number {
  if (typeof sessionStorage === 'undefined') return 0;
  try {
    let start = sessionStorage.getItem(SESSION_KEY);
    if (!start) {
      const now = Date.now();
      sessionStorage.setItem(SESSION_KEY, now.toString());
      return 0;
    }
    const startTimeMs = parseInt(start, 10);
    const diffMs = Date.now() - startTimeMs;
    return Math.floor(diffMs / (1000 * 60));
  } catch {
    return 0;
  }
}

export function resetFocusSession(): void {
  if (typeof sessionStorage === 'undefined') return;
  try {
    sessionStorage.setItem(SESSION_KEY, Date.now().toString());
    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      window.dispatchEvent(new CustomEvent('focus-session-reset'));
    }
  } catch {}
}

/**
 * Gets next upcoming prayer and remaining minutes
 */
export function getNextUpcomingPrayer(): { name: string; minutesRemaining: number; timeStr: string } {
  const defaultTimings: Record<string, string> = {
    Fajr: '05:15',
    Dhuhr: '12:30',
    Asr: '15:45',
    Maghrib: '18:20',
    Isha: '19:45',
  };

  let timings = defaultTimings;
  if (typeof localStorage !== 'undefined') {
    try {
      const cached = localStorage.getItem('cachedPrayerTimes');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed.Fajr) timings = parsed;
      }
    } catch {}
  }

  const now = new Date();
  const currentTotalMinutes = now.getHours() * 60 + now.getMinutes();

  const prayerNames = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
  
  for (const name of prayerNames) {
    const timeStr = timings[name] || defaultTimings[name];
    const prayerMinutes = parseTimeToMinutes(timeStr);
    const diff = prayerMinutes - currentTotalMinutes;

    if (diff > 0) {
      return { name, minutesRemaining: diff, timeStr };
    }
  }

  // If after Isha, next prayer is tomorrow's Fajr
  const fajrTimeStr = timings['Fajr'] || '05:15';
  const fajrMinutes = parseTimeToMinutes(fajrTimeStr);
  const diffTomorrow = (24 * 60 - currentTotalMinutes) + fajrMinutes;

  return { name: 'Fajr (Tomorrow)', minutesRemaining: diffTomorrow, timeStr: fajrTimeStr };
}

let lastNotificationTime = 0;

/**
 * Checks focus time & next prayer proximity, triggering gentle reminder if condition met
 */
export async function checkAndTriggerIntelligentPrayerReminder(): Promise<{
  triggered: boolean;
  message?: string;
  prayerName?: string;
  focusMinutes?: number;
}> {
  const prefs = getFocusPrayerPreferences();
  if (!prefs.enabled) return { triggered: false };

  const focusMinutes = getActiveFocusMinutes();
  const nextPrayer = getNextUpcomingPrayer();

  // Condition check: focus >= threshold AND next prayer approaching within window
  const isFocusSufficient = focusMinutes >= prefs.focusThresholdMinutes;
  const isPrayerApproaching = nextPrayer.minutesRemaining <= prefs.approachingWindowMinutes && nextPrayer.minutesRemaining > 0;

  if (isFocusSufficient && isPrayerApproaching) {
    // Throttle notifications so it doesn't trigger more than once per 20 minutes
    const nowMs = Date.now();
    if (nowMs - lastNotificationTime < 20 * 60 * 1000) {
      return { triggered: false };
    }

    lastNotificationTime = nowMs;

    const title = `🕊️ Gentle Break for ${nextPrayer.name} Approaching`;
    const message = `You've been focused in the app for ${focusMinutes} minutes. ${nextPrayer.name} is in ${nextPrayer.minutesRemaining} minutes (${nextPrayer.timeStr}). Take a peaceful break to make Wudu and prepare for Salah.`;

    // Dispatch custom in-app event for UI banner
    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      window.dispatchEvent(
        new CustomEvent('intelligent-prayer-break-alert', {
          detail: {
            title,
            message,
            prayerName: nextPrayer.name,
            minutesRemaining: nextPrayer.minutesRemaining,
            focusMinutes,
          },
        })
      );
    }

    // Trigger system push notification if allowed
    const granted = getNotificationPermission() === 'granted' || (await requestNotificationPermission());
    if (granted) {
      await showNotification(title, {
        body: message,
        tag: `intelligent-prayer-break-${Date.now()}`,
        requireInteraction: true,
      });
    }

    return {
      triggered: true,
      message,
      prayerName: nextPrayer.name,
      focusMinutes,
    };
  }

  return { triggered: false };
}

/**
 * Starts continuous background monitoring for active focus sessions
 */
export function initIntelligentPrayerMonitor(): () => void {
  if (typeof window === 'undefined') return () => {};

  // Reset focus session on page load
  getActiveFocusMinutes();

  const intervalId = setInterval(() => {
    checkAndTriggerIntelligentPrayerReminder();
  }, 60 * 1000); // Check every minute

  return () => clearInterval(intervalId);
}
