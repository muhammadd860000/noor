/**
 * Tracker utilities for Daily Dhikr completion, time-of-day suggestions, and local storage counters
 */

export interface StorageLike {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem?(key: string): void;
}

export const DHIKR_STORAGE_KEYS = {
  TOTAL_COMPLETED: 'noor_daily_dhikr_total_completed',
  COMPLETION_HISTORY: 'noor_daily_dhikr_history',
  DHIKR_STREAK: 'noor_daily_dhikr_streak',
  LAST_COMPLETED_DATE: 'noor_daily_dhikr_last_date'
};

function getStorage(customStorage?: StorageLike): StorageLike | null {
  if (customStorage) return customStorage;
  if (typeof window !== 'undefined' && typeof window.localStorage !== 'undefined') return window.localStorage;
  if (typeof localStorage !== 'undefined') return localStorage;
  return null;
}

/**
 * Gets total completed Daily Dhikr sessions counter from localStorage
 */
export function getTotalDhikrCompletedCount(storage?: StorageLike): number {
  try {
    const store = getStorage(storage);
    const raw = store ? store.getItem(DHIKR_STORAGE_KEYS.TOTAL_COMPLETED) : null;
    return raw ? parseInt(raw, 10) : 0;
  } catch {
    return 0;
  }
}

/**
 * Checks if a specific dhikr on a given date is marked as done
 */
export function isDhikrMarkedDone(dateStr: string, dhikrId: string, storage?: StorageLike): boolean {
  try {
    const store = getStorage(storage);
    return store ? store.getItem(`dailyDhikr_done_${dateStr}_${dhikrId}`) === 'true' : false;
  } catch {
    return false;
  }
}

/**
 * Marks a daily dhikr as completed, updating the local storage counter and streaks
 */
export function markDailyDhikrAsDone(
  dateStr: string,
  dhikrId: string,
  targetCount: number = 33,
  storage?: StorageLike
): { totalCompleted: number; streak: number; isDone: boolean } {
  try {
    const store = getStorage(storage);
    const isAlreadyDone = store ? store.getItem(`dailyDhikr_done_${dateStr}_${dhikrId}`) === 'true' : false;

    // 1. Mark this specific dhikr as done for date
    if (store) {
      store.setItem(`dailyDhikr_done_${dateStr}_${dhikrId}`, 'true');
      store.setItem(`dailyDhikr_count_${dateStr}_${dhikrId}`, targetCount.toString());
    }

    // 2. Increment total completed counter if not already done today
    let total = getTotalDhikrCompletedCount(store || undefined);
    if (!isAlreadyDone && store) {
      total += 1;
      store.setItem(DHIKR_STORAGE_KEYS.TOTAL_COMPLETED, total.toString());
    }

    // 3. Update streak
    const lastDate = store ? store.getItem(DHIKR_STORAGE_KEYS.LAST_COMPLETED_DATE) : null;
    let streak = parseInt((store && store.getItem(DHIKR_STORAGE_KEYS.DHIKR_STREAK)) || '0', 10);

    if (store && lastDate !== dateStr) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];

      if (lastDate === yesterdayStr) {
        streak += 1;
      } else {
        streak = 1;
      }

      store.setItem(DHIKR_STORAGE_KEYS.DHIKR_STREAK, streak.toString());
      store.setItem(DHIKR_STORAGE_KEYS.LAST_COMPLETED_DATE, dateStr);
    }

    return { totalCompleted: total, streak: streak || 1, isDone: true };
  } catch (err) {
    console.warn('Failed to persist daily dhikr done state:', err);
    return { totalCompleted: 1, streak: 1, isDone: true };
  }
}

/**
 * Toggles or unmarks done state if user desires to reset
 */
export function unmarkDailyDhikrDone(dateStr: string, dhikrId: string, storage?: StorageLike): void {
  try {
    const store = getStorage(storage);
    if (store) {
      if (typeof store.removeItem === 'function') {
        store.removeItem(`dailyDhikr_done_${dateStr}_${dhikrId}`);
      } else {
        store.setItem(`dailyDhikr_done_${dateStr}_${dhikrId}`, 'false');
      }
      store.setItem(`dailyDhikr_count_${dateStr}_${dhikrId}`, '0');
    }
  } catch (err) {
    console.warn('Failed to unmark daily dhikr:', err);
  }
}
