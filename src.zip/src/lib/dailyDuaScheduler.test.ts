import { describe, it, expect, beforeEach } from 'vitest';
import {
  getDailyDuaPreferences,
  saveDailyDuaPreferences,
  getMotivationalDuaForDate,
  evaluateDailyDuaNotificationTrigger,
  DEFAULT_DAILY_DUA_PREFERENCES,
  DailyDuaPreferences
} from './dailyDuaScheduler';

const mockStorage: Record<string, string> = {};

describe('Daily Motivational Dua Notification Scheduler', () => {
  beforeEach(() => {
    Object.keys(mockStorage).forEach(k => delete mockStorage[k]);

    if (typeof globalThis.localStorage === 'undefined') {
      (globalThis as any).localStorage = {
        getItem: (key: string) => mockStorage[key] || null,
        setItem: (key: string, val: string) => { mockStorage[key] = val; },
        removeItem: (key: string) => { delete mockStorage[key]; },
        clear: () => { Object.keys(mockStorage).forEach(k => delete mockStorage[k]); }
      };
    } else {
      localStorage.clear();
    }
  });

  it('loads default daily Dua preferences correctly', () => {
    const prefs = getDailyDuaPreferences();
    expect(prefs).toBeDefined();
    expect(prefs.enabled).toBe(true);
    expect(prefs.time).toBe('09:00');
    expect(prefs.category).toBe('all');
    expect(prefs.soundEnabled).toBe(true);
  });

  it('persists and retrieves updated user-specified notification time and category', () => {
    const customPrefs: DailyDuaPreferences = {
      enabled: true,
      time: '14:30',
      category: 'distress-relief',
      soundEnabled: false
    };
    saveDailyDuaPreferences(customPrefs);

    const loaded = getDailyDuaPreferences();
    expect(loaded.time).toBe('14:30');
    expect(loaded.category).toBe('distress-relief');
    expect(loaded.soundEnabled).toBe(false);
  });

  it('retrieves a valid motivational Dua for any date', () => {
    const testDate = new Date('2026-09-30T10:00:00Z');
    const dua = getMotivationalDuaForDate(testDate, 'all');
    expect(dua).toBeDefined();
    expect(dua.id).toBeDefined();
    expect(dua.title).toBeDefined();
    expect(dua.arabic).toBeDefined();
    expect(dua.meaning).toBeDefined();
  });

  it('filters motivational Duas by chosen category', () => {
    const testDate = new Date('2026-09-30T10:00:00Z');
    const dua = getMotivationalDuaForDate(testDate, 'protection');
    expect(dua).toBeDefined();
    expect(dua.category).toBe('protection');
  });

  it('correctly evaluates when notification trigger condition matches user time', () => {
    // 09:00 = 9 * 60 = 540 minutes
    const targetTimeStr = '09:00';
    const currentTotalMinutes = 540;

    // Matching time, enabled, not notified today -> should trigger
    const shouldTrigger = evaluateDailyDuaNotificationTrigger({
      targetTimeStr,
      currentTotalMinutes,
      isEnabled: true,
      hasNotifiedToday: false
    });
    expect(shouldTrigger).toBe(true);

    // Mismatched time (541 min) -> should NOT trigger
    const mismatchedTime = evaluateDailyDuaNotificationTrigger({
      targetTimeStr,
      currentTotalMinutes: 541,
      isEnabled: true,
      hasNotifiedToday: false
    });
    expect(mismatchedTime).toBe(false);

    // Already notified today -> should NOT trigger duplicate
    const alreadyNotified = evaluateDailyDuaNotificationTrigger({
      targetTimeStr,
      currentTotalMinutes: 540,
      isEnabled: true,
      hasNotifiedToday: true
    });
    expect(alreadyNotified).toBe(false);

    // Disabled in settings -> should NOT trigger
    const disabled = evaluateDailyDuaNotificationTrigger({
      targetTimeStr,
      currentTotalMinutes: 540,
      isEnabled: false,
      hasNotifiedToday: false
    });
    expect(disabled).toBe(false);
  });
});
