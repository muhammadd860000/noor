import { describe, it, expect } from 'vitest';
import { filterDuas, matchDuaQuery, removeArabicTashkeel } from './duaSearch';
import { DuaItem } from '../data/duas';

const mockDuas: DuaItem[] = [
  {
    id: 'dua-1',
    title: 'Upon Waking Up',
    category: 'daily-routine',
    categoryName: 'Waking & Sleeping',
    arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا',
    transliteration: 'Alhamdu lillahilladhi ahyana',
    meaning: 'All praise is for Allah who gave us life',
    urdu: 'تمام تعریفیں اللہ کے لیے ہیں',
    reference: 'Sahih al-Bukhari 6312'
  },
  {
    id: 'dua-2',
    title: 'Supplication for Traveling',
    category: 'travel',
    categoryName: 'Traveling & Journey',
    arabic: 'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَٰذَا',
    transliteration: 'Subhana alladhi sakhkhara lana hadha',
    meaning: 'Glory be to Him who subjected this to us',
    urdu: 'پاک ہے وہ ذات جس نے ہمارے لیے اس کو تابع کیا',
    reference: 'Sahih Muslim 1342'
  },
  {
    id: 'dua-3',
    title: 'For Protection Against Harm',
    category: 'protection',
    categoryName: 'Protection & Safety',
    arabic: 'بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ',
    transliteration: 'Bismillahilladhi la yadurru ma\'asmihi shay\'un',
    meaning: 'In the name of Allah with whose Name nothing can cause harm',
    urdu: 'اللہ کے نام سے جس کے نام کی برکت سے کوئی چیز نقصان نہیں پہنچا سکتی',
    reference: 'Sunan Abi Dawud 5088'
  }
];

describe('Dua Search Engine - Keyword & Multi-field Matching', () => {
  it('matches duas by English title or meaning keywords', () => {
    const results = filterDuas(mockDuas, { query: 'waking' });
    expect(results.length).toBe(1);
    expect(results[0].id).toBe('dua-1');

    const praiseResults = filterDuas(mockDuas, { query: 'praise' });
    expect(praiseResults.length).toBe(1);
    expect(praiseResults[0].id).toBe('dua-1');
  });

  it('matches duas by Transliteration or Reference citation', () => {
    const translitResults = filterDuas(mockDuas, { query: 'sakhkhara' });
    expect(translitResults.length).toBe(1);
    expect(translitResults[0].id).toBe('dua-2');

    const refResults = filterDuas(mockDuas, { query: 'Bukhari 6312' });
    expect(refResults.length).toBe(1);
    expect(refResults[0].id).toBe('dua-1');
  });

  it('matches duas by Arabic query with or without diacritics / tashkeel', () => {
    // Plain Arabic search without tashkeel
    const arabicPlainResults = filterDuas(mockDuas, { query: 'سبحان' });
    expect(arabicPlainResults.length).toBe(1);
    expect(arabicPlainResults[0].id).toBe('dua-2');
  });

  it('matches duas by Urdu translation keywords', () => {
    const urduResults = filterDuas(mockDuas, { query: 'تعریفیں' });
    expect(urduResults.length).toBe(1);
    expect(urduResults[0].id).toBe('dua-1');
  });

  it('correctly filters by category and search keyword simultaneously', () => {
    // Search "Traveling" inside "travel" category -> returns travel dua
    const travelResults = filterDuas(mockDuas, { query: 'Traveling', category: 'travel' });
    expect(travelResults.length).toBe(1);
    expect(travelResults[0].id).toBe('dua-2');

    // Search "Harm" inside "daily-routine" category -> returns empty
    const emptyResults = filterDuas(mockDuas, { query: 'Harm', category: 'daily-routine' });
    expect(emptyResults.length).toBe(0);
  });

  it('filters by bookmarked favorites correctly', () => {
    const favorites = filterDuas(mockDuas, {
      category: 'favorites',
      bookmarkedIds: ['dua-3']
    });

    expect(favorites.length).toBe(1);
    expect(favorites[0].id).toBe('dua-3');
  });
});
