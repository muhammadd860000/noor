/**
 * Utility functions for saving morning intentions, reflections, and streaks
 */

export interface StorageLike {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem?(key: string): void;
}

export interface MorningIntentionRecord {
  dateStr: string;
  reflectionId: string;
  intentionText: string;
  isReflected: boolean;
  timestamp: string;
}

function getStore(customStorage?: StorageLike): StorageLike | null {
  if (customStorage) return customStorage;
  if (typeof window !== 'undefined' && typeof window.localStorage !== 'undefined') return window.localStorage;
  if (typeof localStorage !== 'undefined') return localStorage;
  return null;
}

export function saveMorningIntention(
  dateStr: string,
  reflectionId: string,
  intentionText: string,
  storage?: StorageLike
): boolean {
  try {
    const store = getStore(storage);
    if (!store) return false;

    const record: MorningIntentionRecord = {
      dateStr,
      reflectionId,
      intentionText: intentionText.trim(),
      isReflected: true,
      timestamp: new Date().toISOString()
    };

    store.setItem(`dailyReflection_intention_${dateStr}`, JSON.stringify(record));
    store.setItem(`dailyReflection_done_${dateStr}`, 'true');

    // Update reflection streak
    const lastDate = store.getItem('dailyReflection_last_date');
    let streak = parseInt(store.getItem('dailyReflection_streak') || '0', 10);

    if (lastDate !== dateStr) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];

      if (lastDate === yesterdayStr) {
        streak += 1;
      } else {
        streak = 1;
      }

      store.setItem('dailyReflection_streak', streak.toString());
      store.setItem('dailyReflection_last_date', dateStr);
    }

    return true;
  } catch (err) {
    console.warn('Failed to save morning intention:', err);
    return false;
  }
}

export function getMorningIntention(
  dateStr: string,
  storage?: StorageLike
): MorningIntentionRecord | null {
  try {
    const store = getStore(storage);
    if (!store) return null;

    const raw = store.getItem(`dailyReflection_intention_${dateStr}`);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function getReflectionStreak(storage?: StorageLike): number {
  try {
    const store = getStore(storage);
    if (!store) return 0;
    return parseInt(store.getItem('dailyReflection_streak') || '0', 10);
  } catch {
    return 0;
  }
}
