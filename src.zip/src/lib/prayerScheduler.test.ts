import { describe, it, expect } from 'vitest';
import {
  parseTimeToMinutes,
  calculateMinutesDifference,
  evaluatePrayerNotificationTrigger
} from './prayerScheduler';

describe('Prayer Scheduler - Time Parsing & Mathematical Conversions', () => {
  it('converts standard HH:MM time strings into total minutes from midnight', () => {
    expect(parseTimeToMinutes('05:00')).toBe(300); // 5 * 60
    expect(parseTimeToMinutes('05:30')).toBe(330); // 5 * 60 + 30
    expect(parseTimeToMinutes('12:15')).toBe(735); // 12 * 60 + 15
    expect(parseTimeToMinutes('20:45')).toBe(1245); // 20 * 60 + 45
    expect(parseTimeToMinutes('00:00')).toBe(0);
  });

  it('handles time strings with extra timezone descriptions or whitespace', () => {
    expect(parseTimeToMinutes('18:22 (PKT)')).toBe(1102); // 18 * 60 + 22
    expect(parseTimeToMinutes(' 04:45 ')).toBe(285);
  });

  it('returns 0 for empty or invalid time strings without throwing exceptions', () => {
    expect(parseTimeToMinutes('')).toBe(0);
    expect(parseTimeToMinutes('invalid')).toBe(0);
  });

  it('accurately computes minute difference between scheduled prayer time and current time', () => {
    const currentMinutes = 12 * 60 + 5; // 12:05 (725 min)
    const dhuhrTime = '12:15'; // 735 min

    expect(calculateMinutesDifference(dhuhrTime, currentMinutes)).toBe(10);
    expect(calculateMinutesDifference('12:05', currentMinutes)).toBe(0);
    expect(calculateMinutesDifference('12:00', currentMinutes)).toBe(-5);
  });
});

describe('Prayer Scheduler - Notification Trigger Logic & Deduplication', () => {
  it('triggers exact adhan notification when timingPref is "exact" or "both" and difference is 0', () => {
    const currentTotalMinutes = 735; // 12:15 PM
    const prayerTimeStr = '12:15';

    // With timing = 'exact'
    const resultExact = evaluatePrayerNotificationTrigger({
      prayerTimeStr,
      currentTotalMinutes,
      timingPref: 'exact',
      isPrayerEnabled: true,
      hasNotifiedWarningToday: false,
      hasNotifiedExactToday: false
    });

    expect(resultExact.triggerExact).toBe(true);
    expect(resultExact.triggerWarning).toBe(false);

    // With timing = 'both'
    const resultBoth = evaluatePrayerNotificationTrigger({
      prayerTimeStr,
      currentTotalMinutes,
      timingPref: 'both',
      isPrayerEnabled: true,
      hasNotifiedWarningToday: false,
      hasNotifiedExactToday: false
    });

    expect(resultBoth.triggerExact).toBe(true);
    expect(resultBoth.triggerWarning).toBe(false);
  });

  it('triggers 10-minute warning when timingPref is "10min_before" or "both" and difference is 10', () => {
    const currentTotalMinutes = 725; // 12:05 PM (10 mins before 12:15)
    const prayerTimeStr = '12:15';

    const resultWarning = evaluatePrayerNotificationTrigger({
      prayerTimeStr,
      currentTotalMinutes,
      timingPref: '10min_before',
      isPrayerEnabled: true,
      hasNotifiedWarningToday: false,
      hasNotifiedExactToday: false
    });

    expect(resultWarning.triggerWarning).toBe(true);
    expect(resultWarning.triggerExact).toBe(false);
  });

  it('does NOT trigger notification if the specific prayer is disabled by user preference', () => {
    const currentTotalMinutes = 735;
    const prayerTimeStr = '12:15';

    const result = evaluatePrayerNotificationTrigger({
      prayerTimeStr,
      currentTotalMinutes,
      timingPref: 'both',
      isPrayerEnabled: false, // Prayer disabled
      hasNotifiedWarningToday: false,
      hasNotifiedExactToday: false
    });

    expect(result.triggerExact).toBe(false);
    expect(result.triggerWarning).toBe(false);
  });

  it('prevents duplicate notification when already notified today (anti-spam)', () => {
    const currentTotalMinutes = 735;
    const prayerTimeStr = '12:15';

    const result = evaluatePrayerNotificationTrigger({
      prayerTimeStr,
      currentTotalMinutes,
      timingPref: 'both',
      isPrayerEnabled: true,
      hasNotifiedWarningToday: true,
      hasNotifiedExactToday: true // Already triggered today
    });

    expect(result.triggerExact).toBe(false);
    expect(result.triggerWarning).toBe(false);
  });
});
