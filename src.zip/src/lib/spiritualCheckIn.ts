import { saveToDB, getAllFromDB } from './db';

export interface SpiritualCheckInRecord {
  id: string; // e.g. 'spiritual_2026-09-30'
  date: string; // 'YYYY-MM-DD'
  rating: number; // 1-5 (1: Low, 2: Moderate, 3: Good, 4: High, 5: Radiant)
  label: string; // 'Seeking Peace' | 'Moderate' | 'Grounded' | 'Strong' | 'Radiant'
  note?: string;
  timestamp: number;
}

export const RATING_LABELS: Record<number, { label: string; emoji: string; color: string }> = {
  1: { label: 'Seeking Peace', emoji: '🌧️', color: 'text-blue-400 bg-blue-500/10 border-blue-500/30' },
  2: { label: 'Moderate', emoji: '⛅', color: 'text-amber-400 bg-amber-500/10 border-amber-500/30' },
  3: { label: 'Grounded', emoji: '🌱', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' },
  4: { label: 'Strong', emoji: '✨', color: 'text-teal-400 bg-teal-500/10 border-teal-500/30' },
  5: { label: 'Radiant', emoji: '🌟', color: 'text-amber-300 bg-amber-500/20 border-amber-400/50' }
};

export async function saveSpiritualCheckIn(rating: number, note: string = ''): Promise<SpiritualCheckInRecord> {
  const todayStr = new Date().toISOString().split('T')[0];
  const record: SpiritualCheckInRecord = {
    id: `spiritual_${todayStr}`,
    date: todayStr,
    rating,
    label: RATING_LABELS[rating]?.label || 'Grounded',
    note,
    timestamp: Date.now()
  };

  // 1. Save to LocalStorage for instant UI access
  try {
    const raw = localStorage.getItem('noor_spiritual_checkins');
    const existing: SpiritualCheckInRecord[] = raw ? JSON.parse(raw) : [];
    const filtered = existing.filter(r => r.date !== todayStr);
    const updated = [record, ...filtered];
    localStorage.setItem('noor_spiritual_checkins', JSON.stringify(updated));
  } catch (err) {
    console.warn('[SpiritualCheckIn] LocalStorage save error:', err);
  }

  // 2. Persist to IndexedDB
  try {
    await saveToDB('reflections', {
      ...record,
      scriptureType: 'quran',
      arabic: `Level ${rating}/5`,
      translation: record.label,
      source: 'Daily Spiritual Check-in',
      journalText: note,
    });
  } catch (err) {
    console.warn('[SpiritualCheckIn] IndexedDB save error:', err);
  }

  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('spiritual-checkin-updated', { detail: record }));
  }

  return record;
}

export function getSpiritualCheckInsFromStorage(): SpiritualCheckInRecord[] {
  if (typeof localStorage === 'undefined') return [];
  try {
    const raw = localStorage.getItem('noor_spiritual_checkins');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function getTodaySpiritualCheckIn(): SpiritualCheckInRecord | null {
  const todayStr = new Date().toISOString().split('T')[0];
  const list = getSpiritualCheckInsFromStorage();
  return list.find(r => r.date === todayStr) || null;
}
