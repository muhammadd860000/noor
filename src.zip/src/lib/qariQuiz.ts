export interface QariQuestion {
  id: string;
  type: 'qari_identification' | 'surah_identification' | 'recitation_style';
  audioUrl: string;
  qariName: string;
  surahName: string;
  surahNumber: number;
  style: 'Murattal' | 'Mujawwad' | 'Hadr' | 'Tarteel';
  questionPrompt: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
}

export interface QariQuizStats {
  totalQuizzesTaken: number;
  totalCorrect: number;
  totalQuestions: number;
  learningScorePoints: number;
  currentStreak: number;
  bestStreak: number;
}

const STATS_STORAGE_KEY = 'noor_qari_quiz_stats_v1';

export const QARI_QUESTIONS_POOL: QariQuestion[] = [
  {
    id: 'qari_q1',
    type: 'qari_identification',
    audioUrl: 'https://cdn.islamic.network/quran/audio/128/ar.alafasy/1.mp3',
    qariName: 'Mishary Rashid Alafasy',
    surahName: 'Al-Fatihah',
    surahNumber: 1,
    style: 'Murattal',
    questionPrompt: 'Listen to this recitation of Surah Al-Fatihah. Which world-renowned Qari is reciting?',
    options: [
      'Mishary Rashid Alafasy',
      'Abdul Basit Abdul Samad',
      'Mahmoud Khalil Al-Husary',
      'Abu Bakr Al-Shatri'
    ],
    correctAnswer: 'Mishary Rashid Alafasy',
    explanation: 'This clear, melodic recitation is by Sheikh Mishary Rashid Alafasy, Imam of the Grand Mosque of Kuwait.'
  },
  {
    id: 'qari_q2',
    type: 'surah_identification',
    audioUrl: 'https://cdn.islamic.network/quran/audio/128/ar.alafasy/262.mp3',
    qariName: 'Mishary Rashid Alafasy',
    surahName: 'Al-Baqarah (Ayatul Kursi)',
    surahNumber: 2,
    style: 'Murattal',
    questionPrompt: 'Listen carefully to the audio passage. Which famous verse of Surah Al-Baqarah is being recited?',
    options: [
      'Ayatul Kursi (Verse 255)',
      'Amanar-Rasulu (Verse 285)',
      'Verse 1 (Alif-Lam-Mim)',
      'Verse 183 (Fasting)'
    ],
    correctAnswer: 'Ayatul Kursi (Verse 255)',
    explanation: 'This passage is "Allahu la ilaha illa Huwal-Hayyul-Qayyum..." which is Ayatul Kursi (The Throne Verse).'
  },
  {
    id: 'qari_q3',
    type: 'qari_identification',
    audioUrl: 'https://cdn.islamic.network/quran/audio/128/ar.abdulbasitmurattal/1.mp3',
    qariName: 'Abdul Basit Abdul Samad',
    surahName: 'Al-Fatihah',
    surahNumber: 1,
    style: 'Murattal',
    questionPrompt: 'Listen to the distinct resonance and breath control in this recording. Who is the Qari?',
    options: [
      'Abdul Basit Abdul Samad',
      'Saud Al-Shuraim',
      'Maher Al-Muaiqly',
      'Siddiq Al-Minshawi'
    ],
    correctAnswer: 'Abdul Basit Abdul Samad',
    explanation: 'This legendary voice belongs to Sheikh Abdul Basit Abdul Samad, known for his extraordinary vocal range and breath control.'
  },
  {
    id: 'qari_q4',
    type: 'recitation_style',
    audioUrl: 'https://cdn.islamic.network/quran/audio/128/ar.husary/1.mp3',
    qariName: 'Mahmoud Khalil Al-Husary',
    surahName: 'Al-Fatihah',
    surahNumber: 1,
    style: 'Murattal',
    questionPrompt: 'Listen to Sheikh Al-Husary reciting Surah Al-Fatihah. Which precise recitation style is demonstrated here?',
    options: [
      'Murattal (Measured pace for learning)',
      'Mujawwad (Melodic, extended slow style)',
      'Hadr (Fast pace for repetition)',
      'Tahqiq (Slower than Murattal with extreme care)'
    ],
    correctAnswer: 'Murattal (Measured pace for learning)',
    explanation: 'Sheikh Al-Husary is famous for Murattal recitation, adhering perfectly to all rules of Tajweed with precise speed ideal for memorization.'
  },
  {
    id: 'qari_q5',
    type: 'qari_identification',
    audioUrl: 'https://cdn.islamic.network/quran/audio/128/ar.minshawi/1.mp3',
    qariName: 'Siddiq Al-Minshawi',
    surahName: 'Al-Fatihah',
    surahNumber: 1,
    style: 'Murattal',
    questionPrompt: 'Listen to the soulful, emotional tone of this Surah Al-Fatihah recitation. Who is the reciter?',
    options: [
      'Mohamed Siddiq Al-Minshawi',
      'Mishary Rashid Alafasy',
      'Abdul Rahman Al-Sudais',
      'Ali Jaber'
    ],
    correctAnswer: 'Mohamed Siddiq Al-Minshawi',
    explanation: 'Sheikh Mohamed Siddiq Al-Minshawi is renowned for his deeply emotional and reverent recitation style ("El-Sawt El-Baki" - The Weeping Voice).'
  },
  {
    id: 'qari_q6',
    type: 'surah_identification',
    audioUrl: 'https://cdn.islamic.network/quran/audio/128/ar.alafasy/2172.mp3',
    qariName: 'Mishary Rashid Alafasy',
    surahName: 'Al-Kahf',
    surahNumber: 18,
    style: 'Murattal',
    questionPrompt: 'Listen to the opening verse: "Al-hamdulillahil-ladhi anzala \'ala \'abdihil-kitab...". Which Surah is this?',
    options: [
      'Surah Al-Kahf (The Cave)',
      'Surah Al-Mulk (The Sovereign)',
      'Surah Ya-Sin',
      'Surah Ar-Rahman'
    ],
    correctAnswer: 'Surah Al-Kahf (The Cave)',
    explanation: 'This is Verse 1 of Surah Al-Kahf (Chapter 18), recommended for recitation every Friday.'
  }
];

export function getQariQuizStats(): QariQuizStats {
  if (typeof localStorage === 'undefined') {
    return {
      totalQuizzesTaken: 0,
      totalCorrect: 0,
      totalQuestions: 0,
      learningScorePoints: 0,
      currentStreak: 0,
      bestStreak: 0
    };
  }
  try {
    const raw = localStorage.getItem(STATS_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (err) {
    console.warn('[QariQuiz] Error reading stats:', err);
  }
  return {
    totalQuizzesTaken: 0,
    totalCorrect: 0,
    totalQuestions: 0,
    learningScorePoints: 0,
    currentStreak: 0,
    bestStreak: 0
  };
}

export function recordQariAnswer(isCorrect: boolean, pointsEarned: number = 15): QariQuizStats {
  const current = getQariQuizStats();
  const newStreak = isCorrect ? current.currentStreak + 1 : 0;
  const bestStreak = Math.max(current.bestStreak, newStreak);

  const updated: QariQuizStats = {
    totalQuizzesTaken: current.totalQuizzesTaken + 1,
    totalQuestions: current.totalQuestions + 1,
    totalCorrect: isCorrect ? current.totalCorrect + 1 : current.totalCorrect,
    learningScorePoints: isCorrect ? current.learningScorePoints + pointsEarned : current.learningScorePoints,
    currentStreak: newStreak,
    bestStreak
  };

  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(updated));
    } catch (err) {
      console.warn('[QariQuiz] Error saving stats:', err);
    }
  }

  return updated;
}
