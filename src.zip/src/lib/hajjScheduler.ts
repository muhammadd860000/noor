import { 
  getNotificationPermission, 
  requestNotificationPermission, 
  showNotification 
} from './notifications';

export interface HajjRitualItem {
  id: string;
  hijriDateStr: string;
  name: string;
  arabicName: string;
  defaultTime: string; // e.g. "08:00 AM"
  description: string;
  location: string;
  importance: 'Essential Pillar' | 'Obligatory (Wajib)' | 'Sunnah';
}

export const HAJJ_RITUALS: HajjRitualItem[] = [
  {
    id: 'tarwiyah',
    hijriDateStr: '8th Dhul Hijjah',
    name: 'Day of Tarwiyah (Move to Mina)',
    arabicName: 'يوم التروية - مِنى',
    defaultTime: '08:00 AM',
    location: 'Mina Tents',
    importance: 'Sunnah',
    description: 'Assume Ihram from Makkah, move to Mina before Dhuhr. Recite Talbiyah continuously and pray Dhuhr, Asr, Maghrib, Isha, and Fajr in shortening without combining.'
  },
  {
    id: 'arafat',
    hijriDateStr: '9th Dhul Hijjah',
    name: 'Day of Arafat (Wuqoof)',
    arabicName: 'يوم عرفة - الوقوف بعرفة',
    defaultTime: '12:15 PM (After Dhuhr)',
    location: 'Mount Arafat',
    importance: 'Essential Pillar',
    description: 'The supreme pillar of Hajj ("Hajj is Arafah"). Stand in prayer and intense supplication from Dhuhr until Sunset. Pour out your heart in sincere Du\'a.'
  },
  {
    id: 'muzdalifah',
    hijriDateStr: '9th-10th Dhul Hijjah Night',
    name: 'Departure & Night at Muzdalifah',
    arabicName: 'المبيت بمزدلفة',
    defaultTime: '06:45 PM (After Sunset)',
    location: 'Muzdalifah Plains',
    importance: 'Obligatory (Wajib)',
    description: 'Depart Arafat immediately after Sunset without praying Maghrib at Arafat. Combine Maghrib & Isha at Muzdalifah, sleep under the open sky, and collect pebbles for Jamarat.'
  },
  {
    id: 'jamarat_aqaba',
    hijriDateStr: '10th Dhul Hijjah (Eid al-Adha)',
    name: 'Rami al-Jamarat (Stoning of Aqaba) & Qurbani',
    arabicName: 'رمي جمرة العقبة والذبح',
    defaultTime: '07:30 AM',
    location: 'Jamarat Complex, Mina',
    importance: 'Obligatory (Wajib)',
    description: 'Cast 7 pebbles at Jamarat al-Aqaba saying "Allahu Akbar" with each throw. Perform sacrificial offering (Qurbani) and shave or trim hair (Halq/Taqseer).'
  },
  {
    id: 'tawaf_ifadah',
    hijriDateStr: '10th-11th Dhul Hijjah',
    name: 'Tawaf al-Ifadah & Sa\'i',
    arabicName: 'طواف الإفاضة والسعي',
    defaultTime: '02:00 PM',
    location: 'Al-Masjid al-Haram, Makkah',
    importance: 'Essential Pillar',
    description: 'Perform Tawaf al-Ifadah (7 circuits around the Holy Kaaba) and Sa\'i between Safa and Marwah to completely lift all Ihram restrictions.'
  }
];

export interface HajjNotificationPreferences {
  enabled: boolean;
  enabledRituals: Record<string, boolean>;
  reminderTiming: '1hour_before' | 'exact' | 'both';
  soundEnabled: boolean;
}

export const DEFAULT_HAJJ_NOTIFICATIONS: HajjNotificationPreferences = {
  enabled: true,
  enabledRituals: {
    tarwiyah: true,
    arafat: true,
    muzdalifah: true,
    jamarat_aqaba: true,
    tawaf_ifadah: true,
  },
  reminderTiming: 'both',
  soundEnabled: true,
};

const STORAGE_KEY = 'noor_hajj_ritual_notifications';

export const getHajjNotificationPreferences = (): HajjNotificationPreferences => {
  if (typeof localStorage === 'undefined') return DEFAULT_HAJJ_NOTIFICATIONS;

  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        enabled: parsed.enabled ?? true,
        enabledRituals: { ...DEFAULT_HAJJ_NOTIFICATIONS.enabledRituals, ...(parsed.enabledRituals || {}) },
        reminderTiming: parsed.reminderTiming || 'both',
        soundEnabled: parsed.soundEnabled ?? true,
      };
    }
  } catch (err) {
    console.warn('[HajjScheduler] Error parsing preferences:', err);
  }

  return DEFAULT_HAJJ_NOTIFICATIONS;
};

export const saveHajjNotificationPreferences = (prefs: HajjNotificationPreferences): void => {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      window.dispatchEvent(new CustomEvent('hajj-notifications-updated', { detail: prefs }));
    }
  } catch (err) {
    console.warn('[HajjScheduler] Error saving preferences:', err);
  }
};

export const toggleHajjRitualNotification = async (
  ritualId: string
): Promise<{ success: boolean; newState: boolean; permissionGranted: boolean }> => {
  const current = getHajjNotificationPreferences();
  const willEnable = !current.enabledRituals[ritualId];

  let permissionGranted = getNotificationPermission() === 'granted';

  if (willEnable && !permissionGranted) {
    permissionGranted = await requestNotificationPermission();
    if (!permissionGranted) {
      return { success: false, newState: false, permissionGranted: false };
    }
  }

  const updated: HajjNotificationPreferences = {
    ...current,
    enabledRituals: {
      ...current.enabledRituals,
      [ritualId]: willEnable,
    },
  };

  saveHajjNotificationPreferences(updated);
  return { success: true, newState: willEnable, permissionGranted };
};

export const toggleMasterHajjNotifications = async (
  enabled: boolean
): Promise<{ success: boolean; newState: boolean; permissionGranted: boolean }> => {
  let permissionGranted = getNotificationPermission() === 'granted';

  if (enabled && !permissionGranted) {
    permissionGranted = await requestNotificationPermission();
    if (!permissionGranted) {
      return { success: false, newState: false, permissionGranted: false };
    }
  }

  const current = getHajjNotificationPreferences();
  const updated: HajjNotificationPreferences = {
    ...current,
    enabled,
  };

  saveHajjNotificationPreferences(updated);
  return { success: true, newState: enabled, permissionGranted };
};

export const sendTestHajjRitualNotification = async (ritualId: string = 'arafat'): Promise<boolean> => {
  const permissionGranted = getNotificationPermission() === 'granted' || (await requestNotificationPermission());
  if (!permissionGranted) return false;

  const ritual = HAJJ_RITUALS.find(r => r.id === ritualId) || HAJJ_RITUALS[1];

  await showNotification(`🕋 Hajj Ritual Alert: ${ritual.name}`, {
    body: `[${ritual.hijriDateStr}] ${ritual.description}`,
    tag: `hajj-ritual-test-${ritual.id}-${Date.now()}`,
    requireInteraction: true,
  });

  return true;
};
