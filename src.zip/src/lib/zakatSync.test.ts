import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { 
  queueRecordForSync, 
  processSyncQueue, 
  getSyncStatus
} from './zakatSync';
import * as dbModule from './db';

const mockStorage: Record<string, string> = {};

describe('Zakat Background Sync Engine', () => {
  beforeEach(() => {
    Object.keys(mockStorage).forEach(key => delete mockStorage[key]);

    // Polyfill localStorage
    (globalThis as any).localStorage = {
      getItem: (key: string) => mockStorage[key] || null,
      setItem: (key: string, val: string) => { mockStorage[key] = val; },
      removeItem: (key: string) => { delete mockStorage[key]; },
      clear: () => { Object.keys(mockStorage).forEach(key => delete mockStorage[key]); }
    };

    // Ensure navigator.onLine is true by default
    if (typeof globalThis.navigator === 'undefined') {
      (globalThis as any).navigator = { onLine: true };
    } else {
      Object.defineProperty(navigator, 'onLine', {
        value: true,
        writable: true,
        configurable: true
      });
    }

    vi.restoreAllMocks();
  });

  afterEach(() => {
    if (typeof globalThis.navigator !== 'undefined') {
      Object.defineProperty(navigator, 'onLine', {
        value: true,
        writable: true,
        configurable: true
      });
    }
  });

  it('reports initial sync status correctly', async () => {
    vi.spyOn(dbModule, 'getPendingSyncQueue').mockResolvedValue([]);
    const status = await getSyncStatus();
    expect(status.state).toBe('synced');
    expect(status.pendingCount).toBe(0);
  });

  it('queues a record when offline and processes it when back online', async () => {
    const queueItems: dbModule.SyncQueueItem[] = [];
    vi.spyOn(dbModule, 'queueSyncAction').mockImplementation(async (item) => {
      queueItems.push(item);
    });
    vi.spyOn(dbModule, 'getPendingSyncQueue').mockImplementation(async () => queueItems);
    vi.spyOn(dbModule, 'removeSyncQueueItem').mockImplementation(async (id) => {
      const idx = queueItems.findIndex(q => q.id === id);
      if (idx !== -1) queueItems.splice(idx, 1);
    });
    vi.spyOn(dbModule, 'getCachedZakatContributions').mockResolvedValue([]);
    vi.spyOn(dbModule, 'cacheZakatContributions').mockResolvedValue();

    // Start offline
    Object.defineProperty(navigator, 'onLine', {
      value: false,
      writable: true,
      configurable: true
    });

    const sampleRecord: dbModule.ZakatContributionRecord = {
      id: 'rec_101',
      type: 'zakat',
      amount: 500,
      currency: '$',
      cause: 'Emergency Food Relief',
      recipient: 'Global Aid',
      date: '2026-09-30',
      timestamp: Date.now()
    };

    await queueRecordForSync(sampleRecord, 'insert');
    expect(queueItems.length).toBe(1);

    // Turn back online
    Object.defineProperty(navigator, 'onLine', {
      value: true,
      writable: true,
      configurable: true
    });

    const syncResult = await processSyncQueue();
    expect(syncResult.success).toBe(true);
    expect(syncResult.syncedCount).toBe(1);
    expect(queueItems.length).toBe(0);
  });

  it('handles offline state and retains queue', async () => {
    const queueItems: dbModule.SyncQueueItem[] = [
      {
        id: 'q_1',
        action: 'insert',
        entity: 'zakat',
        payload: { id: 'rec_1' },
        timestamp: Date.now(),
        retryCount: 0
      }
    ];

    Object.defineProperty(navigator, 'onLine', {
      value: false,
      writable: true,
      configurable: true
    });

    vi.spyOn(dbModule, 'getPendingSyncQueue').mockResolvedValue(queueItems);

    const status = await getSyncStatus();
    expect(status.state).toBe('offline');
    expect(status.pendingCount).toBe(1);

    const res = await processSyncQueue();
    expect(res.success).toBe(false);
  });
});
