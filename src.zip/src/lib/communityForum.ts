export interface ForumReply {
  id: string;
  authorName: string;
  authorAvatar?: string;
  content: string;
  timestamp: number;
  likesCount: number;
  userLiked?: boolean;
}

export interface ForumPost {
  id: string;
  authorName: string;
  authorAvatar?: string;
  category: 'Questions' | 'Reflections' | 'Dua Request' | 'Quran Study' | 'General';
  title: string;
  content: string;
  timestamp: number;
  likesCount: number;
  userLiked?: boolean;
  replies: ForumReply[];
  tags?: string[];
}

const STORAGE_KEY = 'noor_community_forum_posts_v1';

export const INITIAL_SEED_POSTS: ForumPost[] = [
  {
    id: 'post_1',
    authorName: 'Zayd Al-Ansari',
    category: 'Reflections',
    title: 'Reflection on Surah Al-Kahf (Verse 10): Finding refuge in Allah during trials',
    content: 'When the young believers retreated into the cave, their first action was to call upon Allah: "Our Lord, grant us from Yourself mercy and prepare for us from our affair right guidance." In moments of confusion or hardship, turning to Allah with complete trust (Tawakkul) brings peace to the heart.',
    timestamp: Date.now() - 3600 * 1000 * 5, // 5 hours ago
    likesCount: 18,
    userLiked: false,
    tags: ['SurahKahf', 'Tawakkul', 'Reflection'],
    replies: [
      {
        id: 'reply_1_1',
        authorName: 'Maryam K.',
        content: 'JazakAllah Khair for this beautiful reminder. It is amazing how Allah protected them while they slept for hundreds of years.',
        timestamp: Date.now() - 3600 * 1000 * 3,
        likesCount: 6,
        userLiked: false
      },
      {
        id: 'reply_1_2',
        authorName: 'Tariq H.',
        content: 'SubhanAllah! Reading Surah Al-Kahf every Friday keeps this lesson fresh in our minds.',
        timestamp: Date.now() - 3600 * 1000 * 1,
        likesCount: 4,
        userLiked: false
      }
    ]
  },
  {
    id: 'post_2',
    authorName: 'Amina B.',
    category: 'Questions',
    title: 'Tips for maintaining focus (Khushu) in Tahajjud prayer?',
    content: 'Assalamu Alaikum brothers and sisters! I have been striving to wake up for Tahajjud consistently, but sometimes my mind wanders due to tiredness. What habits or Dhikr help you maintain deep Khushu during late night prayers?',
    timestamp: Date.now() - 3600 * 1000 * 18, // 18 hours ago
    likesCount: 24,
    userLiked: false,
    tags: ['Tahajjud', 'Khushu', 'PrayerTips'],
    replies: [
      {
        id: 'reply_2_1',
        authorName: 'Bilal M.',
        content: 'Wa Alaikum Assalam! Making Wudu with cold water, reciting verses whose meanings you understand, and sleeping early after Isha make a world of difference.',
        timestamp: Date.now() - 3600 * 1000 * 12,
        likesCount: 12,
        userLiked: false
      }
    ]
  },
  {
    id: 'post_3',
    authorName: 'Yusuf Rahman',
    category: 'Dua Request',
    title: 'Please make Dua for my mother undergoing surgery tomorrow',
    content: 'Dear Ummah family, my mother is undergoing a major heart surgery tomorrow morning. Please keep her in your sincere Duas for a successful procedure and full, swift recovery. May Allah reward you all!',
    timestamp: Date.now() - 3600 * 1000 * 24, // 1 day ago
    likesCount: 42,
    userLiked: false,
    tags: ['DuaRequest', 'Healing', 'Family'],
    replies: [
      {
        id: 'reply_3_1',
        authorName: 'Fatima N.',
        content: 'May Allah Shafi grant her complete Shifa without any illness left behind. Ya Rabb heal her!',
        timestamp: Date.now() - 3600 * 1000 * 20,
        likesCount: 15,
        userLiked: false
      }
    ]
  },
  {
    id: 'post_4',
    authorName: 'Dr. Omar Farooq',
    category: 'Quran Study',
    title: 'The linguistical beauty of "Inna ma\'al \'usri yusra" (Surah Ash-Sharh)',
    content: 'Notice how "al-\'usr" (difficulty) is defined with the definite article "al", meaning it refers to a specific trial. Whereas "yusra" (ease) is indefinite and repeated twice, signifying that one single difficulty is enveloped by endless forms of ease from Allah!',
    timestamp: Date.now() - 3600 * 1000 * 48, // 2 days ago
    likesCount: 35,
    userLiked: false,
    tags: ['Tafseer', 'Linguistics', 'Hope'],
    replies: []
  }
];

export function getStoredForumPosts(): ForumPost[] {
  if (typeof localStorage === 'undefined') return INITIAL_SEED_POSTS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_SEED_POSTS));
      return INITIAL_SEED_POSTS;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.warn('[CommunityForum] Error reading posts:', err);
    return INITIAL_SEED_POSTS;
  }
}

export function saveStoredForumPosts(posts: ForumPost[]): void {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(posts));
  } catch (err) {
    console.warn('[CommunityForum] Error saving posts:', err);
  }
}

export function addForumPost(
  authorName: string,
  category: ForumPost['category'],
  title: string,
  content: string,
  tags: string[] = []
): ForumPost {
  const posts = getStoredForumPosts();

  const newPost: ForumPost = {
    id: `post_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    authorName: authorName.trim() || 'Anonymous Servant of Allah',
    category,
    title: title.trim(),
    content: content.trim(),
    timestamp: Date.now(),
    likesCount: 0,
    userLiked: false,
    replies: [],
    tags
  };

  const updated = [newPost, ...posts];
  saveStoredForumPosts(updated);
  return newPost;
}

export function likeForumPost(postId: string): ForumPost[] {
  const posts = getStoredForumPosts();
  const updated = posts.map(p => {
    if (p.id === postId) {
      const isLiked = !p.userLiked;
      return {
        ...p,
        userLiked: isLiked,
        likesCount: isLiked ? p.likesCount + 1 : Math.max(0, p.likesCount - 1)
      };
    }
    return p;
  });

  saveStoredForumPosts(updated);
  return updated;
}

export function addForumReply(postId: string, authorName: string, content: string): ForumPost[] {
  const posts = getStoredForumPosts();
  const updated = posts.map(p => {
    if (p.id === postId) {
      const newReply: ForumReply = {
        id: `reply_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        authorName: authorName.trim() || 'Servant of Allah',
        content: content.trim(),
        timestamp: Date.now(),
        likesCount: 0,
        userLiked: false
      };
      return {
        ...p,
        replies: [...p.replies, newReply]
      };
    }
    return p;
  });

  saveStoredForumPosts(updated);
  return updated;
}

export function likeForumReply(postId: string, replyId: string): ForumPost[] {
  const posts = getStoredForumPosts();
  const updated = posts.map(p => {
    if (p.id === postId) {
      const updatedReplies = p.replies.map(r => {
        if (r.id === replyId) {
          const isLiked = !r.userLiked;
          return {
            ...r,
            userLiked: isLiked,
            likesCount: isLiked ? r.likesCount + 1 : Math.max(0, r.likesCount - 1)
          };
        }
        return r;
      });
      return { ...p, replies: updatedReplies };
    }
    return p;
  });

  saveStoredForumPosts(updated);
  return updated;
}
