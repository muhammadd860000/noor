import { openDB, IDBPDatabase } from 'idb';

const DB_NAME = 'NoorDB';
const DB_VERSION = 5;

export interface QuranBookmarkRecord {
  id: string | number;
  globalNumber: number;
  surahId?: number;
  surahName?: string;
  ayahNumber?: number;
  text?: string;
  translation?: string;
  timestamp: number;
}

export interface ZakatContributionRecord {
  id: string;
  type: string;
  amount: number;
  currency: string;
  cause: string;
  recipient: string;
  date: string;
  notes?: string;
  projectId?: string;
  projectName?: string;
  timestamp: number;
  syncStatus?: 'synced' | 'pending_sync' | 'syncing';
}

export interface SyncQueueItem {
  id: string;
  action: 'insert' | 'update' | 'delete';
  entity: 'zakat' | 'sadaqah' | 'bookmark' | 'reflection';
  payload: any;
  timestamp: number;
  retryCount: number;
}

export interface DailyQuranJournalRecord {
  id: string; // e.g. 'qjournal_2026-09-30'
  date: string; // 'YYYY-MM-DD'
  surahId: number;
  surahName: string;
  surahArabic?: string;
  startAyah: number;
  endAyah: number;
  totalAyahsInSurah?: number;
  reflectionNote: string;
  moodTag?: 'inspired' | 'peaceful' | 'seeking_guidance' | 'grateful' | 'humbled';
  timestamp: number;
}

export interface ReflectionRecord {
  id: string;
  date: string; // YYYY-MM-DD
  scriptureType: 'quran' | 'hadith';
  arabic: string;
  translation: string;
  source: string;
  theme?: string;
  journalText: string;
  mood?: string;
  intention?: string;
  timestamp: number;
  updatedAt?: number;
}

let dbPromise: Promise<IDBPDatabase> | null = null;

export const initDB = async () => {
  if (typeof window === 'undefined' || typeof indexedDB === 'undefined') {
    return null as unknown as IDBPDatabase;
  }

  if (!dbPromise) {
    dbPromise = openDB(DB_NAME, DB_VERSION, {
      upgrade(db, oldVersion) {
        if (!db.objectStoreNames.contains('quran')) {
          db.createObjectStore('quran', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('prayer')) {
          db.createObjectStore('prayer', { keyPath: 'date' });
        }
        if (!db.objectStoreNames.contains('audio')) {
          db.createObjectStore('audio', { keyPath: 'url' });
        }
        if (!db.objectStoreNames.contains('favorites')) {
          db.createObjectStore('favorites', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }
        if (!db.objectStoreNames.contains('quranProgress')) {
          db.createObjectStore('quranProgress', { keyPath: 'date' });
        }
        if (!db.objectStoreNames.contains('zakatHistory')) {
          db.createObjectStore('zakatHistory', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('quranBookmarks')) {
          db.createObjectStore('quranBookmarks', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('syncQueue')) {
          db.createObjectStore('syncQueue', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('reflections')) {
          db.createObjectStore('reflections', { keyPath: 'id' });
        }
      },
    });
  }
  return dbPromise;
};

export const saveToDB = async (store: string, data: any) => {
  try {
    const db = await initDB();
    if (!db) return;
    await db.put(store, data);
  } catch (err) {
    console.warn(`[IndexedDB] Error saving to ${store}:`, err);
  }
};

export const getFromDB = async (store: string, key: any) => {
  try {
    const db = await initDB();
    if (!db) return null;
    return await db.get(store, key);
  } catch (err) {
    console.warn(`[IndexedDB] Error getting from ${store}:`, err);
    return null;
  }
};

export const deleteFromDB = async (store: string, key: any) => {
  try {
    const db = await initDB();
    if (!db) return;
    await db.delete(store, key);
  } catch (err) {
    console.warn(`[IndexedDB] Error deleting from ${store}:`, err);
  }
};

export const getAllFromDB = async (store: string) => {
  try {
    const db = await initDB();
    if (!db) return [];
    return await db.getAll(store);
  } catch (err) {
    console.warn(`[IndexedDB] Error reading all from ${store}:`, err);
    return [];
  }
};

// ==========================================
// Daily Quran Journal Entries in IndexedDB
// ==========================================

export const saveDailyQuranJournalEntry = async (entry: DailyQuranJournalRecord): Promise<void> => {
  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem('noor_quran_journal_list');
      const list: DailyQuranJournalRecord[] = raw ? JSON.parse(raw) : [];
      const filtered = list.filter(item => item.id !== entry.id);
      localStorage.setItem('noor_quran_journal_list', JSON.stringify([entry, ...filtered]));
    } catch (e) {
      console.warn('[LocalStorage] Quran Journal fallback error:', e);
    }
  }

  try {
    const db = await initDB();
    if (!db) return;
    await db.put('quranProgress', entry);
  } catch (err) {
    console.warn('[IndexedDB] Failed to save Quran journal entry:', err);
  }
};

export const getDailyQuranJournalEntry = async (date: string): Promise<DailyQuranJournalRecord | null> => {
  try {
    const db = await initDB();
    if (db) {
      const res = await db.get('quranProgress', date);
      if (res) return res;
    }
  } catch (err) {
    console.warn('[IndexedDB] Failed to get Quran journal entry:', err);
  }

  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem('noor_quran_journal_list');
      if (raw) {
        const list: DailyQuranJournalRecord[] = JSON.parse(raw);
        return list.find(item => item.date === date || item.id === date) || null;
      }
    } catch {
      // ignore
    }
  }
  return null;
};

export const getAllDailyQuranJournalEntries = async (): Promise<DailyQuranJournalRecord[]> => {
  try {
    const db = await initDB();
    if (db) {
      const entries = await db.getAll('quranProgress');
      if (entries && entries.length > 0) {
        return entries.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      }
    }
  } catch (err) {
    console.warn('[IndexedDB] Failed to read Quran journal entries:', err);
  }

  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem('noor_quran_journal_list');
      if (raw) {
        const list: DailyQuranJournalRecord[] = JSON.parse(raw);
        return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      }
    } catch {
      // ignore
    }
  }
  return [];
};

export const deleteDailyQuranJournalEntry = async (idOrDate: string): Promise<void> => {
  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem('noor_quran_journal_list');
      if (raw) {
        const list: DailyQuranJournalRecord[] = JSON.parse(raw);
        const filtered = list.filter(item => item.id !== idOrDate && item.date !== idOrDate);
        localStorage.setItem('noor_quran_journal_list', JSON.stringify(filtered));
      }
    } catch {
      // ignore
    }
  }

  try {
    const db = await initDB();
    if (!db) return;
    await db.delete('quranProgress', idOrDate);
  } catch (err) {
    console.warn('[IndexedDB] Failed to delete Quran journal entry:', err);
  }
};

// ==========================================
// Reflection Entries in IndexedDB
// ==========================================

export const saveReflectionEntry = async (entry: ReflectionRecord): Promise<void> => {
  // Save fallback copy in localStorage
  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem('noor_reflections_list');
      const list: ReflectionRecord[] = raw ? JSON.parse(raw) : [];
      const filtered = list.filter(item => item.id !== entry.id);
      localStorage.setItem('noor_reflections_list', JSON.stringify([entry, ...filtered]));
    } catch (storageErr) {
      console.warn('[LocalStorage] Fallback storage error:', storageErr);
    }
  }

  try {
    const db = await initDB();
    if (!db) return;
    await db.put('reflections', entry);
  } catch (err) {
    console.warn('[IndexedDB] Failed to save reflection entry:', err);
  }
};

export const getReflectionEntry = async (id: string): Promise<ReflectionRecord | null> => {
  try {
    const db = await initDB();
    if (db) {
      const res = await db.get('reflections', id);
      if (res) return res;
    }
  } catch (err) {
    console.warn('[IndexedDB] Failed to get reflection entry:', err);
  }

  // Fallback from localStorage
  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem('noor_reflections_list');
      if (raw) {
        const list: ReflectionRecord[] = JSON.parse(raw);
        return list.find(item => item.id === id) || null;
      }
    } catch {
      // ignore
    }
  }
  return null;
};

export const getAllReflectionEntries = async (): Promise<ReflectionRecord[]> => {
  try {
    const db = await initDB();
    if (db) {
      const entries = await db.getAll('reflections');
      if (Array.isArray(entries) && entries.length > 0) {
        return entries.sort((a, b) => b.timestamp - a.timestamp);
      }
    }
  } catch (err) {
    console.warn('[IndexedDB] Failed to get all reflections:', err);
  }

  // Fallback from localStorage
  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem('noor_reflections_list');
      if (raw) {
        const list: ReflectionRecord[] = JSON.parse(raw);
        return Array.isArray(list) ? list.sort((a, b) => b.timestamp - a.timestamp) : [];
      }
    } catch {
      // ignore
    }
  }
  return [];
};

export const deleteReflectionEntry = async (id: string): Promise<void> => {
  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem('noor_reflections_list');
      if (raw) {
        const list: ReflectionRecord[] = JSON.parse(raw);
        const filtered = list.filter(item => item.id !== id);
        localStorage.setItem('noor_reflections_list', JSON.stringify(filtered));
      }
    } catch {
      // ignore
    }
  }

  try {
    const db = await initDB();
    if (!db) return;
    await db.delete('reflections', id);
  } catch (err) {
    console.warn('[IndexedDB] Failed to delete reflection entry:', err);
  }
};

// ==========================================
// Zakat History IndexedDB Offline Strategy
// ==========================================

export const cacheZakatContributions = async (contributions: ZakatContributionRecord[]) => {
  try {
    const db = await initDB();
    if (!db) return;
    const tx = db.transaction('zakatHistory', 'readwrite');
    for (const item of contributions) {
      await tx.store.put(item);
    }
    await tx.done;
  } catch (err) {
    console.warn('[IndexedDB] Failed to cache Zakat contributions:', err);
  }
};

export const getCachedZakatContributions = async (): Promise<ZakatContributionRecord[]> => {
  try {
    const records = await getAllFromDB('zakatHistory');
    return (records as ZakatContributionRecord[]) || [];
  } catch (err) {
    console.warn('[IndexedDB] Failed to get cached Zakat contributions:', err);
    return [];
  }
};

export const removeCachedZakatContribution = async (id: string) => {
  await deleteFromDB('zakatHistory', id);
};

// ==========================================
// Sync Queue Storage
// ==========================================

export const queueSyncAction = async (item: SyncQueueItem) => {
  try {
    const db = await initDB();
    if (!db) return;
    await db.put('syncQueue', item);
  } catch (err) {
    console.warn('[IndexedDB] Failed to queue sync item:', err);
  }
};

export const getPendingSyncQueue = async (): Promise<SyncQueueItem[]> => {
  try {
    const items = await getAllFromDB('syncQueue');
    return (items as SyncQueueItem[]) || [];
  } catch (err) {
    console.warn('[IndexedDB] Failed to retrieve sync queue:', err);
    return [];
  }
};

export const removeSyncQueueItem = async (id: string) => {
  await deleteFromDB('syncQueue', id);
};

export const clearSyncQueue = async () => {
  try {
    const db = await initDB();
    if (!db) return;
    await db.clear('syncQueue');
  } catch (err) {
    console.warn('[IndexedDB] Failed to clear sync queue:', err);
  }
};

// ==========================================
// Quran Bookmarks IndexedDB Offline Strategy
// ==========================================

export const cacheQuranBookmark = async (bookmark: QuranBookmarkRecord) => {
  try {
    const db = await initDB();
    if (!db) return;
    await db.put('quranBookmarks', bookmark);
  } catch (err) {
    console.warn('[IndexedDB] Failed to cache Quran bookmark:', err);
  }
};

export const cacheQuranBookmarksBulk = async (bookmarks: QuranBookmarkRecord[]) => {
  try {
    const db = await initDB();
    if (!db) return;
    const tx = db.transaction('quranBookmarks', 'readwrite');
    for (const b of bookmarks) {
      await tx.store.put(b);
    }
    await tx.done;
  } catch (err) {
    console.warn('[IndexedDB] Failed to cache Quran bookmarks bulk:', err);
  }
};

export const getCachedQuranBookmarks = async (): Promise<QuranBookmarkRecord[]> => {
  try {
    const records = await getAllFromDB('quranBookmarks');
    return (records as QuranBookmarkRecord[]) || [];
  } catch (err) {
    console.warn('[IndexedDB] Failed to get cached Quran bookmarks:', err);
    return [];
  }
};

export const removeCachedQuranBookmark = async (id: string | number) => {
  await deleteFromDB('quranBookmarks', id);
};

// ==========================================
// Auto-Sync LocalStorage -> IndexedDB
// ==========================================

export const syncLocalStorageToIndexedDB = async () => {
  if (typeof window === 'undefined' || typeof localStorage === 'undefined') return;

  try {
    // 1. Sync Zakat Contributions
    const rawZakat = localStorage.getItem('noor_charity_contributions');
    if (rawZakat) {
      const parsedZakat: ZakatContributionRecord[] = JSON.parse(rawZakat);
      if (Array.isArray(parsedZakat) && parsedZakat.length > 0) {
        await cacheZakatContributions(parsedZakat);
      }
    }

    // 2. Sync Quran Bookmarks
    const rawBookmarks = localStorage.getItem('bookmarkedAyahs');
    if (rawBookmarks) {
      const parsedBookmarks: number[] = JSON.parse(rawBookmarks);
      if (Array.isArray(parsedBookmarks) && parsedBookmarks.length > 0) {
        const bookmarkRecords: QuranBookmarkRecord[] = parsedBookmarks.map(globalNumber => ({
          id: globalNumber,
          globalNumber,
          surahId: Math.floor(globalNumber / 1000) || 1,
          timestamp: Date.now()
        }));
        await cacheQuranBookmarksBulk(bookmarkRecords);
      }
    }

    // 3. Sync Reflections
    const rawReflections = localStorage.getItem('noor_reflections_list');
    if (rawReflections) {
      const parsedReflections: ReflectionRecord[] = JSON.parse(rawReflections);
      if (Array.isArray(parsedReflections) && parsedReflections.length > 0) {
        for (const ref of parsedReflections) {
          await saveToDB('reflections', ref);
        }
      }
    }
  } catch (err) {
    console.warn('[IndexedDB] Background sync error:', err);
  }
};
