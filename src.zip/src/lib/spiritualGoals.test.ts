import { describe, it, expect, beforeEach } from 'vitest';
import {
  getSpiritualGoals,
  saveSpiritualGoals,
  getGoalCompletionsForDate,
  toggleSpiritualGoal,
  addSpiritualGoal,
  removeSpiritualGoal,
  setAllGoalsForDate,
  calculateGoalsProgress,
  DEFAULT_SPIRITUAL_GOALS
} from './spiritualGoals';

const mockStorage: Record<string, string> = {};

describe('Daily Spiritual Goals Engine', () => {
  beforeEach(() => {
    Object.keys(mockStorage).forEach(k => delete mockStorage[k]);

    if (typeof globalThis.localStorage === 'undefined') {
      (globalThis as any).localStorage = {
        getItem: (key: string) => mockStorage[key] || null,
        setItem: (key: string, val: string) => { mockStorage[key] = val; },
        removeItem: (key: string) => { delete mockStorage[key]; },
        clear: () => { Object.keys(mockStorage).forEach(k => delete mockStorage[k]); }
      };
    } else {
      localStorage.clear();
    }
  });

  it('loads default spiritual goals containing Quran, Adhkar, and Charity', () => {
    const goals = getSpiritualGoals();
    expect(goals.length).toBeGreaterThanOrEqual(3);
    const titles = goals.map(g => g.title);
    expect(titles).toContain('Read one page of Quran');
    expect(titles).toContain('Morning Adhkar');
    expect(titles).toContain('Donate to charity');
  });

  it('allows adding and removing user-defined spiritual habits', () => {
    const newGoal = addSpiritualGoal('Recite Surah Al-Mulk', 'quran');
    expect(newGoal.title).toBe('Recite Surah Al-Mulk');

    const goals = getSpiritualGoals();
    expect(goals.some(g => g.id === newGoal.id)).toBe(true);

    removeSpiritualGoal(newGoal.id);
    const updated = getSpiritualGoals();
    expect(updated.some(g => g.id === newGoal.id)).toBe(false);
  });

  it('accurately toggles goal completions and computes percentage progress', () => {
    const testDate = 'Wed Sep 30 2026';
    const goals = getSpiritualGoals();
    const firstGoal = goals[0];

    // Toggle 1st goal
    const result1 = toggleSpiritualGoal(firstGoal.id, testDate);
    expect(result1.completed).toBe(true);
    expect(result1.completedCount).toBe(1);

    const progress = calculateGoalsProgress(testDate);
    expect(progress.completedCount).toBe(1);
    expect(progress.percentage).toBeGreaterThan(0);

    // Toggle back off
    const result2 = toggleSpiritualGoal(firstGoal.id, testDate);
    expect(result2.completed).toBe(false);
    expect(result2.completedCount).toBe(0);
  });

  it('supports bulk marking all daily goals as completed', () => {
    const testDate = 'Wed Sep 30 2026';
    setAllGoalsForDate(testDate, true);

    const completions = getGoalCompletionsForDate(testDate);
    const goals = getSpiritualGoals();
    goals.forEach(g => {
      expect(completions[g.id]).toBe(true);
    });

    const progress = calculateGoalsProgress(testDate);
    expect(progress.percentage).toBe(100);
    expect(progress.completedCount).toBe(goals.length);
  });
});
