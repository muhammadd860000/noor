import { collectBackupData, NoorExportData } from './dataExport';

export interface SpiritualReport {
  generatedDate: string;
  prayerSummary: {
    totalDaysTracked: number;
    recentConsistencyPct: number;
    breakdown: Record<string, Record<string, boolean>>;
  };
  zakatSummary: {
    totalContributionsCount: number;
    totalAmountContributed: number;
    nisabStandard: string | null;
    annualGoal: number | null;
  };
  goalsSummary: {
    totalGoals: number;
    activeGoalsList: any[];
  };
}

export function generateSpiritualReport(storage?: any): SpiritualReport {
  const backup = collectBackupData(storage);

  // Calculate prayer consistency from historyByDate
  const prayerDates = Object.keys(backup.prayer.historyByDate || {});
  let totalPrayersDone = 0;
  let totalPrayersPossible = prayerDates.length * 5;

  prayerDates.forEach(date => {
    const prayers = backup.prayer.historyByDate[date];
    if (prayers) {
      ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].forEach(p => {
        if (prayers[p]) totalPrayersDone++;
      });
    }
  });

  const recentConsistencyPct = totalPrayersPossible > 0 
    ? Math.round((totalPrayersDone / totalPrayersPossible) * 100) 
    : 0;

  // Calculate zakat contributions total
  const contributions = backup.zakat.contributions || [];
  const totalAmountContributed = contributions.reduce((sum: number, c: any) => sum + (Number(c.amount) || 0), 0);

  return {
    generatedDate: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
    prayerSummary: {
      totalDaysTracked: prayerDates.length,
      recentConsistencyPct,
      breakdown: backup.prayer.historyByDate
    },
    zakatSummary: {
      totalContributionsCount: contributions.length,
      totalAmountContributed,
      nisabStandard: backup.zakat.nisabStandard,
      annualGoal: backup.zakat.annualGoal
    },
    goalsSummary: {
      totalGoals: backup.goals.spiritualGoalsList.length,
      activeGoalsList: backup.goals.spiritualGoalsList
    }
  };
}

/**
 * Opens a printable formatted document window for PDF generation (Save as PDF)
 */
export function openPrintableSpiritualReport(storage?: any): void {
  const report = generateSpiritualReport(storage);

  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('Please allow popups to generate the printable PDF report.');
    return;
  }

  const htmlContent = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Noor Spiritual Journey Report - ${report.generatedDate}</title>
      <style>
        body {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          color: #1e293b;
          line-height: 1.6;
          max-width: 800px;
          margin: 40px auto;
          padding: 20px;
          background: #ffffff;
        }
        .header {
          text-align: center;
          border-bottom: 2px solid #d97706;
          padding-bottom: 20px;
          margin-bottom: 30px;
        }
        .header h1 {
          color: #92400e;
          font-family: serif;
          margin: 0;
          font-size: 28px;
        }
        .header p {
          color: #64748b;
          font-size: 14px;
          margin-top: 5px;
        }
        .arabic-title {
          font-family: serif;
          color: #b45309;
          font-size: 20px;
          margin-bottom: 5px;
        }
        .section {
          margin-bottom: 25px;
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          padding: 20px;
        }
        .section h2 {
          font-size: 16px;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: #92400e;
          margin-top: 0;
          border-bottom: 1px solid #cbd5e1;
          padding-bottom: 8px;
        }
        .grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 15px;
        }
        .stat-card {
          background: #ffffff;
          padding: 12px 16px;
          border-radius: 8px;
          border: 1px solid #e2e8f0;
        }
        .stat-card label {
          font-size: 12px;
          color: #64748b;
          display: block;
        }
        .stat-card value {
          font-size: 20px;
          font-weight: bold;
          color: #0f172a;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 10px;
          font-size: 13px;
        }
        th, td {
          border: 1px solid #cbd5e1;
          padding: 8px 12px;
          text-align: left;
        }
        th {
          background: #f1f5f9;
          color: #334155;
        }
        .footer {
          text-align: center;
          margin-top: 40px;
          font-size: 12px;
          color: #94a3b8;
          border-top: 1px solid #e2e8f0;
          padding-top: 15px;
        }
        @media print {
          body { margin: 0; padding: 15px; }
          .no-print { display: none; }
        }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="arabic-title">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>
        <h1>Noor Islamic Suite — Spiritual Journey Report</h1>
        <p>Generated on ${report.generatedDate} • Weekly Summary & Physical Record</p>
      </div>

      <div class="section">
        <h2>1. Prayer Consistency & Performance</h2>
        <div class="grid">
          <div class="stat-card">
            <label>Total Days Tracked</label>
            <div style="font-size: 20px; font-weight: bold; color: #b45309;">${report.prayerSummary.totalDaysTracked} Days</div>
          </div>
          <div class="stat-card">
            <label>Overall Prayer Consistency</label>
            <div style="font-size: 20px; font-weight: bold; color: #059669;">${report.prayerSummary.recentConsistencyPct}%</div>
          </div>
        </div>
      </div>

      <div class="section">
        <h2>2. Zakat & Sadaqah Contributions</h2>
        <div class="grid">
          <div class="stat-card">
            <label>Total Charity Records</label>
            <div style="font-size: 20px; font-weight: bold; color: #b45309;">${report.zakatSummary.totalContributionsCount} Donations</div>
          </div>
          <div class="stat-card">
            <label>Total Amount Given</label>
            <div style="font-size: 20px; font-weight: bold; color: #059669;">$${report.zakatSummary.totalAmountContributed.toLocaleString()}</div>
          </div>
        </div>
      </div>

      <div class="section">
        <h2>3. Daily Spiritual Goals & Habits</h2>
        <p style="font-size: 13px; color: #475569;">Active Spiritual Goals: <strong>${report.goalsSummary.totalGoals}</strong></p>
        <ul>
          ${report.goalsSummary.activeGoalsList.map((g: any) => `<li>${g.title} (${g.category || 'General'})</li>`).join('') || '<li>No active goals recorded.</li>'}
        </ul>
      </div>

      <div style="text-align: center; margin-top: 30px;" class="no-print">
        <button onclick="window.print()" style="background: #b45309; color: white; border: none; padding: 12px 24px; font-size: 14px; font-weight: bold; border-radius: 8px; cursor: pointer;">
          🖨️ Print / Save as PDF
        </button>
      </div>

      <div class="footer">
        <p>May Allah accept your prayers, charity, and striving. Noor Islamic Suite Offline Backup.</p>
      </div>

      <script>
        window.onload = function() {
          setTimeout(() => {
            window.print();
          }, 500);
        };
      </script>
    </body>
    </html>
  `;

  printWindow.document.write(htmlContent);
  printWindow.document.close();
}
