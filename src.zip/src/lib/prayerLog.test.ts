import { describe, it, expect, beforeEach } from 'vitest';
import {
  getPrayerLogForDate,
  savePrayerLogForDate,
  togglePrayerLog,
  setAllPrayersForDate,
  getWeeklyPrayerSummary,
  PRAYER_NAMES
} from './prayerLog';

const mockStorage: Record<string, string> = {};

describe('PrayerLog & Weekly Consistency Engine', () => {
  beforeEach(() => {
    Object.keys(mockStorage).forEach(k => delete mockStorage[k]);

    if (typeof globalThis.localStorage === 'undefined') {
      (globalThis as any).localStorage = {
        getItem: (key: string) => mockStorage[key] || null,
        setItem: (key: string, val: string) => { mockStorage[key] = val; },
        removeItem: (key: string) => { delete mockStorage[key]; },
        clear: () => { Object.keys(mockStorage).forEach(k => delete mockStorage[k]); }
      };
    } else {
      localStorage.clear();
    }
  });

  it('reads empty prayer log when no previous records exist for a date', () => {
    const log = getPrayerLogForDate('Wed Sep 30 2026');
    expect(log).toEqual({});
  });

  it('toggles prayer completion accurately and persists changes', async () => {
    const testDate = 'Wed Sep 30 2026';
    
    // Toggle Fajr to completed
    const res1 = await togglePrayerLog(testDate, 'Fajr');
    expect(res1.isCompleted).toBe(true);
    expect(res1.updatedPrayers.Fajr).toBe(true);

    // Toggle Fajr again to incomplete
    const res2 = await togglePrayerLog(testDate, 'Fajr');
    expect(res2.isCompleted).toBe(false);
    expect(res2.updatedPrayers.Fajr).toBe(false);
  });

  it('allows bulk marking all 5 prayers as completed or reset', async () => {
    const testDate = 'Wed Sep 30 2026';
    const completedAll = await setAllPrayersForDate(testDate, true);
    
    PRAYER_NAMES.forEach(prayer => {
      expect(completedAll[prayer]).toBe(true);
    });

    const resetAll = await setAllPrayersForDate(testDate, false);
    PRAYER_NAMES.forEach(prayer => {
      expect(resetAll[prayer]).toBe(false);
    });
  });

  it('generates a 7-day weekly prayer summary with accurate bar chart metrics', async () => {
    const refDate = new Date('2026-09-30T10:00:00Z'); // Wednesday
    const wednesdayDateStr = refDate.toDateString();

    // Mark 5/5 for Wednesday
    await setAllPrayersForDate(wednesdayDateStr, true);

    const summary = getWeeklyPrayerSummary(refDate);
    expect(summary.weekDays.length).toBe(7);
    expect(summary.totalCompleted).toBe(5);
    expect(summary.totalPossible).toBe(35);
    expect(summary.perfectDaysCount).toBe(1);

    const wednesday = summary.weekDays.find(d => d.dateStr === wednesdayDateStr);
    expect(wednesday).toBeDefined();
    expect(wednesday?.completedCount).toBe(5);
    expect(wednesday?.percentage).toBe(100);
  });
});
