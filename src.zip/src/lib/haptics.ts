/**
 * Mobile-only Haptic Feedback Engine using navigator.vibrate()
 */

export type VibratePattern = number | number[];

/**
 * Robust check to ensure vibration triggers exclusively on mobile / touch devices
 */
export function isMobileDevice(): boolean {
  const nav = typeof navigator !== 'undefined' ? navigator : (typeof globalThis !== 'undefined' ? (globalThis as any).navigator : undefined);
  const win = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? (globalThis as any).window : undefined);

  if (!nav) {
    return false;
  }

  // Check touch points & coarse pointer
  const hasTouchScreen =
    (nav.maxTouchPoints && nav.maxTouchPoints > 0) ||
    (win && typeof win.matchMedia === 'function' &&
      win.matchMedia('(pointer: coarse)')?.matches);

  // Check mobile user agent signatures
  const isMobileUA = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Mobile|mobile/i.test(
    nav.userAgent || ''
  );

  return Boolean(hasTouchScreen || isMobileUA);
}

/**
 * Triggers haptic vibration pattern if supported and on a mobile device
 */
export function triggerHaptic(pattern: VibratePattern = 15): boolean {
  try {
    const nav = typeof navigator !== 'undefined' ? navigator : (typeof globalThis !== 'undefined' ? (globalThis as any).navigator : undefined);
    if (
      isMobileDevice() &&
      nav &&
      typeof nav.vibrate === 'function'
    ) {
      return nav.vibrate(pattern);
    }
  } catch (err) {
    // Graceful fallback if device permissions block vibration
    console.debug('[Haptics] Vibration not permitted or supported:', err);
  }
  return false;
}

/**
 * Standard button click haptic pulse (subtle, light 12ms)
 */
export function triggerButtonClickHaptic(): boolean {
  return triggerHaptic(12);
}

/**
 * Tasbeeh counter haptic with special milestone patterns at 33, 66, 99, 100 or target completion
 */
export function triggerTasbeehHaptic(newCount: number, target: number = 33): boolean {
  // Check if reached target or notable milestone
  if (newCount > 0 && target > 0 && newCount % target === 0) {
    // Double pulse celebration milestone
    return triggerHaptic([35, 45, 35]);
  } else if (newCount === 33 || newCount === 66 || newCount === 99 || newCount === 100) {
    // Milestone pulse
    return triggerHaptic([30, 40, 30]);
  }

  // Standard crisp tap
  return triggerHaptic(15);
}

/**
 * Success action feedback (e.g. form submit, bookmark saved, backup exported)
 */
export function triggerSuccessHaptic(): boolean {
  return triggerHaptic([20, 50, 30]);
}

/**
 * Warning / Delete action feedback
 */
export function triggerWarningHaptic(): boolean {
  return triggerHaptic([40, 40, 40]);
}
