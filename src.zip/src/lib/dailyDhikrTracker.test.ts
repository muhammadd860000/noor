import { describe, it, expect } from 'vitest';
import {
  getTotalDhikrCompletedCount,
  isDhikrMarkedDone,
  markDailyDhikrAsDone,
  unmarkDailyDhikrDone
} from './dailyDhikrTracker';
import { getCurrentTimeOfDay, getDailyDhikrForDate } from '../data/dailyAdhkar';

class MockStorage {
  private data: Record<string, string> = {};

  getItem(key: string): string | null {
    return this.data[key] ?? null;
  }

  setItem(key: string, value: string) {
    this.data[key] = value;
  }

  removeItem(key: string) {
    delete this.data[key];
  }

  clear() {
    this.data = {};
  }
}

describe('Daily Dhikr Tracker & Morning/Evening Suggestions', () => {
  it('correctly distinguishes morning vs evening time slots', () => {
    const morningDate = new Date('2026-09-28T09:00:00');
    expect(getCurrentTimeOfDay(morningDate)).toBe('morning');

    const eveningDate = new Date('2026-09-28T18:00:00');
    expect(getCurrentTimeOfDay(eveningDate)).toBe('evening');
  });

  it('suggests morning-appropriate dhikr during morning hours', () => {
    const morningDate = new Date('2026-09-28T08:00:00');
    const dhikr = getDailyDhikrForDate(morningDate, 'morning');
    expect(['morning', 'both']).toContain(dhikr.timeOfDay);
  });

  it('suggests evening-appropriate dhikr during evening hours', () => {
    const eveningDate = new Date('2026-09-28T19:00:00');
    const dhikr = getDailyDhikrForDate(eveningDate, 'evening');
    expect(['evening', 'both']).toContain(dhikr.timeOfDay);
  });

  it('marks a daily dhikr as done and increments local storage total completed counter', () => {
    const mockStorage = new MockStorage();

    expect(getTotalDhikrCompletedCount(mockStorage)).toBe(0);
    expect(isDhikrMarkedDone('2026-09-28', 'dhikr-test', mockStorage)).toBe(false);

    const result = markDailyDhikrAsDone('2026-09-28', 'dhikr-test', 33, mockStorage);
    expect(result.isDone).toBe(true);
    expect(result.totalCompleted).toBe(1);
    expect(result.streak).toBe(1);

    expect(isDhikrMarkedDone('2026-09-28', 'dhikr-test', mockStorage)).toBe(true);
    expect(getTotalDhikrCompletedCount(mockStorage)).toBe(1);

    // Marking same dhikr again today does not double count
    const repeatResult = markDailyDhikrAsDone('2026-09-28', 'dhikr-test', 33, mockStorage);
    expect(repeatResult.totalCompleted).toBe(1);
    expect(getTotalDhikrCompletedCount(mockStorage)).toBe(1);
  });

  it('supports unmarking done state', () => {
    const mockStorage = new MockStorage();

    markDailyDhikrAsDone('2026-09-28', 'dhikr-test', 33, mockStorage);
    expect(isDhikrMarkedDone('2026-09-28', 'dhikr-test', mockStorage)).toBe(true);

    unmarkDailyDhikrDone('2026-09-28', 'dhikr-test', mockStorage);
    expect(isDhikrMarkedDone('2026-09-28', 'dhikr-test', mockStorage)).toBe(false);
  });
});
