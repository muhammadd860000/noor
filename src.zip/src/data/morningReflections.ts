/**
 * Curated Morning Islamic Reflection Prompts & Intention-Centering Questions
 */

export interface DailyMorningReflection {
  id: string;
  theme: 'Niyyah (Intention)' | 'Shukr (Gratitude)' | 'Tawakkul (Trust)' | 'Sabr (Patience)' | 'Ikhlas (Sincerity)' | 'Husn al-Khuluq (Character)' | 'Tafakkur (Mindfulness)';
  arabicTheme: string;
  title: string;
  wisdom: string;
  reflectionQuestion: string;
  actionableIntention: string;
  source: string;
}

export const morningReflectionsList: DailyMorningReflection[] = [
  {
    id: "niyyah-pure-purpose",
    theme: "Niyyah (Intention)",
    arabicTheme: "إخلاص النية",
    title: "Centering the Heart's Direction",
    wisdom: "Actions are judged solely by intentions, and every soul will have only what they intended. Transforming ordinary habits—working, eating, walking—into acts of devotion begins with a conscious morning intention.",
    reflectionQuestion: "What is one routine task on your schedule today that you can consciously dedicate to the service of Allah and the benefit of others?",
    actionableIntention: "Before beginning my primary task today, I will pause for 5 seconds and renew my intention: 'For the pleasure of Allah.'",
    source: "Sahih al-Bukhari 1"
  },
  {
    id: "shukr-morning-breath",
    theme: "Shukr (Gratitude)",
    arabicTheme: "شكر النعم",
    title: "The Gift of a New Beginning",
    wisdom: "Upon waking, the Prophet (ﷺ) praised Allah for restoring the soul after sleep. Every morning is an unearned lease on life—a blank slate to seek forgiveness, perform good, and elevate your spiritual rank.",
    reflectionQuestion: "If today were your only opportunity to leave a legacy of kindness, what blessing around you right now deserves your deepest gratitude?",
    actionableIntention: "I will verbally express heartfelt gratitude to at least one person who helped or supported me today.",
    source: "Sahih al-Bukhari 6312"
  },
  {
    id: "tawakkul-releasing-anxiety",
    theme: "Tawakkul (Trust)",
    arabicTheme: "التوكل واليقين",
    title: "Surrendering Tomorrow's Burden",
    wisdom: "The birds set out in the morning with empty bellies and return in the evening full. They expend effort without crippling worry, trusting the Sustainer of all existence.",
    reflectionQuestion: "What upcoming outcome or uncertainty is causing you anxiety, and how can you do your best today while peacefully leaving the result to Allah?",
    actionableIntention: "When worry surfaces today, I will exhale and whisper: 'Hasbiyallahu la ilaha illa Huwa' (Allah is sufficient for me).",
    source: "Sunan at-Tirmidhi 2344"
  },
  {
    id: "sabr-gentle-response",
    theme: "Sabr (Patience)",
    arabicTheme: "الصبر والحلم",
    title: "The Power of the Calm Pause",
    wisdom: "The truly strong person is not the one who overpowers opponents with force, but the one who controls their soul and speech in moments of anger or frustration.",
    reflectionQuestion: "Who or what is most likely to test your patience today, and how can you prepare your heart right now to respond with grace and dignity?",
    actionableIntention: "Whenever I feel tension rising today, I will take a slow breath, seek refuge from Shaytan, and choose silence over harsh words.",
    source: "Sahih al-Bukhari 6114"
  },
  {
    id: "ikhlas-unseen-deeds",
    theme: "Ikhlas (Sincerity)",
    arabicTheme: "الإخلاص في السر",
    title: "The Secret Fragrance of Sincerity",
    wisdom: "The deeds most beloved to Allah are often the quietest: a private tear shed in supplication, a hidden charity, or a sincere prayer for a brother or sister behind their back.",
    reflectionQuestion: "What is one small good deed you can do today in complete secrecy, with no desire for praise, validation, or recognition from anyone except Allah?",
    actionableIntention: "I will make a sincere, silent du'a for someone who has wronged or challenged me.",
    source: "Sahih Muslim 2733"
  },
  {
    id: "husn-khuluq-smiling-mercy",
    theme: "Husn al-Khuluq (Character)",
    arabicTheme: "حسن الخلق",
    title: "Spreading Warmth & Ease",
    wisdom: "The Prophet (ﷺ) said: 'Nothing weighs heavier on the scales of the believer on the Day of Judgment than good character.' A smile, an encouraging word, and removing harm from the path are all forms of charity.",
    reflectionQuestion: "How can your presence today bring comfort and emotional ease to the people you interact with?",
    actionableIntention: "I will offer a genuine warm smile and greeting to everyone I meet today, treating each soul with gentle dignity.",
    source: "Sunan at-Tirmidhi 2002"
  },
  {
    id: "tafakkur-nature-signs",
    theme: "Tafakkur (Mindfulness)",
    arabicTheme: "التفكر والتدبر",
    title: "Seeing the Divine in the Everyday",
    wisdom: "Verily, in the creation of the heavens and the earth, and the alternation of the night and the day, there are indeed signs for people of understanding who remember Allah standing, sitting, and lying on their sides.",
    reflectionQuestion: "When was the last time you truly paused to look up at the morning sky, listen to the breeze, or reflect on the miraculous architecture of life?",
    actionableIntention: "I will spend 2 minutes today observing nature in complete silence, glorifying the Artistry of Allah.",
    source: "Surah Ali 'Imran (3:190-191)"
  },
  {
    id: "forgiveness-releasing-grudges",
    theme: "Husn al-Khuluq (Character)",
    arabicTheme: "العفو والصفح",
    title: "Lightening the Heart's Vessel",
    wisdom: "Do you not wish that Allah should forgive you? The one who overlooks human faults and pardons others invites the boundless mercy and pardon of the Almighty.",
    reflectionQuestion: "Is there a resentment or bitter memory you are carrying into this new morning? What would it feel like to release it for Allah's sake?",
    actionableIntention: "I choose to forgive those who have spoken carelessly or treated me thoughtlessly, seeking Allah's forgiveness in return.",
    source: "Surah An-Nur (24:22)"
  }
];

/**
 * Gets deterministic Daily Morning Reflection based on day of year
 */
export function getDailyMorningReflection(date: Date = new Date()): DailyMorningReflection {
  const startOfYear = new Date(date.getFullYear(), 0, 0);
  const diff = date.getTime() - startOfYear.getTime();
  const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));
  return morningReflectionsList[dayOfYear % morningReflectionsList.length];
}
