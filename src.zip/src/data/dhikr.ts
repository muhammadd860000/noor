export const dhikrList = [
    { arabic: "سُبْحَانَ اللهِ وَبِحَمْدِهِ", meaning: "Glory be to Allah and His praise", transliteration: "SubhanAllah wa bihamdihi" },
    { arabic: "لَا إِلَهَ إِلَّا اللهُ", meaning: "There is no god but Allah", transliteration: "La ilaha illallah" },
    { arabic: "أَسْتَغْفِرُ اللهَ", meaning: "I seek forgiveness from Allah", transliteration: "Astaghfirullah" },
    { arabic: "الْحَمْدُ لِلَّهِ", meaning: "All praise is for Allah", transliteration: "Alhamdulillah" },
    { arabic: "اللهُ أَكْبَرُ", meaning: "Allah is the greatest", transliteration: "Allahu Akbar" }
];
