export interface HadithItem {
  id: number;
  arabic: string;
  narrator: string;
  text: string;
  category: string;
  reference: string;
  lesson?: string;
}

export const hadiths: HadithItem[] = [
  {
    id: 1,
    arabic: "إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى",
    narrator: "Narrated by 'Umar ibn al-Khattab (RA)",
    text: "Actions are judged by intentions, and each person will have what they intended.",
    category: "Intention & Sincerity",
    reference: "Sahih al-Bukhari 1, Sahih Muslim 1907",
    lesson: "Before starting any task, work, or act of worship today, pause and renew your intention purely for Allah."
  },
  {
    id: 2,
    arabic: "لاَ يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لِأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ",
    narrator: "Narrated by Anas ibn Malik (RA)",
    text: "None of you truly believes until he loves for his brother what he loves for himself.",
    category: "Brotherhood & Faith",
    reference: "Sahih al-Bukhari 13, Sahih Muslim 45",
    lesson: "Celebrate other people's successes and blessings as sincerely as you would rejoice in your own."
  },
  {
    id: 3,
    arabic: "خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ",
    narrator: "Narrated by 'Uthman ibn 'Affan (RA)",
    text: "The best among you are those who learn the Quran and teach it to others.",
    category: "Quran & Knowledge",
    reference: "Sahih al-Bukhari 5027",
    lesson: "Dedicate even a few moments today to reciting, understanding, or sharing a verse of the Holy Quran."
  },
  {
    id: 4,
    arabic: "الْكَلِمَةُ الطَّيِّبَةُ صَدَقَةٌ",
    narrator: "Narrated by Abu Hurairah (RA)",
    text: "A good, kind word is charity.",
    category: "Character & Speech",
    reference: "Sahih al-Bukhari 2989, Sahih Muslim 1009",
    lesson: "Brighten someone's day with gentle speech, encouraging words, or heartfelt praise."
  },
  {
    id: 5,
    arabic: "تَبَسُّمُكَ فِي وَجْهِ أَخِيكَ لَكَ صَدَقَةٌ",
    narrator: "Narrated by Abu Dharr (RA)",
    text: "Your smiling in the face of your brother is charity for you.",
    category: "Kindness & Charity",
    reference: "Jami` at-Tirmidhi 1956",
    lesson: "A simple, sincere smile is a universal act of worship that softens hearts and spreads peace."
  },
  {
    id: 6,
    arabic: "مَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الآخِرِ فَلْيَقُلْ خَيْرًا أَوْ لِيَصْمُتْ",
    narrator: "Narrated by Abu Hurairah (RA)",
    text: "Whoever believes in Allah and the Last Day should speak good or remain silent.",
    category: "Speech & Wisdom",
    reference: "Sahih al-Bukhari 6018, Sahih Muslim 47",
    lesson: "Guard your tongue from backbiting, rumors, and useless disputes; choose words that build others up."
  },
  {
    id: 7,
    arabic: "إِنَّ الرِّفْقَ لاَ يَكُونُ فِي شَىْءٍ إِلاَّ زَانَهُ، وَلاَ يُنْزَعُ مِنْ شَىْءٍ إِلاَّ شَانَهُ",
    narrator: "Narrated by 'Aishah (RA)",
    text: "Gentleness is not found in anything except that it beautifies it, and is not withdrawn from anything except that it blemishes it.",
    category: "Gentleness & Compassion",
    reference: "Sahih Muslim 2594",
    lesson: "Approach conflicts, parenting, and everyday disagreements with gentle warmth rather than harshness."
  },
  {
    id: 8,
    arabic: "الرَّاحِمُونَ يَرْحَمُهُمُ الرَّحْمَنُ، ارْحَمُوا مَنْ فِي الأَرْضِ يَرْحَمْكُمْ مَنْ فِي السَّمَاءِ",
    narrator: "Narrated by 'Abdullah ibn 'Amr (RA)",
    text: "Those who are merciful will be shown mercy by the Most Merciful. Be merciful to those on the earth, and the One in the heavens will have mercy on you.",
    category: "Mercy & Compassion",
    reference: "Sunan Abi Dawud 4941, Jami` at-Tirmidhi 1924",
    lesson: "Extend mercy, patience, and forgiveness to every living soul around you."
  },
  {
    id: 9,
    arabic: "مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ",
    narrator: "Narrated by Abu Hurairah (RA)",
    text: "Whoever takes a path seeking knowledge, Allah will make easy for him by it a path to Paradise.",
    category: "Knowledge & Learning",
    reference: "Sahih Muslim 2699",
    lesson: "Learn something beneficial today about your faith, craft, or beneficial knowledge that serves people."
  },
  {
    id: 10,
    arabic: "احْفَظِ اللَّهَ يَحْفَظْكَ، احْفَظِ اللَّهَ تَجِدْهُ تُجَاهَكَ",
    narrator: "Narrated by 'Abdullah ibn 'Abbas (RA)",
    text: "Be mindful of Allah, and He will protect you. Be mindful of Allah, and you will find Him before you.",
    category: "Tawakkul & Mindfulness",
    reference: "Jami` at-Tirmidhi 2516",
    lesson: "Guard Allah's commandments in your private moments, and He will guide and guard your entire life."
  },
  {
    id: 11,
    arabic: "عَجَبًا لِأَمْرِ الْمُؤْمِنِ، إِنَّ أَمْرَهُ كُلَّهُ خَيْرٌ: إِنْ أَصَابَتْهُ سَرَّاءُ شَكَرَ فَكَانَ خَيْرًا لَهُ، وَإِنْ أَصَابَتْهُ ضَرَّاءُ صَبَرَ فَكَانَ خَيْرًا لَهُ",
    narrator: "Narrated by Suhaib ibn Sinan (RA)",
    text: "How wonderful is the affair of the believer, for all of his affairs are good! If prosperity touches him, he is thankful, and that is good for him; and if adversity touches him, he is patient, and that is good for him.",
    category: "Patience & Gratitude",
    reference: "Sahih Muslim 2999",
    lesson: "Every circumstance in your life is an opportunity for elevation: practice Shukr in ease and Sabr in difficulty."
  },
  {
    id: 12,
    arabic: "مَا نَقَصَتْ صَدَقَةٌ مِنْ مَالٍ، وَمَا زَادَ اللَّهُ عَبْدًا بِعَفْوٍ إِلاَّ عِزًّا",
    narrator: "Narrated by Abu Hurairah (RA)",
    text: "Charity does not decrease wealth, and no one forgives another except that Allah increases his honor.",
    category: "Forgiveness & Charity",
    reference: "Sahih Muslim 2588",
    lesson: "Let go of grievances and give generously; Allah replaces what you release with boundless barakah."
  },
  {
    id: 13,
    arabic: "كَلِمَتَانِ خَفِيفَتَانِ عَلَى اللِّسَانِ، ثَقِيلَتَانِ فِي الْمِيزَانِ، حَبِيبَتَانِ إِلَى الرَّحْمَنِ: سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ",
    narrator: "Narrated by Abu Hurairah (RA)",
    text: "Two words are light on the tongue, heavy in the scales, and beloved to the Most Merciful: 'Subhan Allahi wa bihamdihi, Subhan Allahil-'Azim' (Glory be to Allah and His praise, Glory be to Allah the Almighty).",
    category: "Dhikr & Praise",
    reference: "Sahih al-Bukhari 6406, Sahih Muslim 2694",
    lesson: "Repeat these two beloved phrases throughout your day whenever your mind is unoccupied."
  },
  {
    id: 14,
    arabic: "إِنَّمَا بُعِثْتُ لِأُتَمِّمَ صَالِحَ الأَخْلاَقِ",
    narrator: "Narrated by Abu Hurairah (RA)",
    text: "I was sent only to perfect noble character.",
    category: "Noble Character",
    reference: "Musnad Ahmad 8952, Al-Adab al-Mufrad 273",
    lesson: "The truest measure of faith is how you treat people with integrity, humility, and fairness."
  },
  {
    id: 15,
    arabic: "لاَ تَحْقِرَنَّ مِنَ الْمَعْرُوفِ شَيْئًا وَلَوْ أَنْ تَلْقَى أَخَاكَ بِوَجْهٍ طَلِقٍ",
    narrator: "Narrated by Abu Dharr (RA)",
    text: "Do not underestimate any good deed, even meeting your brother with a cheerful face.",
    category: "Good Deeds",
    reference: "Sahih Muslim 2626",
    lesson: "No kindness is too small in the sight of Allah; seize every little opportunity to do good."
  },
  {
    id: 16,
    arabic: "طَهُورٌ شَطْرُ الإِيمَانِ، وَالْحَمْدُ لِلَّهِ تَمْلأُ الْمِيزَانَ",
    narrator: "Narrated by Abu Malik al-Ash'ari (RA)",
    text: "Purity is half of faith, and 'Alhamdulillah' (Praise be to Allah) fills the scale of good deeds.",
    category: "Purity & Gratitude",
    reference: "Sahih Muslim 223",
    lesson: "Maintain outer cleanliness through Wudu and inner purity through constant gratitude to your Creator."
  },
  {
    id: 17,
    arabic: "الْمُؤْمِنُ الْقَوِيُّ خَيْرٌ وَأَحَبُّ إِلَى اللَّهِ مِنَ الْمُؤْمِنِ الضَّعِيفِ، وَفِي كُلٍّ خَيْرٌ",
    narrator: "Narrated by Abu Hurairah (RA)",
    text: "The strong believer is better and more beloved to Allah than the weak believer, while there is good in both. Strive for that which benefits you, seek help from Allah, and do not lose heart.",
    category: "Strength & Resolve",
    reference: "Sahih Muslim 2664",
    lesson: "Cultivate spiritual, mental, and physical resilience while relying completely upon Allah."
  },
  {
    id: 18,
    arabic: "ارْحَمْ مَنْ فِي الْأَرْضِ يَرْحَمْكَ مَنْ فِي السَّمَاءِ",
    narrator: "Narrated by 'Abdullah ibn 'Amr (RA)",
    text: "Have mercy on those on the earth, and the One above the heavens will have mercy on you.",
    category: "Mercy to All",
    reference: "Sunan al-Tirmidhi 1924",
    lesson: "Show compassion not only to friends and family, but to animals, nature, and the vulnerable."
  },
  {
    id: 19,
    arabic: "لَيْسَ الشَّدِيدُ بِالصُّرَعَةِ، إِنَّمَا الشَّدِيدُ الَّذِي يَمْلِكُ نَفْسَهُ عِنْدَ الْغَضَبِ",
    narrator: "Narrated by Abu Hurairah (RA)",
    text: "The strong person is not the one who can overpower others in wrestling; the truly strong person is the one who controls himself in a fit of rage.",
    category: "Self-Control",
    reference: "Sahih al-Bukhari 6114, Sahih Muslim 2609",
    lesson: "When anger flares, seek refuge with Allah, remain silent, change your posture, or perform Wudu."
  },
  {
    id: 20,
    arabic: "مَنْ يُرِدِ اللَّهُ بِهِ خَيْرًا يُفَقِّهْهُ فِي الدِّينِ",
    narrator: "Narrated by Mu'awiyah ibn Abi Sufyan (RA)",
    text: "When Allah wills good for a person, He grants him deep comprehension of the religion.",
    category: "Wisdom & Insight",
    reference: "Sahih al-Bukhari 71, Sahih Muslim 1037",
    lesson: "Seek not just memorization, but true spiritual understanding of your faith and its values."
  }
];
