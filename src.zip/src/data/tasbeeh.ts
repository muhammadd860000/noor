export const commonAdhkars = [
  "SubhanAllah",
  "Alhamdulillah",
  "Allahu Akbar",
  "Astaghfirullah",
  "La ilaha illallah",
];
