export interface DuaItem {
  id: string;
  title: string;
  category: string;
  categoryName: string;
  arabic: string;
  transliteration: string;
  meaning: string;
  urdu?: string;
  reference: string;
  repetitions?: number;
  benefit?: string;
}

export interface DuaCategory {
  id: string;
  name: string;
  arabicName: string;
  icon: string;
  description: string;
  items: DuaItem[];
}

export const DUA_CATEGORIES: { id: string; name: string; arabicName: string; icon: string }[] = [
  { id: 'all', name: 'All Duas', arabicName: 'جميع الأدعية', icon: 'BookOpen' },
  { id: 'favorites', name: 'Bookmarked', arabicName: 'المفضلة', icon: 'Bookmark' },
  { id: 'daily-routine', name: 'Waking & Sleeping', arabicName: 'الاستيقاظ والنوم', icon: 'Sun' },
  { id: 'food-drink', name: 'Food & Eating', arabicName: 'الطعام والشراب', icon: 'Utensils' },
  { id: 'travel', name: 'Traveling & Journey', arabicName: 'السفر والركوب', icon: 'Compass' },
  { id: 'home-mosque', name: 'Home & Mosque', arabicName: 'المنزل والمسجد', icon: 'Home' },
  { id: 'morning-evening', name: 'Morning & Evening', arabicName: 'أذكار الصباح والمساء', icon: 'Moon' },
  { id: 'protection', name: 'Protection & Safety', arabicName: 'الحفظ والوقاية', icon: 'Shield' },
  { id: 'distress-relief', name: 'Distress & Relief', arabicName: 'الهم والفرج', icon: 'Heart' },
  { id: 'forgiveness', name: 'Forgiveness & Parents', arabicName: 'المغفرة والوالدين', icon: 'Sparkles' }
];

export const allDuas: DuaItem[] = [
  // --- WAKING & SLEEPING ---
  {
    id: 'dua-waking-up',
    title: 'Upon Waking Up',
    category: 'daily-routine',
    categoryName: 'Waking & Sleeping',
    arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ',
    transliteration: 'Alhamdu lillahilladhi ahyana ba\'da ma amatana wa ilayhin-nushur.',
    meaning: 'All praise is for Allah who gave us life after having taken it from us, and unto Him is the resurrection.',
    urdu: 'تمام تعریفیں اللہ کے لیے ہیں جس نے ہمیں مارنے کے بعد زندہ کیا اور اسی کی طرف لوٹ کر جانا ہے۔',
    reference: 'Sahih al-Bukhari 6312',
    repetitions: 1,
    benefit: 'Prophetic sunnah upon opening your eyes to begin your day with gratitude to the Creator.'
  },
  {
    id: 'dua-sleep-right-side',
    title: 'Before Sleeping (Lying on Right Side)',
    category: 'daily-routine',
    categoryName: 'Waking & Sleeping',
    arabic: 'بِاسْمِكَ رَبِّ وَضَعْتُ جَنْبِي، وَبِكَ أَرْفَعُهُ، فَإِنْ أَمْسَكْتَ نَفْسِي فَارْحَمْهَا، وَإِنْ أَرْسَلْتَهَا فَاحْفَظْهَا بِمَا تَحْفَظُ بِهِ عِبَادَكَ الصَّالِحِينَ',
    transliteration: 'Bismika Rabbi wadha\'tu janbi, wa bika arfa\'uhu, fain amsakta nafsi farhamha, wa in arsaltaha fahfazha bima tahfazu bihi \'ibadakas-salihin.',
    meaning: 'In Your name, my Lord, I lay down my side, and by Your grace I raise it. If You hold back my soul, have mercy upon it, and if You release it, protect it as You protect Your righteous servants.',
    urdu: 'اے میرے رب! تیرے نام سے میں نے اپنا پہلو رکھا اور تیرے ہی نام سے اسے اٹھاؤں گا۔ اگر تو میری جان روک لے تو اس پر رحم فرما، اور اگر اسے چھوڑ دے تو اس کی حفاظت فرما جس طرح تو اپنے نیک بندوں کی حفاظت فرماتا ہے۔',
    reference: 'Sahih al-Bukhari 6320 & Muslim 2714',
    repetitions: 1,
    benefit: 'Comprehensive protection throughout sleep and peace of heart.'
  },
  {
    id: 'dua-before-sleep-short',
    title: 'Short Supplication Before Sleeping',
    category: 'daily-routine',
    categoryName: 'Waking & Sleeping',
    arabic: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا',
    transliteration: 'Bismikallahumma amutu wa ahya.',
    meaning: 'In Your Name, O Allah, I die and I live.',
    urdu: 'اے اللہ! تیرے ہی نام کے ساتھ میں مرتا ہوں اور جیتا ہوں۔',
    reference: 'Sahih al-Bukhari 6324',
    repetitions: 1
  },

  // --- FOOD & EATING ---
  {
    id: 'dua-before-eating',
    title: 'Before Starting a Meal',
    category: 'food-drink',
    categoryName: 'Food & Eating',
    arabic: 'بِسْمِ اللَّهِ، اللَّهُمَّ بَارِكْ لَنَا فِيمَا رَزَقْتَنَا وَقِنَا عَذَابَ النَّارِ',
    transliteration: 'Bismillah, Allahumma barik lana fima razaqtana waqina \'adhaban-nar.',
    meaning: 'In the name of Allah. O Allah, bless for us that which You have provided for us, and save us from the punishment of the Fire.',
    urdu: 'اللہ کے نام سے۔ اے اللہ! جو رزق تو نے ہمیں دیا ہے اس میں برکت فرما اور ہمیں جہنم کے عذاب سے بچا۔',
    reference: 'Abu Dawud & Hisn al-Muslim',
    repetitions: 1,
    benefit: 'Brings barakah (blessings) to food and prevents Shaytan from partaking in the meal.'
  },
  {
    id: 'dua-forgot-bismillah',
    title: 'If You Forget to Say Bismillah at the Beginning',
    category: 'food-drink',
    categoryName: 'Food & Eating',
    arabic: 'بِسْمِ اللَّهِ أَوَّلَهُ وَآخِرَهُ',
    transliteration: 'Bismillahi awwalahu wa akhirahu.',
    meaning: 'In the name of Allah at its beginning and at its end.',
    urdu: 'اللہ کے نام سے اس کے اول اور آخر میں۔',
    reference: 'Sunan Abi Dawud 3767, at-Tirmidhi 1858',
    repetitions: 1,
    benefit: 'To be recited immediately when you remember you forgot to pronounce Bismillah before eating.'
  },
  {
    id: 'dua-after-eating',
    title: 'After Finishing a Meal',
    category: 'food-drink',
    categoryName: 'Food & Eating',
    arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ',
    transliteration: 'Alhamdu lillahilladhi at\'amana wa saqana wa ja\'alana muslimin.',
    meaning: 'All praise is due to Allah Who gave us food and drink, and made us Muslims.',
    urdu: 'تمام تعریفیں اللہ کے لیے ہیں جس نے ہمیں کھلایا اور پلایا اور ہمیں مسلمان بنایا۔',
    reference: 'Sunan Abi Dawud 3850, at-Tirmidhi 3457',
    repetitions: 1,
    benefit: 'The Prophet (ﷺ) said: "Allah is pleased with His servant who praises Him when eating a morsel or taking a drink."'
  },

  // --- TRAVELING & JOURNEY ---
  {
    id: 'dua-travel-vehicle',
    title: 'Upon Mounting a Vehicle / Starting a Journey',
    category: 'travel',
    categoryName: 'Traveling & Journey',
    arabic: 'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَٰذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ، وَإِنَّا إِلَىٰ رَبِّنَا لَمُنقَلِبُونَ',
    transliteration: 'Subhanalladhi sakh-khara lana hadha wa ma kunna lahu muqrinin, wa inna ila Rabbina lamunqalibun.',
    meaning: 'Glory be to Him Who has subjected this to our use, for we could never have accomplished it by ourselves; and surely unto our Lord we shall return.',
    urdu: 'پاک ہے وہ ذات جس نے اس کو ہمارے تابع کر دیا، حالانکہ ہم اسے قابو میں لانے والے نہ تھے، اور بے شک ہم اپنے رب ہی کی طرف لوٹ کر جانے والے ہیں۔',
    reference: 'Surah Az-Zukhruf 43:13-14 & Sahih Muslim 1342',
    repetitions: 1,
    benefit: 'Essential traveling prayer recited when boarding a car, plane, train, or ship.'
  },
  {
    id: 'dua-travel-journey-full',
    title: 'Comprehensive Traveler\'s Supplication',
    category: 'travel',
    categoryName: 'Traveling & Journey',
    arabic: 'اللَّهُمَّ إِنَّا نَسْأَلُكَ فِي سَفَرِنَا هَذَا الْبِرَّ وَالتَّقْوَى، وَمِنَ الْعَمَلِ مَا تَرْضَى، اللَّهُمَّ هَوِّنْ عَلَيْنَا سَفَرَنَا هَذَا وَاطْوِ عَنَّا بُعْدَهُ',
    transliteration: 'Allahumma inna nas\'aluka fi safarina hadhal-birra wat-taqwa, wa minal-\'amali ma tarda, Allahumma hawwin \'alayna safarana hadha watwi \'anna bu\'dah.',
    meaning: 'O Allah, we ask You on this journey of ours for righteousness and piety, and for deeds that please You. O Allah, make this journey easy for us and shorten its distance.',
    urdu: 'اے اللہ! ہم اپنے اس سفر میں تجھ سے نیکی اور تقویٰ کا سوال کرتے ہیں اور ایسے عمل کا جس سے تو راضی ہو۔ اے اللہ! ہم پر اس سفر کو آسان فرما دے اور اس کی دوری کو سمیٹ دے۔',
    reference: 'Sahih Muslim 1342',
    repetitions: 1
  },
  {
    id: 'dua-returning-travel',
    title: 'Upon Returning from Travel',
    category: 'travel',
    categoryName: 'Traveling & Journey',
    arabic: 'آيِبُونَ تَائِبُونَ عَابِدُونَ لِرَبِّنَا حَامِدُونَ',
    transliteration: 'Ayibuna ta\'ibuna \'abiduna li-Rabbina hamidun.',
    meaning: 'We return, repenting, worshipping, and praising our Lord.',
    urdu: 'ہم لوٹنے والے، توبہ کرنے والے، عبادت کرنے والے اور اپنے رب کی تعریف کرنے والے ہیں۔',
    reference: 'Sahih Muslim 1342',
    repetitions: 1
  },

  // --- HOME & MOSQUE ---
  {
    id: 'dua-leaving-home',
    title: 'Upon Leaving the Home',
    category: 'home-mosque',
    categoryName: 'Home & Mosque',
    arabic: 'بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',
    transliteration: 'Bismillahi, tawakkaltu \'alallah, wa la hawla wa la quwwata illa billah.',
    meaning: 'In the name of Allah, I place my trust in Allah; there is no might and no power except with Allah.',
    urdu: 'اللہ کے نام سے، میں نے اللہ پر بھروسہ کیا، اور گناہوں سے بچنے کی طاقت اور نیکی کرنے کی قوت صرف اللہ ہی کی مدد سے ہے۔',
    reference: 'Sunan Abi Dawud 5095, at-Tirmidhi 3426',
    repetitions: 1,
    benefit: 'The Prophet (ﷺ) said: "It will be said to him: You are guided, defended and protected, and Shaytan steps away from him."'
  },
  {
    id: 'dua-entering-home',
    title: 'Upon Entering the Home',
    category: 'home-mosque',
    categoryName: 'Home & Mosque',
    arabic: 'بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا',
    transliteration: 'Bismillahi walajna, wa bismillahi kharajna, wa \'alallahi Rabbina tawakkalna.',
    meaning: 'In the name of Allah we enter, and in the name of Allah we leave, and upon Allah our Lord we rely.',
    urdu: 'اللہ کے نام کے ساتھ ہم داخل ہوئے اور اللہ کے نام کے ساتھ ہم نکلے اور اپنے رب اللہ پر ہم نے بھروسہ کیا۔',
    reference: 'Sunan Abi Dawud 5096',
    repetitions: 1,
    benefit: 'Followed by greeting your household with "Assalamu Alaikum wa Rahmatullahi wa Barakatuh".'
  },
  {
    id: 'dua-entering-mosque',
    title: 'Upon Entering the Mosque',
    category: 'home-mosque',
    categoryName: 'Home & Mosque',
    arabic: 'اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ',
    transliteration: 'Allahummaf-tah li abwaba rahmatik.',
    meaning: 'O Allah, open for me the doors of Your mercy.',
    urdu: 'اے اللہ! میرے لیے اپنی رحمت کے دروازے کھول دے۔',
    reference: 'Sahih Muslim 713',
    repetitions: 1,
    benefit: 'Enter with the right foot forward while sending salawat upon the Prophet (ﷺ).'
  },
  {
    id: 'dua-leaving-mosque',
    title: 'Upon Leaving the Mosque',
    category: 'home-mosque',
    categoryName: 'Home & Mosque',
    arabic: 'اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ',
    transliteration: 'Allahumma inni as\'aluka min fadlik.',
    meaning: 'O Allah, I ask You from Your bounty.',
    urdu: 'اے اللہ! میں تجھ سے تیرے فضل کا سوال کرتا ہوں۔',
    reference: 'Sahih Muslim 713',
    repetitions: 1,
    benefit: 'Step out with the left foot first into the world seeking halal provision.'
  },

  // --- MORNING & EVENING ---
  {
    id: 'dua-sayyid-al-istighfar',
    title: 'Sayyid al-Istighfar (The Master Supplication for Forgiveness)',
    category: 'morning-evening',
    categoryName: 'Morning & Evening',
    arabic: 'اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ',
    transliteration: 'Allahumma Anta Rabbi la ilaha illa Ant, khalaqtani wa ana \'abduk, wa ana \'ala \'ahdika wa wa\'dika mastata\'t, a\'udhu bika min sharri ma sana\'t, abu\'u laka bini\'matika \'alayy, wa abu\'u laka bidhanbi faghfir li fainnahu la yaghfirudh-dhunuba illa Ant.',
    meaning: 'O Allah, You are my Lord; there is no deity worthy of worship except You. You created me and I am Your servant, and I abide by Your covenant and promise as best I can. I seek refuge in You from the evil of what I have done. I acknowledge Your blessing upon me, and I acknowledge my sin, so forgive me, for none forgives sins except You.',
    urdu: 'اے اللہ! تو میرا رب ہے، تیرے سوا کوئی معبود نہیں، تو نے مجھے پیدا کیا اور میں تیرا بندہ ہوں، اور میں اپنی طاقت کے مطابق تیرے عہد اور وعدے پر قائم ہوں۔ میں اپنے کیے کے شر سے تیری پناہ مانگتا ہوں۔ میں اپنے اوپر تیری نعمتوں کا اعتراف کرتا ہوں اور اپنے گناہوں کا اعتراف کرتا ہوں، پس مجھے بخش دے کیونکہ تیرے سوا کوئی گناہوں کو نہیں بخش سکتا۔',
    reference: 'Sahih al-Bukhari 6306',
    repetitions: 1,
    benefit: 'The Prophet (ﷺ) said: "Whoever recites it during the day with conviction and dies before evening, or recites it at night and dies before morning, will be among the people of Paradise."'
  },
  {
    id: 'dua-morning-bika-asbahna',
    title: 'Morning Remembrance of Life and Creation',
    category: 'morning-evening',
    categoryName: 'Morning & Evening',
    arabic: 'اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ',
    transliteration: 'Allahumma bika asbahna, wa bika amsayna, wa bika nahya, wa bika namutu, wa ilaykan-nushur.',
    meaning: 'O Allah, by You we enter the morning and by You we enter the evening, by You we live and by You we die, and to You is the Resurrection.',
    urdu: 'اے اللہ! تیرے ہی حکم سے ہم نے صبح کی، اور تیرے ہی حکم سے ہم نے شام کی، اور تیرے ہی حکم سے ہم جیتے ہیں، اور تیرے ہی حکم سے ہم مریں گے، اور تیری ہی طرف لوٹ کر جانا ہے۔',
    reference: 'Jami\' at-Tirmidhi 3391',
    repetitions: 1
  },
  {
    id: 'dua-evening-amsayna',
    title: 'Evening Remembrance of Sovereignty',
    category: 'morning-evening',
    categoryName: 'Morning & Evening',
    arabic: 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
    transliteration: 'Amsayna wa amsal-mulku lillah, walhamdu lillah, la ilaha illallahu wahdahu la sharika lah, lahul-mulku wa lahul-hamdu wa Huwa \'ala kulli shay\'in Qadir.',
    meaning: 'We have entered the evening and the kingdom belongs to Allah, and praise is to Allah. There is none worthy of worship but Allah alone without partner. His is the sovereignty and His is the praise, and He has power over all things.',
    urdu: 'ہم نے شام کی اور تمام بادشاہت اللہ ہی کی رہی اور سب تعریف اللہ ہی کے لیے ہے، اللہ کے سوا کوئی معبود نہیں، وہ اکیلا ہے اس کا کوئی شریک نہیں، اسی کی بادشاہی ہے اور اسی کی حمد ہے اور وہ ہر چیز پر قادر ہے۔',
    reference: 'Sahih Muslim 2723',
    repetitions: 1
  },

  // --- PROTECTION & SAFETY ---
  {
    id: 'dua-protection-harm',
    title: 'Protection from Harm on Earth & Sky',
    category: 'protection',
    categoryName: 'Protection & Safety',
    arabic: 'بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ',
    transliteration: 'Bismillahil-ladhi la yadurru ma\'asmihi shay\'un fil-ardi wa la fis-sama\'i wa Huwas-Sami\'ul-\'Alim.',
    meaning: 'In the Name of Allah, with Whose Name nothing on earth or in heaven can cause harm, and He is the All-Hearing, the All-Knowing.',
    urdu: 'اللہ کے نام سے جس کے نام کی برکت سے زمین اور آسمان کی کوئی چیز نقصان نہیں پہنچا سکتی اور وہی خوب سننے والا جاننے والا ہے۔',
    reference: 'Sunan Abi Dawud 5088, at-Tirmidhi 3388',
    repetitions: 3,
    benefit: 'The Prophet (ﷺ) said: "Whoever recites it three times in the morning and evening, nothing will harm him."'
  },
  {
    id: 'dua-refuge-perfect-words',
    title: 'Seeking Refuge in Allah\'s Perfect Words',
    category: 'protection',
    categoryName: 'Protection & Safety',
    arabic: 'أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ',
    transliteration: 'A\'udhu bi kalimatillahit-tammati min sharri ma khalaq.',
    meaning: 'I seek refuge in the perfect words of Allah from the evil of what He has created.',
    urdu: 'میں اللہ کے مکمل کلمات کے ذریعے اس کی پیدا کردہ تمام مخلوق کے شر سے پناہ مانگتا ہوں۔',
    reference: 'Sahih Muslim 2708',
    repetitions: 3,
    benefit: 'Shields against poisonous insects, illnesses, harmful creatures, and human envy.'
  },

  // --- DISTRESS & RELIEF ---
  {
    id: 'dua-yunus-distress',
    title: 'Du\'a of Prophet Yunus (For Any Distress or Hardship)',
    category: 'distress-relief',
    categoryName: 'Distress & Relief',
    arabic: 'لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ',
    transliteration: 'La ilaha illa Anta subhanaka inni kuntu minaz-zalimeen.',
    meaning: 'There is no deity worthy of worship except You; exalted are You! Indeed, I have been of the wrongdoers.',
    urdu: 'تیرے سوا کوئی معبود نہیں، تو پاک ہے، بے شک میں ہی ظالموں میں سے تھا۔',
    reference: 'Surah Al-Anbiya 21:87 & at-Tirmidhi 3505',
    repetitions: 1,
    benefit: 'The Prophet (ﷺ) said: "No Muslim supplicates with this in any matter except that Allah answers his call."'
  },
  {
    id: 'dua-anxiety-grief-debt',
    title: 'Relief from Anxiety, Sorrow, and Debts',
    category: 'distress-relief',
    categoryName: 'Distress & Relief',
    arabic: 'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ، وَالْعَجْزِ وَالْكَسَلِ، وَالْبُخْلِ وَالْجُبْنِ، وَضَلَعِ الدَّيْنِ وَغَلَبَةِ الرِّجَالِ',
    transliteration: 'Allahumma inni a\'udhu bika minal-hammi wal-hazan, wal-\'ajzi wal-kasal, wal-bukhli wal-jubn, wa dala\'id-dayni wa ghalabatir-rijal.',
    meaning: 'O Allah, I seek refuge in You from grief and sorrow, from incapacity and laziness, from miserliness and cowardice, from the burden of debt and from being overpowered by men.',
    urdu: 'اے اللہ! میں غم اور پریشانی سے، عاجزی اور سستی سے، بخل اور بزدلی سے، اور قرض کے بوجھ اور لوگوں کے دباؤ سے تیری پناہ مانگتا ہوں۔',
    reference: 'Sahih al-Bukhari 2893',
    repetitions: 1
  },
  {
    id: 'dua-ease-difficulty',
    title: 'When Facing Something Difficult',
    category: 'distress-relief',
    categoryName: 'Distress & Relief',
    arabic: 'اللَّهُمَّ لَا سَهْلَ إِلَّا مَا جَعَلْتَهُ سَهْلًا، وَأَنْتَ تَجْعَلُ الْحَزْنَ إِذَا شِئْتَ سَهْلًا',
    transliteration: 'Allahumma la sahla illa ma ja\'altahu sahla, wa Anta taj\'alul-hazna idha shi\'ta sahla.',
    meaning: 'O Allah, nothing is easy except what You make easy, and You can make sorrow and difficulty easy if You will.',
    urdu: 'اے اللہ! کوئی چیز آسان نہیں سوائے اس کے جسے تو آسان بنا دے، اور جب تو چاہے تو غم و مشکل کو آسان کر دیتا ہے۔',
    reference: 'Sahih Ibn Hibban 974',
    repetitions: 1,
    benefit: 'Recite during exams, interviews, difficult conversations, or health trials.'
  },

  // --- FORGIVENESS & PARENTS ---
  {
    id: 'dua-parents',
    title: 'Supplication for Parents (Mercy in Old Age)',
    category: 'forgiveness',
    categoryName: 'Forgiveness & Parents',
    arabic: 'رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا',
    transliteration: 'Rabbir-hamhuma kama rabbayani sagheera.',
    meaning: 'My Lord, have mercy upon them as they brought me up when I was small.',
    urdu: 'اے میرے رب! ان دونوں پر رحم فرما جس طرح انہوں نے مجھے بچپن میں پالا تھا۔',
    reference: 'Surah Al-Isra 17:24',
    repetitions: 1,
    benefit: 'The most sublime Quranic prayer for your mother and father, living or departed.'
  },
  {
    id: 'dua-dunya-akhirah',
    title: 'The Most Frequent Prophetic Supplication (Goodness in Both Worlds)',
    category: 'forgiveness',
    categoryName: 'Forgiveness & Parents',
    arabic: 'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ',
    transliteration: 'Rabbana atina fid-dunya hasanatan wa fil-akhirati hasanatan wa qina \'adhaban-nar.',
    meaning: 'Our Lord, give us in this world that which is good and in the Hereafter that which is good, and protect us from the punishment of the Fire.',
    urdu: 'اے ہمارے رب! ہمیں دنیا میں بھی بھلائی عطا فرما اور آخرت میں بھی بھلائی عطا فرما اور ہمیں آگ کے عذاب سے بچا۔',
    reference: 'Surah Al-Baqarah 2:201 & Sahih al-Bukhari 6389',
    repetitions: 1
  }
];

// Helper to get bookmarked dua IDs from localStorage
export const getBookmarkedDuaIds = (): string[] => {
  if (typeof window === 'undefined') return [];
  try {
    const saved = localStorage.getItem('noor_bookmarked_duas');
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
};

// Helper to save bookmarked dua IDs to localStorage
export const saveBookmarkedDuaIds = (ids: string[]): void => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem('noor_bookmarked_duas', JSON.stringify(ids));
    window.dispatchEvent(new CustomEvent('dua-bookmarks-changed', { detail: ids }));
  } catch (e) {
    console.warn(e);
  }
};

// Helper for backward compatibility with previous duaCategories
export const duaCategories = DUA_CATEGORIES.filter(c => c.id !== 'all' && c.id !== 'favorites').map(cat => ({
  id: cat.id,
  name: cat.name,
  items: allDuas.filter(d => d.category === cat.id)
}));
