export const reflections = [
    { title: "Gratitude", content: "Whatever blessing you have, it is from Allah. Being grateful attracts more." },
    { title: "Patience", content: "Indeed, Allah is with the patient." },
    { title: "Trust", content: "Place your trust in Allah, for He is the best of planners." },
    { title: "Hope", content: "Do not despair of the mercy of Allah." },
    { title: "Reflection", content: "He who knows himself, knows his Lord." }
];
