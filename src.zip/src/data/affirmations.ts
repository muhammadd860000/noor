export interface IslamicAffirmation {
  id: string;
  affirmation: string;
  arabic?: string;
  transliteration?: string;
  source: string;
  theme: 'Tawakkul & Trust' | 'Peace & Tranquility' | 'Hope & Mercy' | 'Patience & Strength' | 'Gratitude & Abundance' | 'Self-Worth & Dignity' | 'Healing & Comfort';
  themeColor: string;
  practicalAction: string;
}

export const ISLAMIC_AFFIRMATIONS: IslamicAffirmation[] = [
  {
    id: 'aff-1',
    affirmation: 'Allah has placed immense dignity within my soul. I do not need the validation of people when I have the love and care of my Creator.',
    arabic: 'وَلَقَدْ كَرَّمْنَا بَنِي آدَمَ',
    transliteration: 'Wa laqad karramna bani Adama',
    source: 'Surah Al-Isra (17:70)',
    theme: 'Self-Worth & Dignity',
    themeColor: 'from-amber-500/20 to-amber-900/10 text-amber-400 border-amber-500/30',
    practicalAction: 'Walk with calm confidence today, knowing your true worth is defined by your Creator, not external judgments.'
  },
  {
    id: 'aff-2',
    affirmation: 'I release my worries to Allah. What is meant for me will never miss me, and what missed me was never meant to harm me.',
    arabic: 'حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ',
    transliteration: 'HasbunAllahu wa ni\'mal wakeel',
    source: 'Surah Ali \'Imran (3:173)',
    theme: 'Tawakkul & Trust',
    themeColor: 'from-emerald-500/20 to-emerald-900/10 text-emerald-400 border-emerald-500/30',
    practicalAction: 'Take a deep breath and consciously hand over one heavy concern in your heart to Allah through sincere Dua.'
  },
  {
    id: 'aff-3',
    affirmation: 'Every hardship I endure is actively purifying my heart and elevating my rank in the sight of Allah.',
    arabic: 'مَا يُصِيبُ الْمُسْلِمَ مِنْ نَصَبٍ وَلاَ وَصَبٍ إِلاَّ كَفَّرَ اللَّهُ بِهِ مِنْ خَطَايَاهُ',
    transliteration: 'Ma yuseebul-Muslima min nasabin wa la wasabin illa kaffarAllahu bihi min khatayahu',
    source: 'Sahih al-Bukhari (5641)',
    theme: 'Patience & Strength',
    themeColor: 'from-blue-500/20 to-blue-900/10 text-blue-400 border-blue-500/30',
    practicalAction: 'When frustrated or tired today, say "Alhamdulillah ‘ala kulli hal" (All praise is due to Allah in every condition).'
  },
  {
    id: 'aff-4',
    affirmation: 'Allah\'s mercy is vaster than all of my shortcomings. Today is a fresh beginning to return to Him with hope.',
    arabic: 'إِنَّ رَحْمَتِي سَبَقَتْ غَضَبِي',
    transliteration: 'Inna rahmatee sabaqat ghadabee',
    source: 'Sahih Muslim (2751)',
    theme: 'Hope & Mercy',
    themeColor: 'from-rose-500/20 to-rose-900/10 text-rose-400 border-rose-500/30',
    practicalAction: 'Forgive yourself for past mistakes and whisper a sincere "Astaghfirullah" with full certainty of His forgiveness.'
  },
  {
    id: 'aff-5',
    affirmation: 'My heart is at total peace because Allah is closer to me than my own jugular vein. I am never alone.',
    arabic: 'وَنَحْنُ أَقْرَبُ إِلَيْهِ مِنْ حَبْلِ الْوَرِيدِ',
    transliteration: 'Wa nahnu aqrabu ilayhi min hablil wareed',
    source: 'Surah Qaf (50:16)',
    theme: 'Peace & Tranquility',
    themeColor: 'from-indigo-500/20 to-indigo-900/10 text-indigo-400 border-indigo-500/30',
    practicalAction: 'Spend 2 quiet minutes in silent contemplation after your next prayer feeling Allah\'s divine nearness.'
  },
  {
    id: 'aff-6',
    affirmation: 'Gratitude multiplies every blessing in my life. I have countless unseen gifts to celebrate today.',
    arabic: 'لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ',
    transliteration: 'La\'in shakartum la\'azeedannakum',
    source: 'Surah Ibrahim (14:7)',
    theme: 'Gratitude & Abundance',
    themeColor: 'from-yellow-500/20 to-yellow-900/10 text-yellow-400 border-yellow-500/30',
    practicalAction: 'Name 3 distinct blessings in your life right now that money cannot buy.'
  },
  {
    id: 'aff-7',
    affirmation: 'With every difficulty, ease is already unfolding. I will navigate this season with grace and faith.',
    arabic: 'فَإِنَّ مَعَ الْعُسْرِ يُسْرًا · إِنَّ مَعَ الْعُسْرِ يُسْرًا',
    transliteration: 'Fa inna ma\'al \'usri yusra, Inna ma\'al \'usri yusra',
    source: 'Surah Ash-Sharh (94:5-6)',
    theme: 'Healing & Comfort',
    themeColor: 'from-teal-500/20 to-teal-900/10 text-teal-400 border-teal-500/30',
    practicalAction: 'Look back at past challenges Allah brought you through as proof that this too will pass with ease.'
  },
  {
    id: 'aff-8',
    affirmation: 'I am capable of doing good and leaving a gentle, positive footprint in the lives of everyone I meet today.',
    arabic: 'وَأَحْسِنُوا إِنَّ اللَّهَ يُحِبُّ الْمُحْسِنِينَ',
    transliteration: 'Wa ahsinu inna Allaha yuhibbul muhsineen',
    source: 'Surah Al-Baqarah (2:195)',
    theme: 'Self-Worth & Dignity',
    themeColor: 'from-purple-500/20 to-purple-900/10 text-purple-400 border-purple-500/30',
    practicalAction: 'Offer a genuine smile, a kind greeting (Salam), or a helpful gesture to someone without expecting anything in return.'
  },
  {
    id: 'aff-9',
    affirmation: 'My Rizq (sustenance) is guaranteed and written by the Most Generous. I work diligently with a serene heart.',
    arabic: 'وَمَا مِن دَابَّةٍ فِي الْأَرْضِ إِلَّا عَلَى اللَّهِ رِزْقُهَا',
    transliteration: 'Wa ma min dabbatin fil ardi illa \'alallahi rizquha',
    source: 'Surah Hud (11:6)',
    theme: 'Tawakkul & Trust',
    themeColor: 'from-amber-500/20 to-amber-900/10 text-amber-400 border-amber-500/30',
    practicalAction: 'Replace financial scarcity mindset with gratitude for the sustenance already in your hands.'
  },
  {
    id: 'aff-10',
    affirmation: 'Allah does not burden my soul beyond what I can bear. I have been gifted the strength needed for today.',
    arabic: 'لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا',
    transliteration: 'La yukallifullahu nafsan illa wus\'aha',
    source: 'Surah Al-Baqarah (2:286)',
    theme: 'Patience & Strength',
    themeColor: 'from-sky-500/20 to-sky-900/10 text-sky-400 border-sky-500/30',
    practicalAction: 'Remind yourself whenever you feel overwhelmed: "Allah equipped me for this moment, and His help is near."'
  }
];

export function getDailyAffirmation(date: Date = new Date()): IslamicAffirmation {
  const dayOfYear = Math.floor((date.getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / 86400000);
  return ISLAMIC_AFFIRMATIONS[dayOfYear % ISLAMIC_AFFIRMATIONS.length];
}
