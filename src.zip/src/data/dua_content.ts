export const duas = [
    { title: "For Ease", arabic: "رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي", meaning: "My Lord, expand for me my chest with assurance, and ease for me my task." },
    { title: "For Forgiveness", arabic: "رَبِّ اغْفِرْ لِي وَلِوَالِدَيَّ", meaning: "My Lord, forgive me and my parents." },
    { title: "For Guidance", arabic: "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ", meaning: "Guide us to the straight path." },
    { title: "For Provision", arabic: "اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا وَرِزْقًا طَيِّبًا وَعَمَلًا مُتَقَبَّلًا", meaning: "O Allah, I ask You for beneficial knowledge, good provision, and accepted deeds." },
    { title: "For Protection", arabic: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", meaning: "In the name of Allah, with whose name nothing on earth or in the sky can cause harm, and He is the Hearing, the Knowing." }
];
