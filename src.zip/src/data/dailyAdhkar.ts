export interface DailyDhikrItem {
  id: string;
  title: string;
  arabic: string;
  transliteration: string;
  translation: string;
  meaning?: string;
  category: 'Tasbeeh' | 'Istighfar' | 'Salawat' | 'Tahmeed' | 'Tawheed' | 'Du\'a' | 'Protection';
  timeOfDay: 'morning' | 'evening' | 'both';
  targetCount: number;
  virtue: string;
  source: string;
  reflectionQuestion?: string;
}

export const dailyAdhkarList: DailyDhikrItem[] = [
  {
    id: "allahumma-inni-asaluka-ilman",
    title: "The Morning Purpose & Provision",
    arabic: "اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا",
    transliteration: "Allāhumma innī as’aluka ‘ilman nāfi‘an, wa rizqan ṭayyiban, wa ‘amalan mutaqabbalā",
    translation: "O Allah, I ask You for beneficial knowledge, good and pure provision, and deeds that are accepted.",
    meaning: "The Prophet's morning supplication asking for wisdom that elevates, sustenance that is wholesome, and actions that please Allah.",
    category: "Du'a",
    timeOfDay: "morning",
    targetCount: 7,
    virtue: "A daily morning prayer taught by the Prophet (ﷺ) after Fajr that anchors our pursuits in pure intention.",
    source: "Sunan Ibn Majah 925",
    reflectionQuestion: "Before your day begins, align your intention: what beneficial knowledge or wholesome action will you nurture today?"
  },
  {
    id: "bismillahilladhi-la-yadurru",
    title: "The Divine Shield & Protection",
    arabic: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",
    transliteration: "Bismillāhilladhī lā yaḍurru ma‘asmihi shay’un fil-arḍi wa lā fis-samā’i wa Huwas-Samī‘ul-‘Alīm",
    translation: "In the Name of Allah with Whose Name nothing in the earth or the heavens can cause harm, and He is the All-Hearing, All-Knowing.",
    meaning: "Seeking refuge under the supreme majesty of Allah's Name against all seen and unseen tribulations.",
    category: "Protection",
    timeOfDay: "morning",
    targetCount: 3,
    virtue: "Whoever repeats this three times at the beginning of day and night will be shielded from sudden affliction and harm.",
    source: "Sunan at-Tirmidhi 3388",
    reflectionQuestion: "Stepping into the day remembering Allah transforms vulnerability into courageous confidence."
  },
  {
    id: "hasbiyallahu-la-ilaha",
    title: "Sufficiency in Allah (Morning Shield)",
    arabic: "حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ، عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ",
    transliteration: "Ḥasbiyallāhu lā ilāha illā Huwa, ‘alayhi tawakkaltu wa Huwa Rabbul-‘Arshil-‘Aẓīm",
    translation: "Sufficient for me is Allah; there is no deity except Him. Upon Him I have relied, and He is the Lord of the Tremendous Throne.",
    meaning: "Affirming that Allah alone is enough to protect, fulfill, and comfort the soul through any trial.",
    category: "Protection",
    timeOfDay: "morning",
    targetCount: 7,
    virtue: "Whoever recites this seven times in the morning and evening, Allah will suffice them in all that distresses or concerns them.",
    source: "Sunan Abi Dawud 5081",
    reflectionQuestion: "Breathe gently and whisper: 'Allah is enough for me.' Feel anxiety give way to quiet trust."
  },
  {
    id: "sayyidul-istighfar",
    title: "The Master of Forgiveness (Sayyidul-Istighfar)",
    arabic: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ",
    transliteration: "Allāhumma Anta Rabbī lā ilāha illā Ant, khalaqtanī wa anā ‘abduk, wa anā ‘alā ‘ahdika wa wa‘dika mastata‘t, a‘ūdhu bika min sharri mā ṣana‘t, abū’u laka bi-ni‘matika ‘alay, wa abū’u laka bi-dhanbī faghfir lī fa-innahu lā yaghfirudh-dhunūba illā Ant",
    translation: "O Allah, You are my Lord; there is no deity except You. You created me and I am Your servant, and I abide by Your covenant as best I can. I seek refuge in You from the evil of what I have done. I acknowledge Your blessing upon me, and I confess my sin, so forgive me, for none forgives sins except You.",
    meaning: "The pinnacle prayer of repentance acknowledging Allah's boundless favors alongside our human imperfection.",
    category: "Istighfar",
    timeOfDay: "both",
    targetCount: 1,
    virtue: "Known as Sayyidul-Istighfar. Whoever recites it during the morning or evening with conviction and passes away will be among the people of Paradise.",
    source: "Sahih al-Bukhari 6306",
    reflectionQuestion: "Contemplate how recognizing Allah's overwhelming favors makes humility and repentance feel natural and uplifting."
  },
  {
    id: "subhanallah-wa-bihamdihi",
    title: "Praise & Divine Majesty (Evening Calm)",
    arabic: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ",
    transliteration: "Subḥānallāhi wa biḥamdih, Subḥānallāhil-‘Aẓīm",
    translation: "Glory be to Allah and His is the praise; Glory be to Allah the Most Supreme.",
    meaning: "Exalting Allah above any deficiency while giving Him full praise, affirming His absolute greatness.",
    category: "Tasbeeh",
    timeOfDay: "both",
    targetCount: 33,
    virtue: "Two phrases that are light on the tongue, heavy in the scales of good deeds, and beloved to the Most Merciful.",
    source: "Sahih al-Bukhari 6682",
    reflectionQuestion: "How can pausing to acknowledge Allah's boundless perfection bring peace to your mind right now?"
  },
  {
    id: "la-hawla-wa-la-quwwata",
    title: "Reliance & Inner Surrender (Evening Peace)",
    arabic: "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ",
    transliteration: "Lā ḥawla wa lā quwwata illā billāhil-‘Aliyyil-‘Aẓīm",
    translation: "There is no might nor power except with Allah, the Most High, the Most Great.",
    meaning: "No state can change and no obstacle can be overcome except through the power granted by Allah.",
    category: "Tawheed",
    timeOfDay: "evening",
    targetCount: 33,
    virtue: "A precious treasure from beneath the Throne of Allah in Paradise, freeing the heart from the burden of self-reliance.",
    source: "Sahih al-Bukhari 4205",
    reflectionQuestion: "What heavy burden or worry can you consciously surrender into Allah's capable hands today?"
  },
  {
    id: "astaghfirullah-wa-atoobu",
    title: "Evening Repentance & Cleansing",
    arabic: "أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ",
    transliteration: "Astaghfirullāhal-‘Aẓīm alladhī lā ilāha illā Huwal-Ḥayyul-Qayyūmu wa atūbu ilayh",
    translation: "I seek forgiveness from Allah the Magnificent, besides Whom there is no deity, the Ever-Living, the Sustainer, and I repent unto Him.",
    meaning: "Cleansing the spiritual heart from all errors and returning with humility to the Ever-Forgiving Creator.",
    category: "Istighfar",
    timeOfDay: "evening",
    targetCount: 33,
    virtue: "Whoever recites this, their missteps will be forgiven, opening doors to spiritual clarity and unexpected provision.",
    source: "Sunan Abi Dawud 1517",
    reflectionQuestion: "Remember that repentance is not defeat; it is the ultimate homecoming to the One who loves to forgive."
  },
  {
    id: "salawat-prophet",
    title: "Blessings upon the Messenger",
    arabic: "اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى نَبِيِّنَا مُحَمَّدٍ",
    transliteration: "Allāhumma ṣalli wa sallim wa bārik ‘alā Nabiyyinā Muḥammad",
    translation: "O Allah, send prayers, peace, and blessings upon our Prophet Muhammad.",
    meaning: "Sending salutations of love and honor to the Prophet Muhammad (peace be upon him) who conveyed the message of guidance.",
    category: "Salawat",
    timeOfDay: "both",
    targetCount: 10,
    virtue: "Whoever sends blessings upon the Prophet once, Allah sends ten blessings upon them, erases ten sins, and raises them ten spiritual ranks.",
    source: "Sunan an-Nasa'i 1297",
    reflectionQuestion: "Contemplate the Prophet's compassion and patience. Which of his qualities can you bring into your day?"
  },
  {
    id: "ya-hayyu-ya-qayyum",
    title: "Seeking Divine Care (Morning & Evening)",
    arabic: "يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ، أَصْلِحْ لِي شَأْنِي كُلَّهُ، وَلَا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ",
    transliteration: "Yā Ḥayyu yā Qayyūm, bi-raḥmatika astaghīth, aṣliḥ lī sha’nī kullah, wa lā takilnī ilā nafsī ṭarfata ‘ayn",
    translation: "O Ever-Living, O Sustainer! In Your mercy I seek relief; rectify for me all my affairs, and do not leave me to myself even for the blink of an eye.",
    meaning: "Calling upon Allah's living presence and sustaining power to guide our choices and mend our circumstances.",
    category: "Du'a",
    timeOfDay: "both",
    targetCount: 7,
    virtue: "The Prophet (ﷺ) instructed his daughter Fatimah to recite this every morning and evening as a comprehensive shield and plea for guidance.",
    source: "Mustadrak al-Hakim 2000",
    reflectionQuestion: "Take comfort in knowing that the One who sustains the heavens and the earth is intimately sustaining your heartbeat right now."
  },
  {
    id: "radheetu-billahi-rabba",
    title: "Contentment with Divine Decree",
    arabic: "رَضِيتُ بِاللَّهِ رَبًّا، وَبِالإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا",
    transliteration: "Raḍītu billāhi Rabbā, wa bil-Islāmi dīnā, wa bi-Muḥammadin (ṣallallāhu ‘alayhi wa sallam) nabiyyā",
    translation: "I am pleased with Allah as my Lord, Islam as my faith, and Muhammad (peace and blessings be upon him) as my Prophet.",
    meaning: "Declaring wholehearted contentment with Allah's lordship, His religion, and the guidance of His Messenger.",
    category: "Tawheed",
    timeOfDay: "both",
    targetCount: 3,
    virtue: "The Prophet (ﷺ) promised that whoever recites this with sincere conviction, it is a right upon Allah to please them on the Day of Judgment.",
    source: "Sunan at-Tirmidhi 3389",
    reflectionQuestion: "Contentment is not having everything we want, but trusting that Allah gives us exactly what our soul needs."
  }
];

/**
 * Determines current Islamic time of day: 'morning' (Fajr to Dhuhr/Asr) vs 'evening' (Asr to Night)
 */
export function getCurrentTimeOfDay(date: Date = new Date()): 'morning' | 'evening' {
  const hours = date.getHours();
  // Before 3:00 PM (15:00) is considered morning/daytime, after 15:00 is evening
  return hours < 15 ? 'morning' : 'evening';
}

/**
 * Gets suggested Daily Dhikr for a specific date and time slot
 */
export function getDailyDhikrForDate(
  date: Date = new Date(),
  slot?: 'morning' | 'evening'
): DailyDhikrItem {
  const currentSlot = slot || getCurrentTimeOfDay(date);
  const matchingAdhkar = dailyAdhkarList.filter(
    d => d.timeOfDay === currentSlot || d.timeOfDay === 'both'
  );

  const pool = matchingAdhkar.length > 0 ? matchingAdhkar : dailyAdhkarList;
  const startOfYear = new Date(date.getFullYear(), 0, 0);
  const diff = date.getTime() - startOfYear.getTime();
  const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));

  return pool[dayOfYear % pool.length];
}
