export type QuestionCategory = 'Quran' | 'Seerah' | 'History' | 'Prophets';
export type QuestionDifficulty = 'Easy' | 'Medium' | 'Advanced';

export interface QuizQuestion {
  id: number;
  category: QuestionCategory;
  difficulty: QuestionDifficulty;
  question: string;
  options: string[];
  answer: number; // 0-indexed
  explanation: string;
  reference?: string;
}

export const quizQuestions: QuizQuestion[] = [
  {
    id: 1,
    category: 'Quran',
    difficulty: 'Easy',
    question: 'How many Surahs (chapters) are there in the Holy Quran?',
    options: ['110', '112', '114', '116'],
    answer: 2,
    explanation: 'The Holy Quran consists of 114 Surahs, starting with Surah Al-Fatihah and concluding with Surah An-Nas.',
    reference: 'Traditional Quranic structure'
  },
  {
    id: 2,
    category: 'Quran',
    difficulty: 'Easy',
    question: 'What was the very first word of the Quran revealed to Prophet Muhammad (ﷺ)?',
    options: ['Al-Hamd', 'Iqra (Read/Recite)', 'Qul (Say)', 'Bismillah'],
    answer: 1,
    explanation: 'The first revelation delivered by Archangel Jibril in the Cave of Hira began with "Iqra" (Read/Recite in the Name of your Lord who created).',
    reference: 'Surah Al-Alaq 96:1'
  },
  {
    id: 3,
    category: 'Seerah',
    difficulty: 'Easy',
    question: 'Who was the first person to embrace Islam and believe in the Prophet\'s message?',
    options: ['Abu Bakr as-Siddiq', 'Ali ibn Abi Talib', 'Khadijah bint Khuwaylid', 'Zayd ibn Harithah'],
    answer: 2,
    explanation: 'Khadijah bint Khuwaylid (may Allah be pleased with her), the beloved wife of the Prophet, was the very first person to accept Islam and comfort him after the first revelation.',
    reference: 'Sahih al-Bukhari 3'
  },
  {
    id: 4,
    category: 'Quran',
    difficulty: 'Medium',
    question: 'Which Surah does not begin with the Basmalah ("Bismillahir-Rahmanir-Rahim")?',
    options: ['Surah At-Tawbah', 'Surah Al-Anfal', 'Surah Al-Hajj', 'Surah Al-Qiyamat'],
    answer: 0,
    explanation: 'Surah At-Tawbah (Chapter 9) is the only Surah in the Quran without the Basmalah at its opening, as it opens with a stern declaration of disassociation from treaty violators.',
    reference: 'Surah At-Tawbah 9:1'
  },
  {
    id: 5,
    category: 'History',
    difficulty: 'Easy',
    question: 'Who was elected as the first Caliph (successor) of the Muslim community after the Prophet\'s passing?',
    options: ['Umar ibn al-Khattab', 'Ali ibn Abi Talib', 'Abu Bakr as-Siddiq', 'Uthman ibn Affan'],
    answer: 2,
    explanation: 'Abu Bakr as-Siddiq (may Allah be pleased with him) was chosen by consensus at Saqifah Bani Sa\'idah as the first Rightly Guided Caliph.',
    reference: 'Early Islamic history'
  },
  {
    id: 6,
    category: 'Quran',
    difficulty: 'Medium',
    question: 'Which Surah contains two Basmalahs ("Bismillahir-Rahmanir-Rahim")?',
    options: ['Surah Al-Baqarah', 'Surah An-Naml', 'Surah Al-Kahf', 'Surah Maryam'],
    answer: 1,
    explanation: 'Surah An-Naml contains two Basmalahs: one at its very beginning, and another in verse 30 in the letter sent by Prophet Sulaiman to Queen Bilqis of Sheba.',
    reference: 'Surah An-Naml 27:30'
  },
  {
    id: 7,
    category: 'Prophets',
    difficulty: 'Easy',
    question: 'Which Prophet is mentioned most frequently by name in the Holy Quran?',
    options: ['Prophet Ibrahim', 'Prophet Musa (Moses)', 'Prophet Isa (Jesus)', 'Prophet Nuh (Noah)'],
    answer: 1,
    explanation: 'Prophet Musa (peace be upon him) is mentioned by name over 130 times across various Surahs in the Holy Quran.',
    reference: 'Quranic concordance'
  },
  {
    id: 8,
    category: 'Quran',
    difficulty: 'Easy',
    question: 'What is the greatest Ayah in the Quran, as confirmed by the Prophet (ﷺ)?',
    options: ['Ayat al-Kursi', 'Ayat ad-Dayn', 'Ayat an-Nur', 'Ayat ash-Shifa'],
    answer: 0,
    explanation: 'Ayat al-Kursi (The Verse of the Throne, Surah Al-Baqarah 2:255) is the greatest verse in the Quran, glorifying Allah\'s eternal life and supreme dominion.',
    reference: 'Sahih Muslim 810'
  },
  {
    id: 9,
    category: 'History',
    difficulty: 'Medium',
    question: 'In which year of the Islamic calendar (Hijrah) did the decisive Battle of Badr take place?',
    options: ['1 AH', '2 AH', '3 AH', '5 AH'],
    answer: 1,
    explanation: 'The Battle of Badr occurred on the 17th of Ramadan in the 2nd year of the Hijrah (624 CE), marking the first major military victory for Muslims.',
    reference: 'Surah Al-Anfal 8:41'
  },
  {
    id: 10,
    category: 'Quran',
    difficulty: 'Easy',
    question: 'Which woman is the only female explicitly mentioned by name in the Holy Quran?',
    options: ['Asiyah', 'Khadijah', 'Maryam (Mary)', 'Fatimah'],
    answer: 2,
    explanation: 'Maryam (Mary, mother of Prophet Isa) is the only woman mentioned by name in the Quran, and Chapter 19 is named after her.',
    reference: 'Surah Maryam 19:16'
  },
  {
    id: 11,
    category: 'Seerah',
    difficulty: 'Easy',
    question: 'Which companion accompanied Prophet Muhammad (ﷺ) during the Hijrah emigration from Makkah to Madinah?',
    options: ['Ali ibn Abi Talib', 'Abu Bakr as-Siddiq', 'Umar ibn al-Khattab', 'Bilal ibn Rabah'],
    answer: 1,
    explanation: 'Abu Bakr as-Siddiq was the sole companion who accompanied the Prophet during their perilous journey from the Cave of Thawr to Madinah.',
    reference: 'Surah At-Tawbah 9:40'
  },
  {
    id: 12,
    category: 'Quran',
    difficulty: 'Medium',
    question: 'How many years did the complete revelation of the Holy Quran span?',
    options: ['10 years', '15 years', '23 years', '30 years'],
    answer: 2,
    explanation: 'The Quran was revealed gradually over approximately 23 years: 13 years during the Makkan period and 10 years during the Madinan period.',
    reference: 'Surah Al-Isra 17:106'
  },
  {
    id: 13,
    category: 'History',
    difficulty: 'Medium',
    question: 'Which Caliph commissioned the standardization and distribution of the unified Uthmanic Mushaf?',
    options: ['Abu Bakr as-Siddiq', 'Umar ibn al-Khattab', 'Uthman ibn Affan', 'Ali ibn Abi Talib'],
    answer: 2,
    explanation: 'Caliph Uthman ibn Affan (may Allah be pleased with him) oversaw the standard compilation and sent copies to major Islamic centers to safeguard the text.',
    reference: 'Sahih al-Bukhari 4987'
  },
  {
    id: 14,
    category: 'Prophets',
    difficulty: 'Easy',
    question: 'Which Prophet was swallowed by a giant fish/whale and supplicated to Allah from the darkness?',
    options: ['Prophet Yunus (Jonah)', 'Prophet Ayyub (Job)', 'Prophet Zakariyya', 'Prophet Hud'],
    answer: 0,
    explanation: 'Prophet Yunus was swallowed by the whale and called out: "La ilaha illa Anta, subhanaka inni kuntu minaz-zalimeen" (There is no deity except You; exalted are You, indeed I have been of the wrongdoers).',
    reference: 'Surah Al-Anbiya 21:87'
  },
  {
    id: 15,
    category: 'Quran',
    difficulty: 'Easy',
    question: 'Reciting which Surah is described by the Prophet (ﷺ) as being equal to one-third of the Quran in reward?',
    options: ['Surah Al-Fatihah', 'Surah Al-Ikhlas', 'Surah Al-Mulk', 'Surah Ya-Sin'],
    answer: 1,
    explanation: 'Surah Al-Ikhlas (Say: He is Allah, the One) embodies pure monotheism (Tawheed), making it equal to one-third of the Quran in its theological significance.',
    reference: 'Sahih al-Bukhari 5013'
  },
  {
    id: 16,
    category: 'Seerah',
    difficulty: 'Medium',
    question: 'What was the famous peace treaty concluded between the Muslims and the Quraysh in 6 AH?',
    options: ['Treaty of Taif', 'Treaty of Hudaybiyyah', 'Pact of Hilf al-Fudul', 'Covenant of Yathrib'],
    answer: 1,
    explanation: 'The Treaty of Hudaybiyyah in 6 AH was declared by Allah as a "manifest victory" (Fathan Mubeena) because it paved the way for peaceful spread of Islam.',
    reference: 'Surah Al-Fath 48:1'
  },
  {
    id: 17,
    category: 'Prophets',
    difficulty: 'Easy',
    question: 'Which two Prophets built the foundations of the Holy Ka\'bah in Makkah?',
    options: ['Adam and Seth', 'Ibrahim and Ismail', 'Musa and Harun', 'Dawud and Sulaiman'],
    answer: 1,
    explanation: 'Prophet Ibrahim and his son Prophet Ismail raised the foundations of the Sacred House (Ka\'bah) while praying for a righteous nation.',
    reference: 'Surah Al-Baqarah 2:127'
  },
  {
    id: 18,
    category: 'History',
    difficulty: 'Medium',
    question: 'Which companion was nicknamed "Sayfullah" (The Sword of Allah) by the Prophet (ﷺ)?',
    options: ['Ali ibn Abi Talib', 'Khalid ibn al-Walid', 'Hamzah ibn Abdul-Muttalib', 'Sa\'d ibn Abi Waqqas'],
    answer: 1,
    explanation: 'Khalid ibn al-Walid received this illustrious title from the Prophet after his strategic mastery during the Battle of Mu\'tah.',
    reference: 'Sahih al-Bukhari 3757'
  },
  {
    id: 19,
    category: 'Quran',
    difficulty: 'Easy',
    question: 'What is the shortest Surah in the Holy Quran by number of verses?',
    options: ['Surah An-Nasr', 'Surah Al-Asr', 'Surah Al-Kawthar', 'Surah Al-Ikhlas'],
    answer: 2,
    explanation: 'Surah Al-Kawthar consists of only 3 verses and 10 words, making it the shortest Surah in the Quran.',
    reference: 'Surah Al-Kawthar 108:1-3'
  },
  {
    id: 20,
    category: 'Quran',
    difficulty: 'Medium',
    question: 'Which Surah is often traditionally referred to as the "Heart of the Quran"?',
    options: ['Surah Ar-Rahman', 'Surah Ya-Sin', 'Surah Al-Waqi\'ah', 'Surah Al-Kahf'],
    answer: 1,
    explanation: 'Surah Ya-Sin is called the heart of the Quran due to its comprehensive and moving presentation of core tenets: revelation, resurrection, and accountability.',
    reference: 'Sunan at-Tirmidhi 2887'
  },
  {
    id: 21,
    category: 'Seerah',
    difficulty: 'Medium',
    question: 'What is the name of the constitutional pact established by the Prophet upon arriving in Madinah?',
    options: ['The Charter of Madinah (Sahifat al-Madinah)', 'The Treaty of Aqabah', 'The Najran Accord', 'The Pledge of Ridwan'],
    answer: 0,
    explanation: 'The Charter of Madinah established mutual rights, religious freedom, and collective defense among the Muslim emigrants, local Ansar, and Jewish tribes.',
    reference: 'Ibn Hisham Seerah'
  },
  {
    id: 22,
    category: 'Prophets',
    difficulty: 'Medium',
    question: 'Which animal spoke to Prophet Sulaiman (Solomon), warning its colony to enter their dwellings?',
    options: ['A Bee', 'An Ant', 'A Spider', 'A Dove'],
    answer: 1,
    explanation: 'In Surah An-Naml, an ant warned its companions: "O ants, enter your dwellings lest Sulaiman and his soldiers crush you without noticing."',
    reference: 'Surah An-Naml 27:18'
  },
  {
    id: 23,
    category: 'Quran',
    difficulty: 'Medium',
    question: 'Which Surah is recommended by the Prophet (ﷺ) to be recited every Friday for spiritual illumination?',
    options: ['Surah Al-Kahf', 'Surah Al-Jumu\'ah', 'Surah Al-Hadid', 'Surah As-Sajdah'],
    answer: 0,
    explanation: 'The Prophet (ﷺ) said: "Whoever recites Surah Al-Kahf on the day of Jumu\'ah will have a light that will shine for him from one Friday to the next."',
    reference: 'Sunan al-Bayhaqi'
  },
  {
    id: 24,
    category: 'History',
    difficulty: 'Medium',
    question: 'Which companion was known as "Dhul-Nurayn" (Possessor of Two Lights)?',
    options: ['Ali ibn Abi Talib', 'Uthman ibn Affan', 'Talhah ibn Ubaydullah', 'Az-Zubayr ibn al-Awwam'],
    answer: 1,
    explanation: 'Uthman ibn Affan was honored with this title because he married two daughters of Prophet Muhammad (Ruqayyah and, after her passing, Umm Kulthum).',
    reference: 'Tabaqat Ibn Sa\'d'
  },
  {
    id: 25,
    category: 'Prophets',
    difficulty: 'Easy',
    question: 'Which Prophet was granted miraculous control over the wind and comprehension of bird speech by Allah?',
    options: ['Prophet Dawud', 'Prophet Sulaiman (Solomon)', 'Prophet Yusuf', 'Prophet Idris'],
    answer: 1,
    explanation: 'Allah bestowed upon Prophet Sulaiman exceptional gifts: understanding the language of birds and animals, and command over the wind.',
    reference: 'Surah Saba 34:12'
  },
  {
    id: 26,
    category: 'Quran',
    difficulty: 'Advanced',
    question: 'Which Surah in the Quran contains the longest single verse (Ayat ad-Dayn, the verse on debts and contracts)?',
    options: ['Surah Al-Baqarah', 'Surah An-Nisa', 'Surah Al-Ma\'idah', 'Surah Al-A\'raf'],
    answer: 0,
    explanation: 'Surah Al-Baqarah contains verse 282, which spans an entire page detailing the recording and witnessing of financial transactions and loans.',
    reference: 'Surah Al-Baqarah 2:282'
  },
  {
    id: 27,
    category: 'Seerah',
    difficulty: 'Easy',
    question: 'In which holy city was the Prophet Muhammad (ﷺ) born?',
    options: ['Madinah al-Munawwarah', 'Makkah al-Mukarramah', 'Jerusalem (Al-Quds)', 'Taif'],
    answer: 1,
    explanation: 'The Prophet Muhammad (ﷺ) was born in Makkah in the Year of the Elephant (circa 570 CE) into the Banu Hashim clan of Quraysh.',
    reference: 'Seerah Ibn Kathir'
  },
  {
    id: 28,
    category: 'History',
    difficulty: 'Advanced',
    question: 'Who was appointed by Caliph Abu Bakr as the chief scribe to compile the scattered manuscripts of the Quran?',
    options: ['Abdullah ibn Mas\'ud', 'Ubayy ibn Ka\'b', 'Zayd ibn Thabit', 'Mu\'awiyah ibn Abi Sufyan'],
    answer: 2,
    explanation: 'Zayd ibn Thabit, one of the primary scribes of revelation during the Prophet\'s life, was chosen for his young age, exceptional memory, and rigorous standards.',
    reference: 'Sahih al-Bukhari 4986'
  },
  {
    id: 29,
    category: 'Quran',
    difficulty: 'Medium',
    question: 'In which sacred night was the Holy Quran first sent down from the Preserved Tablet (Al-Lawh Al-Mahfuz)?',
    options: ['Laylatul Mi\'raj', 'Laylatul Qadr (Night of Decree)', 'Laylatul Bara\'ah', 'Laylatul Eid'],
    answer: 1,
    explanation: 'The Quran was sent down on Laylatul Qadr in the month of Ramadan, described as "better than a thousand months."',
    reference: 'Surah Al-Qadr 97:1-3'
  },
  {
    id: 30,
    category: 'Prophets',
    difficulty: 'Medium',
    question: 'Which Prophet was tested with severe loss of health, wealth, and family, yet remained famously patient?',
    options: ['Prophet Ayyub (Job)', 'Prophet Ya\'qub (Jacob)', 'Prophet Yunus', 'Prophet Lut'],
    answer: 0,
    explanation: 'Prophet Ayyub endured immense trials with steadfast patience (Sabr Jameel) and was healed by Allah when he prayed for relief.',
    reference: 'Surah Al-Anbiya 21:83-84'
  }
];

// Helper to retrieve today's Daily Quiz question deterministically based on date
export const getDailyQuizQuestion = (date: Date = new Date()): QuizQuestion => {
  const startOfYear = new Date(date.getFullYear(), 0, 0);
  const diff = date.getTime() - startOfYear.getTime();
  const oneDay = 1000 * 60 * 60 * 24;
  const dayOfYear = Math.floor(diff / oneDay);
  return quizQuestions[dayOfYear % quizQuestions.length];
};

// Helper to get a question for any specific date offset (e.g. yesterday -1)
export const getQuizQuestionForDayOffset = (offsetDays: number = 0): { question: QuizQuestion; date: Date } => {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return {
    question: getDailyQuizQuestion(d),
    date: d
  };
};
