/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HashRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import Home from './components/Home.tsx';
import QuranList from './components/QuranList.tsx';
import Prayer from './components/Prayer.tsx';
import Duas from './components/Duas.tsx';
import Tasbeeh from './components/Tasbeeh.tsx';
import Settings from './components/Settings.tsx';
import Qibla from './components/Qibla.tsx';
import Quiz from './components/Quiz.tsx';
import Learn from './components/Learn.tsx';
import QuranReader from './components/QuranReader.tsx';
import Bookmarks from './components/Bookmarks.tsx';
import Favorites from './components/Favorites.tsx';
import Ramadan from './components/Ramadan.tsx';
import Hadith from './components/Hadith.tsx';
import ZakatTracker from './components/ZakatTracker.tsx';
import Reflection from './components/Reflection.tsx';
import Affirmations from './components/Affirmations.tsx';
import Reports from './components/Reports.tsx';
import DailyQuranJournal from './components/DailyQuranJournal.tsx';
import CommunityForum from './components/CommunityForum.tsx';
import { AudioProvider } from './context/AudioContext.tsx';
import { ThemeProvider } from './context/ThemeContext.tsx';
import { I18nProvider } from './context/I18nContext.tsx';
import AudioPlayer from './components/AudioPlayer.tsx';
import { OfflineIndicator } from './components/OfflineIndicator.tsx';
import { useEffect } from 'react';
import { requestNotificationPermission } from './lib/notifications';
import { startPrayerScheduler } from './lib/prayerScheduler';
import { syncLocalStorageToIndexedDB } from './lib/db';
import { initBackgroundSync } from './lib/zakatSync';
import { useQuizNotifications } from './hooks/useQuizNotifications';
import { initIntelligentPrayerMonitor } from './lib/focusPrayerReminder';

import { Home as HomeIcon, BookOpen, Clock, GraduationCap, MoreHorizontal } from 'lucide-react';

const NavLink = ({ to, label, icon: Icon }: { to: string; label: string; icon: React.ElementType }) => {
  const location = useLocation();
  const isActive = location.pathname.startsWith(to) && to !== '/' ? true : location.pathname === to;
  return (
    <Link
      to={to}
      aria-label={`Navigate to ${label}`}
      aria-current={isActive ? 'page' : undefined}
      className={`flex flex-col items-center gap-1 text-xs font-semibold transition-colors ${
        isActive ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
      }`}
    >
      <Icon size={20} aria-hidden="true" />
      <span>{label}</span>
    </Link>
  );
};

const Layout = ({ children }: { children: React.ReactNode }) => (
  <div className="min-h-screen flex flex-col bg-[var(--bg-primary)] text-[var(--text-primary)]">
    <OfflineIndicator />
    <main className="flex-grow p-4 pb-20" role="main">{children}</main>
    <AudioPlayer />
    <nav
      className="fixed bottom-0 left-0 right-0 border-t border-amber-900/50 bg-slate-950/95 backdrop-blur-md p-2.5 flex justify-around z-30 shadow-2xl"
      aria-label="Main Navigation Bar"
      role="navigation"
    >
      <NavLink to="/" label="Home" icon={HomeIcon} />
      <NavLink to="/quran" label="Quran" icon={BookOpen} />
      <NavLink to="/prayer" label="Prayer" icon={Clock} />
      <NavLink to="/learn" label="Learn" icon={GraduationCap} />
      <NavLink to="/settings" label="More" icon={MoreHorizontal} />
    </nav>
  </div>
);

export default function App() {
  useQuizNotifications();

  useEffect(() => {
    requestNotificationPermission();
    startPrayerScheduler();
    syncLocalStorageToIndexedDB();
    const cleanupSync = initBackgroundSync();
    const cleanupFocusMonitor = initIntelligentPrayerMonitor();
    return () => {
      if (cleanupSync) cleanupSync();
      if (cleanupFocusMonitor) cleanupFocusMonitor();
    };
  }, []);

  return (
    <HashRouter>
      <ThemeProvider>
        <I18nProvider>
          <AudioProvider>
            <Layout>
              <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/quran" element={<QuranList />} />
              <Route path="/quran/:surah" element={<QuranReader />} />
              <Route path="/quran/para/:para" element={<QuranReader />} />
              <Route path="/favorites" element={<Favorites />} />
              <Route path="/bookmarks" element={<Bookmarks />} />
              <Route path="/prayer" element={<Prayer />} />
              <Route path="/duas" element={<Duas />} />
              <Route path="/hadith" element={<Hadith />} />
              <Route path="/tasbeeh" element={<Tasbeeh />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/qibla" element={<Qibla />} />
              <Route path="/quiz" element={<Quiz />} />
              <Route path="/learn" element={<Learn />} />
              <Route path="/ramadan" element={<Ramadan />} />
              <Route path="/zakat" element={<ZakatTracker />} />
              <Route path="/reflections" element={<Reflection />} />
              <Route path="/reflection" element={<Reflection />} />
              <Route path="/affirmations" element={<Affirmations />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="/quran-journal" element={<DailyQuranJournal />} />
              <Route path="/forum" element={<CommunityForum />} />
            </Routes>
          </Layout>
        </AudioProvider>
      </I18nProvider>
    </ThemeProvider>
    </HashRouter>
  );
}
