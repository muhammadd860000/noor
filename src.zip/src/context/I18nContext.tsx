import React, { createContext, useContext, useState, useEffect } from 'react';
import { translations } from '../lib/translations';
import { getFromDB, saveToDB } from '../lib/db';

type Language = 'en' | 'ar';

interface I18nContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: string) => string;
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export const I18nProvider = ({ children }: { children: React.ReactNode }) => {
  const [lang, setLang] = useState<Language>('en');

  useEffect(() => {
    const loadLang = async () => {
      const saved = await getFromDB('settings', 'language');
      if (saved) setLang(saved.value);
    };
    loadLang();
  }, []);

  const setLanguage = async (newLang: Language) => {
    setLang(newLang);
    await saveToDB('settings', { key: 'language', value: newLang });
  };

  const t = (key: string) => translations[lang][key as keyof typeof translations['en']] || key;

  return (
    <I18nContext.Provider value={{ lang, setLang: setLanguage, t }}>
      {children}
    </I18nContext.Provider>
  );
};

export const useI18n = () => {
  const context = useContext(I18nContext);
  if (!context) throw new Error('useI18n must be used within an I18nProvider');
  return context;
};
