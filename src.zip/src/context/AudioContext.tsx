import React, { createContext, useContext, useRef, useState, useEffect, useCallback, useMemo } from 'react';

export interface AudioDebugInfo {
  url: string;
  errorCode: number | null;
  errorMessage: string | null;
  readyState: number;
  networkState: number;
}

export interface AudioContextType {
  isPlaying: boolean;
  setIsPlaying: (playing: boolean) => void;
  audioRef: React.RefObject<HTMLAudioElement | null>;
  currentUrl: string | null;
  setCurrentUrl: (url: string | null) => void;
  playTrack: (url: string) => Promise<void>;
  getAyahAudioUrl: (globalAyahNumber: number) => string;
  progress: number;
  duration: number;
  error: boolean;
  audioDebug: AudioDebugInfo | null;
  reciterInfo: { name: string; englishName: string; type: string; format: string } | null;
  play: () => Promise<void>;
  pause: () => Promise<void>;
  seek: (time: number) => void;
  retry: () => void;
  volume: number;
  setVolume: (vol: number) => void;
  isMuted: boolean;
  toggleMute: () => void;
  triggerNext: () => void;
  triggerPrevious: () => void;
  setOnNext: (cb: (() => void) | null) => void;
  setOnPrevious: (cb: (() => void) | null) => void;
}

export const constructAyahAudioUrl = (globalAyahNumber: number): string => {
  return `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${globalAyahNumber}.mp3`;
};

const AudioContext = createContext<AudioContextType | undefined>(undefined);

export const AudioProvider = ({ children }: { children: React.ReactNode }) => {
  const [isPlaying, setIsPlayingState] = useState(false);
  const [currentUrl, setCurrentUrlState] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [error, setError] = useState(false);
  const [audioDebug, setAudioDebug] = useState<AudioDebugInfo | null>(null);
  const [volume, setVolumeState] = useState(1);
  const [isMuted, setIsMuted] = useState(false);

  const [reciterInfo] = useState<{ name: string; englishName: string; type: string; format: string }>({
    name: 'مشاري العفاسي',
    englishName: 'Mishary Rashid Alafasy',
    type: 'Verse by Verse',
    format: '128 kbps MP3'
  });

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const playPromiseRef = useRef<Promise<void> | null>(null);
  const onNextRef = useRef<(() => void) | null>(null);
  const onPreviousRef = useRef<(() => void) | null>(null);

  const setOnNext = useCallback((cb: (() => void) | null) => {
    onNextRef.current = cb;
  }, []);

  const setOnPrevious = useCallback((cb: (() => void) | null) => {
    onPreviousRef.current = cb;
  }, []);

  const triggerNext = useCallback(() => {
    if (onNextRef.current) {
      onNextRef.current();
    } else {
      const audio = audioRef.current;
      if (audio) {
        audio.currentTime = Math.min(audio.duration || 0, audio.currentTime + 5);
      }
    }
  }, []);

  const triggerPrevious = useCallback(() => {
    if (onPreviousRef.current) {
      onPreviousRef.current();
    } else {
      const audio = audioRef.current;
      if (audio) {
        audio.currentTime = Math.max(0, audio.currentTime - 5);
      }
    }
  }, []);

  // Diagnostic Test on Mount for Al-Fatihah Ayah 1 (Global Ayah 1)
  useEffect(() => {
    const globalAyahNumber = 1;
    const testUrl = constructAyahAudioUrl(globalAyahNumber);

    console.log(
      `[QuranAudio] Constructed audio URL using verified pattern https://cdn.islamic.network/quran/audio/128/ar.alafasy/{global_ayah_number}.mp3:
Ayah: Al-Fatihah 1:1
Global Ayah Number: ${globalAyahNumber}
Constructed URL: ${testUrl}`
    );

    const testAudio = new Audio();
    testAudio.preload = 'auto';

    const readyStateNames: Record<number, string> = {
      0: 'HAVE_NOTHING (0)',
      1: 'HAVE_METADATA (1)',
      2: 'HAVE_CURRENT_DATA (2)',
      3: 'HAVE_FUTURE_DATA (3)',
      4: 'HAVE_ENOUGH_DATA (4)',
    };

    const networkStateNames: Record<number, string> = {
      0: 'NETWORK_EMPTY (0)',
      1: 'NETWORK_IDLE (1)',
      2: 'NETWORK_LOADING (2)',
      3: 'NETWORK_NO_SOURCE (3)',
    };

    let previousReadyState = testAudio.readyState;

    const logAudioEvent = (eventName: string) => {
      const currentReadyState = testAudio.readyState;
      const readyStateTransition =
        previousReadyState !== currentReadyState
          ? `Transition: ${readyStateNames[previousReadyState]} -> ${readyStateNames[currentReadyState]}`
          : `Current: ${readyStateNames[currentReadyState]}`;

      previousReadyState = currentReadyState;

      console.log(
        `[HTMLAudioElement Event - Al-Fatihah Ayah 1]
Event: ${eventName}
URL: ${testAudio.src}
ReadyState: ${readyStateNames[currentReadyState]}
ReadyState Transition: ${readyStateTransition}
NetworkState: ${networkStateNames[testAudio.networkState] ?? testAudio.networkState}
Duration: ${testAudio.duration}
CurrentTime: ${testAudio.currentTime}
Error Code: ${testAudio.error?.code ?? 'null (0 - No Error)'}
Error Message: ${testAudio.error?.message ?? 'null'}`
      );
    };

    const events = [
      'loadstart',
      'progress',
      'loadedmetadata',
      'loadeddata',
      'canplay',
      'canplaythrough',
      'play',
      'pause',
      'waiting',
      'playing',
      'ended',
      'error',
      'stalled',
      'suspend',
      'abort'
    ];

    const handlers: { event: string; fn: () => void }[] = events.map(evt => ({
      event: evt,
      fn: () => logAudioEvent(evt)
    }));

    handlers.forEach(({ event, fn }) => {
      testAudio.addEventListener(event, fn);
    });

    testAudio.src = testUrl;
    testAudio.load();

    return () => {
      handlers.forEach(({ event, fn }) => {
        testAudio.removeEventListener(event, fn);
      });
      testAudio.src = '';
    };
  }, []);

  // Set up event listeners on the main audio element once
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    let previousMainReadyState = audio.readyState;

    const readyStateNames: Record<number, string> = {
      0: 'HAVE_NOTHING (0)',
      1: 'HAVE_METADATA (1)',
      2: 'HAVE_CURRENT_DATA (2)',
      3: 'HAVE_FUTURE_DATA (3)',
      4: 'HAVE_ENOUGH_DATA (4)',
    };

    const logMainEvent = (eventName: string) => {
      const currentReadyState = audio.readyState;
      const isAlFatihah1 = audio.src.endsWith('/1.mp3');
      const prefix = isAlFatihah1
        ? '[QuranAudio Main Element - Al-Fatihah Ayah 1]'
        : '[QuranAudio Main Element]';

      const transition = previousMainReadyState !== currentReadyState
        ? `Transition: ${readyStateNames[previousMainReadyState]} -> ${readyStateNames[currentReadyState]}`
        : `ReadyState: ${readyStateNames[currentReadyState]}`;

      console.log(
        `${prefix} Event: ${eventName} | ${transition} | Duration: ${audio.duration} | Error: ${audio.error ? `Code ${audio.error.code} (${audio.error.message})` : 'None'}`
      );
      previousMainReadyState = currentReadyState;
    };

    const handleLoadedMetadata = () => {
      logMainEvent('loadedmetadata');
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setDuration(audio.duration);
      }
      setError(false);
      setAudioDebug(null);
    };

    const handleCanPlay = () => {
      logMainEvent('canplay');
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setDuration(audio.duration);
      }
      setError(false);
    };

    const handleTimeUpdate = () => {
      setProgress(audio.currentTime);
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setDuration(prev => prev || audio.duration);
      }
    };

    const handlePlay = () => {
      logMainEvent('play');
      setIsPlayingState(true);
    };

    const handlePause = () => {
      logMainEvent('pause');
      setIsPlayingState(false);
    };

    const handleEnded = () => {
      logMainEvent('ended');
      setIsPlayingState(false);
      setProgress(audio.duration || 0);
      if (onNextRef.current) {
        onNextRef.current();
      }
    };

    const handleError = () => {
      logMainEvent('error');
      const err = audio.error;
      const debugInfo: AudioDebugInfo = {
        url: audio.src,
        errorCode: err?.code ?? null,
        errorMessage: err?.message || 'Media source error',
        readyState: audio.readyState,
        networkState: audio.networkState,
      };
      console.error('[QuranAudio Debug] Audio Error event:', debugInfo);
      setError(true);
      setAudioDebug(debugInfo);
      setIsPlayingState(false);
    };

    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('canplay', handleCanPlay);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
    };
  }, []);

  const play = useCallback(async () => {
    const audio = audioRef.current;
    if (!audio || !audio.src) return;
    try {
      console.log('[QuranAudio Debug] Calling play() on:', audio.src);
      const promise = audio.play();
      playPromiseRef.current = promise;
      await promise;
    } catch (err: any) {
      if (err.name === 'AbortError' || err.message?.includes('interrupted') || err.message?.includes('pause')) {
        console.log('[QuranAudio Debug] Play interrupted gracefully');
        return;
      }
      console.error('[QuranAudio Debug] play() error:', err);
      setError(true);
      setAudioDebug({
        url: audio.src,
        errorCode: audio.error?.code ?? null,
        errorMessage: err.message || 'Play failed',
        readyState: audio.readyState,
        networkState: audio.networkState,
      });
    } finally {
      playPromiseRef.current = null;
    }
  }, []);

  const pause = useCallback(async () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (playPromiseRef.current) {
      try {
        await playPromiseRef.current;
      } catch {
        // ignore interruption
      }
    }
    audio.pause();
  }, []);

  const setCurrentUrl = useCallback((url: string | null) => {
    setCurrentUrlState(url);
    const audio = audioRef.current;
    if (!audio) return;

    if (!url) {
      audio.pause();
      audio.removeAttribute('src');
      setProgress(0);
      setDuration(0);
      setIsPlayingState(false);
      setError(false);
      setAudioDebug(null);
      return;
    }

    if (audio.src !== url) {
      audio.src = url;
      audio.preload = 'metadata';
      setProgress(0);
      setDuration(0);
      setError(false);
      setAudioDebug(null);
      audio.load();
    }
  }, []);

  const playTrack = useCallback(async (url: string) => {
    const audio = audioRef.current;
    if (!audio) return;

    const isAlFatihah1 = url.endsWith('/1.mp3');
    console.log(
      `[QuranAudio playTrack] Loading track using verified pattern https://cdn.islamic.network/quran/audio/128/ar.alafasy/{global_ayah_number}.mp3:
URL: ${url} ${isAlFatihah1 ? '(Al-Fatihah Ayah 1)' : ''}
ReadyState before load: ${audio.readyState}`
    );

    setCurrentUrlState(url);

    if (audio.src !== url) {
      if (playPromiseRef.current) {
        try {
          await playPromiseRef.current;
        } catch {
          // ignore
        }
      }
      audio.src = url;
      audio.preload = 'metadata';
      setProgress(0);
      setDuration(0);
      setError(false);
      setAudioDebug(null);
      audio.load();
    }

    try {
      console.log('[QuranAudio Debug] playTrack calling play on:', audio.src);
      const promise = audio.play();
      playPromiseRef.current = promise;
      await promise;
    } catch (err: any) {
      if (err.name === 'AbortError' || err.message?.includes('interrupted') || err.message?.includes('pause')) {
        console.log('[QuranAudio Debug] playTrack play interrupted gracefully');
        return;
      }
      console.error('[QuranAudio Debug] playTrack error:', err);
      setError(true);
      setAudioDebug({
        url: audio.src,
        errorCode: audio.error?.code ?? null,
        errorMessage: err.message || 'Play failed',
        readyState: audio.readyState,
        networkState: audio.networkState,
      });
    } finally {
      playPromiseRef.current = null;
    }
  }, []);

  const setIsPlaying = useCallback((playing: boolean) => {
    if (playing) {
      play();
    } else {
      pause();
    }
  }, [play, pause]);

  const seek = useCallback((time: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.currentTime = time;
    setProgress(time);
  }, []);

  const retry = useCallback(() => {
    const audio = audioRef.current;
    if (!audio || !currentUrl) return;
    console.log('[QuranAudio Debug] Retrying audio load:', currentUrl);
    setError(false);
    setAudioDebug(null);
    audio.src = currentUrl;
    audio.preload = 'metadata';
    audio.load();
    play();
  }, [currentUrl, play]);

  const setVolume = useCallback((vol: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    const clamped = Math.max(0, Math.min(1, vol));
    audio.volume = clamped;
    setVolumeState(clamped);
    setIsMuted(clamped === 0);
  }, []);

  const toggleMute = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const nextMuted = !isMuted;
    audio.muted = nextMuted;
    setIsMuted(nextMuted);
  }, [isMuted]);

  const getAyahAudioUrl = useCallback((globalAyahNumber: number) => {
    return constructAyahAudioUrl(globalAyahNumber);
  }, []);

  const contextValue = useMemo<AudioContextType>(() => ({
    isPlaying,
    setIsPlaying,
    audioRef,
    currentUrl,
    setCurrentUrl,
    playTrack,
    getAyahAudioUrl,
    progress,
    duration,
    error,
    audioDebug,
    reciterInfo,
    play,
    pause,
    seek,
    retry,
    volume,
    setVolume,
    isMuted,
    toggleMute,
    triggerNext,
    triggerPrevious,
    setOnNext,
    setOnPrevious,
  }), [
    isPlaying,
    setIsPlaying,
    currentUrl,
    setCurrentUrl,
    playTrack,
    getAyahAudioUrl,
    progress,
    duration,
    error,
    audioDebug,
    reciterInfo,
    play,
    pause,
    seek,
    retry,
    volume,
    setVolume,
    isMuted,
    toggleMute,
    triggerNext,
    triggerPrevious,
    setOnNext,
    setOnPrevious,
  ]);

  return (
    <AudioContext.Provider value={contextValue}>
      <audio ref={audioRef} preload="metadata" />
      {children}
    </AudioContext.Provider>
  );
};

export const useAudio = () => {
  const context = useContext(AudioContext);
  if (!context) throw new Error('useAudio must be used within an AudioProvider');
  return context;
};
