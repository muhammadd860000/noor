import React, { createContext, useContext, useEffect, useState } from 'react';

type Theme = 'light' | 'dark' | 'system';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
  resolvedTheme: 'light' | 'dark';
  smartThemeEnabled: boolean;
  setSmartThemeEnabled: (enabled: boolean) => void;
  isNightTime: boolean;
  isSmartThemeActive: boolean;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function checkIsNightTime(): boolean {
  const hour = new Date().getHours();
  // Late night / early morning hours between 8 PM (20:00) and 6 AM (06:00)
  return hour >= 20 || hour < 6;
}

export const ThemeProvider = ({ children }: { children: React.ReactNode }) => {
  const [theme, setThemeState] = useState<Theme>(() => {
    const saved = localStorage.getItem('theme');
    return (saved as Theme) || 'system';
  });

  const [smartThemeEnabled, setSmartThemeEnabledState] = useState<boolean>(() => {
    if (typeof localStorage !== 'undefined') {
      const saved = localStorage.getItem('noor_smart_theme_enabled');
      return saved === null ? true : saved === 'true'; // Enabled by default
    }
    return true;
  });

  const [resolvedTheme, setResolvedTheme] = useState<'light' | 'dark'>('dark');
  const [isNightTime, setIsNightTime] = useState<boolean>(checkIsNightTime);

  // Check night time every 60 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setIsNightTime(checkIsNightTime());
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const isSmartThemeActive = smartThemeEnabled && isNightTime;

  useEffect(() => {
    const root = window.document.documentElement;
    let effectiveTheme: 'light' | 'dark' = 'dark';

    // If Smart Theme is enabled and it is night time, force Dark/Night Mode
    if (smartThemeEnabled && isNightTime) {
      effectiveTheme = 'dark';
      root.classList.add('night-mode');
    } else {
      root.classList.remove('night-mode');
      if (theme === 'system') {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        effectiveTheme = prefersDark ? 'dark' : 'light';
      } else {
        effectiveTheme = theme;
      }
    }

    setResolvedTheme(effectiveTheme);

    if (effectiveTheme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }

    localStorage.setItem('theme', theme);
  }, [theme, smartThemeEnabled, isNightTime]);

  // Listen for OS system theme changes if set to 'system'
  useEffect(() => {
    if (theme !== 'system' || (smartThemeEnabled && isNightTime)) return;

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => {
      const root = window.document.documentElement;
      const effectiveTheme = e.matches ? 'dark' : 'light';
      setResolvedTheme(effectiveTheme);
      if (effectiveTheme === 'dark') {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    };

    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, [theme, smartThemeEnabled, isNightTime]);

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme);
  };

  const setSmartThemeEnabled = (enabled: boolean) => {
    setSmartThemeEnabledState(enabled);
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('noor_smart_theme_enabled', String(enabled));
    }
  };

  const toggleTheme = () => {
    setThemeState(prev => {
      if (prev === 'system') return 'light';
      if (prev === 'light') return 'dark';
      return 'system';
    });
  };

  return (
    <ThemeContext.Provider
      value={{
        theme,
        setTheme,
        toggleTheme,
        resolvedTheme,
        smartThemeEnabled,
        setSmartThemeEnabled,
        isNightTime,
        isSmartThemeActive,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within a ThemeProvider');
  return context;
};
