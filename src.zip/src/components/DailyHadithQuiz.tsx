import React, { useState, useMemo } from 'react';
import { 
  BookOpen, 
  HelpCircle, 
  CheckCircle2, 
  XCircle, 
  Award, 
  RotateCcw, 
  Sparkles, 
  ChevronRight, 
  Flame, 
  BookMarked,
  Trophy,
  Share2
} from 'lucide-react';
import { hadiths, HadithItem } from '../data/hadiths';
import { recordQuizAttempt, getQuizLeaderboardStats, QuizScoreRecord } from '../lib/quizLeaderboard';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

interface QuizQuestion {
  id: string;
  hadith: HadithItem;
  questionType: 'narrator' | 'topic';
  prompt: string;
  correctAnswer: string;
  options: string[];
}

export default function DailyHadithQuiz() {
  const [sessionIndex, setSessionIndex] = useState(0); // For restarting quiz
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [userAnswers, setUserAnswers] = useState<Array<{ question: QuizQuestion; selected: string; isCorrect: boolean }>>([]);
  const [quizFinished, setQuizFinished] = useState(false);
  const [latestRecord, setLatestRecord] = useState<QuizScoreRecord | null>(null);

  // Pool of famous narrators for distractors
  const ALL_NARRATORS = [
    "Abu Hurairah (RA)",
    "'Umar ibn al-Khattab (RA)",
    "Anas ibn Malik (RA)",
    "'Aishah bint Abi Bakr (RA)",
    "'Abdullah ibn 'Umar (RA)",
    "'Uthman ibn 'Affan (RA)",
    "Abu Dharr al-Ghifari (RA)",
    "'Abdullah ibn 'Abbas (RA)",
    "Jabir ibn 'Abdullah (RA)",
    "Abu Sa'id al-Khudri (RA)"
  ];

  // Pool of Hadith topics for distractors
  const ALL_TOPICS = [
    "Intention & Sincerity",
    "Brotherhood & Faith",
    "Quran & Knowledge",
    "Character & Speech",
    "Kindness & Charity",
    "Speech & Wisdom",
    "Gentleness & Compassion",
    "Mercy & Compassion",
    "Knowledge & Learning",
    "Tawakkul & Mindfulness",
    "Patience & Perseverance",
    "Gratitude & Supplication"
  ];

  // Shuffle helper
  const shuffleArray = <T,>(array: T[]): T[] => {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  };

  // Generate 4 dynamic questions from Hadith collection
  const questions = useMemo<QuizQuestion[]>(() => {
    // Pick 4 distinct Hadiths
    const shuffledHadiths = shuffleArray(hadiths).slice(0, 4);

    return shuffledHadiths.map((h, idx) => {
      // Alternate between narrator question and topic question
      const isNarratorQuestion = idx % 2 === 0;

      if (isNarratorQuestion) {
        // Clean narrator string for matching option
        const cleanNarrator = h.narrator.replace(/^Narrated by\s+/i, '').trim();

        const distractors = shuffleArray(
          ALL_NARRATORS.filter(n => !cleanNarrator.toLowerCase().includes(n.toLowerCase().replace(/\s+\(ra\)/i, '')))
        ).slice(0, 3);

        const options = shuffleArray([cleanNarrator, ...distractors]);

        return {
          id: `q_${h.id}_narrator_${sessionIndex}`,
          hadith: h,
          questionType: 'narrator',
          prompt: 'Who narrated this noble Hadith?',
          correctAnswer: cleanNarrator,
          options
        };
      } else {
        const correctTopic = h.category;
        const distractors = shuffleArray(
          ALL_TOPICS.filter(t => t.toLowerCase() !== correctTopic.toLowerCase())
        ).slice(0, 3);

        const options = shuffleArray([correctTopic, ...distractors]);

        return {
          id: `q_${h.id}_topic_${sessionIndex}`,
          hadith: h,
          questionType: 'topic',
          prompt: 'What is the primary theme / topic of this Hadith?',
          correctAnswer: correctTopic,
          options
        };
      }
    });
  }, [sessionIndex]);

  const currentQ = questions[currentQuestionIdx];

  const handleSelectOption = (option: string) => {
    if (isAnswerSubmitted) return;
    triggerButtonClickHaptic();
    setSelectedAnswer(option);
  };

  const handleConfirmAnswer = () => {
    if (!selectedAnswer || !currentQ || isAnswerSubmitted) return;

    const isCorrect = selectedAnswer.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase();
    setIsAnswerSubmitted(true);

    if (isCorrect) {
      triggerSuccessHaptic();
    } else {
      triggerHaptic(30);
    }

    setUserAnswers(prev => [...prev, { question: currentQ, selected: selectedAnswer, isCorrect }]);
  };

  const handleNextQuestion = () => {
    triggerButtonClickHaptic();
    setSelectedAnswer(null);
    setIsAnswerSubmitted(false);

    if (currentQuestionIdx + 1 < questions.length) {
      setCurrentQuestionIdx(prev => prev + 1);
    } else {
      // Quiz complete!
      finishQuiz();
    }
  };

  const finishQuiz = () => {
    const totalQuestions = questions.length;
    const score = userAnswers.filter(a => a.isCorrect).length + (
      selectedAnswer?.trim().toLowerCase() === currentQ?.correctAnswer.trim().toLowerCase() ? 1 : 0
    );

    // Save attempt to global quiz history & leaderboard!
    const record = recordQuizAttempt('daily', 'Daily Hadith Quiz', score, totalQuestions);
    setLatestRecord(record);
    setQuizFinished(true);
    triggerSuccessHaptic();
  };

  const handleRestartQuiz = () => {
    triggerButtonClickHaptic();
    setSessionIndex(prev => prev + 1);
    setCurrentQuestionIdx(0);
    setSelectedAnswer(null);
    setIsAnswerSubmitted(false);
    setUserAnswers([]);
    setQuizFinished(false);
    setLatestRecord(null);
  };

  const stats = getQuizLeaderboardStats();

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
      {/* Quiz Title Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
            <BookMarked size={22} />
          </div>
          <div>
            <h3 className="text-base font-serif font-bold text-slate-100 flex items-center gap-2">
              <span>Daily Hadith Quiz</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold">
                Narrators & Topics
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Test your knowledge of Sunnah narrators and core Islamic themes
            </p>
          </div>
        </div>

        {/* User Rank Badge */}
        <div className="flex items-center gap-2 bg-slate-950/80 border border-amber-900/30 px-3 py-2 rounded-xl self-start sm:self-auto">
          <Trophy size={15} className="text-amber-400" />
          <div className="text-xs">
            <span className="text-slate-400 block text-[10px]">Your Rank</span>
            <span className="font-bold text-amber-300">{stats.currentRank.title}</span>
          </div>
        </div>
      </div>

      {!quizFinished ? (
        currentQ && (
          <div className="space-y-4">
            {/* Question Progress Header */}
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono">
                Question <strong className="text-amber-400">{currentQuestionIdx + 1}</strong> of {questions.length}
              </span>
              <span className="text-[11px] bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-amber-300/90 font-mono">
                {currentQ.questionType === 'narrator' ? '👤 Narrator Challenge' : '🏷️ Topic Identification'}
              </span>
            </div>

            {/* Hadith Snippet Card */}
            <div className="p-4 bg-slate-950/90 border border-amber-900/30 rounded-xl space-y-3">
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20 font-semibold">
                {currentQ.hadith.reference}
              </span>

              {/* Arabic Snippet */}
              <p className="text-amber-200 font-arabic text-lg sm:text-xl text-right leading-loose pt-1" dir="rtl">
                "{currentQ.hadith.arabic}"
              </p>

              {/* English Snippet */}
              <p className="text-xs sm:text-sm text-slate-200 italic leading-relaxed bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                "{currentQ.hadith.text}"
              </p>
            </div>

            {/* Question Prompt */}
            <h4 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <HelpCircle size={16} className="text-amber-400" />
              <span>{currentQ.prompt}</span>
            </h4>

            {/* Answer Options Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {currentQ.options.map((opt, i) => {
                const isSelected = selectedAnswer === opt;
                const isCorrect = opt.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase();

                let btnStyle = "bg-slate-950 hover:bg-slate-900 border-slate-800 text-slate-200";

                if (isAnswerSubmitted) {
                  if (isCorrect) {
                    btnStyle = "bg-emerald-950/80 border-emerald-500/80 text-emerald-200 font-bold shadow-sm shadow-emerald-500/20";
                  } else if (isSelected) {
                    btnStyle = "bg-rose-950/80 border-rose-500/80 text-rose-200 font-bold";
                  } else {
                    btnStyle = "bg-slate-950/50 border-slate-900 text-slate-500 opacity-60";
                  }
                } else if (isSelected) {
                  btnStyle = "bg-amber-950/50 border-amber-500 text-amber-300 font-bold shadow-sm shadow-amber-500/20";
                }

                return (
                  <button
                    key={i}
                    type="button"
                    onClick={() => handleSelectOption(opt)}
                    disabled={isAnswerSubmitted}
                    className={`p-3.5 rounded-xl border text-left text-xs transition-all flex items-center justify-between gap-2 ${btnStyle}`}
                  >
                    <span>{opt}</span>
                    {isAnswerSubmitted && isCorrect && (
                      <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
                    )}
                    {isAnswerSubmitted && isSelected && !isCorrect && (
                      <XCircle size={16} className="text-rose-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Feedback / Next Action Bar */}
            {isAnswerSubmitted ? (
              <div className="space-y-3 pt-2">
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                  <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                    <Sparkles size={14} />
                    <span>Prophetic Lesson & Context:</span>
                  </span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {currentQ.hadith.lesson || `Narrated in ${currentQ.hadith.reference} under the category of ${currentQ.hadith.category}.`}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleNextQuestion}
                  className="w-full py-3 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition flex items-center justify-center gap-2"
                >
                  <span>{currentQuestionIdx + 1 < questions.length ? 'Next Question' : 'View Quiz Results'}</span>
                  <ChevronRight size={16} />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleConfirmAnswer}
                disabled={!selectedAnswer}
                className={`w-full py-3 px-4 rounded-xl font-bold text-xs transition ${
                  selectedAnswer
                    ? 'bg-amber-600 hover:bg-amber-500 text-slate-950 shadow-md'
                    : 'bg-slate-950 text-slate-600 border border-slate-800 cursor-not-allowed'
                }`}
              >
                Confirm Answer
              </button>
            )}
          </div>
        )
      ) : (
        /* Quiz Results View */
        <div className="space-y-5 animate-fadeIn">
          <div className="p-5 bg-gradient-to-br from-amber-950/30 via-slate-950 to-slate-950 border border-amber-500/40 rounded-2xl text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mx-auto">
              <Award size={32} />
            </div>

            <div>
              <h4 className="text-lg font-serif font-bold text-slate-100">Quiz Completed, Masha'Allah!</h4>
              <p className="text-xs text-slate-400">Score saved to your global Islamic quiz history</p>
            </div>

            {latestRecord && (
              <div className="grid grid-cols-3 gap-2 max-w-sm mx-auto pt-2">
                <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Score</span>
                  <span className="text-sm font-mono font-bold text-amber-400">{latestRecord.score} / {latestRecord.totalQuestions}</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Accuracy</span>
                  <span className="text-sm font-mono font-bold text-amber-400">{latestRecord.percentage}%</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Points Earned</span>
                  <span className="text-sm font-mono font-bold text-amber-400">+{latestRecord.pointsEarned}</span>
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleRestartQuiz}
              className="flex-1 py-3 px-4 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2"
            >
              <RotateCcw size={15} />
              <span>Try Another Hadith Quiz</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
