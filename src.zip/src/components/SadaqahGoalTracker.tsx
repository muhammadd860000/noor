import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Target, Plus, ArrowUpRight, CheckCircle2, Edit3, Coins, Sparkles, Flame } from 'lucide-react';
import { triggerHaptic, triggerSuccessHaptic } from '../lib/haptics';

export default function SadaqahGoalTracker() {
  const [monthlyTarget, setMonthlyTarget] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('noor_sadaqah_monthly_goal');
      return saved ? parseFloat(saved) || 200 : 200;
    } catch {
      return 200;
    }
  });

  const [isEditingTarget, setIsEditingTarget] = useState(false);
  const [tempTarget, setTempTarget] = useState(monthlyTarget.toString());
  const [currentMonthTotal, setCurrentMonthTotal] = useState(0);
  const [quickAddAmount, setQuickAddAmount] = useState('');
  const [showQuickAdd, setShowQuickAdd] = useState(false);

  // Load current month's contributions from localStorage or IndexedDB
  const refreshContributions = () => {
    try {
      const raw = localStorage.getItem('noor_charity_contributions');
      if (raw) {
        const parsed = JSON.parse(raw);
        const now = new Date();
        const currentYear = now.getFullYear();
        const currentMonth = now.getMonth();

        let monthSum = 0;
        parsed.forEach((item: any) => {
          const itemDate = new Date(item.date);
          if (itemDate.getFullYear() === currentYear && itemDate.getMonth() === currentMonth) {
            monthSum += Number(item.amount) || 0;
          }
        });
        setCurrentMonthTotal(monthSum);
      } else {
        // Default seed demo value if empty
        setCurrentMonthTotal(125);
      }
    } catch {
      setCurrentMonthTotal(125);
    }
  };

  useEffect(() => {
    refreshContributions();
    const handleStorageChange = () => refreshContributions();
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const handleSaveTarget = (e: React.FormEvent) => {
    e.preventDefault();
    const val = Math.max(1, parseFloat(tempTarget) || 200);
    setMonthlyTarget(val);
    localStorage.setItem('noor_sadaqah_monthly_goal', val.toString());
    setIsEditingTarget(false);
    triggerSuccessHaptic();
  };

  const handleQuickAddDonation = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(quickAddAmount);
    if (!amt || amt <= 0) return;

    triggerHaptic(15);
    const newRecord = {
      id: `sadaqah_${Date.now()}`,
      type: 'sadaqah',
      amount: amt,
      currency: 'USD',
      cause: 'General Sadaqah',
      recipient: 'Community Support',
      date: new Date().toISOString().slice(0, 10),
      timestamp: Date.now()
    };

    try {
      const raw = localStorage.getItem('noor_charity_contributions');
      const list = raw ? JSON.parse(raw) : [];
      const updated = [newRecord, ...list];
      localStorage.setItem('noor_charity_contributions', JSON.stringify(updated));
    } catch (err) {
      console.warn('Error saving quick donation:', err);
    }

    setQuickAddAmount('');
    setShowQuickAdd(false);
    triggerSuccessHaptic();
    refreshContributions();
  };

  const currentMonthName = useMemo(() => {
    return new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  }, []);

  const progressPct = Math.min(100, Math.round((currentMonthTotal / (monthlyTarget || 1)) * 100));
  const isGoalReached = currentMonthTotal >= monthlyTarget;

  // SVG Ring Chart Calculations
  const radius = 52;
  const strokeWidth = 10;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPct / 100) * circumference;

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-5 shadow-xl space-y-4 relative overflow-hidden transition-all duration-300 hover:border-amber-700/50">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <Heart size={20} className="fill-amber-500/20" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>Monthly Sadaqah Goal</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold">
                {currentMonthName}
              </span>
            </h3>
            <p className="text-xs text-slate-400">Track and fulfill your voluntary charity targets</p>
          </div>
        </div>

        <Link
          to="/zakat"
          onClick={() => triggerHaptic(10)}
          className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-semibold px-2.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 transition"
          title="Open Zakat & Sadaqah Hub"
        >
          <span>Zakat Hub</span>
          <ArrowUpRight size={14} />
        </Link>
      </div>

      {/* Main Grid: Ring Chart & Goal Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
        {/* SVG Ring Chart Column */}
        <div className="sm:col-span-5 flex flex-col items-center justify-center p-2 relative">
          <div className="relative w-36 h-36 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 120 120">
              {/* Background Ring */}
              <circle
                cx="60"
                cy="60"
                r={radius}
                className="text-slate-800"
                strokeWidth={strokeWidth}
                stroke="currentColor"
                fill="transparent"
              />
              {/* Progress Ring */}
              <circle
                cx="60"
                cy="60"
                r={radius}
                className="text-amber-500 transition-all duration-1000 ease-out"
                strokeWidth={strokeWidth}
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                stroke="currentColor"
                fill="transparent"
              />
            </svg>

            {/* Inner Ring Text */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-2xl font-mono font-bold text-amber-400 leading-none">
                {progressPct}%
              </span>
              <span className="text-[10px] text-slate-400 font-mono mt-1">
                {isGoalReached ? "Goal Met!" : "Achieved"}
              </span>
            </div>
          </div>
        </div>

        {/* Financial Progress & Target Details Column */}
        <div className="sm:col-span-7 space-y-3">
          <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Current Sadaqah:</span>
              <span className="font-mono font-bold text-slate-100 text-base">${currentMonthTotal.toLocaleString()}</span>
            </div>

            <div className="flex items-center justify-between text-xs border-t border-slate-800/80 pt-2">
              <div className="flex items-center gap-1.5 text-slate-400">
                <Target size={13} className="text-amber-500" />
                <span>Monthly Target:</span>
              </div>

              {isEditingTarget ? (
                <form onSubmit={handleSaveTarget} className="flex items-center gap-1">
                  <span className="text-slate-400 text-xs">$</span>
                  <input
                    type="number"
                    min="1"
                    value={tempTarget}
                    onChange={e => setTempTarget(e.target.value)}
                    className="w-16 bg-slate-900 text-amber-300 font-mono text-xs p-1 rounded border border-amber-500 outline-none"
                    autoFocus
                  />
                  <button type="submit" className="px-2 py-0.5 bg-amber-500 text-slate-950 font-bold text-[10px] rounded">
                    Save
                  </button>
                </form>
              ) : (
                <div className="flex items-center gap-1.5">
                  <span className="font-mono font-bold text-amber-400">${monthlyTarget.toLocaleString()}</span>
                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic(10);
                      setTempTarget(monthlyTarget.toString());
                      setIsEditingTarget(true);
                    }}
                    className="text-slate-500 hover:text-amber-400 transition p-0.5"
                    title="Edit Monthly Goal"
                  >
                    <Edit3 size={13} />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Goal Status Banner */}
          {isGoalReached ? (
            <div className="p-2.5 bg-emerald-950/30 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
              <span>Masha'Allah! You reached your monthly Sadaqah goal.</span>
            </div>
          ) : (
            <div className="p-2.5 bg-amber-950/20 border border-amber-500/20 rounded-xl text-xs text-amber-200/90 flex items-center justify-between">
              <span>Remaining to goal:</span>
              <strong className="font-mono text-amber-400">${Math.max(0, monthlyTarget - currentMonthTotal).toLocaleString()}</strong>
            </div>
          )}

          {/* Action Buttons: Quick Add or Record Donation Link */}
          <div className="flex items-center gap-2">
            {!showQuickAdd ? (
              <button
                type="button"
                onClick={() => {
                  triggerHaptic(15);
                  setShowQuickAdd(true);
                }}
                className="flex-1 py-2 px-3 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-md transition active:scale-95 flex items-center justify-center gap-1.5"
              >
                <Plus size={15} />
                <span>Quick Add Sadaqah</span>
              </button>
            ) : (
              <form onSubmit={handleQuickAddDonation} className="flex-1 flex items-center gap-1.5">
                <span className="text-xs font-mono text-amber-400">$</span>
                <input
                  type="number"
                  min="1"
                  step="any"
                  placeholder="Amount"
                  value={quickAddAmount}
                  onChange={e => setQuickAddAmount(e.target.value)}
                  className="w-full bg-slate-950 text-slate-100 border border-amber-500/50 p-1.5 rounded-xl text-xs font-mono outline-none"
                  autoFocus
                  required
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl"
                >
                  Add
                </button>
                <button
                  type="button"
                  onClick={() => setShowQuickAdd(false)}
                  className="px-2 py-1.5 text-slate-400 hover:text-slate-200 text-xs"
                >
                  ✕
                </button>
              </form>
            )}

            <Link
              to="/zakat"
              onClick={() => triggerHaptic(10)}
              className="py-2 px-3 bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-slate-100 text-xs font-semibold rounded-xl transition flex items-center gap-1 shrink-0"
            >
              <span>Record in ZakatTracker</span>
              <ArrowUpRight size={14} />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
