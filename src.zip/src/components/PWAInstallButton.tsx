import React from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, install } = usePWAInstall();

  if (isInstalled || !isInstallable) return null;

  return (
    <button
      onClick={install}
      className="flex items-center gap-2 rounded-lg bg-amber-600 px-4 py-2 text-sm font-medium text-slate-950 shadow-sm hover:bg-amber-500 transition"
    >
      <Download size={18} />
      Install App
    </button>
  );
};
