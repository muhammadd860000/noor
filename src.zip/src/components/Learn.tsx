import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Sparkles, HelpCircle, Heart, ChevronRight, Award, Coins } from 'lucide-react';
import DailyVerseQuiz from './DailyVerseQuiz';
import QariQuiz from './QariQuiz';
import DhikrMasteryQuiz from './DhikrMasteryQuiz';

export default function Learn() {
  return (
    <div className="space-y-6 pb-12">
      <header>
        <h2 className="text-2xl text-amber-500 font-serif">Learn & Reflect</h2>
        <p className="text-xs text-slate-400 mt-1">Explore authentic supplications and test your Quranic knowledge</p>
      </header>

      {/* Dhikr Mastery Quiz Gamified Section */}
      <DhikrMasteryQuiz />

      {/* Daily Quran Verse Quiz Feature */}
      <DailyVerseQuiz />

      {/* Qari Recitation & Audio Identification Quiz */}
      <QariQuiz />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Daily Quranic Quiz & Knowledge Hub */}
        <Link 
          to="/quiz" 
          className="group relative p-6 bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl hover:border-amber-600/60 transition-all duration-300 shadow-xl flex flex-col justify-between space-y-4"
        >
          <div className="flex items-start justify-between">
            <span className="p-3 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Sparkles size={24} />
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-950/80 border border-emerald-800/60 px-2.5 py-1 rounded-full">
              <Award size={12} /> Daily Challenge Active
            </span>
          </div>

          <div>
            <h3 className="text-xl font-bold text-slate-100 group-hover:text-amber-400 transition-colors">
              Daily Quranic Quiz
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm mt-1 leading-relaxed">
              Test your knowledge every day with fresh multiple-choice questions on the Quran, Seerah, and Islamic history, plus unlimited practice mode.
            </p>
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-amber-500 font-medium">
            <span>Play Today's Question</span>
            <ChevronRight size={16} className="transition-transform group-hover:translate-x-1" />
          </div>
        </Link>

        {/* Duas & Azkar */}
        <Link 
          to="/duas" 
          className="group relative p-6 bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl hover:border-amber-600/60 transition-all duration-300 shadow-xl flex flex-col justify-between space-y-4"
        >
          <div className="flex items-start justify-between">
            <span className="p-3 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Heart size={24} />
            </span>
            <span className="text-[11px] font-mono text-slate-400 px-2.5 py-1 rounded-full bg-slate-800/80 border border-slate-700">
              Authentic Duas
            </span>
          </div>

          <div>
            <h3 className="text-xl font-bold text-slate-100 group-hover:text-emerald-400 transition-colors">
              Duas & Adhkar
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm mt-1 leading-relaxed">
              Morning & evening supplications, Quranic prayers, and protective adhkar with Arabic text, transliteration, and audio.
            </p>
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-emerald-400 font-medium">
            <span>Explore Supplications</span>
            <ChevronRight size={16} className="transition-transform group-hover:translate-x-1" />
          </div>
        </Link>

        {/* Zakat & Sadaqah Hub */}
        <Link 
          to="/zakat" 
          className="group relative p-6 bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl hover:border-amber-600/60 transition-all duration-300 shadow-xl flex flex-col justify-between space-y-4"
        >
          <div className="flex items-start justify-between">
            <span className="p-3 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Coins size={24} />
            </span>
            <span className="text-[11px] font-mono text-amber-400 px-2.5 py-1 rounded-full bg-amber-950/80 border border-amber-800/60">
              Third Pillar of Islam
            </span>
          </div>

          <div>
            <h3 className="text-xl font-bold text-slate-100 group-hover:text-amber-400 transition-colors">
              Zakat & Sadaqah
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm mt-1 leading-relaxed">
              Calculate your annual 2.5% Zakat based on gold/silver Nisab, track charitable contributions, and monitor your personal giving goals.
            </p>
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-amber-500 font-medium">
            <span>Calculate Zakat & Track Giving</span>
            <ChevronRight size={16} className="transition-transform group-hover:translate-x-1" />
          </div>
        </Link>

        {/* Daily Dhikr & Tasbeeh Hub */}
        <Link 
          to="/tasbeeh" 
          className="group relative p-6 bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl hover:border-amber-600/60 transition-all duration-300 shadow-xl flex flex-col justify-between space-y-4"
        >
          <div className="flex items-start justify-between">
            <span className="p-3 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Sparkles size={24} />
            </span>
            <span className="text-[11px] font-mono text-amber-400 px-2.5 py-1 rounded-full bg-amber-950/80 border border-amber-800/60">
              Daily Remembrance
            </span>
          </div>

          <div>
            <h3 className="text-xl font-bold text-slate-100 group-hover:text-amber-400 transition-colors">
              Daily Dhikr & Tasbeeh
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm mt-1 leading-relaxed">
              Daily recommended morning and evening adhkar with tap-to-count circular progress counter, target goals, audio pronunciation, and habit tracking.
            </p>
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-amber-500 font-medium">
            <span>Open Digital Tasbeeh Counter</span>
            <ChevronRight size={16} className="transition-transform group-hover:translate-x-1" />
          </div>
        </Link>

        {/* Daily Scripture & Journal Hub */}
        <Link 
          to="/reflections" 
          className="group relative p-6 bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl hover:border-amber-600/60 transition-all duration-300 shadow-xl flex flex-col justify-between space-y-4"
        >
          <div className="flex items-start justify-between">
            <span className="p-3 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <BookOpen size={24} />
            </span>
            <span className="text-[11px] font-mono text-emerald-400 px-2.5 py-1 rounded-full bg-emerald-950/80 border border-emerald-800/60">
              Tadabbur & Journal
            </span>
          </div>

          <div>
            <h3 className="text-xl font-bold text-slate-100 group-hover:text-emerald-400 transition-colors">
              Scripture Reflection & Journal
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm mt-1 leading-relaxed">
              Read daily Quranic verses and Prophetic Hadiths with personal spiritual journal entries stored locally in IndexedDB.
            </p>
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-emerald-400 font-medium">
            <span>Write Today's Reflection</span>
            <ChevronRight size={16} className="transition-transform group-hover:translate-x-1" />
          </div>
        </Link>

        {/* Islamic Affirmations Hub */}
        <Link 
          to="/affirmations" 
          className="group relative p-6 bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl hover:border-amber-600/60 transition-all duration-300 shadow-xl flex flex-col justify-between space-y-4"
        >
          <div className="flex items-start justify-between">
            <span className="p-3 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Sparkles size={24} />
            </span>
            <span className="text-[11px] font-mono text-amber-400 px-2.5 py-1 rounded-full bg-amber-950/80 border border-amber-800/60">
              Spiritual Mindset
            </span>
          </div>

          <div>
            <h3 className="text-xl font-bold text-slate-100 group-hover:text-amber-400 transition-colors">
              Islamic Affirmations
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm mt-1 leading-relaxed">
              Daily positive Islamic affirmations based on Quran & Hadith to cultivate Tawakkul, peace, patience, gratitude, and confidence.
            </p>
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-amber-500 font-medium">
            <span>Explore Affirmations</span>
            <ChevronRight size={16} className="transition-transform group-hover:translate-x-1" />
          </div>
        </Link>
      </div>
    </div>
  );
}
