import React, { useState, useEffect, useMemo } from 'react';
import { 
  Sun, 
  Sparkles, 
  Compass, 
  RefreshCw, 
  CheckCircle2, 
  Send, 
  Share2, 
  Copy, 
  Check, 
  Flame,
  HelpCircle,
  PenTool,
  Lightbulb
} from 'lucide-react';
import { 
  morningReflectionsList, 
  getDailyMorningReflection, 
  DailyMorningReflection 
} from '../data/morningReflections';
import { 
  saveMorningIntention, 
  getMorningIntention, 
  getReflectionStreak 
} from '../lib/dailyReflectionTracker';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export default function DailyReflection() {
  const todayDateStr = useMemo(() => new Date().toISOString().split('T')[0], []);
  const todayFormatted = useMemo(() => {
    return new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'short',
      day: 'numeric'
    });
  }, []);

  const defaultReflection = useMemo(() => getDailyMorningReflection(new Date()), []);

  const [activeIndex, setActiveIndex] = useState(() => {
    const savedId = localStorage.getItem(`dailyReflection_selectedId_${todayDateStr}`);
    if (savedId) {
      const idx = morningReflectionsList.findIndex(r => r.id === savedId);
      if (idx !== -1) return idx;
    }
    const defIdx = morningReflectionsList.findIndex(r => r.id === defaultReflection.id);
    return defIdx !== -1 ? defIdx : 0;
  });

  const reflection: DailyMorningReflection = morningReflectionsList[activeIndex] || defaultReflection;

  // Intention input state
  const [intentionInput, setIntentionInput] = useState('');
  const [savedRecord, setSavedRecord] = useState(() => getMorningIntention(todayDateStr));
  const [isReflected, setIsReflected] = useState(() => Boolean(savedRecord?.isReflected));
  const [streak, setStreak] = useState(() => getReflectionStreak());
  const [copied, setCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    localStorage.setItem(`dailyReflection_selectedId_${todayDateStr}`, reflection.id);
    const existing = getMorningIntention(todayDateStr);
    setSavedRecord(existing);
    setIsReflected(Boolean(existing?.isReflected));
    if (existing?.intentionText) {
      setIntentionInput(existing.intentionText);
    }
    setStreak(getReflectionStreak());
  }, [reflection.id, todayDateStr]);

  const handleSaveIntention = (e: React.FormEvent) => {
    e.preventDefault();
    if (!intentionInput.trim()) return;

    triggerSuccessHaptic();
    const success = saveMorningIntention(todayDateStr, reflection.id, intentionInput);
    if (success) {
      const updated = getMorningIntention(todayDateStr);
      setSavedRecord(updated);
      setIsReflected(true);
      setIsEditing(false);
      setStreak(getReflectionStreak());
    }
  };

  const handleQuickReflectToggle = () => {
    triggerSuccessHaptic();
    const textToSave = intentionInput.trim() || reflection.actionableIntention;
    saveMorningIntention(todayDateStr, reflection.id, textToSave);
    const updated = getMorningIntention(todayDateStr);
    setSavedRecord(updated);
    setIsReflected(true);
    setStreak(getReflectionStreak());
  };

  const cycleReflection = () => {
    triggerButtonClickHaptic();
    setActiveIndex(prev => (prev + 1) % morningReflectionsList.length);
  };

  const handleCopy = async () => {
    triggerButtonClickHaptic();
    const text = `🌅 Morning Islamic Reflection: ${reflection.title}\n\n"${reflection.wisdom}"\n\n🤔 Question to Ponder:\n"${reflection.reflectionQuestion}"\n\n🎯 Today's Intention:\n${reflection.actionableIntention}\n\nReference: ${reflection.source}\nShared via Noor`;

    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(text);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleShare = async () => {
    triggerButtonClickHaptic();
    const shareData = {
      title: `Morning Reflection: ${reflection.title}`,
      text: `${reflection.title}\n\n"${reflection.wisdom}"\n\nQuestion: "${reflection.reflectionQuestion}"`,
      url: window.location.origin
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          handleCopy();
        }
      }
    } else {
      handleCopy();
    }
  };

  return (
    <article 
      aria-label="Daily Morning Reflection & Intention Centering"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-700/50 md:col-span-2"
    >
      {/* Subtle decorative glow */}
      <div 
        aria-hidden="true" 
        className="absolute -top-16 -right-16 w-44 h-44 rounded-full bg-amber-500/5 blur-3xl pointer-events-none"
      />

      {/* Header bar: Title, date & streak badge */}
      <div className="flex items-center justify-between pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-2">
          <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
            <Sun size={18} />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-semibold tracking-wide uppercase text-amber-500 flex items-center gap-1.5">
                Daily Morning Reflection
              </h2>
              <span className="text-xs font-serif text-slate-400 opacity-80" dir="rtl">
                تأملات الصباح
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {todayFormatted} · {reflection.theme}
            </p>
          </div>
        </div>

        {/* Header Right Actions */}
        <div className="flex items-center gap-1">
          {/* Reflection streak */}
          {streak > 0 && (
            <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-500/10 text-amber-400 border border-amber-500/20 mr-1">
              <Flame size={12} className="text-amber-500" />
              <span>{streak} Day Focus</span>
            </span>
          )}

          {/* Cycle to another prompt */}
          <button
            type="button"
            onClick={cycleReflection}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition-colors"
            title="Explore another reflection prompt"
            aria-label="Discover another reflection prompt"
          >
            <RefreshCw size={15} />
          </button>

          {/* Copy */}
          <button
            type="button"
            onClick={handleCopy}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition-colors"
            title="Copy reflection"
            aria-label="Copy reflection"
          >
            {copied ? <Check size={15} className="text-emerald-400" /> : <Copy size={15} />}
          </button>

          {/* Share */}
          <button
            type="button"
            onClick={handleShare}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition-colors"
            title="Share reflection"
            aria-label="Share reflection"
          >
            <Share2 size={15} />
          </button>
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="pt-4 grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Column: Wisdom & Thought-Provoking Question */}
        <div className="lg:col-span-7 space-y-3.5">
          {/* Theme & Arabic Tag */}
          <div className="flex items-center justify-between">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/30">
              <Sparkles size={11} /> {reflection.theme}
            </span>
            <span className="text-xs font-serif text-amber-200/70" dir="rtl">
              {reflection.arabicTheme}
            </span>
          </div>

          {/* Title & Core Wisdom */}
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-slate-100 mb-1.5 font-serif">
              {reflection.title}
            </h3>
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
              "{reflection.wisdom}"
            </p>
          </div>

          {/* Thought-Provoking Question Box */}
          <div className="p-3.5 sm:p-4 bg-amber-950/20 border border-amber-500/30 rounded-xl space-y-1 relative overflow-hidden">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-400">
              <HelpCircle size={14} />
              <span>Question to Ponder Today / سؤال اليوم:</span>
            </div>
            <p className="text-xs sm:text-sm text-amber-100 font-medium leading-relaxed italic select-text">
              "{reflection.reflectionQuestion}"
            </p>
          </div>

          {/* Source Citation */}
          <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1.5">
            <span>Reference:</span>
            <span className="text-slate-400">{reflection.source}</span>
          </div>
        </div>

        {/* Right Column: Intention Setting & Interactive Centerpiece */}
        <div className="lg:col-span-5 bg-slate-950/60 border border-amber-900/30 rounded-2xl p-4 sm:p-5 flex flex-col justify-between space-y-3.5 shadow-inner">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                <Compass size={14} /> Suggested Actionable Intention:
              </span>
              {isReflected && (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-950/80 border border-emerald-800/50 px-2 py-0.5 rounded-full">
                  <CheckCircle2 size={11} /> Centered
                </span>
              )}
            </div>
            
            <p className="text-xs text-slate-300 bg-slate-900/90 p-3 rounded-xl border border-slate-800 leading-relaxed italic">
              "{reflection.actionableIntention}"
            </p>
          </div>

          {/* User Custom Morning Intention Form */}
          {savedRecord && !isEditing ? (
            <div className="bg-slate-900/90 border border-emerald-500/30 rounded-xl p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 size={13} /> Your Intention for Today:
                </span>
                <button
                  type="button"
                  onClick={() => {
                    triggerButtonClickHaptic();
                    setIsEditing(true);
                  }}
                  className="text-[10px] text-amber-400 hover:underline flex items-center gap-0.5"
                >
                  <PenTool size={10} /> Edit
                </button>
              </div>
              <p className="text-xs text-slate-200 leading-relaxed font-medium">
                "{savedRecord.intentionText}"
              </p>
            </div>
          ) : (
            <form onSubmit={handleSaveIntention} className="space-y-2">
              <label htmlFor="morning-intention-input" className="block text-[11px] font-medium text-slate-400">
                Write Your Morning Intention (Niyyah):
              </label>
              <div className="relative">
                <input
                  id="morning-intention-input"
                  type="text"
                  placeholder="e.g. I intend to do my work with ihsan..."
                  value={intentionInput}
                  onChange={(e) => setIntentionInput(e.target.value)}
                  className="w-full bg-slate-900 border border-amber-900/40 text-slate-100 text-xs px-3 py-2.5 rounded-xl placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors shadow-inner"
                />
              </div>
              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={!intentionInput.trim()}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 disabled:hover:bg-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-md shadow-amber-500/20 transition active:scale-95"
                >
                  <Send size={12} />
                  <span>Set Intention</span>
                </button>
                {!isReflected && (
                  <button
                    type="button"
                    onClick={handleQuickReflectToggle}
                    className="py-2 px-3 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 font-medium text-xs rounded-xl transition active:scale-95"
                    title="Adopt suggested intention directly"
                  >
                    Adopt
                  </button>
                )}
              </div>
            </form>
          )}

          {/* Footer note */}
          <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-800/60 flex items-center justify-between">
            <span>Intentions shape your day</span>
            <span className="text-amber-500/80 font-mono text-[10px]">إنما الأعمال بالنيات</span>
          </div>
        </div>
      </div>
    </article>
  );
}
