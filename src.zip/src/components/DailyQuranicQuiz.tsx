import React, { useState, useEffect, useMemo } from 'react';
import { 
  Sparkles, 
  Flame, 
  CheckCircle2, 
  XCircle, 
  BookOpen, 
  Share2, 
  Check, 
  ChevronLeft, 
  ChevronRight, 
  Award,
  RotateCcw
} from 'lucide-react';
import { getDailyQuizQuestion, QuizQuestion, quizQuestions } from '../data/quiz';
import { recordQuizAttempt } from '../lib/quizLeaderboard';
import { triggerHaptic } from '../lib/haptics';

export default function DailyQuranicQuiz() {
  const [dayOffset, setDayOffset] = useState<number>(0); // 0 = today, -1 = yesterday, etc.
  
  const targetDate = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + dayOffset);
    return d;
  }, [dayOffset]);

  const dateKey = useMemo(() => targetDate.toISOString().slice(0, 10), [targetDate]);

  const formattedDate = useMemo(() => {
    return targetDate.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'short',
      day: 'numeric'
    });
  }, [targetDate]);

  // Current question for this day
  const question: QuizQuestion = useMemo(() => getDailyQuizQuestion(targetDate), [targetDate]);

  // User's answer state for this date
  const [selectedOption, setSelectedOption] = useState<number | null>(() => {
    try {
      const saved = localStorage.getItem(`dailyQuiz_answer_${dateKey}`);
      return saved !== null ? parseInt(saved, 10) : null;
    } catch {
      return null;
    }
  });

  const [copied, setCopied] = useState(false);

  // Daily streak tracker
  const [streak, setStreak] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('dailyQuiz_streak');
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });

  // Total daily quizzes answered
  const [stats, setStats] = useState(() => {
    try {
      const total = parseInt(localStorage.getItem('dailyQuiz_total') || '0', 10);
      const correct = parseInt(localStorage.getItem('dailyQuiz_correct') || '0', 10);
      return { total, correct };
    } catch {
      return { total: 0, correct: 0 };
    }
  });

  // Re-load answer state whenever dateKey changes
  useEffect(() => {
    try {
      const saved = localStorage.getItem(`dailyQuiz_answer_${dateKey}`);
      setSelectedOption(saved !== null ? parseInt(saved, 10) : null);
    } catch {
      setSelectedOption(null);
    }
  }, [dateKey]);

  // Handle selecting an option
  const handleSelectOption = (index: number) => {
    if (selectedOption !== null) return; // Already answered

    const isCorrect = index === question.answer;
    triggerHaptic(isCorrect ? 40 : 20);

    setSelectedOption(index);
    localStorage.setItem(`dailyQuiz_answer_${dateKey}`, index.toString());

    // Update streak and stats only for today's question
    if (dayOffset === 0) {
      const lastAnsweredDate = localStorage.getItem('dailyQuiz_lastAnsweredDate');
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().slice(0, 10);

      let newStreak = streak;
      if (lastAnsweredDate === yesterdayStr) {
        newStreak += 1;
      } else if (lastAnsweredDate === dateKey) {
        // already counted today
      } else {
        newStreak = 1;
      }

      setStreak(newStreak);
      localStorage.setItem('dailyQuiz_streak', newStreak.toString());
      localStorage.setItem('dailyQuiz_lastAnsweredDate', dateKey);

      const newTotal = stats.total + 1;
      const newCorrect = stats.correct + (isCorrect ? 1 : 0);
      setStats({ total: newTotal, correct: newCorrect });
      localStorage.setItem('dailyQuiz_total', newTotal.toString());
      localStorage.setItem('dailyQuiz_correct', newCorrect.toString());

      // Record in Leaderboard
      recordQuizAttempt('daily', question.category || 'Quran', isCorrect ? 1 : 0, 1);
    }
  };

  // Handle share
  const handleShare = async () => {
    triggerHaptic(15);
    const isCorrect = selectedOption === question.answer;
    const shareText = `🕌 Daily Quranic Quiz (${formattedDate})\n\n"${question.question}"\n\n${
      selectedOption !== null 
        ? isCorrect 
          ? `✅ I got it right! The answer is: ${question.options[question.answer]}` 
          : `📖 The correct answer was: ${question.options[question.answer]}`
        : 'Can you answer this question?'
    }\n\nTest your knowledge on Noor!`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Daily Quranic Quiz',
          text: shareText,
          url: window.location.origin
        });
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          await navigator.clipboard.writeText(shareText);
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        }
      }
    } else {
      await navigator.clipboard.writeText(shareText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const isAnswered = selectedOption !== null;
  const isCorrect = isAnswered && selectedOption === question.answer;
  const optionLetters = ['A', 'B', 'C', 'D'];

  return (
    <section 
      aria-label="Daily Quranic Quiz"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-700/50"
    >
      {/* Decorative ambient background glows */}
      <div 
        aria-hidden="true" 
        className="absolute -top-16 -right-16 w-44 h-44 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" 
      />
      <div 
        aria-hidden="true" 
        className="absolute -bottom-16 -left-16 w-44 h-44 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none" 
      />

      {/* Header bar: Title, Streak, and Date navigation */}
      <div className="flex items-center justify-between pb-4 border-b border-amber-900/20">
        <div className="flex items-center gap-2.5">
          <span className="p-2 rounded-xl bg-amber-500/10 text-amber-500">
            <Sparkles size={18} />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-semibold tracking-wide uppercase text-amber-500">
                Daily Quranic Quiz
              </h3>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-slate-800 text-amber-400/90 border border-amber-900/30">
                {question.category}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {dayOffset === 0 ? "Today's Challenge" : formattedDate} · Difficulty: {question.difficulty}
            </p>
          </div>
        </div>

        {/* Streak & Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {streak > 0 && (
            <div 
              title={`${streak}-day daily quiz streak!`}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold"
            >
              <Flame size={14} className="fill-amber-400 text-amber-500 animate-pulse" />
              <span>{streak} {streak === 1 ? 'Day' : 'Days'}</span>
            </div>
          )}

          {/* Date switcher (Yesterday / Today) */}
          <div className="flex items-center bg-slate-800/80 rounded-xl p-0.5 border border-slate-700/50 text-xs">
            <button
              type="button"
              onClick={() => {
                triggerHaptic(15);
                setDayOffset(prev => prev - 1);
              }}
              title="Previous day's question"
              className="p-1 hover:text-amber-400 transition-colors rounded-lg"
              aria-label="Previous day's question"
            >
              <ChevronLeft size={16} />
            </button>
            <span className="px-1.5 text-[11px] font-mono text-slate-300">
              {dayOffset === 0 ? 'Today' : `${dayOffset}d`}
            </span>
            <button
              type="button"
              disabled={dayOffset >= 0}
              onClick={() => {
                triggerHaptic(15);
                setDayOffset(prev => prev + 1);
              }}
              title="Next day's question"
              className={`p-1 transition-colors rounded-lg ${
                dayOffset >= 0 ? 'text-slate-600 cursor-not-allowed' : 'hover:text-amber-400 text-slate-300'
              }`}
              aria-label="Next day's question"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Main Question Body */}
      <div className="pt-4 space-y-4">
        <h4 className="text-base sm:text-lg font-medium text-slate-100 leading-snug">
          {question.question}
        </h4>

        {/* Options Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {question.options.map((option, idx) => {
            const isChosen = selectedOption === idx;
            const isCorrectOption = idx === question.answer;

            let optionClasses = 'bg-slate-950/60 hover:bg-slate-800/60 border-slate-800 text-slate-200';
            let badgeClasses = 'bg-slate-800 text-slate-400 border-slate-700';

            if (isAnswered) {
              if (isCorrectOption) {
                optionClasses = 'bg-emerald-950/40 border-emerald-500/70 text-emerald-200 font-medium shadow-sm shadow-emerald-500/10 ring-1 ring-emerald-500/30';
                badgeClasses = 'bg-emerald-500 text-slate-950 font-bold border-emerald-400';
              } else if (isChosen && !isCorrectOption) {
                optionClasses = 'bg-red-950/40 border-red-500/60 text-red-200 line-through opacity-85';
                badgeClasses = 'bg-red-500 text-slate-950 font-bold border-red-400';
              } else {
                optionClasses = 'bg-slate-950/30 border-slate-900 text-slate-500 opacity-60';
              }
            }

            return (
              <button
                key={idx}
                type="button"
                disabled={isAnswered}
                onClick={() => handleSelectOption(idx)}
                className={`p-3 sm:p-3.5 rounded-xl border text-left flex items-center gap-3 transition-all duration-200 select-none ${
                  !isAnswered ? 'active:scale-[0.98] cursor-pointer' : 'cursor-default'
                } ${optionClasses}`}
              >
                <span className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-mono font-semibold border flex-shrink-0 transition-colors ${badgeClasses}`}>
                  {isAnswered && isCorrectOption ? (
                    <Check size={14} strokeWidth={3} />
                  ) : isAnswered && isChosen ? (
                    '✕'
                  ) : (
                    optionLetters[idx]
                  )}
                </span>
                <span className="text-sm leading-snug flex-grow">
                  {option}
                </span>
              </button>
            );
          })}
        </div>

        {/* Detailed Explanation & Insight Card (Revealed upon answering) */}
        {isAnswered && (
          <div className="mt-4 p-4 rounded-xl border bg-slate-950/80 border-amber-900/30 space-y-2.5 animate-fadeIn">
            {/* Result Status Banner */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {isCorrect ? (
                  <span className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400 bg-emerald-950/70 border border-emerald-800/60 px-2.5 py-1 rounded-full">
                    <CheckCircle2 size={14} /> Correct! Masha'Allah
                  </span>
                ) : (
                  <span className="flex items-center gap-1.5 text-xs font-semibold text-red-400 bg-red-950/70 border border-red-800/60 px-2.5 py-1 rounded-full">
                    <XCircle size={14} /> Incorrect — Keep learning!
                  </span>
                )}
                {isCorrect && (
                  <span className="text-xs font-mono text-amber-400 font-semibold">
                    +10 Points
                  </span>
                )}
              </div>

              {/* Share Question Button */}
              <button
                type="button"
                onClick={handleShare}
                className="text-xs text-slate-400 hover:text-amber-400 flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-slate-800 transition-colors"
                title="Share this question"
                aria-label="Share question"
              >
                {copied ? <Check size={13} className="text-emerald-400" /> : <Share2 size={13} />}
                <span>{copied ? 'Copied' : 'Share'}</span>
              </button>
            </div>

            {/* Explanation paragraph */}
            <div className="text-xs text-slate-300 leading-relaxed pt-1">
              <span className="text-amber-400 font-semibold flex items-center gap-1 mb-1">
                <BookOpen size={13} /> Explanation & Reflection
              </span>
              <p>{question.explanation}</p>
            </div>

            {/* Reference Citation */}
            {question.reference && (
              <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 flex items-center gap-1">
                <span className="text-slate-500 font-mono">Reference:</span>
                <span className="text-slate-300 font-medium">{question.reference}</span>
              </div>
            )}
          </div>
        )}

        {/* Footer info & stats */}
        <div className="pt-2 flex items-center justify-between text-xs text-slate-400">
          <div>
            {!isAnswered ? (
              <span className="text-amber-500/90 font-medium">
                Choose an answer to reveal the Quranic explanation
              </span>
            ) : (
              <span>Come back tomorrow for a new question!</span>
            )}
          </div>

          {stats.total > 0 && (
            <div className="text-[11px] font-mono text-slate-400 hidden sm:block">
              Accuracy: <span className="text-slate-200 font-semibold">{Math.round((stats.correct / stats.total) * 100)}%</span> ({stats.correct}/{stats.total})
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
