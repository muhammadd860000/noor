import React, { useState, useEffect, useMemo } from 'react';
import { 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid, 
  ReferenceLine,
  Cell
} from 'recharts';
import { 
  TrendingUp, 
  Flame, 
  Award, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  BarChart3, 
  LineChart as LineChartIcon,
  Info
} from 'lucide-react';
import { getAllFromDB, getFromDB } from '../lib/db';
import { triggerHaptic } from '../lib/haptics';

const OBLIGATORY_PRAYERS = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

interface DayRecord {
  dateStr: string; // "YYYY-MM-DD"
  displayDate: string; // "Sep 28"
  fullDate: string; // "Monday, Sep 28"
  completedCount: number; // 0 to 5
  percentage: number; // 0 to 100
  prayers: Record<string, boolean>;
}

export default function PrayerInsights() {
  const [activeTab, setActiveTab] = useState<'trend' | 'breakdown'>('trend');
  const [dbRecords, setDbRecords] = useState<Record<string, Record<string, boolean>>>({});
  const [loading, setLoading] = useState(true);

  // Load 30-day prayer data from IndexedDB & localStorage
  const loadPrayerData = async () => {
    try {
      const recordsMap: Record<string, Record<string, boolean>> = {};

      // 1. Fetch from IndexedDB
      const allDbPrayer = await getAllFromDB('prayer');
      if (Array.isArray(allDbPrayer)) {
        allDbPrayer.forEach(item => {
          if (item && item.date && item.date !== 'history' && item.prayers) {
            // item.date can be a Date string (e.g. "Mon Sep 28 2026") or ISO format
            const parsed = new Date(item.date);
            if (!isNaN(parsed.getTime())) {
              const isoKey = parsed.toISOString().slice(0, 10);
              recordsMap[isoKey] = item.prayers;
              recordsMap[item.date] = item.prayers;
            }
          }
        });
      }

      // 2. Fetch recent days from localStorage as well
      const now = new Date();
      for (let i = 0; i < 35; i++) {
        const d = new Date(now);
        d.setDate(d.getDate() - i);
        const toDateString = d.toDateString();
        const isoString = d.toISOString().slice(0, 10);

        const localSaved = localStorage.getItem(`dailyPrayers_${toDateString}`);
        if (localSaved) {
          try {
            const parsedLocal = JSON.parse(localSaved);
            recordsMap[isoString] = { ...recordsMap[isoString], ...parsedLocal };
            recordsMap[toDateString] = { ...recordsMap[toDateString], ...parsedLocal };
          } catch (e) {
            // ignore
          }
        }
      }

      setDbRecords(recordsMap);
    } catch (err) {
      console.warn('Error loading prayer history for insights:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPrayerData();

    // Listen for live updates when user toggles any prayer on any screen
    const handleSync = () => {
      loadPrayerData();
    };

    window.addEventListener('prayer-status-changed', handleSync);
    return () => window.removeEventListener('prayer-status-changed', handleSync);
  }, []);

  // Compute exact past 30 days time series
  const past30DaysData: DayRecord[] = useMemo(() => {
    const list: DayRecord[] = [];
    const now = new Date();

    for (let i = 29; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);

      const isoKey = d.toISOString().slice(0, 10);
      const toDateKey = d.toDateString();

      // Look up recorded prayers
      const recorded = dbRecords[isoKey] || dbRecords[toDateKey] || {};

      let completedCount = 0;
      OBLIGATORY_PRAYERS.forEach(p => {
        if (recorded[p]) completedCount++;
      });

      // If user has zero recorded history overall, seed a realistic sample for days older than today
      // so the initial preview is immediately valuable and demonstrates the chart capabilities
      const hasAnyRecords = Object.keys(dbRecords).length > 0;
      if (!hasAnyRecords && i > 0) {
        // Pseudo-deterministic pattern for realistic showcase
        const pseudoRand = (d.getDate() * 7 + d.getMonth() * 13) % 10;
        const mockCompleted = pseudoRand < 3 ? 4 : pseudoRand < 8 ? 5 : 3;
        completedCount = mockCompleted;
      }

      list.push({
        dateStr: isoKey,
        displayDate: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        fullDate: d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
        completedCount,
        percentage: Math.round((completedCount / 5) * 100),
        prayers: recorded
      });
    }

    return list;
  }, [dbRecords]);

  // Aggregate statistics
  const stats = useMemo(() => {
    let totalCompleted = 0;
    const totalPossible = past30DaysData.length * 5; // 150 prayers
    let fullDaysCount = 0; // days with 5/5
    let currentStreak = 0;

    // Check streak starting from today backwards
    for (let i = past30DaysData.length - 1; i >= 0; i--) {
      if (past30DaysData[i].completedCount >= 4) {
        currentStreak++;
      } else {
        break;
      }
    }

    // Individual prayer breakdown
    const prayerCounts: Record<string, number> = {
      Fajr: 0,
      Dhuhr: 0,
      Asr: 0,
      Maghrib: 0,
      Isha: 0
    };

    past30DaysData.forEach(day => {
      totalCompleted += day.completedCount;
      if (day.completedCount === 5) fullDaysCount++;

      OBLIGATORY_PRAYERS.forEach(p => {
        if (day.prayers[p]) {
          prayerCounts[p] += 1;
        } else if (day.completedCount > 0) {
          // If we had simulated count
          prayerCounts[p] += Math.min(1, day.completedCount / 5);
        }
      });
    });

    const overallPercentage = Math.round((totalCompleted / (totalPossible || 1)) * 100);

    const prayerBreakdownList = OBLIGATORY_PRAYERS.map(name => {
      const count = Math.round(prayerCounts[name] || 0);
      const pct = Math.min(100, Math.round((count / past30DaysData.length) * 100));
      return {
        name,
        count,
        total: past30DaysData.length,
        percentage: pct
      };
    });

    // Sort to find strongest and most challenging prayer
    const sorted = [...prayerBreakdownList].sort((a, b) => b.percentage - a.percentage);
    const strongestPrayer = sorted[0];
    const challengingPrayer = sorted[sorted.length - 1];

    return {
      totalCompleted,
      totalPossible,
      fullDaysCount,
      overallPercentage,
      currentStreak,
      prayerBreakdownList,
      strongestPrayer,
      challengingPrayer
    };
  }, [past30DaysData]);

  // Custom Tooltip for Area Chart
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload as DayRecord;
      return (
        <div className="bg-slate-900/95 border border-amber-500/40 rounded-xl p-3 shadow-2xl backdrop-blur-md text-xs space-y-1.5 min-w-[150px]">
          <div className="font-semibold text-amber-400 border-b border-slate-800 pb-1">
            {data.fullDate}
          </div>
          <div className="flex justify-between items-center text-slate-200">
            <span>Prayers Offered:</span>
            <span className="font-mono font-bold text-amber-300">
              {data.completedCount} / 5
            </span>
          </div>
          <div className="flex justify-between items-center text-slate-400 text-[11px]">
            <span>Daily Score:</span>
            <span className={`font-mono font-semibold ${data.percentage === 100 ? 'text-emerald-400' : 'text-slate-300'}`}>
              {data.percentage}%
            </span>
          </div>
          {data.completedCount === 5 && (
            <div className="text-[10px] text-emerald-400 font-semibold pt-0.5 flex items-center gap-1">
              <CheckCircle2 size={12} /> Complete Salah Day!
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  // Custom Tooltip for Breakdown Bar Chart
  const CustomBreakdownTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900/95 border border-amber-500/40 rounded-xl p-3 shadow-2xl backdrop-blur-md text-xs space-y-1 min-w-[140px]">
          <div className="font-semibold text-amber-400">
            {data.name} Salah
          </div>
          <div className="text-slate-200">
            Offered: <span className="font-mono font-bold text-amber-300">{data.count}</span> of {data.total} days
          </div>
          <div className="text-slate-400 text-[11px]">
            Consistency: <span className="text-emerald-400 font-semibold">{data.percentage}%</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <section 
      aria-label="Prayer Consistency Insights"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-700/50 space-y-6"
    >
      {/* Decorative ambient background flares */}
      <div 
        aria-hidden="true" 
        className="absolute -top-16 -right-16 w-48 h-48 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" 
      />
      <div 
        aria-hidden="true" 
        className="absolute -bottom-16 -left-16 w-48 h-48 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none" 
      />

      {/* Header with Title and Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <span className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <TrendingUp size={20} />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-100 tracking-tight">
                Prayer Insights
              </h3>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                30-Day Analysis
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Visualize your daily Salah consistency and identify growth areas
            </p>
          </div>
        </div>

        {/* View Mode Toggle: 30D Trend vs Per-Prayer Breakdown */}
        <div className="flex bg-slate-950/80 border border-amber-900/30 p-1 rounded-xl text-xs self-start sm:self-auto">
          <button
            type="button"
            onClick={() => {
              triggerHaptic(10);
              setActiveTab('trend');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'trend'
                ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <LineChartIcon size={14} />
            <span>30-Day Trend</span>
          </button>
          <button
            type="button"
            onClick={() => {
              triggerHaptic(10);
              setActiveTab('breakdown');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'breakdown'
                ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BarChart3 size={14} />
            <span>By Prayer</span>
          </button>
        </div>
      </div>

      {/* 4 Summary Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Overall Completion Rate */}
        <div className="p-3.5 bg-slate-950/60 border border-amber-900/20 rounded-xl space-y-1">
          <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
            <CheckCircle2 size={13} className="text-amber-500" />
            30-Day Rate
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl sm:text-2xl font-mono font-bold text-slate-100">
              {stats.overallPercentage}%
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              ({stats.totalCompleted}/{stats.totalPossible})
            </span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-1 mt-1 overflow-hidden">
            <div 
              className="bg-amber-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${stats.overallPercentage}%` }}
            />
          </div>
        </div>

        {/* Consistency Streak */}
        <div className="p-3.5 bg-slate-950/60 border border-amber-900/20 rounded-xl space-y-1">
          <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
            <Flame size={13} className="text-amber-500" />
            Active Streak
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl sm:text-2xl font-mono font-bold text-amber-400">
              {stats.currentStreak}
            </span>
            <span className="text-xs text-slate-300 font-medium">Days</span>
          </div>
          <p className="text-[10px] text-slate-400">Consecutive consistent Salah</p>
        </div>

        {/* Perfect Salah Days (5/5) */}
        <div className="p-3.5 bg-slate-950/60 border border-amber-900/20 rounded-xl space-y-1">
          <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
            <Award size={13} className="text-emerald-400" />
            Full Days (5/5)
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl sm:text-2xl font-mono font-bold text-emerald-400">
              {stats.fullDaysCount}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">/ 30 Days</span>
          </div>
          <p className="text-[10px] text-slate-400">All 5 prayers fulfilled</p>
        </div>

        {/* Most Consistent Prayer */}
        <div className="p-3.5 bg-slate-950/60 border border-amber-900/20 rounded-xl space-y-1">
          <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
            <Sparkles size={13} className="text-amber-400" />
            Top Consistency
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-base sm:text-lg font-bold text-slate-100">
              {stats.strongestPrayer.name}
            </span>
            <span className="text-xs text-emerald-400 font-mono font-semibold">
              {stats.strongestPrayer.percentage}%
            </span>
          </div>
          <p className="text-[10px] text-slate-400">Your most faithful prayer</p>
        </div>
      </div>

      {/* Main Recharts Visualization Canvas */}
      <div className="bg-slate-950/60 border border-amber-900/20 rounded-2xl p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="font-semibold text-slate-200">
            {activeTab === 'trend' ? 'Daily Completed Prayers (0 - 5)' : 'Prayer-by-Prayer Completion Rate'}
          </span>
          <span className="text-[11px] font-mono text-slate-400">
            {activeTab === 'trend' ? 'Goal: 5 Prayers / Day' : 'Target: 100%'}
          </span>
        </div>

        <div className="w-full h-64 min-w-0">
          {activeTab === 'trend' ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={past30DaysData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="prayerAreaGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.45} />
                    <stop offset="95%" stopColor="#d97706" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.35} vertical={false} />
                <XAxis 
                  dataKey="displayDate" 
                  stroke="#64748b" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={{ stroke: '#334155' }}
                  interval={4}
                />
                <YAxis 
                  domain={[0, 5]} 
                  ticks={[0, 1, 2, 3, 4, 5]} 
                  stroke="#64748b" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={{ stroke: '#334155' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine y={5} stroke="#10b981" strokeDasharray="4 4" opacity={0.6} />
                <Area 
                  type="monotone" 
                  dataKey="completedCount" 
                  stroke="#f59e0b" 
                  strokeWidth={2.5} 
                  fillOpacity={1} 
                  fill="url(#prayerAreaGradient)" 
                  activeDot={{ r: 5, fill: '#f59e0b', stroke: '#ffffff', strokeWidth: 2 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.prayerBreakdownList} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.35} vertical={false} />
                <XAxis 
                  dataKey="name" 
                  stroke="#94a3b8" 
                  fontSize={12} 
                  fontWeight={600}
                  tickLine={false} 
                  axisLine={{ stroke: '#334155' }}
                />
                <YAxis 
                  domain={[0, 100]} 
                  ticks={[0, 25, 50, 75, 100]} 
                  stroke="#64748b" 
                  fontSize={10} 
                  tickLine={false} 
                  unit="%" 
                  axisLine={{ stroke: '#334155' }}
                />
                <Tooltip content={<CustomBreakdownTooltip />} />
                <ReferenceLine y={100} stroke="#10b981" strokeDasharray="4 4" opacity={0.5} />
                <Bar 
                  dataKey="percentage" 
                  radius={[8, 8, 0, 0]}
                  maxBarSize={48}
                >
                  {stats.prayerBreakdownList.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.percentage >= 90 ? '#10b981' : entry.percentage >= 75 ? '#f59e0b' : '#f97316'} 
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* 30-Day Dot Matrix Heatmap Streak (Miniature Overview) */}
        <div className="pt-3 border-t border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1 font-medium">
              <Calendar size={13} className="text-amber-500" />
              Past 30 Days Mini-Map:
            </span>
            <span>Hover or tap points on the graph above for details</span>
          </div>

          <div className="grid grid-cols-10 sm:grid-cols-15 gap-1.5">
            {past30DaysData.map((d, i) => {
              let dotBg = 'bg-slate-800/80 border-slate-700/60';
              if (d.completedCount === 5) {
                dotBg = 'bg-emerald-500 border-emerald-400 shadow-xs shadow-emerald-500/20';
              } else if (d.completedCount >= 3) {
                dotBg = 'bg-amber-500 border-amber-400';
              } else if (d.completedCount > 0) {
                dotBg = 'bg-amber-800/60 border-amber-700/60';
              }

              return (
                <div 
                  key={d.dateStr}
                  title={`${d.displayDate}: ${d.completedCount}/5 offered`}
                  className={`w-full aspect-square rounded-md border flex items-center justify-center text-[9px] font-mono font-bold transition-transform hover:scale-125 ${dotBg} ${
                    i === past30DaysData.length - 1 ? 'ring-2 ring-white/80' : ''
                  }`}
                >
                  <span className={d.completedCount === 5 ? 'text-slate-950' : 'text-slate-200'}>
                    {d.completedCount}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Actionable Spiritual Reflection & Recommendation */}
      <div className="p-4 bg-amber-950/20 border border-amber-900/30 rounded-xl flex items-start gap-3 text-xs leading-relaxed">
        <Info size={16} className="text-amber-400 flex-shrink-0 mt-0.5" />
        <div className="space-y-1">
          <span className="font-semibold text-amber-300 block">
            Personal Spiritual Insight
          </span>
          <p className="text-slate-300">
            {stats.overallPercentage >= 85 ? (
              <>
                Masha'Allah! Your 30-day Salah consistency is exceptional at <strong>{stats.overallPercentage}%</strong>. Your devotion to {stats.strongestPrayer.name} is a guiding light. Continue guarding your prayers punctually!
              </>
            ) : stats.overallPercentage >= 60 ? (
              <>
                Alhamdulillah! You have completed <strong>{stats.totalCompleted}</strong> prayers in the past 30 days. To strengthen your streak, try setting push notifications 10 minutes before <strong>{stats.challengingPrayer.name}</strong> to never miss an Adhan.
              </>
            ) : (
              <>
                A noble journey begins one prayer at a time. The Prophet (ﷺ) reminded us that the most beloved deeds to Allah are those done consistently, even if small. Focus on locking in today's remaining prayers!
              </>
            )}
          </p>
        </div>
      </div>
    </section>
  );
}
