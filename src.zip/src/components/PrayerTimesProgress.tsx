import React from 'react';
import { usePrayerTimes } from '../hooks/usePrayerTimes';
import { Clock } from 'lucide-react';

export default function PrayerTimesProgress() {
  const { times, nextPrayer } = usePrayerTimes();

  if (!times) return null;

  const prayerList = ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

  return (
    <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 shadow-lg md:col-span-2">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-amber-600 font-semibold flex items-center gap-2">
          <Clock size={18} /> Prayer Timeline
        </h3>
        {nextPrayer && (
          <span className="text-slate-400 text-sm">
            Next: <span className="text-amber-500 font-bold">{nextPrayer.name}</span> ({nextPrayer.remaining} remaining)
          </span>
        )}
      </div>
      
      <div className="relative pt-4">
        <div className="h-1 bg-slate-700 rounded-full absolute top-6 left-2 right-2"></div>
        <div className="flex justify-between relative z-10">
            {prayerList.map(prayer => (
                <div key={prayer} className="flex flex-col items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${nextPrayer?.name === prayer ? 'bg-amber-500 ring-2 ring-amber-500/50' : 'bg-slate-600'}`}></div>
                    <span className={`text-xs ${nextPrayer?.name === prayer ? 'text-amber-500 font-bold' : 'text-slate-400'}`}>{prayer}</span>
                    <span className="text-xs text-slate-500">{times[prayer]}</span>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
}
