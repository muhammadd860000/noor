import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Sparkles, 
  RefreshCw, 
  Heart, 
  Bookmark, 
  BookmarkCheck, 
  Share2, 
  Copy, 
  Check, 
  Volume2, 
  ExternalLink,
  BookOpen
} from 'lucide-react';
import { 
  allDuas, 
  DuaItem, 
  getBookmarkedDuaIds, 
  saveBookmarkedDuaIds 
} from '../data/duas';
import { getMotivationalDuaForDate } from '../lib/dailyDuaScheduler';
import { triggerHaptic, triggerButtonClickHaptic, triggerSuccessHaptic } from '../lib/haptics';

export default function DailyDuaCard() {
  const [currentDua, setCurrentDua] = useState<DuaItem>(() => getMotivationalDuaForDate(new Date()));
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(getBookmarkedDuaIds);
  const [isCopied, setIsCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  useEffect(() => {
    const handleBookmarkSync = (e: Event) => {
      const customEvent = e as CustomEvent<string[]>;
      if (customEvent.detail) {
        setBookmarkedIds(customEvent.detail);
      } else {
        setBookmarkedIds(getBookmarkedDuaIds());
      }
    };

    window.addEventListener('dua-bookmarks-changed', handleBookmarkSync);
    window.addEventListener('storage', handleBookmarkSync);
    return () => {
      window.removeEventListener('dua-bookmarks-changed', handleBookmarkSync);
      window.removeEventListener('storage', handleBookmarkSync);
    };
  }, []);

  const isBookmarked = bookmarkedIds.includes(currentDua.id);

  const toggleFavorite = () => {
    triggerHaptic(15);
    const nextIds = isBookmarked
      ? bookmarkedIds.filter(id => id !== currentDua.id)
      : [...bookmarkedIds, currentDua.id];

    saveBookmarkedDuaIds(nextIds);
    setBookmarkedIds(nextIds);
    if (!isBookmarked) {
      triggerSuccessHaptic();
    }
  };

  const handleRefresh = () => {
    triggerButtonClickHaptic();
    // Pick a random Dua different from the current one
    const pool = allDuas.filter(d => d.id !== currentDua.id);
    if (pool.length > 0) {
      const randomIndex = Math.floor(Math.random() * pool.length);
      setCurrentDua(pool[randomIndex]);
    }
  };

  const handleCopy = async () => {
    triggerButtonClickHaptic();
    const formattedText = `✨ ${currentDua.title}\n\n${currentDua.arabic}\n\n"${currentDua.meaning}"\n\n📖 Reference: ${currentDua.reference}\n\nShared via Noor Islamic Companion`;
    try {
      await navigator.clipboard.writeText(formattedText);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    } catch (err) {
      console.warn('Clipboard copy failed:', err);
    }
  };

  const handleSpeak = () => {
    triggerButtonClickHaptic();
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(currentDua.arabic);
    utterance.lang = 'ar-SA';
    utterance.rate = 0.85;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-emerald-900/40 rounded-2xl p-5 shadow-xl space-y-4 relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute top-0 right-0 w-36 h-36 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between gap-2 border-b border-emerald-900/30 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 shrink-0">
            <Sparkles size={20} />
          </div>
          <div>
            <h3 className="text-sm font-serif font-bold text-slate-100 flex items-center gap-2">
              <span>Daily Supplication (Dua)</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                {currentDua.categoryName || 'Daily Routine'}
              </span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">{currentDua.title}</p>
          </div>
        </div>

        {/* Refresh & Favorite Buttons */}
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={handleRefresh}
            className="p-2 rounded-xl bg-slate-950 text-slate-400 hover:text-emerald-400 border border-slate-800 hover:border-emerald-500/40 transition active:scale-95"
            title="Load New Curated Dua"
          >
            <RefreshCw size={16} />
          </button>

          <button
            type="button"
            onClick={toggleFavorite}
            className={`p-2 rounded-xl border transition active:scale-95 flex items-center gap-1 text-xs font-bold ${
              isBookmarked
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/50 shadow-sm'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-amber-400 hover:border-amber-500/40'
            }`}
            title={isBookmarked ? "Remove from Favorites" : "Save to Favorites"}
          >
            <Heart size={16} fill={isBookmarked ? "currentColor" : "none"} className={isBookmarked ? "text-amber-400" : ""} />
          </button>
        </div>
      </div>

      {/* Arabic Text */}
      <div className="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-4 text-center space-y-3">
        <p className="text-xl sm:text-2xl font-arabic text-slate-100 leading-loose tracking-wide dir-rtl font-serif">
          {currentDua.arabic}
        </p>
        
        {currentDua.transliteration && (
          <p className="text-xs text-emerald-300/90 italic font-medium">
            {currentDua.transliteration}
          </p>
        )}
      </div>

      {/* Meaning & Benefit */}
      <div className="space-y-1.5">
        <p className="text-xs text-slate-300 leading-relaxed font-sans">
          "{currentDua.meaning}"
        </p>
        {currentDua.benefit && (
          <p className="text-[11px] text-amber-300/80 bg-amber-950/30 border border-amber-800/40 p-2 rounded-xl font-sans">
            💡 {currentDua.benefit}
          </p>
        )}
      </div>

      {/* Bottom Controls & Reference */}
      <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800/80">
        <span className="text-[10px] font-mono text-slate-400 truncate">
          📖 {currentDua.reference || 'Quran & Sunnah'}
        </span>

        <div className="flex items-center gap-1.5 shrink-0">
          {/* Recite Audio Button */}
          <button
            type="button"
            onClick={handleSpeak}
            className={`p-1.5 px-2.5 rounded-xl border text-[11px] font-semibold transition flex items-center gap-1 ${
              isSpeaking
                ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-sm'
                : 'bg-slate-950 text-slate-300 border-slate-800 hover:text-emerald-400'
            }`}
            title="Recite Dua Aloud"
          >
            <Volume2 size={14} className={isSpeaking ? "animate-pulse" : ""} />
            <span className="hidden sm:inline">{isSpeaking ? 'Speaking...' : 'Recite'}</span>
          </button>

          {/* Copy Button */}
          <button
            type="button"
            onClick={handleCopy}
            className="p-1.5 px-2.5 rounded-xl bg-slate-950 text-slate-300 hover:text-emerald-400 border border-slate-800 transition text-[11px] font-semibold flex items-center gap-1"
            title="Copy Dua to Clipboard"
          >
            {isCopied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
            <span className="hidden sm:inline">{isCopied ? 'Copied' : 'Copy'}</span>
          </button>

          {/* View in Duas Library */}
          <Link
            to="/duas"
            className="p-1.5 px-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/30 transition text-[11px] font-semibold flex items-center gap-1"
          >
            <BookOpen size={14} />
            <span>Library</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
