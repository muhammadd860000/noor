import React, { useState, useMemo, useEffect } from 'react';
import { Search, Copy, Check, Share2, BookOpen, Sparkles, Heart, HeartOff } from 'lucide-react';
import { hadiths, HadithItem } from '../data/hadiths';
import DailyHadithQuiz from './DailyHadithQuiz';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export default function Hadith() {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [sharedId, setSharedId] = useState<number | null>(null);
  const [favoriteIds, setFavoriteIds] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('noor_favorite_hadith_ids');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('noor_favorite_hadith_ids', JSON.stringify(favoriteIds));
    } catch {}
  }, [favoriteIds]);

  const toggleFavorite = (hadithId: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    triggerHaptic(15);
    setFavoriteIds(prev => {
      const exists = prev.includes(hadithId);
      return exists ? prev.filter(id => id !== hadithId) : [...prev, hadithId];
    });
  };

  // Daily featured Hadith based on day of year
  const dailyFeaturedHadith = useMemo(() => {
    const now = new Date();
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now.getTime() - start.getTime();
    const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));
    return hadiths[dayOfYear % hadiths.length];
  }, []);

  // Extract unique categories plus Favorites
  const categories = useMemo(() => {
    const set = new Set<string>();
    hadiths.forEach(h => set.add(h.category));
    return ['All', 'Favorites', ...Array.from(set)];
  }, []);

  const filteredHadiths = useMemo(() => {
    return hadiths.filter(h => {
      let matchesCat = true;
      if (selectedCategory === 'Favorites') {
        matchesCat = favoriteIds.includes(h.id);
      } else if (selectedCategory !== 'All') {
        matchesCat = h.category === selectedCategory;
      }

      const q = search.toLowerCase().trim();
      const matchesSearch = !q || 
        h.text.toLowerCase().includes(q) ||
        (h.arabic && h.arabic.includes(q)) ||
        h.narrator.toLowerCase().includes(q) ||
        h.reference.toLowerCase().includes(q) ||
        (h.lesson && h.lesson.toLowerCase().includes(q)) ||
        h.category.toLowerCase().includes(q);

      return matchesCat && matchesSearch;
    });
  }, [search, selectedCategory, favoriteIds]);

  const handleCopy = async (hadith: HadithItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    triggerButtonClickHaptic();
    const content = `📜 Prophetic Guidance\n\n"${hadith.arabic}"\n\n${hadith.narrator}:\n"${hadith.text}"\n\n📖 Reference: ${hadith.reference}\n💡 Lesson: ${hadith.lesson || 'Wisdom for everyday life'}\n\nShared via Noor`;
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(content);
      }
      setCopiedId(hadith.id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (e) {
      console.warn(e);
      setCopiedId(hadith.id);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  const handleShare = async (hadith: HadithItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    triggerButtonClickHaptic();

    const shareTitle = `Hadith: ${hadith.category} — ${hadith.reference}`;
    const shareText = `"${hadith.arabic}"\n\n${hadith.narrator}:\n"${hadith.text}"\n\n📖 Reference: ${hadith.reference}\n\nShared via Noor`;
    const shareUrl = window.location.href;

    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: shareUrl
        });
        triggerSuccessHaptic();
        setSharedId(hadith.id);
        setTimeout(() => setSharedId(null), 2000);
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          handleCopy(hadith);
        }
      }
    } else {
      // Fallback to clipboard copy when Web Share API is not supported
      handleCopy(hadith);
    }
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Header */}
      <header className="space-y-1">
        <h2 className="text-2xl text-amber-500 font-serif font-bold">Hadith Collection</h2>
        <p className="text-xs text-slate-400">Authentic prophetic guidance and teachings with Arabic texts, lessons, and native social sharing</p>
      </header>

      {/* Daily Featured Hadith Highlight Banner */}
      {dailyFeaturedHadith && (
        <section 
          aria-label="Daily Featured Hadith"
          className="bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/40 rounded-2xl p-5 shadow-xl space-y-3 relative overflow-hidden"
        >
          <div className="flex items-center justify-between">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40">
              <Sparkles size={13} className="text-amber-400" />
              <span>Today's Featured Daily Hadith</span>
            </span>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={(e) => handleCopy(dailyFeaturedHadith, e)}
                className="p-2 text-slate-400 hover:text-amber-300 hover:bg-slate-800/80 rounded-xl transition"
                title="Copy Daily Hadith"
                aria-label="Copy Daily Hadith"
              >
                {copiedId === dailyFeaturedHadith.id ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
              </button>
              <button
                type="button"
                onClick={(e) => handleShare(dailyFeaturedHadith, e)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition active:scale-95"
                title="Share Daily Hadith via Web Share API"
                aria-label="Share Daily Hadith with friends and family"
              >
                <Share2 size={14} />
                <span>{sharedId === dailyFeaturedHadith.id ? 'Shared!' : 'Share Daily Hadith'}</span>
              </button>
            </div>
          </div>

          {dailyFeaturedHadith.arabic && (
            <p className="text-lg sm:text-xl font-arabic text-amber-200 text-right leading-loose pt-1" dir="rtl">
              {dailyFeaturedHadith.arabic}
            </p>
          )}

          <p className="text-slate-200 text-sm leading-relaxed italic">
            "{dailyFeaturedHadith.text}"
          </p>

          <div className="flex items-center justify-between pt-2 border-t border-amber-900/30 text-xs font-mono text-amber-400">
            <span>{dailyFeaturedHadith.narrator} · {dailyFeaturedHadith.reference}</span>
            <span className="text-slate-400">{dailyFeaturedHadith.category}</span>
          </div>
        </section>
      )}

      {/* Daily Hadith Interactive Quiz */}
      <DailyHadithQuiz />

      {/* Search Input */}
      <div className="relative">
        <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          type="text"
          placeholder="Search by keyword, topic, narrator, or Arabic..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-slate-900 border border-amber-900/30 text-slate-100 pl-10 pr-4 py-3 rounded-2xl focus:border-amber-500 outline-none text-sm placeholder-slate-500 shadow-inner"
        />
      </div>

      {/* Category Pills */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
        {categories.map(cat => (
          <button
            key={cat}
            type="button"
            onClick={() => {
              triggerButtonClickHaptic();
              setSelectedCategory(cat);
            }}
            className={`px-3 py-1.5 rounded-xl font-medium transition-colors whitespace-nowrap ${
              selectedCategory === cat
                ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Hadith Cards */}
      <div className="space-y-4">
        {filteredHadiths.map((hadith) => (
          <div 
            key={hadith.id} 
            className="p-5 bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl space-y-3 shadow-lg hover:border-amber-700/50 transition-all"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-400 border border-amber-500/20 font-semibold uppercase tracking-wider">
                {hadith.category}
              </span>

              <div className="flex items-center gap-1.5">
                <span className="text-xs text-slate-400 italic mr-1">
                  {hadith.narrator}
                </span>

                {/* Native Web Share API Button */}
                <button
                  type="button"
                  onClick={(e) => handleShare(hadith, e)}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-lg transition active:scale-95"
                  title="Share Hadith via Social Media or Messaging Apps"
                  aria-label="Share Hadith"
                >
                  <Share2 size={13} />
                  <span>{sharedId === hadith.id ? 'Shared!' : 'Share'}</span>
                </button>

                {/* Favorite Bookmark Button */}
                <button
                  type="button"
                  onClick={(e) => toggleFavorite(hadith.id, e)}
                  className={`p-1.5 rounded-lg border transition ${
                    favoriteIds.includes(hadith.id)
                      ? 'bg-rose-500/20 text-rose-400 border-rose-500/40 font-bold'
                      : 'text-slate-400 border-slate-800 hover:text-rose-400 hover:bg-slate-800'
                  }`}
                  title={favoriteIds.includes(hadith.id) ? 'Remove from favorites' : 'Save as favorite'}
                  aria-label="Toggle favorite Hadith"
                >
                  <Heart size={14} className={favoriteIds.includes(hadith.id) ? 'fill-rose-400 text-rose-400' : ''} />
                </button>

                {/* Copy Button */}
                <button
                  type="button"
                  onClick={(e) => handleCopy(hadith, e)}
                  className="p-1.5 text-slate-400 hover:text-amber-400 rounded-lg hover:bg-slate-800 transition-colors"
                  title="Copy Hadith"
                  aria-label="Copy Hadith"
                >
                  {copiedId === hadith.id ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                </button>
              </div>
            </div>

            {hadith.arabic && (
              <p className="text-lg sm:text-xl font-arabic text-amber-300 text-right leading-loose pt-1" dir="rtl">
                {hadith.arabic}
              </p>
            )}

            <p className="text-slate-200 text-sm leading-relaxed italic">
              "{hadith.text}"
            </p>

            {hadith.lesson && (
              <div className="p-3 bg-amber-950/20 border border-amber-500/20 rounded-xl text-xs text-slate-300 flex items-start gap-2">
                <Sparkles size={14} className="text-amber-400 flex-shrink-0 mt-0.5" />
                <span>{hadith.lesson}</span>
              </div>
            )}

            <div className="pt-2 border-t border-slate-800/80 flex justify-between items-center text-xs font-mono text-amber-700">
              <span>📖 {hadith.reference}</span>
              <span className="text-slate-500 text-[10px]">Hadith #{hadith.id}</span>
            </div>
          </div>
        ))}

        {filteredHadiths.length === 0 && (
          <div className="p-10 bg-slate-900/40 border border-slate-800 rounded-2xl text-center space-y-2">
            <BookOpen size={28} className="mx-auto text-amber-500/50" />
            <p className="text-sm font-semibold text-slate-200">No Hadiths found</p>
            <p className="text-xs text-slate-500">Try searching with a different word or select 'All' categories.</p>
          </div>
        )}
      </div>
    </div>
  );
}
