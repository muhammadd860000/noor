import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Calendar, 
  ChevronLeft, 
  ChevronRight, 
  Sparkles, 
  Flame, 
  BarChart3, 
  Award, 
  RotateCcw,
  Check,
  Clock,
  TrendingUp
} from 'lucide-react';
import { 
  getWeeklyPrayerSummary, 
  togglePrayerLog, 
  setAllPrayersForDate, 
  PRAYER_NAMES, 
  PrayerName, 
  WeeklyPrayerSummary, 
  DayPrayerLog 
} from '../lib/prayerLog';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

const PRAYER_DETAILS: Record<PrayerName, { arabic: string; timeOfDay: string }> = {
  Fajr: { arabic: 'الفجر', timeOfDay: 'Dawn prayer' },
  Dhuhr: { arabic: 'الظهر', timeOfDay: 'Midday prayer' },
  Asr: { arabic: 'العصر', timeOfDay: 'Afternoon prayer' },
  Maghrib: { arabic: 'المغرب', timeOfDay: 'Sunset prayer' },
  Isha: { arabic: 'العشاء', timeOfDay: 'Night prayer' }
};

interface PrayerLogProps {
  onPrayerToggled?: (prayer: string, completed: boolean) => void;
  className?: string;
}

export default function PrayerLog({ onPrayerToggled, className = '' }: PrayerLogProps) {
  const [selectedDate, setSelectedDate] = useState<Date>(() => new Date());
  const [summary, setSummary] = useState<WeeklyPrayerSummary>(() => getWeeklyPrayerSummary(new Date()));

  const selectedDateStr = useMemo(() => selectedDate.toDateString(), [selectedDate]);
  const isTodaySelected = useMemo(() => selectedDateStr === new Date().toDateString(), [selectedDateStr]);

  const refreshSummary = useCallback(() => {
    setSummary(getWeeklyPrayerSummary(selectedDate));
  }, [selectedDate]);

  useEffect(() => {
    refreshSummary();

    const handleSync = (e: Event) => {
      refreshSummary();
    };

    window.addEventListener('prayer-status-changed', handleSync);
    return () => window.removeEventListener('prayer-status-changed', handleSync);
  }, [refreshSummary]);

  // Current day data from weekly summary
  const currentDayLog: DayPrayerLog = useMemo(() => {
    const found = summary.weekDays.find(d => d.dateStr === selectedDateStr);
    if (found) return found;

    return {
      date: selectedDate,
      dateStr: selectedDateStr,
      isoDate: selectedDate.toISOString().slice(0, 10),
      dayShort: selectedDate.toLocaleDateString('en-US', { weekday: 'short' }),
      dayFull: selectedDate.toLocaleDateString('en-US', { weekday: 'long' }),
      dateNum: selectedDate.getDate(),
      prayers: {},
      completedCount: 0,
      totalPossible: 5,
      percentage: 0,
      isToday: isTodaySelected
    };
  }, [summary, selectedDateStr, selectedDate, isTodaySelected]);

  const handleTogglePrayer = async (prayer: PrayerName) => {
    triggerButtonClickHaptic();
    const { isCompleted } = await togglePrayerLog(selectedDateStr, prayer);
    if (isCompleted) {
      triggerSuccessHaptic();
    }
    refreshSummary();
    if (onPrayerToggled) {
      onPrayerToggled(prayer, isCompleted);
    }
  };

  const handleToggleAll = async (completeAll: boolean) => {
    triggerHaptic(25);
    await setAllPrayersForDate(selectedDateStr, completeAll);
    refreshSummary();
  };

  const handlePrevWeek = () => {
    triggerButtonClickHaptic();
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() - 7);
    setSelectedDate(newDate);
  };

  const handleNextWeek = () => {
    triggerButtonClickHaptic();
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + 7);
    setSelectedDate(newDate);
  };

  const handleJumpToToday = () => {
    triggerButtonClickHaptic();
    setSelectedDate(new Date());
  };

  const handleSelectDay = (day: DayPrayerLog) => {
    triggerButtonClickHaptic();
    setSelectedDate(day.date);
  };

  return (
    <section 
      aria-label="Prayer Log and Weekly Consistency"
      className={`bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6 ${className}`}
    >
      {/* Header Bar with Week Range & Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
            <BarChart3 size={20} />
          </div>
          <div>
            <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              <span>Prayer Log & Weekly Consistency</span>
              <span className="text-xs text-amber-500 font-serif opacity-80" dir="rtl">
                سجل الصلوات
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Track your 5 daily obligatory prayers and visualize weekly devotion
            </p>
          </div>
        </div>

        {/* Week Navigator */}
        <div className="flex items-center gap-1.5 self-start sm:self-auto bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            type="button"
            onClick={handlePrevWeek}
            aria-label="Previous Week"
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition"
          >
            <ChevronLeft size={16} />
          </button>
          
          <button
            type="button"
            onClick={handleJumpToToday}
            className={`px-2.5 py-1 rounded-lg font-medium transition ${
              isTodaySelected 
                ? 'bg-amber-600 text-slate-950 font-bold shadow-sm' 
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            Today
          </button>

          <button
            type="button"
            onClick={handleNextWeek}
            aria-label="Next Week"
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      {/* Weekly Consistency Bar Chart */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="font-semibold uppercase tracking-wider text-amber-500/90 flex items-center gap-1.5">
            <TrendingUp size={13} />
            7-Day Consistency Chart
          </span>
          <span className="font-mono text-slate-300">
            {summary.totalCompleted} / {summary.totalPossible} Prayers Completed ({summary.weeklyPercentage}%)
          </span>
        </div>

        {/* 7-Day Interactive Bar Chart */}
        <div className="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-4 sm:p-5">
          <div className="grid grid-cols-7 gap-2 sm:gap-3 items-end h-36 pt-4 pb-2">
            {summary.weekDays.map((day) => {
              const isSelected = day.dateStr === selectedDateStr;
              const fillPct = (day.completedCount / 5) * 100;

              return (
                <button
                  key={day.dateStr}
                  type="button"
                  onClick={() => handleSelectDay(day)}
                  className={`flex flex-col items-center justify-end h-full group focus:outline-none transition-transform active:scale-95 ${
                    isSelected ? 'scale-105' : 'opacity-80 hover:opacity-100'
                  }`}
                >
                  {/* Score Tag Above Bar */}
                  <span className={`text-[10px] sm:text-xs font-mono mb-1.5 font-semibold transition ${
                    day.completedCount === 5 
                      ? 'text-emerald-400' 
                      : day.completedCount > 0 
                        ? 'text-amber-400' 
                        : 'text-slate-500'
                  }`}>
                    {day.completedCount}/5
                  </span>

                  {/* Vertical Bar Track & Fill */}
                  <div className={`w-full max-w-[32px] sm:max-w-[42px] bg-slate-900 rounded-t-xl h-24 relative overflow-hidden border transition-all ${
                    isSelected 
                      ? 'border-amber-400 ring-2 ring-amber-500/30' 
                      : day.isToday 
                        ? 'border-amber-500/60' 
                        : 'border-slate-800'
                  }`}>
                    <div 
                      className={`w-full absolute bottom-0 transition-all duration-500 rounded-t-lg ${
                        day.completedCount === 5
                          ? 'bg-gradient-to-t from-emerald-600 to-emerald-400 shadow-lg shadow-emerald-500/20'
                          : day.completedCount >= 3
                            ? 'bg-gradient-to-t from-amber-600 to-amber-400 shadow-lg shadow-amber-500/20'
                            : day.completedCount > 0
                              ? 'bg-gradient-to-t from-amber-800 to-amber-600'
                              : 'bg-transparent'
                      }`}
                      style={{ height: `${fillPct}%` }}
                    />
                  </div>

                  {/* Day Name & Date Num */}
                  <div className="text-center mt-2">
                    <span className={`text-[10px] uppercase font-bold block ${
                      isSelected ? 'text-amber-400 font-extrabold' : 'text-slate-400'
                    }`}>
                      {day.dayShort}
                    </span>
                    <span className={`text-[11px] font-mono block ${
                      day.isToday ? 'text-amber-300 font-bold' : 'text-slate-500'
                    }`}>
                      {day.dateNum}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Selected Day Check-off Header & Quick Bulk Controls */}
      <div className="space-y-3 pt-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-1">
          <div>
            <h4 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <Calendar size={15} className="text-amber-500" />
              <span>{currentDayLog.dayFull}, {currentDayLog.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
              {currentDayLog.isToday && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 font-semibold">
                  Today
                </span>
              )}
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              {currentDayLog.completedCount} of 5 prayers completed ({currentDayLog.percentage}%)
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <button
              type="button"
              onClick={() => handleToggleAll(true)}
              className="text-amber-400 hover:text-amber-300 font-semibold transition"
            >
              Mark All Completed
            </button>
            <span className="text-slate-600">·</span>
            <button
              type="button"
              onClick={() => handleToggleAll(false)}
              className="text-slate-400 hover:text-slate-200 transition"
            >
              Reset Day
            </button>
          </div>
        </div>

        {/* 5 Daily Prayer Check Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5">
          {PRAYER_NAMES.map((prayer) => {
            const isDone = !!currentDayLog.prayers[prayer];
            const details = PRAYER_DETAILS[prayer];

            return (
              <button
                key={prayer}
                type="button"
                onClick={() => handleTogglePrayer(prayer)}
                className={`flex sm:flex-col items-center justify-between p-3.5 rounded-xl border text-left sm:text-center transition-all active:scale-[0.98] ${
                  isDone
                    ? 'bg-amber-950/30 border-amber-500/60 shadow-md shadow-amber-950/40 text-slate-100 ring-1 ring-amber-500/30'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-amber-900/40 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center sm:flex-col gap-2.5 sm:gap-1">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center border transition-colors ${
                    isDone 
                      ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-sm' 
                      : 'border-slate-700 bg-slate-900 text-transparent'
                  }`}>
                    <Check size={16} strokeWidth={3} className={isDone ? 'block' : 'opacity-0'} />
                  </div>
                  
                  <div>
                    <span className={`text-sm font-bold block ${isDone ? 'text-amber-300' : 'text-slate-200'}`}>
                      {prayer}
                    </span>
                    <span className="text-xs text-amber-400/80 font-serif block sm:inline" dir="rtl">
                      {details.arabic}
                    </span>
                  </div>
                </div>

                <div className="text-right sm:text-center mt-0 sm:mt-1">
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                    isDone 
                      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' 
                      : 'bg-slate-900 text-slate-500 border-slate-800'
                  }`}>
                    {isDone ? 'Completed' : 'Pending'}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Weekly Stats Summary Footprint */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2 border-t border-amber-900/20 text-xs">
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
          <span className="text-slate-400 block text-[11px]">Weekly Completion</span>
          <span className="text-lg font-mono font-bold text-amber-400 mt-0.5 block">
            {summary.weeklyPercentage}%
          </span>
          <span className="text-[10px] text-slate-500">{summary.totalCompleted} / 35 prayers</span>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
          <span className="text-slate-400 block text-[11px]">Perfect Days (5/5)</span>
          <span className="text-lg font-mono font-bold text-emerald-400 mt-0.5 block">
            {summary.perfectDaysCount} {summary.perfectDaysCount === 1 ? 'day' : 'days'}
          </span>
          <span className="text-[10px] text-slate-500">100% completed days</span>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
          <span className="text-slate-400 block text-[11px]">Consistency Streak</span>
          <span className="text-lg font-mono font-bold text-amber-300 mt-0.5 block flex items-center gap-1">
            <Flame size={16} className="text-amber-500" />
            <span>{summary.currentStreak} {summary.currentStreak === 1 ? 'day' : 'days'}</span>
          </span>
          <span className="text-[10px] text-slate-500">Consecutive prayer days</span>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
          <span className="text-slate-400 block text-[11px]">Devotion Level</span>
          <span className="text-lg font-bold text-slate-200 mt-0.5 block">
            {summary.weeklyPercentage >= 90 
              ? 'Exemplary' 
              : summary.weeklyPercentage >= 70 
                ? 'Consistent' 
                : summary.weeklyPercentage >= 40 
                  ? 'Steadfast' 
                  : 'Building'}
          </span>
          <span className="text-[10px] text-amber-500/80">Keep striving for His sake</span>
        </div>
      </div>
    </section>
  );
}
