import { useState, useEffect } from 'react';
import { Target, Plus, RefreshCw } from 'lucide-react';
import { triggerHaptic } from '../lib/haptics';
import { dhikrList } from '../data/dhikr';

export default function DhikrTracker() {
  const [count, setCount] = useState(() => {
    const saved = localStorage.getItem('dhikrCount');
    const savedDate = localStorage.getItem('dhikrDate');
    const today = new Date().toDateString();
    return savedDate === today ? (saved ? parseInt(saved) : 0) : 0;
  });
  const [goal] = useState(100);
  const [dailyZikr, setDailyZikr] = useState(() => {
    const saved = localStorage.getItem('dailyZikr');
    const savedDate = localStorage.getItem('dailyZikrDate');
    const today = new Date().toDateString();
    
    if (saved && savedDate === today) return JSON.parse(saved);
    
    const randomZikr = dhikrList[Math.floor(Math.random() * dhikrList.length)];
    localStorage.setItem('dailyZikr', JSON.stringify(randomZikr));
    localStorage.setItem('dailyZikrDate', today);
    return randomZikr;
  });

  useEffect(() => {
    localStorage.setItem('dhikrCount', count.toString());
    localStorage.setItem('dhikrDate', new Date().toDateString());
  }, [count]);

  const progress = Math.min((count / goal) * 100, 100);

  const increment = () => {
    setCount(prev => prev + 1);
    triggerHaptic(10);
  };

  const reset = () => {
    setCount(0);
    triggerHaptic(20);
  };

  return (
    <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-amber-600 font-semibold flex items-center gap-2">
            <Target size={18}/> Daily Dhikr
        </h3>
        <button onClick={reset} className="text-slate-500 hover:text-amber-500">
            <RefreshCw size={18} />
        </button>
      </div>
      
      <div className="text-center mb-4">
        <p className="text-2xl text-slate-100 font-arabic mb-1">{dailyZikr.arabic}</p>
        <p className="text-slate-400 text-sm mb-3">{dailyZikr.meaning}</p>
        <span className="text-4xl font-bold text-slate-100">{count}</span>
        <span className="text-slate-400"> / {goal}</span>
      </div>

      <div className="w-full bg-slate-800 rounded-full h-3 mb-6">
        <div 
            className="bg-amber-600 h-3 rounded-full transition-all duration-300"
            style={{ width: `${progress}` + '%' }}
        />
      </div>

      <button 
        onClick={increment}
        className="w-full bg-amber-600 text-slate-950 font-bold py-3 rounded-xl flex items-center justify-center gap-2 hover:bg-amber-500 transition"
      >
        <Plus size={20} /> Add Recitation
      </button>
    </div>
  );
}
