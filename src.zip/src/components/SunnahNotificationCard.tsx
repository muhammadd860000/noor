import React, { useState, useEffect } from 'react';
import { 
  Sun, 
  CloudRain, 
  Moon, 
  Compass, 
  Bell, 
  BellOff, 
  Check, 
  Sparkles, 
  MapPin, 
  Thermometer, 
  Send,
  Zap,
  Info
} from 'lucide-react';
import { 
  fetchCurrentContext, 
  generateSunnahAlert, 
  getSunnahPreferences, 
  saveSunnahPreferences, 
  triggerLiveSunnahContextAlert, 
  SunnahContextAlert, 
  SunnahNotificationPreferences 
} from '../lib/sunnahNotificationScheduler';
import { triggerHaptic, triggerSuccessHaptic } from '../lib/haptics';

export default function SunnahNotificationCard() {
  const [prefs, setPrefs] = useState<SunnahNotificationPreferences>(getSunnahPreferences);
  const [weatherContext, setWeatherContext] = useState<{
    temperatureC: number;
    isRaining: boolean;
    weatherDescription: string;
    cityName: string;
  } | null>(null);
  const [currentAlert, setCurrentAlert] = useState<SunnahContextAlert | null>(null);
  const [loadingContext, setLoadingContext] = useState(true);
  const [testSent, setTestSent] = useState(false);

  useEffect(() => {
    const loadContext = async () => {
      setLoadingContext(true);
      // Try getting browser coordinates if available
      if ('geolocation' in navigator) {
        navigator.geolocation.getCurrentPosition(
          async (pos) => {
            const ctx = await fetchCurrentContext(pos.coords.latitude, pos.coords.longitude);
            setWeatherContext(ctx);
            setCurrentAlert(generateSunnahAlert(ctx.temperatureC, ctx.isRaining, ctx.cityName));
            setLoadingContext(false);
          },
          async () => {
            const ctx = await fetchCurrentContext();
            setWeatherContext(ctx);
            setCurrentAlert(generateSunnahAlert(ctx.temperatureC, ctx.isRaining, ctx.cityName));
            setLoadingContext(false);
          },
          { timeout: 5000 }
        );
      } else {
        const ctx = await fetchCurrentContext();
        setWeatherContext(ctx);
        setCurrentAlert(generateSunnahAlert(ctx.temperatureC, ctx.isRaining, ctx.cityName));
        setLoadingContext(false);
      }
    };

    loadContext();

    const handleUpdate = (e: Event) => {
      const customEvent = e as CustomEvent<SunnahNotificationPreferences>;
      if (customEvent.detail) setPrefs(customEvent.detail);
      else setPrefs(getSunnahPreferences());
    };

    window.addEventListener('sunnah-notifications-updated', handleUpdate);
    return () => window.removeEventListener('sunnah-notifications-updated', handleUpdate);
  }, []);

  const handleMasterToggle = () => {
    triggerHaptic(20);
    const updated = { ...prefs, enabled: !prefs.enabled };
    setPrefs(updated);
    saveSunnahPreferences(updated);
    if (updated.enabled) triggerSuccessHaptic();
  };

  const handleToggleType = (key: keyof SunnahNotificationPreferences['alertTypes']) => {
    triggerHaptic(15);
    const updated = {
      ...prefs,
      alertTypes: {
        ...prefs.alertTypes,
        [key]: !prefs.alertTypes[key],
      },
    };
    setPrefs(updated);
    saveSunnahPreferences(updated);
  };

  const handleSendTestNotification = async () => {
    triggerHaptic(20);
    const sent = await triggerLiveSunnahContextAlert();
    if (sent) {
      setTestSent(true);
      triggerSuccessHaptic();
      setTimeout(() => setTestSent(false), 3500);
    }
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-5 shadow-xl space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <Compass size={20} />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>Context-Aware Sunnah Reminders</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold">
                Sun & Weather Aware
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Analyzes sun position, weather conditions, and location to deliver Sunnah-inspired alerts
            </p>
          </div>
        </div>

        {/* Master Enable Button */}
        <button
          type="button"
          onClick={handleMasterToggle}
          className={`px-3 py-1.5 rounded-xl font-bold text-xs transition flex items-center gap-1.5 self-start sm:self-auto ${
            prefs.enabled
              ? 'bg-amber-600 text-slate-950 shadow-md shadow-amber-600/20'
              : 'bg-slate-950 text-slate-400 border border-slate-800'
          }`}
        >
          {prefs.enabled ? <Bell size={14} className="fill-slate-950" /> : <BellOff size={14} />}
          <span>{prefs.enabled ? 'Sunnah Alerts Active' : 'Enable Sunnah Alerts'}</span>
        </button>
      </div>

      {/* Real-time Context Analysis Live Card */}
      <div className="p-4 bg-slate-950/80 border border-amber-900/30 rounded-xl space-y-3">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-amber-400 font-bold">
            <Sparkles size={15} />
            <span>Current Environmental Context</span>
          </div>

          {weatherContext && (
            <div className="flex items-center gap-3 text-[11px] font-mono text-slate-300">
              <span className="flex items-center gap-1">
                <MapPin size={12} className="text-amber-500" />
                <span>{weatherContext.cityName}</span>
              </span>
              <span className="flex items-center gap-1">
                <Thermometer size={12} className="text-amber-400" />
                <span>{weatherContext.temperatureC}°C</span>
              </span>
            </div>
          )}
        </div>

        {loadingContext ? (
          <div className="h-14 bg-slate-900 animate-pulse rounded-lg" />
        ) : currentAlert ? (
          <div className="space-y-2 pt-1">
            <div className="p-3 bg-slate-900/90 border border-slate-800 rounded-xl space-y-1.5">
              <span className="text-xs font-bold text-slate-100 block">{currentAlert.title}</span>
              <p className="text-xs text-slate-300 leading-relaxed">{currentAlert.message}</p>
              {currentAlert.arabicDua && (
                <p className="text-amber-300 font-arabic text-sm text-right leading-loose pt-1" dir="rtl">
                  {currentAlert.arabicDua}
                </p>
              )}
              <div className="flex items-center gap-2 pt-1 text-[11px] text-amber-400/90 italic">
                <Info size={13} className="shrink-0" />
                <span>Sunnah Insight ({currentAlert.hadithRef}): {currentAlert.sunnahLesson}</span>
              </div>
            </div>
          </div>
        ) : null}

        <button
          type="button"
          onClick={handleSendTestNotification}
          className="w-full py-2 px-3 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold text-xs rounded-xl transition flex items-center justify-center gap-2"
        >
          <Send size={14} />
          <span>Send Live Sunnah Context Push Notification</span>
        </button>
      </div>

      {/* Sunnah Alert Categories Toggles */}
      <div className="space-y-2 pt-1">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">Configurable Sunnah Conditions</h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          {/* Heat & Dhuhr Zenith */}
          <button
            type="button"
            onClick={() => handleToggleType('heat_dhuhr')}
            className={`p-3 rounded-xl border text-left transition flex items-start justify-between gap-2 ${
              prefs.enabled && prefs.alertTypes.heat_dhuhr
                ? 'bg-amber-950/20 border-amber-500/40 text-slate-100'
                : 'bg-slate-950/60 border-slate-800 text-slate-400'
            }`}
          >
            <div>
              <div className="flex items-center gap-1.5 font-bold">
                <Sun size={14} className="text-amber-400" />
                <span>Dhuhr Zenith & Heat (Ibrad)</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">Alerts when sun passes meridian or during peak midday heat.</p>
            </div>
            <span className={`w-4 h-4 rounded-full flex items-center justify-center border text-[10px] shrink-0 ${
              prefs.enabled && prefs.alertTypes.heat_dhuhr ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold' : 'border-slate-700'
            }`}>
              {prefs.enabled && prefs.alertTypes.heat_dhuhr ? '✓' : ''}
            </span>
          </button>

          {/* Rain Duas */}
          <button
            type="button"
            onClick={() => handleToggleType('rain_dua')}
            className={`p-3 rounded-xl border text-left transition flex items-start justify-between gap-2 ${
              prefs.enabled && prefs.alertTypes.rain_dua
                ? 'bg-amber-950/20 border-amber-500/40 text-slate-100'
                : 'bg-slate-950/60 border-slate-800 text-slate-400'
            }`}
          >
            <div>
              <div className="flex items-center gap-1.5 font-bold">
                <CloudRain size={14} className="text-sky-400" />
                <span>Rainy Day Duas</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">Notifies during rainfall with prophetic rain supplications.</p>
            </div>
            <span className={`w-4 h-4 rounded-full flex items-center justify-center border text-[10px] shrink-0 ${
              prefs.enabled && prefs.alertTypes.rain_dua ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold' : 'border-slate-700'
            }`}>
              {prefs.enabled && prefs.alertTypes.rain_dua ? '✓' : ''}
            </span>
          </button>

          {/* Pre-dawn Sky */}
          <button
            type="button"
            onClick={() => handleToggleType('predawn_sky')}
            className={`p-3 rounded-xl border text-left transition flex items-start justify-between gap-2 ${
              prefs.enabled && prefs.alertTypes.predawn_sky
                ? 'bg-amber-950/20 border-amber-500/40 text-slate-100'
                : 'bg-slate-950/60 border-slate-800 text-slate-400'
            }`}
          >
            <div>
              <div className="flex items-center gap-1.5 font-bold">
                <Moon size={14} className="text-indigo-400" />
                <span>Pre-Dawn Last Third (Tahajjud)</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">Alerts during the quiet last third of the night before Fajr.</p>
            </div>
            <span className={`w-4 h-4 rounded-full flex items-center justify-center border text-[10px] shrink-0 ${
              prefs.enabled && prefs.alertTypes.predawn_sky ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold' : 'border-slate-700'
            }`}>
              {prefs.enabled && prefs.alertTypes.predawn_sky ? '✓' : ''}
            </span>
          </button>

          {/* Friday Hour */}
          <button
            type="button"
            onClick={() => handleToggleType('friday_hour')}
            className={`p-3 rounded-xl border text-left transition flex items-start justify-between gap-2 ${
              prefs.enabled && prefs.alertTypes.friday_hour
                ? 'bg-amber-950/20 border-amber-500/40 text-slate-100'
                : 'bg-slate-950/60 border-slate-800 text-slate-400'
            }`}
          >
            <div>
              <div className="flex items-center gap-1.5 font-bold">
                <Sparkles size={14} className="text-emerald-400" />
                <span>Friday Hour of Acceptance</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">Reminds on Friday afternoon before Maghrib for accepted Du'a.</p>
            </div>
            <span className={`w-4 h-4 rounded-full flex items-center justify-center border text-[10px] shrink-0 ${
              prefs.enabled && prefs.alertTypes.friday_hour ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold' : 'border-slate-700'
            }`}>
              {prefs.enabled && prefs.alertTypes.friday_hour ? '✓' : ''}
            </span>
          </button>
        </div>
      </div>

      {testSent && (
        <div className="p-2.5 bg-emerald-950/30 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
          <Check size={14} className="text-emerald-400" />
          <span>Live Sunnah context push notification sent to your system browser alerts!</span>
        </div>
      )}
    </div>
  );
}
