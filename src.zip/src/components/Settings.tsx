import React, { useState, useEffect } from 'react';
import { useTheme } from '../context/ThemeContext';
import { useI18n } from '../context/I18nContext';
import PrayerNotificationManager from './PrayerNotificationManager';
import DailyDuaNotificationCard from './DailyDuaNotificationCard';
import DailyQuizNotificationCard from './DailyQuizNotificationCard';
import HajjRitualNotificationCard from './HajjRitualNotificationCard';
import SunnahNotificationCard from './SunnahNotificationCard';
import FocusPrayerReminderCard from './FocusPrayerReminderCard';
import PrayerAlarmSettings from './PrayerAlarmSettings';
import FeedbackModal from './FeedbackModal';
import { Link } from 'react-router-dom';
import { 
  MessageSquarePlus, 
  Bookmark, 
  Download, 
  Upload, 
  Copy, 
  Check, 
  CheckCircle2, 
  HardDrive, 
  Bell, 
  Moon, 
  Globe, 
  Type, 
  MapPin, 
  FileJson, 
  Sparkles, 
  BookHeart, 
  HandHeart, 
  Calendar,
  FileText,
  Printer 
} from 'lucide-react';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';
import { collectBackupData, downloadBackupFile, restoreBackupData, NoorExportData } from '../lib/dataExport';
import { openPrintableSpiritualReport } from '../lib/pdfSummaryGenerator';

export default function Settings() {
  const { theme, setTheme, toggleTheme, resolvedTheme, smartThemeEnabled, setSmartThemeEnabled, isNightTime, isSmartThemeActive } = useTheme();
  const { lang, setLang, t } = useI18n();
  const [fontSize, setFontSize] = useState(() => localStorage.getItem('userFontSize') || 'medium');
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);
  const [copiedBackup, setCopiedBackup] = useState(false);
  const [restoreMessage, setRestoreMessage] = useState<{ text: string; success: boolean } | null>(null);
  const [city, setCity] = useState(() => localStorage.getItem('userCity') || '');
  const [backupStats, setBackupStats] = useState<NoorExportData | null>(null);

  useEffect(() => {
    try {
      setBackupStats(collectBackupData());
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('userCity', city);
  }, [city]);

  useEffect(() => {
    localStorage.setItem('userFontSize', fontSize);
  }, [fontSize]);

  const handleExportData = () => {
    triggerButtonClickHaptic();
    setIsExporting(true);
    try {
      const data = collectBackupData();
      const success = downloadBackupFile(data);
      if (success) {
        triggerSuccessHaptic();
        setExportSuccess(true);
        setBackupStats(data);
        setTimeout(() => setExportSuccess(false), 3500);
      }
    } catch (err) {
      console.error('Failed to export backup:', err);
    } finally {
      setIsExporting(false);
    }
  };

  const handleCopyJSON = async () => {
    triggerButtonClickHaptic();
    try {
      const data = collectBackupData();
      await navigator.clipboard.writeText(JSON.stringify(data, null, 2));
      triggerSuccessHaptic();
      setCopiedBackup(true);
      setTimeout(() => setCopiedBackup(false), 3000);
    } catch (err) {
      console.warn('Clipboard copy failed:', err);
    }
  };

  const handleFileRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    triggerButtonClickHaptic();
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const result = restoreBackupData(text);
        if (result.success) {
          triggerSuccessHaptic();
          setRestoreMessage({
            text: `Restored ${result.counts.prayers} prayer records, ${result.counts.journals} reflections, and ${result.counts.zakatEntries} charity entries!`,
            success: true
          });
          setBackupStats(collectBackupData());
        } else {
          setRestoreMessage({ text: result.message, success: false });
        }
      } catch (err: any) {
        setRestoreMessage({ text: err?.message || 'Invalid JSON file', success: false });
      }
      setTimeout(() => setRestoreMessage(null), 6000);
    };
    reader.readAsText(file);
    // Reset file input value
    e.target.value = '';
  };

  return (
    <div className="space-y-6 pb-20">
      <header>
        <h2 className="text-2xl text-amber-500 font-serif">Settings</h2>
        <p className="text-xs text-slate-400 mt-1">
          Manage prayer alerts, notifications, appearance, and local data
        </p>
      </header>

      <div className="space-y-5">
        {/* Prayer Alerts & Push Notifications Section */}
        <PrayerNotificationManager />

        {/* Daily Motivational Dua Recurring Notification */}
        <DailyDuaNotificationCard />

        {/* Daily Islamic Quiz Scheduled Reminder */}
        <DailyQuizNotificationCard />

        {/* Hajj & Umrah Ritual Reminders */}
        <HajjRitualNotificationCard />

        {/* Context-Aware Sunnah Weather & Sun Reminders */}
        <SunnahNotificationCard />

        {/* Intelligent Focus Prayer Break Reminder */}
        <FocusPrayerReminderCard />

        {/* Location & Appearance */}
        <section className="bg-slate-900/60 border border-amber-900/30 rounded-2xl p-5 space-y-4">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-amber-500 flex items-center gap-2">
            <Globe size={16} />
            <span>Location & Preferences</span>
          </h3>

          <div className="space-y-3">
            {/* Language */}
            <div className="flex justify-between items-center pb-3 border-b border-slate-800">
              <div>
                <span className="text-slate-200 text-sm font-medium">{t('Language')}</span>
                <p className="text-[11px] text-slate-400">Select application interface language</p>
              </div>
              <div className="flex gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                <button 
                  type="button"
                  onClick={() => {
                    triggerHaptic(10);
                    setLang('en');
                  }} 
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${lang === 'en' ? 'bg-amber-600 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  English
                </button>
                <button 
                  type="button"
                  onClick={() => {
                    triggerHaptic(10);
                    setLang('ar');
                  }} 
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${lang === 'ar' ? 'bg-amber-600 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  العربية
                </button>
              </div>
            </div>

            {/* City */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
              <div>
                <span className="text-slate-200 text-sm font-medium flex items-center gap-1.5">
                  <MapPin size={14} className="text-amber-500" />
                  <span>City / Location</span>
                </span>
                <p className="text-[11px] text-slate-400">Used for local prayer times calculation</p>
              </div>
              <input 
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Enter city (e.g. London, Cairo, Mecca)"
                className="bg-slate-950 text-slate-200 border border-slate-800 focus:border-amber-500 p-2 text-xs rounded-xl outline-none w-full sm:w-64"
              />
            </div>

            {/* Bookmarks link */}
            <div className="flex justify-between items-center pb-3 border-b border-slate-800">
              <div>
                <span className="text-slate-200 text-sm font-medium">Saved Bookmarks & Reports</span>
                <p className="text-[11px] text-slate-400">Quickly access pinned Quran verses or download spiritual reports</p>
              </div>
              <div className="flex items-center gap-2">
                <Link 
                  to="/reports" 
                  className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 border border-amber-500/30 transition"
                >
                  <FileText size={14} /> 
                  <span>Reports</span>
                </Link>
                <Link 
                  to="/bookmarks" 
                  className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 border border-amber-500/30 transition"
                >
                  <Bookmark size={14} /> 
                  <span>Bookmarks</span>
                </Link>
              </div>
            </div>

            {/* Appearance Settings Panel */}
            <div className="space-y-4 pb-4 border-b border-slate-800">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="text-slate-200 text-sm font-semibold flex items-center gap-1.5">
                    <Moon size={16} className="text-amber-500" />
                    <span>Appearance & Visual Theme</span>
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Current active mode: <strong className="text-amber-400 uppercase font-mono">{isSmartThemeActive ? 'Night Mode (Smart Theme Active)' : theme === 'system' ? `Auto (${resolvedTheme})` : theme}</strong>
                  </p>
                </div>

                <span className="self-start sm:self-auto px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-amber-500/10 text-amber-400 border border-amber-500/30">
                  Active: {isSmartThemeActive ? '🌙 Smart Night Palette' : theme === 'system' ? `Auto (${resolvedTheme})` : `${theme} Mode`}
                </span>
              </div>

              {/* Smart Theme Toggle Card */}
              <div className="p-4 bg-gradient-to-r from-indigo-950/40 via-slate-950 to-slate-900 border border-amber-500/30 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
                <div className="space-y-0.5">
                  <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                    <Sparkles size={15} />
                    <span>Smart Theme (Automatic Night Mode Shifting)</span>
                  </span>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Detects local time (8:00 PM – 6:00 AM) and shifts to an ultra-dark 'Night Mode' palette for late-night Quran recitation & Dhikr.
                  </p>
                  {isNightTime && (
                    <span className="inline-block mt-1 text-[10px] font-mono text-emerald-400 font-bold bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded-full">
                      🌙 Local Night Hours Detected ({new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic(20);
                    setSmartThemeEnabled(!smartThemeEnabled);
                  }}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shrink-0 ${
                    smartThemeEnabled
                      ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                      : 'bg-slate-900 text-slate-400 border border-slate-800'
                  }`}
                >
                  <span>{smartThemeEnabled ? 'Smart Theme Active' : 'Enable Smart Theme'}</span>
                </button>
              </div>

              {/* Radio options with visual cards & toggle switches */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Auto / System Option */}
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic(15);
                    setTheme('system');
                  }}
                  className={`p-3.5 rounded-2xl border text-left transition flex flex-col justify-between space-y-2 relative ${
                    theme === 'system'
                      ? 'bg-amber-500/15 border-amber-500 text-slate-100 shadow-md shadow-amber-500/10'
                      : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                      🖥️ System Auto
                    </span>
                    <input
                      type="radio"
                      name="theme-override"
                      checked={theme === 'system'}
                      onChange={() => setTheme('system')}
                      className="accent-amber-500"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 leading-tight">
                    Syncs automatically with your device's operating system dark/light preference
                  </p>
                </button>

                {/* Light Option */}
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic(15);
                    setTheme('light');
                  }}
                  className={`p-3.5 rounded-2xl border text-left transition flex flex-col justify-between space-y-2 relative ${
                    theme === 'light'
                      ? 'bg-amber-500/15 border-amber-500 text-slate-100 shadow-md shadow-amber-500/10'
                      : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                      ☀️ Light Mode
                    </span>
                    <input
                      type="radio"
                      name="theme-override"
                      checked={theme === 'light'}
                      onChange={() => setTheme('light')}
                      className="accent-amber-500"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 leading-tight">
                    Clean, high-contrast bright theme ideal for daytime reading
                  </p>
                </button>

                {/* Dark Option */}
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic(15);
                    setTheme('dark');
                  }}
                  className={`p-3.5 rounded-2xl border text-left transition flex flex-col justify-between space-y-2 relative ${
                    theme === 'dark'
                      ? 'bg-amber-500/15 border-amber-500 text-slate-100 shadow-md shadow-amber-500/10'
                      : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                      🌙 Dark Mode
                    </span>
                    <input
                      type="radio"
                      name="theme-override"
                      checked={theme === 'dark'}
                      onChange={() => setTheme('dark')}
                      className="accent-amber-500"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 leading-tight">
                    Subtle OLED dark palette designed for nighttime reflection and minimal strain
                  </p>
                </button>
              </div>
            </div>

            {/* Font Size */}
            <div className="flex justify-between items-center">
              <div>
                <span className="text-slate-200 text-sm font-medium flex items-center gap-1.5">
                  <Type size={14} className="text-amber-500" />
                  <span>Script & Font Size</span>
                </span>
                <p className="text-[11px] text-slate-400">Adjust text size for Quran reading</p>
              </div>
              <select 
                value={fontSize} 
                onChange={(e) => setFontSize(e.target.value)}
                className="bg-slate-950 text-slate-200 border border-slate-800 focus:border-amber-500 p-2 text-xs rounded-xl outline-none"
              >
                <option value="small">Small</option>
                <option value="medium">Medium (Standard)</option>
                <option value="large">Large (Enhanced)</option>
              </select>
            </div>
          </div>
        </section>

        {/* Data Backup & Export Section */}
        <section className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-amber-500 flex items-center gap-2">
              <HardDrive size={16} />
              <span>Data Backup & Export / ڈیٹا بیک اپ</span>
            </h3>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
              JSON v2.0
            </span>
          </div>
          
          <p className="text-xs text-slate-400 leading-relaxed">
            Download a portable, offline JSON backup of your reflection journals, Zakat calculations, charity donation history, prayer logs, daily spiritual goals, and bookmarks.
          </p>

          {/* Backup Content Breakdown Summary */}
          {backupStats && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs pt-1">
              <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-2.5">
                <span className="text-[10px] text-slate-400 flex items-center gap-1">
                  <Calendar size={11} className="text-amber-500" /> Prayers
                </span>
                <span className="text-sm font-mono font-bold text-amber-400 block mt-0.5">
                  {backupStats.meta.totalPrayerDaysTracked} Days
                </span>
              </div>

              <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-2.5">
                <span className="text-[10px] text-slate-400 flex items-center gap-1">
                  <BookHeart size={11} className="text-emerald-500" /> Journals
                </span>
                <span className="text-sm font-mono font-bold text-emerald-400 block mt-0.5">
                  {backupStats.meta.totalJournalEntries} Entries
                </span>
              </div>

              <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-2.5">
                <span className="text-[10px] text-slate-400 flex items-center gap-1">
                  <HandHeart size={11} className="text-rose-500" /> Zakat
                </span>
                <span className="text-sm font-mono font-bold text-rose-400 block mt-0.5">
                  {backupStats.meta.totalCharityEntries} Records
                </span>
              </div>

              <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-2.5">
                <span className="text-[10px] text-slate-400 flex items-center gap-1">
                  <Sparkles size={11} className="text-amber-400" /> Habits
                </span>
                <span className="text-sm font-mono font-bold text-amber-300 block mt-0.5">
                  {backupStats.meta.totalSpiritualGoals} Goals
                </span>
              </div>
            </div>
          )}

          {/* Action Buttons: Download JSON, Copy JSON, Restore File */}
          <div className="flex flex-col sm:flex-row gap-2.5 pt-1">
            <button
              type="button"
              onClick={handleExportData}
              disabled={isExporting}
              className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-xl font-medium transition active:scale-[0.99] border ${
                exportSuccess
                  ? 'bg-emerald-600/20 border-emerald-500/50 text-emerald-400 shadow-md shadow-emerald-500/10'
                  : 'bg-amber-600 text-slate-950 font-bold hover:bg-amber-500 border-amber-500 shadow-md shadow-amber-600/20'
              }`}
            >
              {exportSuccess ? (
                <>
                  <CheckCircle2 size={16} className="text-emerald-400 animate-pulse" />
                  <span className="text-xs font-semibold">Backup Downloaded!</span>
                </>
              ) : (
                <>
                  <Download size={16} className={isExporting ? 'animate-bounce' : 'text-slate-950'} />
                  <span className="text-xs font-bold">
                    {isExporting ? 'Preparing...' : 'Export JSON Backup'}
                  </span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleCopyJSON}
              className="flex items-center justify-center gap-1.5 px-4 py-3 bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-amber-500/40 text-slate-300 rounded-xl text-xs font-medium transition active:scale-[0.99]"
              title="Copy raw JSON backup to clipboard"
            >
              {copiedBackup ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
              <span>{copiedBackup ? 'Copied!' : 'Copy JSON'}</span>
            </button>

            <label className="flex items-center justify-center gap-1.5 px-4 py-3 bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-amber-500/40 text-amber-400 rounded-xl text-xs font-semibold cursor-pointer transition active:scale-[0.99]">
              <Upload size={14} />
              <span>Restore Backup</span>
              <input
                type="file"
                accept=".json,application/json"
                onChange={handleFileRestore}
                className="hidden"
              />
            </label>
          </div>

          {/* Download PDF Summary Report Button */}
          <button
            type="button"
            onClick={() => {
              triggerButtonClickHaptic();
              openPrintableSpiritualReport();
            }}
            className="w-full mt-2 flex items-center justify-center gap-2 p-3 bg-slate-950 hover:bg-slate-850 border border-amber-900/40 hover:border-amber-500/60 text-amber-400 rounded-xl text-xs font-bold transition active:scale-[0.99] shadow-sm"
          >
            <FileText size={16} className="text-amber-500" />
            <span>Generate Downloadable PDF Summary (Prayer Consistency, Zakat & Goals)</span>
          </button>

          {/* Restore Message Toast */}
          {restoreMessage && (
            <div className={`p-3 rounded-xl text-xs flex items-center gap-2 border animate-fadeIn ${
              restoreMessage.success 
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300' 
                : 'bg-red-950/40 border-red-500/40 text-red-300'
            }`}>
              <CheckCircle2 size={15} />
              <span>{restoreMessage.text}</span>
            </div>
          )}
        </section>

        {/* Prayer Alarm & Custom Athan Sounds Section */}
        <PrayerAlarmSettings />

        {/* Help & Feedback Section */}
        <section className="bg-slate-900/60 border border-amber-900/30 rounded-2xl p-5 space-y-3">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-amber-500">
            Help & Feedback / رائے اور مدد
          </h3>
          <p className="text-xs text-slate-400">
            Have a suggestion, found a bug, or spotted a typo? Let us know directly.
          </p>
          <button
            type="button"
            onClick={() => {
              triggerHaptic(15);
              setIsFeedbackOpen(true);
            }}
            className="w-full flex items-center justify-between p-3 bg-slate-950 hover:bg-slate-800 border border-amber-500/30 rounded-xl text-amber-400 font-medium transition active:scale-[0.99]"
          >
            <span className="flex items-center gap-2.5 text-xs">
              <MessageSquarePlus size={16} className="text-amber-400" />
              <span>Send Feedback or Bug Report</span>
            </span>
            <span className="text-[10px] text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
              رائے دیں
            </span>
          </button>
        </section>
      </div>

      <FeedbackModal 
        isOpen={isFeedbackOpen} 
        onClose={() => setIsFeedbackOpen(false)} 
      />
    </div>
  );
}
