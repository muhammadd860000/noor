import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  BookOpen, 
  Sparkles, 
  Heart, 
  Save, 
  Trash2, 
  Share2, 
  Copy, 
  Check, 
  RefreshCw, 
  Calendar, 
  PenTool, 
  Tag, 
  History, 
  Download, 
  CheckCircle2, 
  Flame, 
  ChevronRight,
  Smile,
  Search,
  Filter,
  Layers,
  MessageSquareQuote
} from 'lucide-react';
import { 
  saveReflectionEntry, 
  getAllReflectionEntries, 
  deleteReflectionEntry, 
  ReflectionRecord 
} from '../lib/db';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export interface ScriptureItem {
  id: string;
  type: 'quran' | 'hadith';
  arabic: string;
  translation: string;
  source: string;
  theme: string;
  reflectionPrompt: string;
}

export const DAILY_SCRIPTURES: ScriptureItem[] = [
  {
    id: 'sc-1',
    type: 'quran',
    arabic: 'فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ',
    translation: 'So remember Me; I will remember you. And be grateful to Me and do not deny Me.',
    source: 'Surah Al-Baqarah (2:152)',
    theme: 'Remembrance & Gratitude',
    reflectionPrompt: 'In what moments today did you consciously remember Allah? What blessings are you most thankful for?'
  },
  {
    id: 'sc-2',
    type: 'hadith',
    arabic: 'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى',
    translation: 'Actions are judged by intentions, and every person will get what was intended.',
    source: 'Sahih al-Bukhari (1)',
    theme: 'Pure Intentions (Ikhlas)',
    reflectionPrompt: 'Check your intentions for today. How can you transform your routine tasks into acts of worship?'
  },
  {
    id: 'sc-3',
    type: 'quran',
    arabic: 'وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا وَيَرْزُقْهُ مِنْ حَيْثُ لَا يَحْتَسِبُ',
    translation: 'And whoever is mindful of Allah—He will make for them a way out, and provide for them from sources they could never imagine.',
    source: 'Surah At-Talaq (65:2-3)',
    theme: 'Tawakkul & Trust in Allah',
    reflectionPrompt: 'What worry or uncertainty are you currently carrying? How can you surrender it to Allah in prayer?'
  },
  {
    id: 'sc-4',
    type: 'hadith',
    arabic: 'عَجَبًا لأَمْرِ الْمُؤْمِنِ إِنَّ أَمْرَهُ كُلَّهُ خَيْرٌ',
    translation: 'How wonderful is the affair of the believer, for all of his affairs are good for him.',
    source: 'Sahih Muslim (2999)',
    theme: 'Optimism & Resilience (Sabr)',
    reflectionPrompt: 'How can you view today\'s challenges with patience (Sabr) and gratitude (Shukr)?'
  },
  {
    id: 'sc-5',
    type: 'quran',
    arabic: 'أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ',
    translation: 'Unquestionably, by the remembrance of Allah hearts are assured.',
    source: 'Surah Ar-Ra\'d (13:28)',
    theme: 'Inner Peace & Serenity',
    reflectionPrompt: 'When you feel anxiety or stress, what Dhikr or Quran recitation brings tranquility to your heart?'
  },
  {
    id: 'sc-6',
    type: 'hadith',
    arabic: 'لاَ يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ',
    translation: 'None of you truly believes until he loves for his brother what he loves for himself.',
    source: 'Sahih al-Bukhari (13)',
    theme: 'Compassion & Brotherhood',
    reflectionPrompt: 'Who in your life can you support, forgive, or pray for today without their knowledge?'
  },
  {
    id: 'sc-7',
    type: 'quran',
    arabic: 'وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ',
    translation: 'When My servants ask you concerning Me, indeed I am near. I respond to the invocation of the supplicant when he calls upon Me.',
    source: 'Surah Al-Baqarah (2:186)',
    theme: 'Dua & Closeness to Allah',
    reflectionPrompt: 'What heartfelt supplication (Du\'a) is closest to your heart right now?'
  },
  {
    id: 'sc-8',
    type: 'hadith',
    arabic: 'خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ',
    translation: 'The best of you are those who learn the Quran and teach it.',
    source: 'Sahih al-Bukhari (5027)',
    theme: 'Quranic Knowledge',
    reflectionPrompt: 'What verse or teaching of the Quran has guided a recent decision or action?'
  }
];

export const MOODS = [
  { id: 'grateful', label: 'Grateful (شاكر)', emoji: '🤲' },
  { id: 'peaceful', label: 'Peaceful (مطمئن)', emoji: '🕊️' },
  { id: 'hopeful', label: 'Hopeful (راجٍ)', emoji: '✨' },
  { id: 'repentant', label: 'Seeking Forgiveness (تائب)', emoji: '💧' },
  { id: 'motivated', label: 'Motivated (عازم)', emoji: '🔥' },
  { id: 'contemplative', label: 'Contemplative (متفكر)', emoji: '📖' }
];

export default function Reflection() {
  const todayDateStr = useMemo(() => new Date().toISOString().split('T')[0], []);
  const todayFormatted = useMemo(() => {
    return new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'short',
      day: 'numeric'
    });
  }, []);

  // Filter scripture type
  const [filterType, setFilterType] = useState<'all' | 'quran' | 'hadith'>('all');

  // Filtered pool of scriptures
  const availableScriptures = useMemo(() => {
    if (filterType === 'quran') return DAILY_SCRIPTURES.filter(s => s.type === 'quran');
    if (filterType === 'hadith') return DAILY_SCRIPTURES.filter(s => s.type === 'hadith');
    return DAILY_SCRIPTURES;
  }, [filterType]);

  // Selected scripture for today based on date
  const [activeScriptureIndex, setActiveScriptureIndex] = useState(() => {
    const dayOfYear = Math.floor((new Date().getTime() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
    return dayOfYear % DAILY_SCRIPTURES.length;
  });

  const currentScripture: ScriptureItem = availableScriptures[activeScriptureIndex % availableScriptures.length] || DAILY_SCRIPTURES[0];

  // Journal form state
  const [journalText, setJournalText] = useState('');
  const [selectedMood, setSelectedMood] = useState('grateful');
  const [intentionText, setIntentionText] = useState('');
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'write' | 'history'>('write');

  // IndexedDB Journal History State
  const [journalHistory, setJournalHistory] = useState<ReflectionRecord[]>([]);
  const [historySearch, setHistorySearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);

  // Load IndexedDB history on mount
  const loadHistory = useCallback(async () => {
    const records = await getAllReflectionEntries();
    setJournalHistory(records);

    // Pre-populate today's existing journal entry if present
    const todayEntry = records.find(r => r.date === todayDateStr);
    if (todayEntry) {
      setJournalText(todayEntry.journalText);
      if (todayEntry.mood) setSelectedMood(todayEntry.mood);
      if (todayEntry.intention) setIntentionText(todayEntry.intention);
    }
  }, [todayDateStr]);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  // Handle Save Journal Entry to IndexedDB
  const handleSaveEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!journalText.trim()) return;

    triggerSuccessHaptic();

    const recordId = editingId || `refl_${todayDateStr}_${Date.now()}`;
    const newRecord: ReflectionRecord = {
      id: recordId,
      date: todayDateStr,
      scriptureType: currentScripture.type,
      arabic: currentScripture.arabic,
      translation: currentScripture.translation,
      source: currentScripture.source,
      theme: currentScripture.theme,
      journalText: journalText.trim(),
      mood: selectedMood,
      intention: intentionText.trim() || undefined,
      timestamp: Date.now(),
      updatedAt: editingId ? Date.now() : undefined
    };

    await saveReflectionEntry(newRecord);
    await loadHistory();

    setEditingId(null);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  // Delete from IndexedDB
  const handleDeleteEntry = async (id: string) => {
    triggerHaptic(20);
    await deleteReflectionEntry(id);
    await loadHistory();
    if (editingId === id) {
      setEditingId(null);
      setJournalText('');
      setIntentionText('');
    }
  };

  // Edit existing reflection
  const handleEditEntry = (entry: ReflectionRecord) => {
    triggerButtonClickHaptic();
    setEditingId(entry.id);
    setJournalText(entry.journalText);
    if (entry.mood) setSelectedMood(entry.mood);
    if (entry.intention) setIntentionText(entry.intention);
    setActiveTab('write');
  };

  // Cycle scripture
  const handleCycleScripture = () => {
    triggerButtonClickHaptic();
    setActiveScriptureIndex(prev => (prev + 1) % availableScriptures.length);
  };

  // Copy scripture
  const handleCopyScripture = async () => {
    triggerButtonClickHaptic();
    const content = `✨ Daily Islamic Reflection\n\n"${currentScripture.arabic}"\n\n"${currentScripture.translation}"\n\n📖 ${currentScripture.source}\nTheme: ${currentScripture.theme}\n\nShared via Noor`;
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(content);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Export Journal as text file
  const handleExportJournal = () => {
    triggerButtonClickHaptic();
    if (journalHistory.length === 0) return;

    let content = `NOOR SPIRITUAL JOURNAL ENTRIES\nGenerated on: ${new Date().toLocaleString()}\nTotal Reflections: ${journalHistory.length}\n========================================\n\n`;

    journalHistory.forEach((item, idx) => {
      content += `[Entry #${idx + 1}] Date: ${item.date} | Mood: ${item.mood || 'N/A'}\n`;
      content += `Scripture (${item.scriptureType.toUpperCase()}): ${item.source}\n`;
      content += `Arabic: ${item.arabic}\n`;
      content += `Translation: "${item.translation}"\n`;
      content += `\nPersonal Journal Reflection:\n${item.journalText}\n`;
      if (item.intention) {
        content += `Actionable Intention: ${item.intention}\n`;
      }
      content += `\n----------------------------------------\n\n`;
    });

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `noor-reflections-${todayDateStr}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Filtered History
  const filteredHistory = useMemo(() => {
    const q = historySearch.toLowerCase().trim();
    if (!q) return journalHistory;
    return journalHistory.filter(item => 
      item.journalText.toLowerCase().includes(q) ||
      item.translation.toLowerCase().includes(q) ||
      item.source.toLowerCase().includes(q) ||
      (item.mood && item.mood.toLowerCase().includes(q)) ||
      (item.intention && item.intention.toLowerCase().includes(q)) ||
      item.date.includes(q)
    );
  }, [journalHistory, historySearch]);

  return (
    <div className="space-y-6 pb-16">
      {/* Header */}
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl text-amber-500 font-serif">Daily Reflection & Journal</h2>
            <span className="text-xs font-serif text-slate-400 opacity-80" dir="rtl">
              التفكر والتدبر واليوميات
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Contemplate authentic Quranic verses & Prophetic Hadith, and record your personal spiritual realizations in local IndexedDB
          </p>
        </div>

        {/* Tab switcher: Write vs History */}
        <div className="flex items-center gap-2">
          <div className="flex bg-slate-900 border border-amber-900/30 rounded-xl p-1 text-xs">
            <button
              type="button"
              onClick={() => {
                triggerHaptic(10);
                setActiveTab('write');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                activeTab === 'write'
                  ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <PenTool size={13} />
              <span>Today's Entry</span>
            </button>
            <button
              type="button"
              onClick={() => {
                triggerHaptic(10);
                setActiveTab('history');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                activeTab === 'history'
                  ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <History size={13} />
              <span>Journal History ({journalHistory.length})</span>
            </button>
          </div>
        </div>
      </header>

      {activeTab === 'write' ? (
        <div className="space-y-6">
          {/* Daily Scripture Showcase Box */}
          <section className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
            {/* Ambient gold glow */}
            <div 
              aria-hidden="true" 
              className="absolute -top-16 -right-16 w-44 h-44 rounded-full bg-amber-500/5 blur-3xl pointer-events-none"
            />

            {/* Scripture Header Controls */}
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-amber-900/20">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
                  <MessageSquareQuote size={18} />
                </span>
                <div>
                  <span className="text-xs font-mono font-semibold text-amber-500 uppercase tracking-wider">
                    {currentScripture.type === 'quran' ? 'Quranic Ayah' : 'Prophetic Hadith'} · {currentScripture.theme}
                  </span>
                  <p className="text-[11px] text-slate-400">{todayFormatted}</p>
                </div>
              </div>

              {/* Type Filter Buttons & Cycle */}
              <div className="flex items-center gap-1.5">
                <div className="flex bg-slate-950/80 border border-slate-800 rounded-xl p-0.5 text-xs">
                  <button
                    type="button"
                    onClick={() => {
                      triggerButtonClickHaptic();
                      setFilterType('all');
                    }}
                    className={`px-2 py-0.5 rounded-lg transition ${filterType === 'all' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
                  >
                    All
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      triggerButtonClickHaptic();
                      setFilterType('quran');
                    }}
                    className={`px-2 py-0.5 rounded-lg transition ${filterType === 'quran' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
                  >
                    Quran
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      triggerButtonClickHaptic();
                      setFilterType('hadith');
                    }}
                    className={`px-2 py-0.5 rounded-lg transition ${filterType === 'hadith' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
                  >
                    Hadith
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleCycleScripture}
                  className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition"
                  title="Discover another scripture"
                  aria-label="Discover another scripture"
                >
                  <RefreshCw size={14} />
                </button>

                <button
                  type="button"
                  onClick={handleCopyScripture}
                  className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition"
                  title="Copy Scripture"
                  aria-label="Copy Scripture"
                >
                  {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                </button>
              </div>
            </div>

            {/* Scripture Arabic & Translation */}
            <div className="pt-4 space-y-3">
              <p 
                dir="rtl" 
                lang="ar" 
                className="text-xl sm:text-2xl text-amber-100/95 font-serif text-right leading-[2.2] select-text py-1"
              >
                {currentScripture.arabic}
              </p>

              <p className="text-slate-200 text-sm sm:text-base leading-relaxed italic font-serif">
                "{currentScripture.translation}"
              </p>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 text-xs">
                <span className="font-medium text-amber-500 bg-amber-500/10 border border-amber-500/20 px-2.5 py-0.5 rounded-full">
                  {currentScripture.source}
                </span>

                <span className="text-slate-400 italic">
                  Prompt: {currentScripture.reflectionPrompt}
                </span>
              </div>
            </div>
          </section>

          {/* Personal Journal Entry Form */}
          <form onSubmit={handleSaveEntry} className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
                  <PenTool size={18} />
                </span>
                <h3 className="text-sm font-semibold uppercase tracking-wider text-emerald-400">
                  {editingId ? 'Edit Journal Entry' : 'Personal Reflection Journal (Stored in IndexedDB)'}
                </h3>
              </div>

              {savedSuccess && (
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-400 bg-emerald-950/80 border border-emerald-800/60 px-2.5 py-0.5 rounded-full animate-fadeIn">
                  <CheckCircle2 size={13} /> Saved in IndexedDB
                </span>
              )}
            </div>

            {/* Mood / Spiritual State Selector */}
            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 font-medium flex items-center gap-1">
                <Smile size={13} /> Current Spiritual State / Mood:
              </label>
              <div className="flex flex-wrap gap-1.5">
                {MOODS.map(m => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      triggerHaptic(10);
                      setSelectedMood(m.id);
                    }}
                    className={`px-2.5 py-1 rounded-xl text-xs flex items-center gap-1.5 transition ${
                      selectedMood === m.id
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                        : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    <span>{m.emoji}</span>
                    <span>{m.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Journal Textarea */}
            <div className="space-y-1.5">
              <label htmlFor="reflectionTextarea" className="text-xs text-slate-400 font-medium">
                Your Personal Reflection & Thoughts:
              </label>
              <textarea
                id="reflectionTextarea"
                rows={4}
                value={journalText}
                onChange={(e) => setJournalText(e.target.value)}
                placeholder="Write your reflections on this verse or hadith... What resonated with you? How does this apply to your day? What gratitude or lesson does it evoke?"
                className="w-full bg-slate-950 border border-amber-900/30 focus:border-amber-500 text-slate-200 text-sm p-3.5 rounded-xl outline-none transition placeholder:text-slate-600 resize-y"
              />
            </div>

            {/* Actionable Intention */}
            <div className="space-y-1.5">
              <label htmlFor="intentionInput" className="text-xs text-slate-400 font-medium">
                Actionable Daily Intention (Optional):
              </label>
              <input
                id="intentionInput"
                type="text"
                value={intentionText}
                onChange={(e) => setIntentionText(e.target.value)}
                placeholder="e.g. Practice patience in traffic, give secret charity, or recite Ayatul Kursi after Dhuhr"
                className="w-full bg-slate-950 border border-amber-900/30 focus:border-amber-500 text-slate-200 text-xs p-3 rounded-xl outline-none transition placeholder:text-slate-600"
              />
            </div>

            {/* Form Actions */}
            <div className="flex items-center justify-between pt-2">
              {editingId ? (
                <button
                  type="button"
                  onClick={() => {
                    setEditingId(null);
                    setJournalText('');
                    setIntentionText('');
                  }}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 transition"
                >
                  Cancel Edit
                </button>
              ) : (
                <span className="text-[11px] text-slate-500">Persisted locally in IndexedDB</span>
              )}

              <button
                type="submit"
                disabled={!journalText.trim()}
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs rounded-xl transition shadow-md shadow-amber-600/20 active:scale-95 disabled:opacity-50"
              >
                <Save size={14} />
                <span>{editingId ? 'Update Journal Entry' : 'Save Reflection Entry'}</span>
              </button>
            </div>
          </form>
        </div>
      ) : (
        /* Journal History View */
        <div className="space-y-4">
          {/* Search & Export Toolbar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-amber-900/30 p-3.5 rounded-2xl">
            <div className="relative flex-1">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={historySearch}
                onChange={(e) => setHistorySearch(e.target.value)}
                placeholder="Search reflections by keywords, scripture, or dates..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 text-xs text-slate-200 pl-8 pr-3 py-2 rounded-xl outline-none placeholder:text-slate-600"
              />
            </div>

            <button
              type="button"
              onClick={handleExportJournal}
              disabled={journalHistory.length === 0}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-950 border border-amber-900/40 hover:border-amber-500/60 text-amber-400 text-xs font-semibold rounded-xl transition active:scale-95 disabled:opacity-50 self-start sm:self-auto"
            >
              <Download size={13} />
              <span>Export Journal (.txt)</span>
            </button>
          </div>

          {/* List of Entries */}
          {filteredHistory.length === 0 ? (
            <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-8 text-center space-y-2">
              <PenTool size={32} className="mx-auto text-slate-600" />
              <h4 className="text-sm font-semibold text-slate-300">No Journal Entries Found</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                {historySearch ? 'No entries matched your search query.' : 'Write your first reflection on today\'s scripture to start your spiritual journal.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredHistory.map((item) => (
                <article 
                  key={item.id}
                  className="bg-slate-900 border border-amber-900/30 rounded-2xl p-4 sm:p-5 shadow-md space-y-3 transition hover:border-amber-700/40"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-amber-500">
                        {item.date}
                      </span>
                      <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700">
                        {item.scriptureType} · {item.source}
                      </span>
                      {item.mood && (
                        <span className="text-xs text-slate-400">
                          {MOODS.find(m => m.id === item.mood)?.emoji} {MOODS.find(m => m.id === item.mood)?.label.split(' ')[0]}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleEditEntry(item)}
                        className="px-2.5 py-1 rounded-lg text-xs text-amber-400 hover:bg-slate-800 transition"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteEntry(item.id)}
                        className="p-1 text-slate-500 hover:text-rose-400 transition"
                        title="Delete entry"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>

                  {/* Scripture Quote */}
                  <div className="bg-slate-950/70 border border-slate-800/60 rounded-xl p-3 space-y-1 text-xs">
                    <p dir="rtl" lang="ar" className="text-amber-200/90 font-serif text-right text-sm leading-relaxed">
                      {item.arabic}
                    </p>
                    <p className="text-slate-400 italic">
                      "{item.translation}"
                    </p>
                  </div>

                  {/* Personal Journal Text */}
                  <div className="space-y-1">
                    <h5 className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">
                      My Personal Reflection:
                    </h5>
                    <p className="text-xs sm:text-sm text-slate-200 whitespace-pre-wrap leading-relaxed">
                      {item.journalText}
                    </p>
                  </div>

                  {/* Intention if present */}
                  {item.intention && (
                    <div className="pt-2 border-t border-slate-800/60 text-xs text-amber-300/90 flex items-center gap-1.5">
                      <span className="font-semibold text-amber-400">Action Intention:</span>
                      <span>{item.intention}</span>
                    </div>
                  )}
                </article>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
