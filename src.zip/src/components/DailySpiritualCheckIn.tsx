import React, { useState, useEffect } from 'react';
import { Sparkles, CheckCircle2, Heart, Flame, MessageSquare } from 'lucide-react';
import { 
  saveSpiritualCheckIn, 
  getTodaySpiritualCheckIn, 
  RATING_LABELS, 
  SpiritualCheckInRecord 
} from '../lib/spiritualCheckIn';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export default function DailySpiritualCheckIn() {
  const [todayRecord, setTodayRecord] = useState<SpiritualCheckInRecord | null>(() => getTodaySpiritualCheckIn());
  const [selectedRating, setSelectedRating] = useState<number>(3);
  const [reflectionNote, setReflectionNote] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState<boolean>(Boolean(todayRecord));

  useEffect(() => {
    if (todayRecord) {
      setSelectedRating(todayRecord.rating);
      setReflectionNote(todayRecord.note || '');
      setIsSubmitted(true);
    }
  }, [todayRecord]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    triggerButtonClickHaptic();
    const saved = await saveSpiritualCheckIn(selectedRating, reflectionNote);
    setTodayRecord(saved);
    setIsSubmitted(true);
    triggerSuccessHaptic();
  };

  return (
    <div className="bg-slate-900 border border-emerald-900/30 rounded-2xl p-5 shadow-xl space-y-4 relative overflow-hidden">
      <div className="flex items-center justify-between border-b border-emerald-900/30 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Sparkles size={20} />
          </div>
          <div>
            <h3 className="text-base font-serif font-bold text-slate-100 flex items-center gap-2">
              <span>Daily Spiritual Check-in</span>
              {isSubmitted && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold flex items-center gap-1">
                  <CheckCircle2 size={12} /> Logged
                </span>
              )}
            </h3>
            <p className="text-xs text-slate-400">Rate your spiritual energy & connection level today</p>
          </div>
        </div>
      </div>

      {isSubmitted && todayRecord ? (
        <div className="bg-slate-950/80 border border-emerald-500/30 rounded-2xl p-4 text-center space-y-3">
          <div className="flex items-center justify-center gap-2">
            <span className="text-3xl">{RATING_LABELS[todayRecord.rating]?.emoji}</span>
            <div className="text-left">
              <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${RATING_LABELS[todayRecord.rating]?.color}`}>
                Level {todayRecord.rating}/5 · {todayRecord.label}
              </span>
              <p className="text-[11px] text-slate-400 mt-1">Recorded for today</p>
            </div>
          </div>

          {todayRecord.note && (
            <p className="text-xs text-slate-300 bg-slate-900/90 border border-slate-800 p-2.5 rounded-xl italic">
              "{todayRecord.note}"
            </p>
          )}

          <button
            type="button"
            onClick={() => { triggerHaptic(10); setIsSubmitted(false); }}
            className="text-[11px] text-slate-400 hover:text-emerald-400 underline font-medium"
          >
            Update Spiritual Check-in
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Rating 1-5 Pills */}
          <div className="grid grid-cols-5 gap-2">
            {[1, 2, 3, 4, 5].map((lvl) => {
              const meta = RATING_LABELS[lvl];
              const isSelected = selectedRating === lvl;
              return (
                <button
                  type="button"
                  key={lvl}
                  onClick={() => { triggerHaptic(12); setSelectedRating(lvl); }}
                  className={`p-2.5 rounded-2xl border flex flex-col items-center gap-1.5 transition active:scale-95 ${
                    isSelected
                      ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 shadow-lg shadow-emerald-500/10 scale-105'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span className="text-xl">{meta.emoji}</span>
                  <span className="text-[10px] font-bold font-mono">{lvl}</span>
                </button>
              );
            })}
          </div>

          <div className="p-2.5 bg-slate-950/60 border border-slate-800 rounded-xl text-center text-xs text-emerald-300 font-semibold">
            {RATING_LABELS[selectedRating]?.emoji} {RATING_LABELS[selectedRating]?.label} (Level {selectedRating}/5)
          </div>

          {/* Optional Reflection Note */}
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300 mb-1">
              <MessageSquare size={14} className="text-slate-400" />
              <span>Optional Reflection Note</span>
            </div>
            <input
              type="text"
              value={reflectionNote}
              onChange={(e) => setReflectionNote(e.target.value)}
              placeholder="How are you feeling spiritually today?"
              className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl p-2.5 text-xs text-slate-100 outline-none"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl transition shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-1.5"
          >
            <Sparkles size={16} />
            <span>Save Spiritual Check-in</span>
          </button>
        </form>
      )}
    </div>
  );
}
