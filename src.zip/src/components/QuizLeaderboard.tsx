import React, { useState, useEffect, useMemo } from 'react';
import { 
  Award, 
  Trophy, 
  Flame, 
  Target, 
  CheckCircle2, 
  Sparkles, 
  Trash2, 
  RotateCcw, 
  Filter, 
  History, 
  ChevronRight, 
  TrendingUp, 
  Star,
  Zap,
  BookOpen
} from 'lucide-react';
import { 
  getQuizLeaderboardStats, 
  clearQuizHistory, 
  QuizLeaderboardStats, 
  QuizScoreRecord, 
  QUIZ_RANKS 
} from '../lib/quizLeaderboard';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export default function QuizLeaderboard() {
  const [stats, setStats] = useState<QuizLeaderboardStats>(() => getQuizLeaderboardStats());
  const [filterMode, setFilterMode] = useState<'all' | 'daily' | 'practice'>('all');
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const refreshStats = () => {
    setStats(getQuizLeaderboardStats());
  };

  useEffect(() => {
    refreshStats();
  }, []);

  const handleClearHistory = () => {
    triggerHaptic(20);
    clearQuizHistory();
    refreshStats();
    setShowClearConfirm(false);
  };

  const filteredHistory = useMemo(() => {
    if (filterMode === 'daily') return stats.history.filter(h => h.mode === 'daily');
    if (filterMode === 'practice') return stats.history.filter(h => h.mode === 'practice');
    return stats.history;
  }, [stats.history, filterMode]);

  const topPerformances = useMemo(() => {
    return [...stats.history]
      .sort((a, b) => b.pointsEarned - a.pointsEarned || b.percentage - a.percentage)
      .slice(0, 3);
  }, [stats.history]);

  return (
    <div className="space-y-6">
      {/* Current Rank & Tier Banner */}
      <div className="bg-gradient-to-r from-amber-950/40 via-slate-900 to-amber-950/30 border border-amber-900/40 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0 mt-0.5">
              <Trophy size={28} />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-mono font-semibold text-amber-500 uppercase tracking-wider">
                  Islamic Knowledge Rank
                </span>
                <span className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${stats.currentRank.badgeColor}`}>
                  {stats.currentRank.title}
                </span>
                <span className="text-xs text-amber-300 font-serif" dir="rtl">
                  {stats.currentRank.arabicTitle}
                </span>
              </div>

              <h3 className="text-xl sm:text-2xl font-serif font-bold text-slate-100 mt-1">
                {stats.cumulativeScore.toLocaleString()} Total XP Points
              </h3>

              <p className="text-xs text-slate-400 mt-0.5">
                {stats.currentRank.description}
              </p>
            </div>
          </div>

          {/* Quick Streak Badge */}
          <div className="flex items-center gap-2 bg-slate-950/70 border border-amber-900/30 px-3.5 py-2 rounded-xl self-start sm:self-auto">
            <Flame size={18} className="text-amber-500" />
            <div className="text-xs">
              <span className="font-bold text-amber-400">{stats.currentStreak} Day Streak</span>
              <span className="text-slate-500 text-[10px] block">Best: {stats.bestStreak}d</span>
            </div>
          </div>
        </div>

        {/* Progress Bar to Next Rank */}
        {stats.nextRank && (
          <div className="mt-4 pt-3 border-t border-amber-900/20 space-y-1.5">
            <div className="flex justify-between text-xs text-slate-400">
              <span>Next Rank: <strong className="text-amber-400">{stats.nextRank.title}</strong></span>
              <span className="font-mono">{stats.cumulativeScore} / {stats.nextRank.minPoints} XP ({stats.progressToNextRankPct}%)</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
              <div 
                className="bg-amber-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${stats.progressToNextRankPct}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Statistics 4-Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-amber-900/30 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center gap-1.5 text-slate-400 text-xs">
            <Target size={14} className="text-amber-500" />
            <span>Accuracy</span>
          </div>
          <p className="text-xl font-mono font-bold text-slate-100">
            {stats.overallAccuracyPct}%
          </p>
          <span className="text-[10px] text-slate-500">
            {stats.totalCorrect} / {stats.totalQuestionsAnswered} correct
          </span>
        </div>

        <div className="bg-slate-900 border border-amber-900/30 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center gap-1.5 text-slate-400 text-xs">
            <BookOpen size={14} className="text-emerald-500" />
            <span>Quizzes Taken</span>
          </div>
          <p className="text-xl font-mono font-bold text-slate-100">
            {stats.totalQuizzesTaken}
          </p>
          <span className="text-[10px] text-slate-500">
            All modes & categories
          </span>
        </div>

        <div className="bg-slate-900 border border-amber-900/30 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center gap-1.5 text-slate-400 text-xs">
            <Star size={14} className="text-yellow-500" />
            <span>Perfect Scores</span>
          </div>
          <p className="text-xl font-mono font-bold text-slate-100">
            {stats.perfectScoresCount}
          </p>
          <span className="text-[10px] text-slate-500">
            100% accuracy runs
          </span>
        </div>

        <div className="bg-slate-900 border border-amber-900/30 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center gap-1.5 text-slate-400 text-xs">
            <Zap size={14} className="text-purple-500" />
            <span>Best Run Score</span>
          </div>
          <p className="text-xl font-mono font-bold text-slate-100">
            {stats.highestScore}
          </p>
          <span className="text-[10px] text-slate-500">
            Max correct in single run
          </span>
        </div>
      </div>

      {/* Top 3 High Scores */}
      {topPerformances.length > 0 && (
        <section className="bg-slate-900 border border-amber-900/30 rounded-2xl p-4 sm:p-5 space-y-3">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-amber-500 flex items-center gap-1.5">
            <Award size={14} />
            Top Historical Performances
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {topPerformances.map((perf, index) => (
              <div 
                key={perf.id}
                className="bg-slate-950/70 border border-amber-900/20 rounded-xl p-3 flex items-center justify-between"
              >
                <div className="flex items-center gap-2.5">
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    index === 0 ? 'bg-amber-500 text-slate-950' : index === 1 ? 'bg-slate-300 text-slate-950' : 'bg-amber-800 text-amber-100'
                  }`}>
                    #{index + 1}
                  </span>
                  <div>
                    <span className="text-xs font-medium text-slate-200 block">{perf.category}</span>
                    <span className="text-[10px] text-slate-400">{perf.dateStr}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-mono font-bold text-amber-400">+{perf.pointsEarned} XP</span>
                  <span className="text-[10px] text-emerald-400 block font-mono">{perf.score}/{perf.totalQuestions} ({perf.percentage}%)</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Historical Attempts Log */}
      <section className="bg-slate-900 border border-amber-900/30 rounded-2xl p-4 sm:p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-900/20">
          <div className="flex items-center gap-2">
            <History size={16} className="text-amber-500" />
            <h4 className="text-sm font-semibold text-slate-200">
              Quiz History Log ({filteredHistory.length})
            </h4>
          </div>

          <div className="flex items-center gap-2">
            {/* Filter pills */}
            <div className="flex bg-slate-950 border border-slate-800 rounded-xl p-0.5 text-xs">
              <button
                type="button"
                onClick={() => {
                  triggerButtonClickHaptic();
                  setFilterMode('all');
                }}
                className={`px-2.5 py-1 rounded-lg transition ${
                  filterMode === 'all' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => {
                  triggerButtonClickHaptic();
                  setFilterMode('daily');
                }}
                className={`px-2.5 py-1 rounded-lg transition ${
                  filterMode === 'daily' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Daily
              </button>
              <button
                type="button"
                onClick={() => {
                  triggerButtonClickHaptic();
                  setFilterMode('practice');
                }}
                className={`px-2.5 py-1 rounded-lg transition ${
                  filterMode === 'practice' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Practice
              </button>
            </div>

            {/* Clear History Button */}
            {stats.history.length > 0 && (
              <button
                type="button"
                onClick={() => setShowClearConfirm(true)}
                className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition"
                title="Reset Quiz History"
              >
                <Trash2 size={14} />
              </button>
            )}
          </div>
        </div>

        {/* Clear Confirmation Prompt */}
        {showClearConfirm && (
          <div className="bg-rose-950/40 border border-rose-800/60 rounded-xl p-3.5 flex items-center justify-between gap-3 text-xs animate-fadeIn">
            <span className="text-rose-200">Are you sure you want to reset your quiz leaderboard history & XP?</span>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleClearHistory}
                className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg transition"
              >
                Yes, Reset
              </button>
              <button
                type="button"
                onClick={() => setShowClearConfirm(false)}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* History List */}
        {filteredHistory.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-xs space-y-1">
            <Award size={28} className="mx-auto text-slate-600 mb-2" />
            <p>No quiz attempts recorded yet.</p>
            <p className="text-[11px] text-slate-600">Take a Daily Quiz or complete a Practice session to earn XP points!</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {filteredHistory.map((item) => (
              <div
                key={item.id}
                className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 flex items-center justify-between gap-2 text-xs hover:border-amber-900/30 transition"
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg font-mono font-bold text-xs ${
                    item.percentage === 100 
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : item.percentage >= 70
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        : 'bg-slate-800 text-slate-300'
                  }`}>
                    {item.percentage}%
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-slate-200">{item.category}</span>
                      <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                        {item.mode}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-500">{item.dateStr}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-mono font-bold text-amber-400 block">+{item.pointsEarned} XP</span>
                  <span className="text-[11px] text-slate-400 font-mono">{item.score} of {item.totalQuestions} correct</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
