import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Plus, 
  Trash2, 
  Sparkles, 
  BookOpen, 
  Heart, 
  Sun, 
  Moon, 
  HandHeart, 
  Award, 
  Check, 
  PlusCircle, 
  RotateCcw,
  Target
} from 'lucide-react';
import { 
  getSpiritualGoals, 
  getGoalCompletionsForDate, 
  toggleSpiritualGoal, 
  addSpiritualGoal, 
  removeSpiritualGoal, 
  setAllGoalsForDate, 
  calculateGoalsProgress, 
  PRESET_GOAL_SUGGESTIONS, 
  SpiritualGoal, 
  GoalCategory,
  getTodayDateString 
} from '../lib/spiritualGoals';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

const CATEGORY_META: Record<GoalCategory, { label: string; icon: React.ReactNode; color: string }> = {
  quran: { label: 'Quran', icon: <BookOpen size={13} />, color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' },
  dhikr: { label: 'Adhkar & Dhikr', icon: <Sun size={13} />, color: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
  charity: { label: 'Charity & Sadaqah', icon: <HandHeart size={13} />, color: 'bg-rose-500/10 text-rose-400 border-rose-500/20' },
  prayer: { label: 'Sunnah Prayer', icon: <Moon size={13} />, color: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' },
  sunnah: { label: 'Sunnah Habit', icon: <Sparkles size={13} />, color: 'bg-teal-500/10 text-teal-400 border-teal-500/20' },
  general: { label: 'Spiritual Habit', icon: <Target size={13} />, color: 'bg-slate-800 text-slate-300 border-slate-700' }
};

export default function DailyGoals() {
  const todayDateStr = useMemo(() => getTodayDateString(), []);
  const [goals, setGoals] = useState<SpiritualGoal[]>(() => getSpiritualGoals());
  const [completions, setCompletions] = useState<Record<string, boolean>>(() => getGoalCompletionsForDate(todayDateStr));
  const [newGoalTitle, setNewGoalTitle] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<GoalCategory>('quran');
  const [isAddingOpen, setIsAddingOpen] = useState(false);
  const [celebrate, setCelebrate] = useState(false);

  const refreshState = useCallback(() => {
    const currentGoals = getSpiritualGoals();
    const currentCompletions = getGoalCompletionsForDate(todayDateStr);
    setGoals(currentGoals);
    setCompletions(currentCompletions);
  }, [todayDateStr]);

  useEffect(() => {
    refreshState();

    const handleGoalsUpdate = () => refreshState();
    const handleCompletionsUpdate = () => refreshState();

    window.addEventListener('spiritual-goals-updated', handleGoalsUpdate);
    window.addEventListener('spiritual-goals-completed-changed', handleCompletionsUpdate);

    return () => {
      window.removeEventListener('spiritual-goals-updated', handleGoalsUpdate);
      window.removeEventListener('spiritual-goals-completed-changed', handleCompletionsUpdate);
    };
  }, [refreshState]);

  const progress = useMemo(() => {
    const completedCount = goals.filter(g => !!completions[g.id]).length;
    const totalCount = goals.length;
    const percentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
    return { completedCount, totalCount, percentage };
  }, [goals, completions]);

  const handleToggle = (goalId: string) => {
    triggerButtonClickHaptic();
    const result = toggleSpiritualGoal(goalId, todayDateStr);
    if (result.completed) {
      triggerSuccessHaptic();
    }
    refreshState();

    if (result.percentage === 100 && result.totalCount > 0) {
      setCelebrate(true);
      setTimeout(() => setCelebrate(false), 4000);
    }
  };

  const handleAddGoal = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!newGoalTitle.trim()) return;

    triggerButtonClickHaptic();
    addSpiritualGoal(newGoalTitle.trim(), selectedCategory);
    setNewGoalTitle('');
    setIsAddingOpen(false);
    refreshState();
  };

  const handleAddPreset = (preset: { title: string; category: GoalCategory }) => {
    triggerButtonClickHaptic();
    // Only add if not already present
    const exists = goals.some(g => g.title.toLowerCase() === preset.title.toLowerCase());
    if (!exists) {
      addSpiritualGoal(preset.title, preset.category);
      refreshState();
    }
  };

  const handleRemove = (goalId: string) => {
    triggerHaptic(15);
    removeSpiritualGoal(goalId);
    refreshState();
  };

  const handleToggleAll = (completeAll: boolean) => {
    triggerHaptic(25);
    setAllGoalsForDate(todayDateStr, completeAll);
    refreshState();
    if (completeAll) {
      setCelebrate(true);
      setTimeout(() => setCelebrate(false), 4000);
    }
  };

  return (
    <section 
      aria-label="Daily Spiritual Goals"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 shadow-xl md:col-span-2 space-y-4 relative overflow-hidden"
    >
      {/* Decorative Glow */}
      <div 
        aria-hidden="true" 
        className="absolute -top-10 -right-10 w-32 h-32 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" 
      />

      {/* Header & Quick Progress */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
            <Sparkles size={20} />
          </div>
          <div>
            <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              <span>Daily Spiritual Goals</span>
              <span className="text-xs text-amber-500 font-serif opacity-80" dir="rtl">
                الأهداف اليومية
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Cultivate daily Quran reading, morning/evening adhkar, and voluntary charity
            </p>
          </div>
        </div>

        {/* Action button to open add goal dialog */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => {
              triggerButtonClickHaptic();
              setIsAddingOpen(!isAddingOpen);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-400 text-xs font-semibold transition active:scale-95"
          >
            <Plus size={15} />
            <span>{isAddingOpen ? 'Close' : 'Define Goal'}</span>
          </button>
        </div>
      </div>

      {/* Progress Bar & Summary Metrics */}
      <div className="space-y-1.5 bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-300 font-medium flex items-center gap-1.5">
            <Target size={13} className="text-amber-500" />
            Today's Spiritual Progress:
          </span>
          <span className="font-mono font-bold text-amber-400">
            {progress.completedCount} / {progress.totalCount} Goals ({progress.percentage}%)
          </span>
        </div>

        {/* Progress Bar Track */}
        <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden border border-slate-800">
          <div 
            className={`h-full transition-all duration-500 rounded-full ${
              progress.percentage === 100 
                ? 'bg-gradient-to-r from-emerald-500 to-emerald-400 shadow-md shadow-emerald-500/30' 
                : 'bg-gradient-to-r from-amber-600 to-amber-400'
            }`}
            style={{ width: `${progress.percentage}%` }}
          />
        </div>

        {/* Celebration Toast on 100% completion */}
        {celebrate && (
          <div className="pt-1 flex items-center justify-center gap-2 text-xs text-emerald-400 font-semibold animate-pulse">
            <Award size={15} />
            <span>Masha'Allah! All daily spiritual goals completed for today!</span>
          </div>
        )}
      </div>

      {/* Define Custom Goal Form (Collapsible) */}
      {isAddingOpen && (
        <form onSubmit={handleAddGoal} className="bg-slate-950 border border-amber-500/30 rounded-xl p-4 space-y-3 animate-fadeIn">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <PlusCircle size={14} className="text-amber-500" />
              <span>Define New Spiritual Habit</span>
            </h4>
            <span className="text-[11px] text-slate-400">Customize daily target</span>
          </div>

          <input
            type="text"
            value={newGoalTitle}
            onChange={(e) => setNewGoalTitle(e.target.value)}
            placeholder="e.g. Read 1 Juz of Quran, 100x Astaghfirullah, Give Sadaqah..."
            className="w-full bg-slate-900 border border-slate-700 text-slate-100 px-3.5 py-2.5 rounded-xl text-xs placeholder-slate-500 focus:outline-none focus:border-amber-500"
            autoFocus
          />

          <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
            <div className="flex flex-wrap items-center gap-1.5 text-xs">
              <span className="text-slate-400 text-[11px]">Category:</span>
              {(['quran', 'dhikr', 'charity', 'prayer', 'sunnah'] as GoalCategory[]).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg text-xs capitalize transition ${
                    selectedCategory === cat 
                      ? 'bg-amber-600 text-slate-950 font-bold' 
                      : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <button
              type="submit"
              disabled={!newGoalTitle.trim()}
              className="px-4 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-slate-950 text-xs font-bold transition active:scale-95"
            >
              Add Goal
            </button>
          </div>
        </form>
      )}

      {/* Preset Quick Suggestion Chips */}
      <div className="space-y-1.5">
        <span className="text-[11px] text-slate-400 font-medium">Quick Habits (Tap to add if missing):</span>
        <div className="flex flex-wrap gap-1.5">
          {PRESET_GOAL_SUGGESTIONS.map((preset) => {
            const isAlreadyAdded = goals.some(g => g.title.toLowerCase() === preset.title.toLowerCase());
            if (isAlreadyAdded) return null;

            return (
              <button
                key={preset.title}
                type="button"
                onClick={() => handleAddPreset(preset)}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-950/70 hover:bg-slate-850 border border-slate-800 text-slate-300 text-xs transition active:scale-95 hover:border-amber-500/40"
              >
                <Plus size={11} className="text-amber-500" />
                <span>{preset.title}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* List of Defined Goals with Checkoffs */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-400 pb-1">
          <span>Today's Checklist:</span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleToggleAll(true)}
              className="text-amber-400 hover:text-amber-300 font-medium transition"
            >
              Complete All
            </button>
            <span className="text-slate-600">·</span>
            <button
              type="button"
              onClick={() => handleToggleAll(false)}
              className="text-slate-400 hover:text-slate-200 transition"
            >
              Reset
            </button>
          </div>
        </div>

        {goals.length === 0 ? (
          <div className="text-center py-6 bg-slate-950/40 rounded-xl border border-dashed border-slate-800 text-slate-500 text-xs">
            No daily goals defined yet. Tap "Define Goal" or a quick habit above to get started!
          </div>
        ) : (
          goals.map((goal) => {
            const isDone = !!completions[goal.id];
            const meta = CATEGORY_META[goal.category] || CATEGORY_META.general;

            return (
              <div
                key={goal.id}
                className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                  isDone 
                    ? 'bg-amber-950/20 border-amber-500/40 text-slate-200' 
                    : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                {/* Checkbox & Title */}
                <button
                  type="button"
                  onClick={() => handleToggle(goal.id)}
                  className="flex items-center gap-3 text-left flex-grow mr-2 group focus:outline-none"
                >
                  <div className={`w-6 h-6 rounded-lg flex items-center justify-center border transition-all ${
                    isDone 
                      ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-sm' 
                      : 'border-slate-700 bg-slate-900 group-hover:border-amber-500/50'
                  }`}>
                    {isDone && <Check size={14} strokeWidth={3} className="text-slate-950" />}
                  </div>

                  <div>
                    <span className={`text-xs sm:text-sm font-medium block transition-all ${
                      isDone ? 'line-through text-slate-400' : 'text-slate-100'
                    }`}>
                      {goal.title}
                    </span>
                    <span className={`inline-flex items-center gap-1 text-[10px] px-2 py-0.2 rounded-full border mt-0.5 ${meta.color}`}>
                      {meta.icon}
                      <span>{meta.label}</span>
                    </span>
                  </div>
                </button>

                {/* Remove Goal Button */}
                <button
                  type="button"
                  onClick={() => handleRemove(goal.id)}
                  title="Remove goal"
                  className="p-1.5 text-slate-600 hover:text-red-400 rounded-lg transition-colors hover:bg-slate-900"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            );
          })
        )}
      </div>
    </section>
  );
}
