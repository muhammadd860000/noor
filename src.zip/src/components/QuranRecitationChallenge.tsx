import React, { useState, useEffect } from 'react';
import { BookOpen, Sparkles, CheckCircle2, Award, Calendar, Flame } from 'lucide-react';
import { triggerHaptic, triggerSuccessHaptic } from '../lib/haptics';

const STORAGE_KEY = 'noor_juz_challenge_progress';

export default function QuranRecitationChallenge() {
  const [completedDays, setCompletedDays] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(completedDays));
    } catch {}
  }, [completedDays]);

  const toggleDay = (dayNum: number) => {
    triggerHaptic(15);
    setCompletedDays(prev => {
      const isDone = prev.includes(dayNum);
      const updated = isDone ? prev.filter(d => d !== dayNum) : [...prev, dayNum];
      if (!isDone && updated.length === 30) {
        triggerSuccessHaptic();
      }
      return updated;
    });
  };

  const completedCount = completedDays.length;
  const pct = Math.round((completedCount / 30) * 100);

  return (
    <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <span className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <Award size={20} />
          </span>
          <div>
            <h3 className="text-base font-bold text-slate-100">30-Day Quran Recitation Challenge (Complete a Juz)</h3>
            <p className="text-xs text-slate-400">Track your daily 1-Juz recitation journey for 30 consecutive days</p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs">
          <Flame size={14} className="text-amber-500" />
          <span className="text-amber-300 font-bold">{completedCount}/30 Days ({pct}%)</span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden border border-slate-800">
        <div 
          className="bg-gradient-to-r from-amber-600 to-amber-400 h-full transition-all duration-500 rounded-full"
          style={{ width: `${pct}%` }}
        />
      </div>

      {/* Grid of 30 Days */}
      <div className="grid grid-cols-6 sm:grid-cols-10 gap-2 pt-2">
        {Array.from({ length: 30 }, (_, i) => i + 1).map(day => {
          const isDone = completedDays.includes(day);

          return (
            <button
              key={day}
              type="button"
              onClick={() => toggleDay(day)}
              className={`p-2.5 rounded-xl text-xs font-bold transition flex flex-col items-center justify-center gap-0.5 border ${
                isDone
                  ? 'bg-amber-600 text-slate-950 border-amber-400 shadow-md shadow-amber-600/20'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-amber-700/50'
              }`}
            >
              <span className="text-[10px] opacity-75">Day</span>
              <span>{day}</span>
              {isDone && <CheckCircle2 size={10} className="text-slate-950 fill-amber-400" />}
            </button>
          );
        })}
      </div>

      {pct === 100 && (
        <div className="p-4 bg-emerald-950/30 border border-emerald-500/50 rounded-2xl flex items-center gap-3 text-xs text-emerald-300 animate-fadeIn">
          <Award size={20} className="text-emerald-400 shrink-0" />
          <div>
            <span className="font-bold text-emerald-200 block text-sm">Masha'Allah! 30-Day Quran Challenge Completed!</span>
            <p className="text-emerald-400/90 text-xs mt-0.5">May Allah reward your dedication to His Noble Book and make it a witness for you on the Day of Judgment.</p>
          </div>
        </div>
      )}
    </div>
  );
}
