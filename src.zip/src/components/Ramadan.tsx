
import React, { useState, useEffect } from 'react';
import { Sun, Moon } from 'lucide-react';

export default function Ramadan() {
  const [timeLeft, setTimeLeft] = useState('');

  useEffect(() => {
    const timer = setInterval(() => {
      // Mock countdown to Iftar - logic to be replaced with real API data
      setTimeLeft("04:32:15");
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="space-y-6 pb-20">
      <header>
        <h2 className="text-2xl text-amber-500 font-serif mb-6">Ramadan 2026</h2>
      </header>

      <div className="bg-slate-900 border border-amber-900/30 rounded-3xl p-8 text-center shadow-xl">
        <h3 className="text-slate-400 mb-2">Time until Iftar</h3>
        <p className="text-5xl font-mono text-slate-100 font-bold">{timeLeft}</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-4 text-center">
            <Sun className="mx-auto text-amber-500 mb-2" />
            <p className="text-slate-400 text-sm">Sehri</p>
            <p className="text-slate-200 font-bold">04:15 AM</p>
        </div>
        <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-4 text-center">
            <Moon className="mx-auto text-amber-500 mb-2" />
            <p className="text-slate-400 text-sm">Iftar</p>
            <p className="text-slate-200 font-bold">06:45 PM</p>
        </div>
      </div>
    </div>
  );
}
