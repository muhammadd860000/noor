import React, { useState, useEffect, useCallback } from 'react';
import { 
  Bell, 
  BellOff, 
  BellRing, 
  Volume2, 
  VolumeX, 
  Clock, 
  Check, 
  AlertTriangle, 
  ShieldCheck, 
  Sparkles,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { 
  isNotificationSupported, 
  getNotificationPermission, 
  requestNotificationPermission, 
  getPrayerNotificationPreferences, 
  savePrayerNotificationPreferences,
  sendTestPrayerNotification,
  PrayerNotificationPreferences,
  NotificationPermissionState
} from '../lib/notifications';
import { triggerHaptic } from '../lib/haptics';

interface PrayerNotificationManagerProps {
  times?: Record<string, string> | null;
  compact?: boolean;
}

const PRAYER_LIST = [
  { name: 'Fajr', arabic: 'الفجر' },
  { name: 'Sunrise', arabic: 'الشروق' },
  { name: 'Dhuhr', arabic: 'الظهر' },
  { name: 'Asr', arabic: 'العصر' },
  { name: 'Maghrib', arabic: 'المغرب' },
  { name: 'Isha', arabic: 'العشاء' }
];

export default function PrayerNotificationManager({ times, compact = false }: PrayerNotificationManagerProps) {
  const [permission, setPermission] = useState<NotificationPermissionState>(getNotificationPermission);
  const [prefs, setPrefs] = useState<PrayerNotificationPreferences>(getPrayerNotificationPreferences);
  const [testSent, setTestSent] = useState(false);
  const [bannerNotice, setBannerNotice] = useState<string | null>(null);
  const [isExpanded, setIsExpanded] = useState(!compact);

  // Sync state when preferences or permissions change
  useEffect(() => {
    const handlePrefUpdate = (e: Event) => {
      const customEvent = e as CustomEvent<PrayerNotificationPreferences>;
      if (customEvent.detail) {
        setPrefs(customEvent.detail);
      } else {
        setPrefs(getPrayerNotificationPreferences());
      }
    };

    const handlePermUpdate = () => {
      setPermission(getNotificationPermission());
    };

    window.addEventListener('prayer-notifications-updated', handlePrefUpdate);
    window.addEventListener('notification-permission-changed', handlePermUpdate);

    return () => {
      window.removeEventListener('prayer-notifications-updated', handlePrefUpdate);
      window.removeEventListener('notification-permission-changed', handlePermUpdate);
    };
  }, []);

  const handleRequestPermission = async () => {
    triggerHaptic(20);
    const granted = await requestNotificationPermission();
    setPermission(getNotificationPermission());
    if (granted) {
      setBannerNotice('Notification permission granted! Push notifications are now active.');
      setTimeout(() => setBannerNotice(null), 4000);
    } else {
      setBannerNotice('Notifications are disabled in your browser. Please allow notifications in site settings.');
      setTimeout(() => setBannerNotice(null), 6000);
    }
  };

  const handleTogglePrayer = async (prayerName: string) => {
    triggerHaptic(15);
    const willEnable = !prefs.enabledPrayers[prayerName];

    // If enabling and permission is not granted yet, ask for permission
    if (willEnable && permission !== 'granted') {
      const granted = await requestNotificationPermission();
      setPermission(getNotificationPermission());
      if (!granted) {
        setBannerNotice('Please allow browser notifications to receive prayer alerts.');
        setTimeout(() => setBannerNotice(null), 5000);
        return;
      }
    }

    const updated: PrayerNotificationPreferences = {
      ...prefs,
      enabledPrayers: {
        ...prefs.enabledPrayers,
        [prayerName]: willEnable
      }
    };

    setPrefs(updated);
    savePrayerNotificationPreferences(updated);
  };

  const handleTimingChange = (newTiming: 'exact' | '10min_before' | 'both') => {
    triggerHaptic(15);
    const updated: PrayerNotificationPreferences = {
      ...prefs,
      timing: newTiming
    };
    setPrefs(updated);
    savePrayerNotificationPreferences(updated);
  };

  const handleSoundToggle = () => {
    triggerHaptic(15);
    const updated: PrayerNotificationPreferences = {
      ...prefs,
      soundEnabled: !prefs.soundEnabled
    };
    setPrefs(updated);
    savePrayerNotificationPreferences(updated);
  };

  const handleToggleAll = async (enable: boolean) => {
    triggerHaptic(25);
    if (enable && permission !== 'granted') {
      const granted = await requestNotificationPermission();
      setPermission(getNotificationPermission());
      if (!granted) {
        setBannerNotice('Please allow notifications in your browser to enable prayer alerts.');
        setTimeout(() => setBannerNotice(null), 5000);
        return;
      }
    }

    const newEnabled: Record<string, boolean> = {};
    PRAYER_LIST.forEach(p => {
      newEnabled[p.name] = enable;
    });

    const updated: PrayerNotificationPreferences = {
      ...prefs,
      enabledPrayers: newEnabled
    };
    setPrefs(updated);
    savePrayerNotificationPreferences(updated);
  };

  const handleSendTest = async () => {
    triggerHaptic(20);
    const sent = await sendTestPrayerNotification();
    setPermission(getNotificationPermission());
    if (sent) {
      setTestSent(true);
      setBannerNotice('Test notification sent! Check your notification center.');
      setTimeout(() => {
        setTestSent(false);
        setBannerNotice(null);
      }, 4000);
    } else {
      setBannerNotice('Unable to send test notification. Please enable notifications in your browser.');
      setTimeout(() => setBannerNotice(null), 5000);
    }
  };

  const enabledCount = PRAYER_LIST.filter(p => !!prefs.enabledPrayers[p.name]).length;
  const isSupported = isNotificationSupported();

  return (
    <section 
      aria-label="Prayer Notification Settings"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 shadow-xl space-y-4"
    >
      {/* Header bar with Status Badge */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className={`p-2 rounded-xl transition-colors ${
            permission === 'granted' 
              ? 'bg-amber-500/10 text-amber-500' 
              : permission === 'denied' 
                ? 'bg-red-500/10 text-red-400' 
                : 'bg-slate-800 text-slate-400'
          }`}>
            {permission === 'granted' ? <BellRing size={18} /> : <BellOff size={18} />}
          </span>
          <div>
            <h3 className="text-sm font-semibold tracking-wide uppercase text-amber-500 flex items-center gap-2">
              Prayer Push Notifications
              {permission === 'granted' && (
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400" title="Notifications Active" />
              )}
            </h3>
            <p className="text-xs text-slate-400">
              {permission === 'granted' 
                ? `${enabledCount} of ${PRAYER_LIST.length} prayers active` 
                : permission === 'denied' 
                  ? 'Notifications blocked by browser' 
                  : 'Receive timely Adhan alerts'}
            </p>
          </div>
        </div>

        {/* Header Action or Expand Toggle */}
        <div className="flex items-center gap-2">
          {permission !== 'granted' && isSupported && (
            <button
              type="button"
              onClick={handleRequestPermission}
              className="text-xs font-semibold px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-slate-950 rounded-xl transition-all shadow-md shadow-amber-600/20 active:scale-95"
            >
              Enable Notifications
            </button>
          )}

          {compact && (
            <button
              type="button"
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800 transition-colors"
              aria-label={isExpanded ? 'Collapse notification settings' : 'Expand notification settings'}
            >
              {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            </button>
          )}
        </div>
      </div>

      {/* Dynamic Feedback Banner */}
      {bannerNotice && (
        <div className="p-3 bg-amber-950/40 border border-amber-500/30 rounded-xl text-xs text-amber-300 flex items-center justify-between animate-fadeIn">
          <span>{bannerNotice}</span>
          <button 
            type="button" 
            onClick={() => setBannerNotice(null)}
            className="text-slate-400 hover:text-slate-200 ml-2"
          >
            ×
          </button>
        </div>
      )}

      {/* Permission Denied Guide */}
      {permission === 'denied' && (
        <div className="p-3.5 bg-red-950/30 border border-red-800/40 rounded-xl text-xs text-red-300 space-y-1">
          <div className="flex items-center gap-1.5 font-semibold text-red-400">
            <AlertTriangle size={15} />
            <span>Browser Permission Blocked</span>
          </div>
          <p className="text-slate-300">
            Notifications are currently blocked. To receive alerts, click the lock or settings icon in your browser URL bar and change Notifications to <strong>Allow</strong>.
          </p>
        </div>
      )}

      {/* Unsupported Guide */}
      {!isSupported && (
        <div className="p-3 bg-slate-800/60 border border-slate-700/50 rounded-xl text-xs text-slate-400">
          This browser environment does not support web push notifications. Try using an installed PWA or modern browser.
        </div>
      )}

      {/* Expandable Per-Prayer Toggles */}
      {isExpanded && (
        <div className="space-y-4 pt-1">
          {/* Quick All / None Action Bar */}
          <div className="flex items-center justify-between text-xs text-slate-400 pb-1">
            <span>Toggle specific prayer times:</span>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => handleToggleAll(true)}
                className="text-amber-500 hover:text-amber-400 font-medium transition-colors"
              >
                Enable All
              </button>
              <span className="text-slate-600">·</span>
              <button
                type="button"
                onClick={() => handleToggleAll(false)}
                className="hover:text-slate-200 transition-colors"
              >
                Mute All
              </button>
            </div>
          </div>

          {/* Grid of 6 Prayer Cards with Individual Push Toggles */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {PRAYER_LIST.map((prayer) => {
              const isEnabled = !!prefs.enabledPrayers[prayer.name];
              const prayerTime = times ? times[prayer.name] : null;

              return (
                <div
                  key={prayer.name}
                  onClick={() => handleTogglePrayer(prayer.name)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === ' ' || e.key === 'Enter') {
                      e.preventDefault();
                      handleTogglePrayer(prayer.name);
                    }
                  }}
                  aria-pressed={isEnabled}
                  aria-label={`Toggle notifications for ${prayer.name}`}
                  className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer select-none transition-all duration-200 active:scale-95 ${
                    isEnabled
                      ? 'bg-amber-950/25 border-amber-500/40 text-slate-200 shadow-sm shadow-amber-500/10'
                      : 'bg-slate-950/60 hover:bg-slate-800/50 border-slate-800/80 text-slate-400'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className={`text-xs font-semibold ${isEnabled ? 'text-amber-300' : 'text-slate-300'}`}>
                        {prayer.name}
                      </span>
                      <span className="text-[10px] text-slate-400 font-serif opacity-80" dir="rtl">
                        {prayer.arabic}
                      </span>
                    </div>
                    {prayerTime && (
                      <span className="text-[11px] font-mono text-amber-500/90 font-medium block mt-0.5">
                        {prayerTime}
                      </span>
                    )}
                  </div>

                  {/* Toggle Pill Button */}
                  <div className={`w-9 h-5 rounded-full p-0.5 transition-colors duration-200 flex items-center ${
                    isEnabled ? 'bg-amber-600 justify-end' : 'bg-slate-800 justify-start'
                  }`}>
                    <div className="w-4 h-4 rounded-full bg-slate-100 shadow-sm" />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Timing Preferences & Audio Sound Settings */}
          <div className="pt-3 border-t border-amber-900/20 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {/* Timing selection */}
            <div className="space-y-1.5">
              <span className="text-slate-400 font-medium flex items-center gap-1">
                <Clock size={13} /> Notification Timing
              </span>
              <div className="flex gap-1.5">
                {[
                  { id: 'both', label: '10m & Adhan' },
                  { id: 'exact', label: 'At Adhan' },
                  { id: '10min_before', label: '10m Before' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleTimingChange(item.id as any)}
                    className={`flex-1 py-1 px-2 rounded-lg text-xs font-medium transition-colors ${
                      prefs.timing === item.id
                        ? 'bg-amber-600/30 text-amber-400 border border-amber-500/40'
                        : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border border-transparent'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Sound toggle & Test button */}
            <div className="space-y-1.5">
              <span className="text-slate-400 font-medium flex items-center gap-1">
                {prefs.soundEnabled ? <Volume2 size={13} /> : <VolumeX size={13} />}
                Audio & Verification
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleSoundToggle}
                  className={`flex-1 py-1 px-2 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 transition-colors ${
                    prefs.soundEnabled
                      ? 'bg-amber-600/20 text-amber-400 border-amber-500/40'
                      : 'bg-slate-800/80 text-slate-400 border-slate-700'
                  }`}
                >
                  {prefs.soundEnabled ? <Volume2 size={13} /> : <VolumeX size={13} />}
                  <span>{prefs.soundEnabled ? 'Chime On' : 'Silent'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleSendTest}
                  disabled={testSent}
                  className="flex-1 py-1 px-2 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-750 text-slate-200 hover:text-amber-400 border border-slate-700 hover:border-amber-500/40 transition-colors flex items-center justify-center gap-1.5"
                >
                  {testSent ? <Check size={13} className="text-emerald-400" /> : <Sparkles size={13} />}
                  <span>{testSent ? 'Sent!' : 'Test Push'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
