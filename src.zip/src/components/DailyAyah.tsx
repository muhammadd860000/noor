import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { 
  BookOpen, 
  Play, 
  Pause, 
  RefreshCw, 
  Bookmark, 
  Share2, 
  Copy, 
  Check, 
  ChevronRight, 
  Sparkles,
  BookMarked
} from 'lucide-react';
import { useAudio, constructAyahAudioUrl } from '../context/AudioContext';
import { triggerHaptic } from '../lib/haptics';

export interface DailyAyahData {
  globalNumber: number;
  numberInSurah: number;
  juz: number;
  text: string;
  translation: string;
  tafsir?: string;
  surah: {
    number: number;
    name: string;
    englishName: string;
    englishNameTranslation: string;
    numberOfAyahs: number;
    revelationType: string;
  };
}

// Curated uplifting fallback verses for offline reliability
const FALLBACK_VERSES: DailyAyahData[] = [
  {
    globalNumber: 255,
    numberInSurah: 255,
    juz: 3,
    text: "ٱللَّهُ لَآ إِلَٰهَ إِلَّا هُوَ ٱلْحَىُّ ٱلْقَيُّومُ ۚ لَا تَأْخُذُهُۥ سِنَةٌۭ وَلَا نَوْمٌۭ ۚ لَّهُۥ مَا فِى ٱلسَّمَٰوَٰتِ وَمَا فِى ٱلْأَرْضِ",
    translation: "Allah - there is no deity except Him, the Ever-Living, the Sustainer of all existence. Neither drowsiness overtakes Him nor sleep. To Him belongs whatever is in the heavens and whatever is on the earth.",
    tafsir: "آية الكرسي: أعظم آية في كتاب الله تعالى، تشتمل على أسماء الله وصفاته العظمى وألوهيته وربوبيته المطلقة.",
    surah: {
      number: 2,
      name: "سُورَةُ البَقَرَةِ",
      englishName: "Al-Baqarah",
      englishNameTranslation: "The Cow",
      numberOfAyahs: 286,
      revelationType: "Medinan"
    }
  },
  {
    globalNumber: 152,
    numberInSurah: 152,
    juz: 2,
    text: "فَٱذْكُرُونِىٓ أَذْكُرْكُمْ وَٱشْكُرُوا۟ لِى وَلَا تَكْفُرُونِ",
    translation: "So remember Me; I will remember you. And be grateful to Me and do not deny Me.",
    tafsir: "فاذكروني بطاعتي والإخلاص لي أذكركم بالثواب والمغفرة والرحمة، واشكروا لي نعمي العظيمة.",
    surah: {
      number: 2,
      name: "سُورَةُ البَقَرَةِ",
      englishName: "Al-Baqarah",
      englishNameTranslation: "The Cow",
      numberOfAyahs: 286,
      revelationType: "Medinan"
    }
  },
  {
    globalNumber: 6112,
    numberInSurah: 5,
    juz: 30,
    text: "فَإِنَّ مَعَ ٱلْعُسْرِ يُسْرًا ۝ إِنَّ مَعَ ٱلْعُسْرِ يُسْرًا",
    translation: "For indeed, with hardship [will be] ease. Indeed, with hardship [will be] ease.",
    tafsir: "فإن مع الضيق والشدة فرجًا وتيسيرًا، ولن يغلب عسر يسرين.",
    surah: {
      number: 94,
      name: "سُورَةُ الشَّرۡحِ",
      englishName: "Ash-Sharh",
      englishNameTranslation: "The Relief",
      numberOfAyahs: 8,
      revelationType: "Meccan"
    }
  },
  {
    globalNumber: 4139,
    numberInSurah: 53,
    juz: 24,
    text: "قُلْ يَٰعِبَادِىَ ٱلَّذِينَ أَسْرَفُوا۟ عَلَىٰٓ أَنفُسِهِمْ لَا تَقْنَطُوا۟ مِن رَّحْمَةِ ٱللَّهِ ۚ إِنَّ ٱللَّهَ يَغْفِرُ ٱلذُّنُوبَ جَمِيعًا ۚ إِنَّهُۥ هُوَ ٱلْغَفُورُ ٱلرَّحِيمُ",
    translation: "Say, 'O My servants who have transgressed against themselves [by sinning], do not despair of the mercy of Allah. Indeed, Allah forgives all sins. Indeed, it is He who is the Forgiving, the Merciful.'",
    tafsir: "هذه الآية الكريمة دعوة لجميع المذنبين إلى التوبة والإنابة إلى الله تعالى، وبيان أن الله يغفر الذنوب جميعًا لمن تاب.",
    surah: {
      number: 39,
      name: "سُورَةُ الزُّمَرِ",
      englishName: "Az-Zumar",
      englishNameTranslation: "The Troops",
      numberOfAyahs: 75,
      revelationType: "Meccan"
    }
  },
  {
    globalNumber: 1735,
    numberInSurah: 28,
    juz: 13,
    text: "ٱلَّذِينَ ءَامَنُوا۟ وَتَطْمَئِنُّ قُلُوبُهُم بِذِكْرِ ٱللَّهِ ۗ أَلَا بِذِكْرِ ٱللَّهِ تَطْمَئِنُّ ٱلْقُلُوبُ",
    translation: "Those who have believed and whose hearts are assured by the remembrance of Allah. Unquestionably, by the remembrance of Allah hearts are assured.",
    tafsir: "الذين صدقوا بالله ورسوله تسكن نفوسهم ويذهب قلقها وتطيب بذكر الله وطاعته.",
    surah: {
      number: 13,
      name: "سُورَةُ الرَّعۡدِ",
      englishName: "Ar-Ra'd",
      englishNameTranslation: "The Thunder",
      numberOfAyahs: 43,
      revelationType: "Medinan"
    }
  }
];

export default function DailyAyah() {
  const [ayah, setAyah] = useState<DailyAyahData | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showTafsir, setShowTafsir] = useState(false);
  const [errorNotice, setErrorNotice] = useState<string | null>(null);

  const { isPlaying, currentUrl, playTrack, pause } = useAudio();

  // Format today's date banner nicely
  const todayFormatted = useMemo(() => {
    return new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'short',
      day: 'numeric'
    });
  }, []);

  // Check if this Ayah is currently playing
  const isThisAyahPlaying = useMemo(() => {
    if (!ayah || !isPlaying || !currentUrl) return false;
    const targetUrl = constructAyahAudioUrl(ayah.globalNumber);
    return currentUrl === targetUrl;
  }, [ayah, isPlaying, currentUrl]);

  // Load bookmark status whenever ayah changes
  useEffect(() => {
    if (!ayah) return;
    try {
      const savedBookmarks = JSON.parse(localStorage.getItem('bookmarkedAyahs') || '[]');
      setIsBookmarked(savedBookmarks.includes(ayah.globalNumber));
    } catch {
      setIsBookmarked(false);
    }
  }, [ayah]);

  // Core fetch function
  const fetchRandomAyah = useCallback(async (isManualRefresh = false) => {
    if (isManualRefresh) {
      setRefreshing(true);
      triggerHaptic();
    } else {
      setLoading(true);
    }
    setErrorNotice(null);

    const todayDate = new Date().toISOString().split('T')[0];

    // If initial load and today's verse exists in cache, load it directly
    if (!isManualRefresh) {
      const cachedDate = localStorage.getItem('dailyAyahDate');
      const cachedAyah = localStorage.getItem('dailyAyah');
      if (cachedDate === todayDate && cachedAyah) {
        try {
          const parsed = JSON.parse(cachedAyah);
          setAyah(parsed);
          setLoading(false);
          return;
        } catch (e) {
          console.warn('[DailyAyah] Failed to parse cached ayah', e);
        }
      }
    }

    try {
      // Fetch random ayah with Arabic Uthmani, Sahih International English translation, and Muyassar Tafsir
      const response = await fetch(
        'https://api.alquran.cloud/v1/ayah/random/editions/quran-uthmani,en.sahih,ar.muyassar'
      );
      
      if (!response.ok) {
        throw new Error(`API returned status ${response.status}`);
      }

      const resJson = await response.json();
      if (resJson.code !== 200 || !Array.isArray(resJson.data) || resJson.data.length < 2) {
        throw new Error('Invalid Quran API response format');
      }

      const arabicData = resJson.data[0];
      const translationData = resJson.data[1];
      const tafsirData = resJson.data[2];

      const newDailyAyah: DailyAyahData = {
        globalNumber: arabicData.number,
        numberInSurah: arabicData.numberInSurah,
        juz: arabicData.juz,
        text: arabicData.text,
        translation: translationData.text,
        tafsir: tafsirData?.text || undefined,
        surah: {
          number: arabicData.surah.number,
          name: arabicData.surah.name,
          englishName: arabicData.surah.englishName,
          englishNameTranslation: arabicData.surah.englishNameTranslation,
          numberOfAyahs: arabicData.surah.numberOfAyahs,
          revelationType: arabicData.surah.revelationType
        }
      };

      setAyah(newDailyAyah);
      localStorage.setItem('dailyAyah', JSON.stringify(newDailyAyah));
      localStorage.setItem('dailyAyahDate', todayDate);
    } catch (err) {
      console.warn('[DailyAyah] Online fetch failed, selecting fallback:', err);
      // Select deterministic fallback based on day of the year
      const now = new Date();
      const startOfYear = new Date(now.getFullYear(), 0, 0);
      const dayOfYear = Math.floor((now.getTime() - startOfYear.getTime()) / (1000 * 60 * 60 * 24));
      const fallback = FALLBACK_VERSES[dayOfYear % FALLBACK_VERSES.length];
      
      setAyah(fallback);
      localStorage.setItem('dailyAyah', JSON.stringify(fallback));
      localStorage.setItem('dailyAyahDate', todayDate);
      if (isManualRefresh) {
        setErrorNotice('Using offline verse archive.');
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  // Initial load
  useEffect(() => {
    fetchRandomAyah(false);
  }, [fetchRandomAyah]);

  // Handle Audio playback
  const handleToggleAudio = async () => {
    triggerHaptic();
    if (!ayah) return;

    if (isThisAyahPlaying) {
      pause();
    } else {
      const audioUrl = constructAyahAudioUrl(ayah.globalNumber);
      await playTrack(audioUrl);
    }
  };

  // Handle Bookmark toggle
  const handleToggleBookmark = () => {
    triggerHaptic();
    if (!ayah) return;

    try {
      const currentBookmarks: number[] = JSON.parse(localStorage.getItem('bookmarkedAyahs') || '[]');
      let updated: number[];
      if (currentBookmarks.includes(ayah.globalNumber)) {
        updated = currentBookmarks.filter(num => num !== ayah.globalNumber);
        setIsBookmarked(false);
      } else {
        updated = [...currentBookmarks, ayah.globalNumber];
        setIsBookmarked(true);
      }
      localStorage.setItem('bookmarkedAyahs', JSON.stringify(updated));
    } catch (e) {
      console.error('[DailyAyah] Failed to toggle bookmark', e);
    }
  };

  // Handle Copy text
  const handleCopy = async () => {
    triggerHaptic();
    if (!ayah) return;

    const formatted = `"${ayah.text}"\n\n"${ayah.translation}"\n\n— Surah ${ayah.surah.englishName} (${ayah.surah.name}) [${ayah.surah.number}:${ayah.numberInSurah}]`;

    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(formatted);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Handle Share
  const handleShare = async () => {
    triggerHaptic();
    if (!ayah) return;

    const shareData = {
      title: `Daily Ayah: Surah ${ayah.surah.englishName} (${ayah.surah.number}:${ayah.numberInSurah})`,
      text: `${ayah.text}\n\n"${ayah.translation}"\n— Surah ${ayah.surah.englishName} [${ayah.surah.number}:${ayah.numberInSurah}]`,
      url: window.location.origin
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          handleCopy();
        }
      }
    } else {
      handleCopy();
    }
  };

  if (loading) {
    return (
      <div className="bg-slate-900/90 border border-amber-900/30 rounded-2xl p-6 shadow-xl md:col-span-2 animate-pulse space-y-4">
        <div className="flex justify-between items-center">
          <div className="h-4 bg-slate-800 rounded w-1/3"></div>
          <div className="h-6 bg-slate-800 rounded-full w-12"></div>
        </div>
        <div className="h-14 bg-slate-800/80 rounded w-full"></div>
        <div className="h-8 bg-slate-800/60 rounded w-3/4"></div>
        <div className="flex gap-2 pt-2">
          <div className="h-9 bg-slate-800 rounded w-28"></div>
          <div className="h-9 bg-slate-800 rounded w-24"></div>
        </div>
      </div>
    );
  }

  if (!ayah) return null;

  return (
    <section 
      aria-label="Daily Ayah" 
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden md:col-span-2 group transition-all duration-300 hover:border-amber-700/50"
    >
      {/* Subtle decorative Islamic arch geometric glow */}
      <div 
        aria-hidden="true" 
        className="absolute -top-16 -right-16 w-44 h-44 rounded-full bg-amber-500/5 blur-3xl pointer-events-none"
      />
      <div 
        aria-hidden="true" 
        className="absolute -bottom-16 -left-16 w-44 h-44 rounded-full bg-amber-600/5 blur-3xl pointer-events-none"
      />

      {/* Header bar: Kicker title, date, and quiet utility icons */}
      <div className="flex items-center justify-between pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-2">
          <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-500">
            <BookOpen size={18} />
          </span>
          <div>
            <h2 className="text-sm font-semibold tracking-wide uppercase text-amber-500 flex items-center gap-1.5">
              Daily Ayah
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-500/60" />
            </h2>
            <p className="text-xs text-slate-400">
              {todayFormatted}
            </p>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1">
          {/* Refresh / Discover new verse */}
          <button
            type="button"
            onClick={() => fetchRandomAyah(true)}
            disabled={refreshing}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition-colors"
            title="Discover another Ayah"
            aria-label="Discover another Ayah"
          >
            <RefreshCw size={16} className={refreshing ? 'animate-spin text-amber-500' : ''} />
          </button>

          {/* Bookmark */}
          <button
            type="button"
            onClick={handleToggleBookmark}
            className={`p-2 rounded-lg transition-colors ${
              isBookmarked 
                ? 'text-amber-400 bg-amber-500/10' 
                : 'text-slate-400 hover:text-amber-400 hover:bg-slate-800/80'
            }`}
            title={isBookmarked ? 'Bookmarked' : 'Add to Bookmarks'}
            aria-label={isBookmarked ? 'Bookmarked' : 'Bookmark this verse'}
          >
            <Bookmark size={16} className={isBookmarked ? 'fill-amber-400' : ''} />
          </button>

          {/* Copy */}
          <button
            type="button"
            onClick={handleCopy}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition-colors relative"
            title="Copy verse"
            aria-label="Copy verse text and translation"
          >
            {copied ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
          </button>

          {/* Share */}
          <button
            type="button"
            onClick={handleShare}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition-colors"
            title="Share verse"
            aria-label="Share verse"
          >
            <Share2 size={16} />
          </button>
        </div>
      </div>

      {errorNotice && (
        <p className="text-xs text-amber-400/80 mt-2 italic">{errorNotice}</p>
      )}

      {/* Main Scripture Card Content */}
      <div className="pt-4 space-y-4">
        {/* Arabic Ayah Scripture */}
        <div className="relative">
          <p 
            dir="rtl" 
            lang="ar"
            className="text-2xl sm:text-3xl text-amber-100/95 font-serif text-right leading-[2.2] tracking-wide select-text selection:bg-amber-500/30 py-1"
          >
            {ayah.text}
            <span 
              className="inline-flex items-center justify-center mr-2 align-middle text-amber-500/80 text-sm font-sans font-medium px-2 py-0.5 rounded-full border border-amber-500/30"
              title={`Ayah ${ayah.numberInSurah}`}
            >
              ۝ {ayah.numberInSurah}
            </span>
          </p>
        </div>

        {/* English Translation */}
        <p className="text-slate-300 text-sm sm:text-base leading-relaxed font-normal italic select-text selection:bg-amber-500/30">
          "{ayah.translation}"
        </p>

        {/* Unboxed Metadata Line (Zero-Pill Discipline with Typographic Separators) */}
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-400 pt-1">
          <span className="font-medium text-amber-400">
            Surah {ayah.surah.englishName} ({ayah.surah.name})
          </span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>Ayah {ayah.numberInSurah} of {ayah.surah.numberOfAyahs}</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>{ayah.surah.revelationType}</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>Juz {ayah.juz}</span>
        </div>

        {/* Tafsir / Reflection Collapsible Panel */}
        {showTafsir && ayah.tafsir && (
          <div className="mt-3 p-4 bg-slate-950/70 border border-amber-900/30 rounded-xl space-y-2 animate-fadeIn">
            <div className="flex items-center justify-between text-xs text-amber-500 font-medium">
              <span className="flex items-center gap-1.5">
                <Sparkles size={14} /> Reflection & Tafsir (الميسر)
              </span>
              <button 
                type="button" 
                onClick={() => setShowTafsir(false)}
                className="text-slate-500 hover:text-slate-300"
              >
                Hide
              </button>
            </div>
            <p dir="rtl" className="text-slate-300 text-sm leading-relaxed text-right font-serif">
              {ayah.tafsir}
            </p>
          </div>
        )}

        {/* Primary Interactive Action Controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="flex items-center gap-2">
            {/* Audio Recitation Button */}
            <button
              type="button"
              onClick={handleToggleAudio}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-200 ${
                isThisAyahPlaying 
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20 ring-2 ring-amber-400/50' 
                  : 'bg-amber-600/20 hover:bg-amber-600/30 text-amber-400 border border-amber-600/40'
              }`}
              aria-label={isThisAyahPlaying ? 'Pause recitation' : 'Listen to recitation by Mishary Rashid Alafasy'}
            >
              {isThisAyahPlaying ? (
                <>
                  <Pause size={14} className="fill-slate-950" />
                  <span>Playing Recitation</span>
                  <span className="flex gap-0.5 items-end h-3 ml-1">
                    <span className="w-0.5 h-3 bg-slate-950 animate-pulse" />
                    <span className="w-0.5 h-2 bg-slate-950 animate-pulse delay-75" />
                    <span className="w-0.5 h-3.5 bg-slate-950 animate-pulse delay-150" />
                  </span>
                </>
              ) : (
                <>
                  <Play size={14} className="fill-amber-400 translate-x-0.5" />
                  <span>Listen Recitation</span>
                </>
              )}
            </button>

            {/* Reflection / Tafsir Button */}
            {ayah.tafsir && (
              <button
                type="button"
                onClick={() => setShowTafsir(!showTafsir)}
                className={`px-3 py-2 rounded-xl text-xs font-medium border transition-colors ${
                  showTafsir
                    ? 'bg-slate-800 text-amber-400 border-amber-600/40'
                    : 'text-slate-300 hover:text-amber-400 border-slate-700/60 hover:border-amber-600/30'
                }`}
              >
                {showTafsir ? 'Hide Tafsir' : 'Tafsir & Meaning'}
              </button>
            )}
          </div>

          {/* Read in Context Link to QuranReader */}
          <Link
            to={`/quran/${ayah.surah.number}`}
            className="flex items-center gap-1 text-xs text-amber-500 hover:text-amber-400 font-medium py-1 group/link"
          >
            <span>Read in Surah {ayah.surah.englishName}</span>
            <ChevronRight size={14} className="transition-transform group-hover/link:translate-x-0.5" />
          </Link>
        </div>
      </div>
    </section>
  );
}
