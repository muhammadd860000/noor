import { useAudio } from '../context/AudioContext';
import { Play, Pause } from 'lucide-react';

export default function MiniAudioPlayer() {
  const { isPlaying, setIsPlaying, audioRef, progress, duration, currentUrl } = useAudio();

  if (!currentUrl) return null;

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
        audioRef.current.pause();
    } else {
        audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-amber-900/50 p-3 flex items-center gap-4 z-50">
       <button onClick={togglePlay} className="text-amber-500">
         {isPlaying ? <Pause size={20} /> : <Play size={20} />}
       </button>
       <div className="flex-1 h-1 bg-slate-700 rounded-full">
         <div className="h-full bg-amber-500 rounded-full" style={{ width: `${(progress / (duration || 1)) * 100}%` }} />
       </div>
    </div>
  );
}
