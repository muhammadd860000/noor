import React, { useState, useEffect, useMemo } from 'react';
import HajjUmrahDuas from './HajjUmrahDuas.tsx';
import HajjRitualNotificationCard from './HajjRitualNotificationCard.tsx';
import { 
  Compass, 
  Sparkles, 
  CheckCircle2, 
  Circle, 
  RefreshCw, 
  ChevronRight, 
  Award, 
  Volume2, 
  VolumeX, 
  ShieldCheck, 
  Heart, 
  Luggage, 
  Footprints, 
  SunMedium, 
  MapPin, 
  BookOpen, 
  Info 
} from 'lucide-react';
import { triggerHaptic } from '../lib/haptics';

interface PilgrimTip {
  id: number;
  category: 'Spiritual' | 'Health' | 'Practical' | 'Etiquette';
  title: string;
  tip: string;
  hadithOrAyah?: string;
  badgeColor: string;
}

const PILGRIM_TIPS: PilgrimTip[] = [
  {
    id: 1,
    category: 'Spiritual',
    title: 'Purify Your Intention (Ikhlas)',
    tip: 'Ensure your pilgrimage is purely for the sake of Allah alone, free from vanity, showing off (Riya\'), or excessive social media documentation. Guard the sanctity of your sacred journey.',
    hadithOrAyah: '“And complete the Hajj and \'Umrah for Allah.” (Surah Al-Baqarah 2:196)',
    badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/20'
  },
  {
    id: 2,
    category: 'Etiquette',
    title: 'Patience (Sabr) is Half Your Pilgrimage',
    tip: 'You will encounter crowds, long queues, and intense heat. Meet every delay with smiling patience, dhikr, and forgiveness. Never argue, push, or speak harshly with fellow pilgrims.',
    hadithOrAyah: '“Whoever performs Hajj and does not commit obscenity or wickedness will return as free from sin as the day his mother bore him.” (Sahih al-Bukhari)',
    badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
  },
  {
    id: 3,
    category: 'Health',
    title: 'Hydration & Sun Protection',
    tip: 'Drink Zamzam and bottled water continuously throughout the day, even before you feel thirsty. Carry an umbrella or sun parasol during daytime Tawaf and Jamarat.',
    hadithOrAyah: '“The water of Zamzam is for whatever purpose it is drunk.” (Sunan Ibn Majah)',
    badgeColor: 'bg-blue-500/10 text-blue-400 border-blue-500/20'
  },
  {
    id: 4,
    category: 'Practical',
    title: 'Pre-Conditioning & Foot Care',
    tip: 'Begin walking 6,000 to 10,000 steps daily at home a month before departure. Break in your walking sandals thoroughly and pack unscented anti-chafing petroleum jelly.',
    hadithOrAyah: 'Physical stamina preserves your mental presence and khushu\' in worship.',
    badgeColor: 'bg-purple-500/10 text-purple-400 border-purple-500/20'
  },
  {
    id: 5,
    category: 'Spiritual',
    title: 'Prepare a Personal Du\'a Book',
    tip: 'Write down specific supplications for yourself, your parents, spouse, children, loved ones, and the entire Ummah before arriving in Arafah and the Kaaba so no prayer is forgotten.',
    hadithOrAyah: '“The best supplication is the supplication on the Day of Arafah.” (Sunan al-Tirmidhi)',
    badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/20'
  },
  {
    id: 6,
    category: 'Practical',
    title: 'Strictly Unscented Toiletries in Ihram',
    tip: 'Double check that your soap, shampoo, body lotion, sunscreen, wet wipes, and lip balm are 100% fragrance-free. Using scented products while in the state of Ihram is prohibited.',
    hadithOrAyah: 'A pilgrim in Ihram is prohibited from applying perfume or scented oils.',
    badgeColor: 'bg-rose-500/10 text-rose-400 border-rose-500/20'
  },
  {
    id: 7,
    category: 'Etiquette',
    title: 'Reverence at the Black Stone (Hajar al-Aswad)',
    tip: 'It is a Sunnah to touch or kiss the Black Stone only if reachable without harming others. If crowded, simply point with your right hand from afar saying “Allahu Akbar” — do not push or shove!',
    hadithOrAyah: 'Preventing harm to a Muslim is an obligation, whereas kissing the stone is a recommended Sunnah.',
    badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
  },
  {
    id: 8,
    category: 'Spiritual',
    title: 'Moisten Your Tongue with Talbiyah',
    tip: 'From the moment you assume Ihram at the Miqat until you cast the first pebble at Jamarat al-Aqaba on Eid morning, chant the Talbiyah aloud frequently with deep contemplation.',
    hadithOrAyah: '“Labbayk Allahumma Labbayk, Labbayka La Shareeka Laka Labbayk...”',
    badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/20'
  }
];

interface ChecklistItem {
  id: string;
  title: string;
  subtitle: string;
  arabic?: string;
  stage?: string;
}

const UMRAH_STEPS: ChecklistItem[] = [
  {
    id: 'u-1',
    stage: 'Step 1',
    title: 'Enter Ihram from the Miqat',
    subtitle: 'Perform Ghusl, clip nails, wear Ihram garments (2 white sheets for men), pray 2 rak\'ahs, and declare Niyyah: "Labbayk Allahumma Umrah".',
    arabic: 'لَبَّيْكَ اللَّهُمَّ عُمْرَة'
  },
  {
    id: 'u-2',
    stage: 'Step 2',
    title: 'Recite the Talbiyah Continually',
    subtitle: 'Chant the sacred pilgrimage call with devotion until you reach the Holy Mosque (Masjid al-Haram) in Makkah.',
    arabic: 'لَبَّيْكَ اللَّهُمَّ لَبَّيْكَ، لَبَّيْكَ لاَ شَرِيكَ لَكَ لَبَّيْكَ'
  },
  {
    id: 'u-3',
    stage: 'Step 3',
    title: 'Perform Tawaf al-Umrah (7 Circuits)',
    subtitle: 'Start at the Black Stone (Hajar al-Aswad); complete 7 anti-clockwise rounds around the Holy Kaaba. Men uncover right shoulder (Idtiba\').',
    arabic: 'طَوَافُ العُمْرَة (٧ أَشْوَاط)'
  },
  {
    id: 'u-4',
    stage: 'Step 4',
    title: 'Pray Behind Maqam Ibrahim & Drink Zamzam',
    subtitle: 'Offer 2 rak\'ahs near Maqam Ibrahim (reciting Surah Al-Kafirun & Al-Ikhlas), make du\'a, and drink your fill of blessed Zamzam water.',
    arabic: 'رَكْعَتَا مَقَامِ إِبْرَاهِيم وَشُرْبُ زَمْزَم'
  },
  {
    id: 'u-5',
    stage: 'Step 5',
    title: 'Perform Sa\'i Between Safa & Marwa (7 Laps)',
    subtitle: 'Ascend Mount Safa, face the Kaaba in prayer, walk to Mount Marwa (lap 1), repeating for 7 total laps ending at Marwa (~3.15 km).',
    arabic: 'السَّعْيُ بَيْنَ الصَّفَا وَالمَرْوَة'
  },
  {
    id: 'u-6',
    stage: 'Step 6',
    title: 'Halq (Shaving) or Taqseer (Haircut)',
    subtitle: 'Men shave head or trim hair equally (shaving is superior); women trim a fingertip length from the end of their hair. Ihram is now officially lifted!',
    arabic: 'الحَلْقُ أَوِ التَّقْصِير'
  }
];

const HAJJ_STEPS: ChecklistItem[] = [
  {
    id: 'h-1',
    stage: '8th Dhu al-Hijjah',
    title: 'Day of Tarwiyah — Departure to Mina',
    subtitle: 'Assume Ihram from your accommodation in Makkah; travel to Mina before Dhuhr. Pray Dhuhr, Asr, Maghrib, Isha, and Fajr shortened but not combined.',
    arabic: 'يَوْمُ التَّرْوِيَة (مِنَى)'
  },
  {
    id: 'h-2',
    stage: '9th Dhu al-Hijjah',
    title: 'Day of Arafah — The Climax of Hajj',
    subtitle: 'Move to the plains of Arafah after sunrise. Listen to Khutbah, combine Dhuhr & Asr at mid-day, and stand in heartfelt supplication until sunset.',
    arabic: 'يَوْمُ عَرَفَة (الحَجُّ عَرَفَة)'
  },
  {
    id: 'h-3',
    stage: 'Night of 9th / 10th',
    title: 'Muzdalifah — Night Under the Stars',
    subtitle: 'Proceed peacefully to Muzdalifah after sunset. Pray Maghrib & Isha combined; sleep under the open sky; collect 49-70 pebbles for Jamarat.',
    arabic: 'المُبِيتُ بِمُزْدَلِفَة'
  },
  {
    id: 'h-4',
    stage: '10th Dhu al-Hijjah',
    title: 'Yawm an-Nahr — Jamarat, Qurbani & Eid',
    subtitle: 'Return to Mina. Stone Jamarat al-Aqaba (7 pebbles); offer sacrificial animal (Hady); shave/trim hair (1st Tahallul); proceed to Makkah for Tawaf al-Ifadah.',
    arabic: 'يَوْمُ النَّحْرِ وَعِيدُ الأَضْحَى'
  },
  {
    id: 'h-5',
    stage: '11th-13th Dhu al-Hijjah',
    title: 'Ayyam at-Tashreeq — Stoning & Remembrance',
    subtitle: 'Stay in Mina. Stone all three pillars (Small, Medium, Large with 7 pebbles each) each afternoon. Abundant dhikr and praise of Allah.',
    arabic: 'أَيَّامُ التَّشْرِيقِ بِمِنَى'
  },
  {
    id: 'h-6',
    stage: 'Final Rite',
    title: 'Tawaf al-Wada\' (Farewell Circumambulation)',
    subtitle: 'Perform the final 7 circuits around the Kaaba immediately before departing Makkah to return home with a forgiven Hajj Mabrur.',
    arabic: 'طَوَافُ الوَدَاع'
  }
];

const PREPARATION_STEPS: ChecklistItem[] = [
  {
    id: 'p-1',
    stage: 'Spiritual',
    title: 'Settle All Debts & Financial Obligations',
    subtitle: 'Pay off outstanding debts, return trusts (Amanah), and ensure funds used for pilgrimage are 100% Halal and pure.'
  },
  {
    id: 'p-2',
    stage: 'Spiritual',
    title: 'Seek Mutual Forgiveness & Write Islamic Will',
    subtitle: 'Mend broken relationships with family and peers; seek mutual forgiveness; draft an Islamic will (Wasiyyah) before travel.'
  },
  {
    id: 'p-3',
    stage: 'Packing',
    title: 'Essential Ihram & Garments',
    subtitle: 'Pack 2 sets of unstitched white Ihram towels (for men), an Ihram belt or cross-body waist bag, and heavy-duty safety pins.'
  },
  {
    id: 'p-4',
    stage: 'Packing',
    title: 'Unscented Toiletries Pouch',
    subtitle: 'Unscented bar soap, fragrance-free sunscreen (SPF 50), petroleum jelly, unscented wet wipes, and lip balm.'
  },
  {
    id: 'p-5',
    stage: 'Medical',
    title: 'Personal Medical Kit & Hydration Salts',
    subtitle: 'Throat lozenges, painkillers, diarrhea medicine, band-aids/moleskin for blisters, oral rehydration electrolyte packets.'
  },
  {
    id: 'p-6',
    stage: 'Documents',
    title: 'Valid Visa, Passport & Digital Copies',
    subtitle: 'Valid passport with at least 6 months validity, Nusuk registration, vaccination cards, and printed hotel vouchers.'
  }
];

const STORAGE_KEY = 'noor_hajj_umrah_progress';
const READ_TIPS_KEY = 'noor_hajj_read_tips';

export default function HajjUmrahGuide() {
  const [activeTab, setActiveTab] = useState<'tips' | 'umrah' | 'hajj' | 'alerts' | 'prep' | 'duas'>('tips');
  
  // Deterministic daily tip based on day of year
  const scheduledTipIndex = useMemo(() => {
    const now = new Date();
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now.getTime() - start.getTime();
    const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));
    return dayOfYear % PILGRIM_TIPS.length;
  }, []);

  const [tipIndex, setTipIndex] = useState(scheduledTipIndex);
  
  const [readTips, setReadTips] = useState<Record<number, boolean>>(() => {
    try {
      const saved = localStorage.getItem(READ_TIPS_KEY);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(READ_TIPS_KEY, JSON.stringify(readTips));
    } catch (e) {
      console.warn(e);
    }
  }, [readTips]);
  
  // Progress tracker stored in localStorage
  const [completedSteps, setCompletedSteps] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(completedSteps));
    } catch (e) {
      console.warn(e);
    }
  }, [completedSteps]);

  // Toggle step completion
  const toggleStep = (id: string) => {
    triggerHaptic(20);
    setCompletedSteps(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  // Cycle daily tip
  const cycleTip = () => {
    triggerHaptic(15);
    setTipIndex(prev => (prev + 1) % PILGRIM_TIPS.length);
  };

  const toggleReadTip = (id: number) => {
    triggerHaptic(18);
    setReadTips(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const currentTip = PILGRIM_TIPS[tipIndex];
  const isTipRead = !!readTips[currentTip.id];

  // Active checklist calculation
  const currentList = useMemo(() => {
    if (activeTab === 'umrah') return UMRAH_STEPS;
    if (activeTab === 'hajj') return HAJJ_STEPS;
    if (activeTab === 'prep') return PREPARATION_STEPS;
    return [];
  }, [activeTab]);

  const progress = useMemo(() => {
    if (currentList.length === 0) return { completed: 0, total: 0, pct: 0 };
    const completed = currentList.filter(item => completedSteps[item.id]).length;
    const total = currentList.length;
    const pct = Math.round((completed / total) * 100);
    return { completed, total, pct };
  }, [currentList, completedSteps]);

  return (
    <section 
      aria-label="Hajj and Umrah Pilgrim Guide"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-700/50 md:col-span-2 space-y-5"
    >
      {/* Decorative ambient flares */}
      <div 
        aria-hidden="true" 
        className="absolute -top-20 -right-20 w-52 h-52 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" 
      />
      <div 
        aria-hidden="true" 
        className="absolute -bottom-20 -left-20 w-52 h-52 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none" 
      />

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <span className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <Compass size={20} />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-100 tracking-tight">
                Hajj & Umrah Guide
              </h3>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Pilgrim Companion
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Daily pilgrim tips, step-by-step ritual checklists, and practical preparation for Makkah & Madinah
            </p>
          </div>
        </div>

        {/* Tab Navigation Pill Switcher */}
        <div className="flex bg-slate-950/80 border border-amber-900/30 p-1 rounded-xl text-xs self-start sm:self-auto overflow-x-auto max-w-full">
          <button
            type="button"
            onClick={() => {
              triggerHaptic(10);
              setActiveTab('tips');
            }}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'tips'
                ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            💡 Daily Tip
          </button>
          <button
            type="button"
            onClick={() => {
              triggerHaptic(10);
              setActiveTab('umrah');
            }}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'umrah'
                ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🕋 Umrah Steps
          </button>
          <button
            type="button"
            onClick={() => {
              triggerHaptic(10);
              setActiveTab('hajj');
            }}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'hajj'
                ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ⛺ Hajj Days
          </button>
          <button
            type="button"
            onClick={() => {
              triggerHaptic(10);
              setActiveTab('alerts');
            }}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'alerts'
                ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🔔 Ritual Alerts
          </button>
          <button
            type="button"
            onClick={() => {
              triggerHaptic(10);
              setActiveTab('prep');
            }}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'prep'
                ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🎒 Preparation
          </button>
          <button
            type="button"
            onClick={() => {
              triggerHaptic(10);
              setActiveTab('duas');
            }}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === 'duas'
                ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🤲 Pilgrim Duas
          </button>
        </div>
      </div>

      {/* VIEW: PILGRIM DUAS LIBRARY */}
      {activeTab === 'duas' && (
        <div className="animate-fadeIn">
          <HajjUmrahDuas />
        </div>
      )}

      {/* VIEW: RITUAL ALERTS & SCHEDULER */}
      {activeTab === 'alerts' && (
        <div className="animate-fadeIn">
          <HajjRitualNotificationCard />
        </div>
      )}

      {/* VIEW 1: DAILY PILGRIM TIP SHOWCASE */}
      {activeTab === 'tips' && (
        <div className="space-y-4 animate-fadeIn">
          {/* Main Tip Showcase Card */}
          <div className="p-5 sm:p-6 bg-slate-950/70 border border-amber-900/40 rounded-2xl relative overflow-hidden shadow-inner space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-mono uppercase px-2.5 py-0.5 rounded-full border font-bold ${currentTip.badgeColor}`}>
                  {currentTip.category} Advice
                </span>
                <span className="text-[11px] text-slate-400 font-mono">
                  Tip #{currentTip.id} of {PILGRIM_TIPS.length}
                </span>
              </div>

              {/* Refresh / Next Tip Button */}
              <button
                type="button"
                onClick={cycleTip}
                className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-amber-400 bg-slate-900 border border-slate-800 hover:border-amber-500/40 px-2.5 py-1 rounded-xl transition-all"
                title="Shuffle next pilgrim tip"
              >
                <RefreshCw size={13} className="text-amber-500" />
                <span>Next Gem</span>
              </button>
            </div>

            <div className="space-y-2">
              <h4 className="text-lg sm:text-xl font-bold text-slate-100 flex items-center gap-2">
                <Sparkles size={18} className="text-amber-500 flex-shrink-0" />
                {currentTip.title}
              </h4>
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                {currentTip.tip}
              </p>
            </div>

            {currentTip.hadithOrAyah && (
              <div className="pt-3 border-t border-slate-800/80 flex items-start gap-2 text-xs text-amber-400/90 italic">
                <BookOpen size={14} className="flex-shrink-0 mt-0.5 text-amber-500" />
                <span>{currentTip.hadithOrAyah}</span>
              </div>
            )}

            {/* Mark as Read Button */}
            <div className="pt-2 flex items-center justify-between">
              <span className="text-xs text-slate-400">
                {isTipRead ? '✨ Tip read and completed for today' : 'Mark this daily guidance as read'}
              </span>
              <button
                type="button"
                onClick={() => toggleReadTip(currentTip.id)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  isTipRead
                    ? 'bg-emerald-950/80 border border-emerald-500/50 text-emerald-200'
                    : 'bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                }`}
              >
                <CheckCircle2 size={15} className={isTipRead ? 'text-emerald-400' : 'text-slate-950'} />
                <span>{isTipRead ? 'Marked as Read ✓' : 'Mark as Read'}</span>
              </button>
            </div>
          </div>

          {/* Sacred Talbiyah Centerpiece Banner */}
          <div className="p-4 bg-gradient-to-r from-amber-950/40 via-slate-950 to-slate-900 border border-amber-500/30 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-left">
              <span className="text-[10px] font-mono uppercase text-amber-400 font-bold block">
                The Sacred Pilgrim's Anthem (At-Talbiyah)
              </span>
              <p className="text-lg sm:text-xl font-arabic text-amber-300 leading-relaxed" dir="rtl">
                لَبَّيْكَ اللَّهُمَّ لَبَّيْكَ، لَبَّيْكَ لاَ شَرِيكَ لَكَ لَبَّيْكَ، إِنَّ الْحَمْدَ وَالنِّعْمَةَ لَكَ وَالْمُلْكَ، لاَ شَرِيكَ لَكَ
              </p>
              <p className="text-xs text-slate-400 italic">
                "Here I am at Your service, O Allah, here I am. Here I am, You have no partner, here I am. Verily all praise, blessings, and sovereignty belong to You alone. You have no partner."
              </p>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: STEP-BY-STEP CHECKLISTS (UMRAH, HAJJ, PREPARATION) */}
      {activeTab !== 'tips' && (
        <div className="space-y-4 animate-fadeIn">
          {/* Progress Status Bar */}
          <div className="bg-slate-950/70 border border-amber-900/30 rounded-xl p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-inner">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-200">
                  {activeTab === 'umrah' ? 'Umrah Ritual Progress' : activeTab === 'hajj' ? 'Hajj Days Milestone Progress' : 'Journey Preparation Checklist'}
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-bold">
                  {progress.completed} of {progress.total} Completed
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Tap each step as you complete it. Your progress is saved automatically on this device.
              </p>
            </div>

            {/* Percentage Bar */}
            <div className="w-full sm:w-48 space-y-1 self-stretch sm:self-auto">
              <div className="flex justify-between text-[11px] font-mono text-slate-300">
                <span>Completion:</span>
                <span className={progress.pct === 100 ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                  {progress.pct}%
                </span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-500 ${
                    progress.pct === 100 ? 'bg-emerald-500' : 'bg-amber-500'
                  }`}
                  style={{ width: `${progress.pct}%` }}
                />
              </div>
            </div>
          </div>

          {/* Interactive Checklist Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {currentList.map(step => {
              const isDone = !!completedSteps[step.id];

              return (
                <div
                  key={step.id}
                  onClick={() => toggleStep(step.id)}
                  className={`cursor-pointer rounded-2xl p-4 border transition-all duration-200 flex items-start gap-3 relative select-none ${
                    isDone
                      ? 'bg-emerald-950/20 border-emerald-500/40 ring-1 ring-emerald-500/20'
                      : 'bg-slate-950/60 border-slate-800 hover:border-amber-700/50'
                  }`}
                >
                  {/* Checkbox Icon */}
                  <button
                    type="button"
                    className="mt-0.5 flex-shrink-0 transition-transform active:scale-90"
                    aria-label={`Mark ${step.title} as ${isDone ? 'incomplete' : 'complete'}`}
                  >
                    {isDone ? (
                      <CheckCircle2 size={20} className="text-emerald-400 fill-emerald-950/80" />
                    ) : (
                      <Circle size={20} className="text-slate-600 hover:text-amber-500" />
                    )}
                  </button>

                  {/* Step Description */}
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      {step.stage && (
                        <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20 font-semibold">
                          {step.stage}
                        </span>
                      )}
                      {step.arabic && (
                        <span className="text-xs font-arabic text-amber-300/80" dir="rtl">
                          {step.arabic}
                        </span>
                      )}
                    </div>

                    <h5 className={`text-sm font-bold transition-colors ${
                      isDone ? 'text-slate-300 line-through decoration-emerald-500/50' : 'text-slate-100'
                    }`}>
                      {step.title}
                    </h5>

                    <p className="text-xs text-slate-400 leading-relaxed">
                      {step.subtitle}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Congratulatory Badge if Complete */}
          {progress.pct === 100 && (
            <div className="p-4 bg-emerald-950/30 border border-emerald-500/50 rounded-2xl flex items-center gap-3 text-xs text-emerald-300 animate-fadeIn">
              <Award size={20} className="text-emerald-400 flex-shrink-0" />
              <div>
                <span className="font-bold text-emerald-200 block text-sm">
                  Masha'Allah! All {progress.total} Steps Completed!
                </span>
                <p className="text-emerald-400/90 text-xs mt-0.5">
                  May Allah accept your Umrah and Hajj, forgive all your sins, and grant you a Hajj Mabrur and Sa'y Mashkur!
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
