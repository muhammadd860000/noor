import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { 
  Sparkles, 
  RotateCcw, 
  Check, 
  Copy, 
  Share2, 
  RefreshCw, 
  ChevronRight, 
  BookOpen,
  Award,
  Plus,
  Minus,
  Sun,
  Moon,
  CheckCircle2,
  Flame,
  Volume2,
  VolumeX
} from 'lucide-react';
import { 
  dailyAdhkarList, 
  getDailyDhikrForDate, 
  getCurrentTimeOfDay, 
  DailyDhikrItem 
} from '../data/dailyAdhkar';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';
import { 
  getTotalDhikrCompletedCount, 
  isDhikrMarkedDone, 
  markDailyDhikrAsDone, 
  unmarkDailyDhikrDone 
} from '../lib/dailyDhikrTracker';

export default function DailyDhikr() {
  const todayDateStr = useMemo(() => new Date().toISOString().split('T')[0], []);
  const todayFormatted = useMemo(() => {
    return new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'short',
      day: 'numeric'
    });
  }, []);

  // Time slot mode: 'morning' | 'evening'
  const defaultSlot = useMemo(() => getCurrentTimeOfDay(), []);
  const [timeSlot, setTimeSlot] = useState<'morning' | 'evening'>(defaultSlot);

  // Today's suggested dhikr based on time slot
  const defaultDhikr = useMemo(() => getDailyDhikrForDate(new Date(), timeSlot), [timeSlot]);

  // Currently viewed dhikr
  const [activeDhikrIndex, setActiveDhikrIndex] = useState(() => {
    const savedId = localStorage.getItem(`dailyDhikr_selectedId_${todayDateStr}`);
    if (savedId) {
      const idx = dailyAdhkarList.findIndex(d => d.id === savedId);
      if (idx !== -1) return idx;
    }
    const defIdx = dailyAdhkarList.findIndex(d => d.id === defaultDhikr.id);
    return defIdx !== -1 ? defIdx : 0;
  });

  const currentDhikr: DailyDhikrItem = dailyAdhkarList[activeDhikrIndex] || defaultDhikr;

  // Target count goal state
  const [goal, setGoal] = useState<number>(() => {
    const savedGoal = localStorage.getItem(`dailyDhikr_goal_${currentDhikr.id}`);
    return savedGoal ? parseInt(savedGoal, 10) : currentDhikr.targetCount;
  });

  // Current recitation count for today
  const [count, setCount] = useState<number>(() => {
    const savedCount = localStorage.getItem(`dailyDhikr_count_${todayDateStr}_${currentDhikr.id}`);
    return savedCount ? parseInt(savedCount, 10) : 0;
  });

  // Done status from local storage
  const [isDone, setIsDone] = useState<boolean>(() => {
    return isDhikrMarkedDone(todayDateStr, currentDhikr.id);
  });

  // Total completed sessions counter
  const [totalCompleted, setTotalCompleted] = useState<number>(getTotalDhikrCompletedCount);
  const [copied, setCopied] = useState(false);
  const [shared, setShared] = useState(false);
  const [showReflection, setShowReflection] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<0.8 | 1.0>(1.0);

  // Sync count, goal, and done state when active dhikr changes
  useEffect(() => {
    localStorage.setItem(`dailyDhikr_selectedId_${todayDateStr}`, currentDhikr.id);
    
    const savedGoal = localStorage.getItem(`dailyDhikr_goal_${currentDhikr.id}`);
    const activeGoal = savedGoal ? parseInt(savedGoal, 10) : currentDhikr.targetCount;
    setGoal(activeGoal);

    const savedCount = localStorage.getItem(`dailyDhikr_count_${todayDateStr}_${currentDhikr.id}`);
    const activeCount = savedCount ? parseInt(savedCount, 10) : 0;
    setCount(activeCount);

    const markedDone = isDhikrMarkedDone(todayDateStr, currentDhikr.id) || (activeCount >= activeGoal && activeGoal > 0);
    setIsDone(markedDone);
    setTotalCompleted(getTotalDhikrCompletedCount());
  }, [currentDhikr.id, currentDhikr.targetCount, todayDateStr]);

  // Persist count
  useEffect(() => {
    localStorage.setItem(`dailyDhikr_count_${todayDateStr}_${currentDhikr.id}`, count.toString());
  }, [count, currentDhikr.id, todayDateStr]);

  // Clean up speech synth on unmount
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Handle Mark as Done
  const handleMarkAsDone = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    triggerSuccessHaptic();

    const newTarget = goal || currentDhikr.targetCount;
    const res = markDailyDhikrAsDone(todayDateStr, currentDhikr.id, newTarget);
    setCount(newTarget);
    setIsDone(true);
    setTotalCompleted(res.totalCompleted);
  };

  // Handle increment
  const handleIncrement = useCallback((delta = 1) => {
    setCount(prev => {
      const next = Math.max(0, prev + delta);
      if (next >= goal && !isDone) {
        triggerSuccessHaptic();
        const res = markDailyDhikrAsDone(todayDateStr, currentDhikr.id, goal);
        setIsDone(true);
        setTotalCompleted(res.totalCompleted);
      } else {
        triggerHaptic(20);
      }
      return next;
    });
  }, [goal, isDone, currentDhikr.id, todayDateStr]);

  // Handle reset
  const handleReset = (e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic(30);
    setCount(0);
    setIsDone(false);
    unmarkDailyDhikrDone(todayDateStr, currentDhikr.id);
  };

  // Switch time slot
  const handleToggleTimeSlot = (slot: 'morning' | 'evening') => {
    triggerButtonClickHaptic();
    setTimeSlot(slot);
    const suggested = getDailyDhikrForDate(new Date(), slot);
    const idx = dailyAdhkarList.findIndex(d => d.id === suggested.id);
    if (idx !== -1) {
      setActiveDhikrIndex(idx);
    }
  };

  // Cycle to next dhikr
  const handleNextDhikr = () => {
    triggerButtonClickHaptic();
    setActiveDhikrIndex(prev => (prev + 1) % dailyAdhkarList.length);
  };

  // Handle copy text
  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    triggerButtonClickHaptic();
    const content = `✨ Daily Recommended Dhikr\n\n"${currentDhikr.arabic}"\n\n${currentDhikr.transliteration}\n"${currentDhikr.translation}"\n\n📖 Virtue: ${currentDhikr.virtue} (${currentDhikr.source})\n\nShared via Noor`;

    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(content);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Handle Web Share
  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    triggerButtonClickHaptic();

    const title = `Daily Recommended Dhikr: ${currentDhikr.title}`;
    const text = `✨ Daily Recommended Dhikr\n\n"${currentDhikr.arabic}"\n\n${currentDhikr.transliteration}\n"${currentDhikr.translation}"\n\n📖 Virtue: ${currentDhikr.virtue} (${currentDhikr.source})\n\nShared via Noor`;
    const url = window.location.origin;

    if (navigator.share) {
      try {
        await navigator.share({ title, text, url });
        triggerSuccessHaptic();
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          handleCopy(e);
        }
      }
    } else {
      handleCopy(e);
    }
  };

  // Recitation speech synth with Arabic pronunciation
  const handleToggleSpeech = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    triggerButtonClickHaptic();

    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(currentDhikr.arabic);
    utterance.lang = 'ar-SA';
    utterance.rate = playbackSpeed;

    const voices = window.speechSynthesis.getVoices();
    const arabicVoice = voices.find(v => v.lang.startsWith('ar') || v.name.toLowerCase().includes('arabic'));
    if (arabicVoice) {
      utterance.voice = arabicVoice;
    } else {
      utterance.text = currentDhikr.transliteration;
      utterance.lang = 'en-US';
      utterance.rate = playbackSpeed * 0.85;
    }

    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  // Progress calculations for the circular dial
  const progressPercent = Math.min(Math.round((count / (goal || 1)) * 100), 100);
  const strokeRadius = 40;
  const circumference = 2 * Math.PI * strokeRadius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <section 
      aria-label="Daily Dhikr & Progress Counter"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-700/50"
    >
      {/* Decorative ambient background */}
      <div 
        aria-hidden="true" 
        className="absolute -top-16 -right-16 w-44 h-44 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none"
      />

      {/* Header bar: Title, time of day tabs, and action controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-amber-900/20 gap-2.5">
        <div className="flex items-center gap-2">
          <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
            <Sparkles size={18} />
          </span>
          <div>
            <h2 className="text-sm font-semibold tracking-wide uppercase text-amber-500 flex items-center gap-1.5">
              Daily Recommended Dhikr · {timeSlot === 'morning' ? 'Morning Adhkar' : 'Evening Adhkar'}
            </h2>
            <p className="text-xs text-slate-400">
              {todayFormatted} · {currentDhikr.category}
            </p>
          </div>
        </div>

        {/* Time slot toggle & Action icons */}
        <div className="flex items-center gap-1.5 self-start sm:self-auto">
          {/* Morning / Evening Toggle */}
          <div className="flex bg-slate-950/80 border border-slate-800 rounded-xl p-0.5">
            <button
              type="button"
              onClick={() => handleToggleTimeSlot('morning')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                timeSlot === 'morning'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sun size={12} className="text-amber-400" />
              <span>Morning</span>
            </button>
            <button
              type="button"
              onClick={() => handleToggleTimeSlot('evening')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                timeSlot === 'evening'
                  ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Moon size={12} className="text-indigo-400" />
              <span>Evening</span>
            </button>
          </div>

          {/* Shuffle / Next Dhikr Switcher */}
          <button
            type="button"
            onClick={handleNextDhikr}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition-colors"
            title="Discover another Dhikr"
            aria-label="Discover another Dhikr"
          >
            <RefreshCw size={15} />
          </button>

          {/* Audio Pronunciation */}
          <button
            type="button"
            onClick={handleToggleSpeech}
            className={`p-2 rounded-lg transition-colors ${
              isPlayingAudio ? 'text-amber-400 bg-amber-500/20' : 'text-slate-400 hover:text-amber-400 hover:bg-slate-800/80'
            }`}
            title="Pronounce Dhikr"
            aria-label="Pronounce Dhikr"
          >
            {isPlayingAudio ? <VolumeX size={15} /> : <Volume2 size={15} />}
          </button>

          {/* Native Web Share API */}
          <button
            type="button"
            onClick={handleShare}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition-colors"
            title="Share Daily Dhikr"
            aria-label="Share Daily Dhikr"
          >
            {shared ? <Check size={15} className="text-emerald-400" /> : <Share2 size={15} />}
          </button>

          {/* Copy */}
          <button
            type="button"
            onClick={handleCopy}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition-colors"
            title="Copy Dhikr"
            aria-label="Copy Dhikr"
          >
            {copied ? <Check size={15} className="text-emerald-400" /> : <Copy size={15} />}
          </button>
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="pt-4 grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Column: Scripture, Transliteration, Translation, Reflection */}
        <div className="lg:col-span-7 space-y-3">
          {/* Time of Day Badge & Audio Pronunciation Control */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${
              timeSlot === 'morning'
                ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                : 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30'
            }`}>
              {timeSlot === 'morning' ? <Sun size={12} /> : <Moon size={12} />}
              {timeSlot === 'morning' ? 'Recommended Morning Adhkar / أذكار الصباح' : 'Recommended Evening Adhkar / أذكار المساء'}
            </span>

            {/* Pronunciation Listen Bar */}
            <div className="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1 rounded-xl border border-slate-800">
              <button
                type="button"
                onClick={handleToggleSpeech}
                className={`flex items-center gap-1.5 text-xs font-semibold px-2 py-0.5 rounded-lg transition ${
                  isPlayingAudio
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                    : 'text-amber-400 hover:text-amber-300'
                }`}
                title="Listen to Arabic Pronunciation"
              >
                {isPlayingAudio ? <VolumeX size={13} /> : <Volume2 size={13} />}
                <span>{isPlayingAudio ? 'Stop Audio' : 'Listen Pronunciation'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  triggerButtonClickHaptic();
                  setPlaybackSpeed(prev => prev === 1.0 ? 0.8 : 1.0);
                }}
                className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 hover:text-amber-400 border border-slate-800"
                title="Change recitation speed (Normal / Slow for learning)"
              >
                {playbackSpeed}x
              </button>
            </div>
          </div>

          {/* Arabic Calligraphy Scripture */}
          <p 
            dir="rtl" 
            lang="ar"
            className="text-xl sm:text-2xl lg:text-3xl text-amber-100/95 font-serif text-right leading-[2.2] select-text selection:bg-amber-500/30 py-1"
          >
            {currentDhikr.arabic}
          </p>

          {/* Transliteration */}
          <p className="text-xs sm:text-sm text-amber-400/90 font-medium tracking-wide">
            {currentDhikr.transliteration}
          </p>

          {/* Translation */}
          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed italic">
            "{currentDhikr.translation}"
          </p>

          {/* Metadata */}
          <div className="flex flex-wrap items-center gap-x-2 text-xs text-slate-400 pt-1">
            <span className="text-amber-500 font-medium">{currentDhikr.title}</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>{currentDhikr.source}</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Recommended: {currentDhikr.targetCount}×</span>
          </div>

          {/* Collapsible Spiritual Virtue */}
          <div className="pt-2">
            <button
              type="button"
              onClick={() => {
                triggerButtonClickHaptic();
                setShowReflection(!showReflection);
              }}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1.5 transition-colors"
            >
              <BookOpen size={14} />
              <span>{showReflection ? 'Hide Spiritual Reflection' : 'Why Recite This? (Spiritual Reflection & Virtue)'}</span>
            </button>

            {showReflection && (
              <div className="mt-3 p-4 bg-slate-950/80 border border-emerald-900/30 rounded-xl space-y-2.5 text-xs animate-fadeIn">
                <div>
                  <h4 className="font-semibold text-emerald-400 mb-1">Prophetic Virtue (Fadilah)</h4>
                  <p className="text-slate-300 leading-relaxed">
                    {currentDhikr.virtue}
                  </p>
                </div>
                {currentDhikr.reflectionQuestion && (
                  <div className="pt-2.5 border-t border-slate-800/80 text-amber-300/90">
                    <span className="font-semibold text-amber-400 not-italic">Daily Reflection: </span>
                    <span className="italic">{currentDhikr.reflectionQuestion}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Counter Dial + Step Controls + Progress Goal */}
        <div className="lg:col-span-5 bg-slate-950/60 border border-amber-900/30 rounded-2xl p-4 sm:p-5 flex flex-col justify-between space-y-4 shadow-inner">
          {/* Top of Card: Target Selection & Milestone Badge */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-slate-400">Target:</span>
              {[currentDhikr.targetCount, 33, 100]
                .filter((val, i, arr) => arr.indexOf(val) === i)
                .map((targetVal) => (
                  <button
                    key={targetVal}
                    type="button"
                    onClick={() => {
                      triggerButtonClickHaptic();
                      setGoal(targetVal);
                      localStorage.setItem(`dailyDhikr_goal_${currentDhikr.id}`, targetVal.toString());
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                      goal === targetVal
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40 font-semibold'
                        : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-transparent'
                    }`}
                  >
                    {targetVal}×
                  </button>
                ))}
            </div>

            {isDone ? (
              <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-400 bg-emerald-950/80 border border-emerald-800/50 px-2 py-0.5 rounded-full animate-fadeIn">
                <CheckCircle2 size={13} /> Completed
              </span>
            ) : (
              <span className="text-[11px] font-mono text-amber-400">
                {progressPercent}%
              </span>
            )}
          </div>

          {/* Central Tappable Tasbeeh Counter Circle */}
          <div className="flex flex-col items-center gap-3">
            <div 
              role="button"
              tabIndex={0}
              onClick={() => handleIncrement(1)}
              onKeyDown={(e) => {
                if (e.key === ' ' || e.key === 'Enter') {
                  e.preventDefault();
                  handleIncrement(1);
                }
              }}
              aria-label={`Recite Dhikr. Current count ${count} of ${goal}. Tap to count.`}
              className="group/counter relative mx-auto w-36 h-36 sm:w-40 sm:h-40 flex items-center justify-center cursor-pointer select-none rounded-full transition-transform duration-150 active:scale-95 hover:shadow-lg hover:shadow-amber-500/10 focus:outline-none focus:ring-2 focus:ring-amber-500/50"
            >
              {/* SVG Circular Progress Dial */}
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 96 96">
                <circle
                  cx="48"
                  cy="48"
                  r={strokeRadius}
                  fill="transparent"
                  stroke="currentColor"
                  strokeWidth="6"
                  className="text-slate-800/80"
                />
                <circle
                  cx="48"
                  cy="48"
                  r={strokeRadius}
                  fill="transparent"
                  stroke="currentColor"
                  strokeWidth="6"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  className={`transition-all duration-300 ${
                    isDone ? 'text-emerald-400' : 'text-amber-500'
                  }`}
                />
              </svg>

              {/* Centered Count Display */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="text-3xl sm:text-4xl font-mono font-bold text-slate-100 tracking-tight group-hover/counter:text-amber-400 transition-colors">
                  {count}
                </span>
                <span className="text-xs font-mono text-slate-400">
                  / {goal}
                </span>
                <span className="text-[10px] text-amber-500/80 mt-1 flex items-center gap-0.5">
                  <Plus size={10} /> Tap to Recite
                </span>
              </div>
            </div>

            {/* Quick Step Increment/Decrement buttons */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleIncrement(-1)}
                disabled={count === 0}
                className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition disabled:opacity-40"
                title="Subtract 1"
                aria-label="Subtract 1"
              >
                <Minus size={14} />
              </button>
              <button
                type="button"
                onClick={() => handleIncrement(1)}
                className="px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 hover:bg-amber-500/30 text-xs font-semibold transition"
                title="Add 1"
              >
                +1
              </button>
              <button
                type="button"
                onClick={() => handleIncrement(10)}
                className="px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 hover:bg-amber-500/30 text-xs font-semibold transition"
                title="Add 10"
              >
                +10
              </button>
            </div>
          </div>

          {/* Mark as Done / Completed Button */}
          <div className="space-y-2">
            <button
              type="button"
              onClick={handleMarkAsDone}
              className={`w-full flex items-center justify-center gap-2 p-2.5 rounded-xl font-bold text-xs transition active:scale-95 shadow-md ${
                isDone
                  ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-600/30'
                  : 'bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-amber-500/20'
              }`}
            >
              {isDone ? (
                <>
                  <CheckCircle2 size={16} className="text-emerald-400" />
                  <span>Marked as Done / مکمل ہو گیا</span>
                </>
              ) : (
                <>
                  <Check size={16} />
                  <span>Mark as Done ({goal}×)</span>
                </>
              )}
            </button>

            {/* Total Completed Counter */}
            <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 pt-1">
              <span>Total Dhikr Completed:</span>
              <span className="font-mono font-bold text-amber-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                {totalCompleted} {totalCompleted === 1 ? 'time' : 'times'}
              </span>
            </div>
          </div>

          {/* Footer of Card: Reset button and link to Full Tasbeeh */}
          <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 text-xs">
            {count > 0 || isDone ? (
              <button
                type="button"
                onClick={handleReset}
                className="text-slate-400 hover:text-rose-400 transition-colors flex items-center gap-1 py-1"
                title="Reset counter"
              >
                <RotateCcw size={13} />
                <span>Reset</span>
              </button>
            ) : (
              <span className="text-slate-500 text-[11px]">Daily spiritual habit</span>
            )}

            <Link
              to="/tasbeeh"
              className="flex items-center gap-1 text-slate-400 hover:text-amber-400 transition-colors font-medium group/link py-1"
            >
              <span>Full Tasbeeh</span>
              <ChevronRight size={14} className="transition-transform group-hover/link:translate-x-0.5" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
