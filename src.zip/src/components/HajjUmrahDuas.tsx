import React, { useState, useEffect } from 'react';
import { Bookmark, Sparkles, Copy, Check, BookOpen, Volume2, Heart } from 'lucide-react';
import { triggerHaptic, triggerSuccessHaptic } from '../lib/haptics';

export interface HajjDua {
  id: string;
  title: string;
  arabic: string;
  transliteration: string;
  translation: string;
  ritualContext: string;
  reference: string;
}

export const HAJJ_UMRAH_DUAS: HajjDua[] = [
  {
    id: 'hdua-1',
    title: 'The Sacred Talbiyah',
    arabic: 'لَبَّيْكَ اللَّهُمَّ لَبَّيْكَ، لَبَّيْكَ لاَ شَرِيكَ لَكَ لَبَّيْكَ، إِنَّ الْحَمْدَ وَالنِّعْمَةَ لَكَ وَالْمُلْكَ، لاَ شَرِيكَ لَكَ',
    transliteration: 'Labbayka Allahumma Labbayk, Labbayka la shareeka laka Labbayk, innal-hamda wan-ni’mata laka wal-mulk, la shareeka lak.',
    translation: 'Here I am, O Allah, here I am. Here I am, You have no partner, here I am. Verily, all praise and blessings are Yours, and all sovereignty. You have no partner.',
    ritualContext: 'Chanted constantly from the moment of Ihram until reaching Makkah / Jamarat al-Aqaba.',
    reference: 'Sahih al-Bukhari & Muslim'
  },
  {
    id: 'hdua-2',
    title: 'Entering Masjid al-Haram',
    arabic: 'بِسْمِ اللَّهِ، وَالصَّلَاةُ وَالسَّلَامُ عَلَى رَسُولِ اللَّهِ، اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ',
    transliteration: 'Bismillahi, was-salatu was-salamu ‘ala Rasoolillah, Allahumma aftah lee abwaba rahmatik.',
    translation: 'In the name of Allah, and prayers and peace be upon the Messenger of Allah. O Allah, open for me the doors of Your mercy.',
    ritualContext: 'Recited with the right foot forward when stepping into the Holy Mosque.',
    reference: 'Sunan Ibn Majah'
  },
  {
    id: 'hdua-3',
    title: 'Upon Seeing the Holy Kaaba',
    arabic: 'اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، فَحَيِّن ربنا بِالسَّلَامِ',
    transliteration: 'Allahumma Antas-Salam wa minkas-salam, fa hayyina Rabbana bis-salam.',
    translation: 'O Allah, You are Peace and from You is peace. Grant us life, our Lord, in peace.',
    ritualContext: 'Recited upon first catching sight of the Holy Kaaba before commencing Tawaf.',
    reference: 'Sunan al-Bayhaqi'
  },
  {
    id: 'hdua-4',
    title: 'Between Yemeni Corner & Black Stone',
    arabic: 'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ',
    transliteration: 'Rabbana atina fid-dunya hasanatan wa fil-akhirati hasanatan wa qina \'adhaban-nar.',
    translation: 'Our Lord, give us in this world [that which is] good and in the Hereafter [that which is] good and protect us from the punishment of the Fire.',
    ritualContext: 'Recited during every circuit of Tawaf between the Yemeni Corner and the Black Stone.',
    reference: 'Surah Al-Baqarah 2:201 (Sunan Abu Dawud)'
  },
  {
    id: 'hdua-5',
    title: 'At Mount Safa & Marwa',
    arabic: 'إِنَّ الصَّفَا وَالْمَرْوَةَ مِنْ شَعَائِرِ اللَّهِ ... أَبْدَأُ بِمَا بَدَأَ اللَّهُ بِهِ',
    transliteration: 'Innas-Safa wal-Marwata min sha\'airillah... Abda\'u bima bada\'allahu bih.',
    translation: 'Indeed, Safa and Marwa are among the symbols of Allah... I begin with what Allah began with.',
    ritualContext: 'Recited when standing facing the Kaaba upon ascending Mount Safa and Marwa.',
    reference: 'Sahih Muslim'
  },
  {
    id: 'hdua-6',
    title: 'Supreme Supplication on Arafah',
    arabic: 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
    transliteration: 'La ilaha illallahu wahdahu la shareeka lah, lahul-mulku walahul-hamdu wa huwa ‘ala kulli shay\'in qadeer.',
    translation: 'There is no god but Allah alone, Who has no partner. His is the dominion and His is the praise, and He is able to do all things.',
    ritualContext: 'The greatest du\'a of the Day of Arafah, recited repeatedly from noon until sunset.',
    reference: 'Sunan al-Tirmidhi'
  },
  {
    id: 'hdua-7',
    title: 'When Throwing Jamarat Pebbles',
    arabic: 'بِسْمِ اللَّهِ، وَاللَّهُ أَكْبَرُ رَغْمًا لِلشَّيْطَانِ وَحِزْبِهِ',
    transliteration: 'Bismillahi, wallahu Akbar, raghman lish-shaytani wa hizbih.',
    translation: 'In the name of Allah, and Allah is the Greatest, in defiance of Satan and his party.',
    ritualContext: 'Recited as each individual pebble is cast at the Jamarat pillars.',
    reference: 'Sahih Muslim'
  },
  {
    id: 'hdua-8',
    title: 'Drinking Zamzam Water',
    arabic: 'اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا وَاسِعًا، وَشِفَاءً مِنْ كُلِّ دَاءٍ',
    transliteration: 'Allahumma inni as\'aluka ‘ilman nafi\'an, wa rizqan wasi\'an, wa shifa\'an min kulli da\'.',
    translation: 'O Allah, I ask You for beneficial knowledge, abundant sustenance, and a cure from every disease.',
    ritualContext: 'Recited before drinking blessed Zamzam water with sincere intention.',
    reference: 'Mustadrak al-Hakim'
  }
];

const STORAGE_KEY = 'noor_hajj_bookmarked_duas';

export default function HajjUmrahDuas() {
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : ['hdua-1', 'hdua-4', 'hdua-6'];
    } catch {
      return ['hdua-1', 'hdua-4', 'hdua-6'];
    }
  });

  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [filterMode, setFilterMode] = useState<'all' | 'bookmarks'>('all');

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(bookmarkedIds));
    } catch {}
  }, [bookmarkedIds]);

  const toggleBookmark = (id: string) => {
    triggerHaptic(15);
    setBookmarkedIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleCopy = async (dua: HajjDua) => {
    triggerHaptic(10);
    const text = `${dua.title}\n\n${dua.arabic}\n\nTransliteration: ${dua.transliteration}\nTranslation: ${dua.translation}\nContext: ${dua.ritualContext}\nReference: ${dua.reference}`;
    try {
      await navigator.clipboard.writeText(text);
      triggerSuccessHaptic();
      setCopiedId(dua.id);
      setTimeout(() => setCopiedId(null), 2500);
    } catch (e) {
      console.warn(e);
    }
  };

  const displayedDuas = filterMode === 'bookmarks' 
    ? HAJJ_UMRAH_DUAS.filter(d => bookmarkedIds.includes(d.id))
    : HAJJ_UMRAH_DUAS;

  return (
    <div className="space-y-4">
      {/* Sub-header & Filter Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-amber-900/30 p-4 rounded-2xl">
        <div>
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <Sparkles size={16} className="text-amber-500" />
            <span>Essential Hajj & Umrah Duas Library</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Authentic supplications for every ritual step. Bookmark your favorites for quick offline access.
          </p>
        </div>

        <div className="flex bg-slate-950 border border-slate-800 p-1 rounded-xl text-xs self-start sm:self-auto">
          <button
            type="button"
            onClick={() => {
              triggerHaptic(15);
              setFilterMode('all');
            }}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              filterMode === 'all'
                ? 'bg-amber-600 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Duas ({HAJJ_UMRAH_DUAS.length})
          </button>
          <button
            type="button"
            onClick={() => {
              triggerHaptic(15);
              setFilterMode('bookmarks');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
              filterMode === 'bookmarks'
                ? 'bg-amber-600 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bookmark size={13} className={filterMode === 'bookmarks' ? 'fill-slate-950' : ''} />
            <span>Bookmarked ({bookmarkedIds.length})</span>
          </button>
        </div>
      </div>

      {/* Duas List */}
      <div className="space-y-3.5">
        {displayedDuas.length === 0 ? (
          <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-2">
            <Bookmark size={28} className="mx-auto text-slate-600" />
            <h4 className="text-sm font-bold text-slate-300">No bookmarked Duas yet</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Click the bookmark icon on any essential pilgrimage Dua to save it here for quick access during Tawaf, Sa'i, or Arafah.
            </p>
          </div>
        ) : (
          displayedDuas.map((dua) => {
            const isBookmarked = bookmarkedIds.includes(dua.id);
            const isCopied = copiedId === dua.id;

            return (
              <div 
                key={dua.id}
                className="bg-slate-900 border border-amber-900/30 hover:border-amber-700/50 rounded-2xl p-4 sm:p-5 transition-all space-y-3.5 shadow-md"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/20 font-semibold">
                      {dua.reference}
                    </span>
                    <h4 className="text-base font-bold font-serif text-slate-100 mt-1.5">
                      {dua.title}
                    </h4>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Copy button */}
                    <button
                      type="button"
                      onClick={() => handleCopy(dua)}
                      title="Copy Dua"
                      aria-label="Copy Dua"
                      className="p-2 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-400 hover:text-slate-200 transition"
                    >
                      {isCopied ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
                    </button>

                    {/* Bookmark Toggle */}
                    <button
                      type="button"
                      onClick={() => toggleBookmark(dua.id)}
                      title={isBookmarked ? 'Remove bookmark' : 'Bookmark Dua'}
                      aria-label="Bookmark Dua"
                      className={`p-2 rounded-xl border transition ${
                        isBookmarked
                          ? 'bg-amber-500/20 border-amber-500/40 text-amber-400'
                          : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-300'
                      }`}
                    >
                      <Bookmark size={16} className={isBookmarked ? 'fill-amber-400' : ''} />
                    </button>
                  </div>
                </div>

                {/* Arabic Text */}
                <div className="p-4 bg-slate-950/80 border border-amber-900/20 rounded-xl text-right">
                  <p className="text-lg sm:text-xl font-serif text-amber-200 leading-loose select-text" dir="rtl">
                    {dua.arabic}
                  </p>
                </div>

                {/* Transliteration & Translation */}
                <div className="space-y-1.5 text-xs sm:text-sm">
                  <p className="text-amber-400/90 font-mono italic">
                    "{dua.transliteration}"
                  </p>
                  <p className="text-slate-300 leading-relaxed">
                    {dua.translation}
                  </p>
                </div>

                {/* Ritual Context Footer */}
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <BookOpen size={13} className="text-amber-500" />
                    <strong>Ritual Context:</strong> {dua.ritualContext}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
