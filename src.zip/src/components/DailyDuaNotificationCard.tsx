import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Bell, 
  Clock, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Check, 
  Send, 
  BookOpen, 
  ShieldCheck, 
  AlertCircle 
} from 'lucide-react';
import { 
  getDailyDuaPreferences, 
  saveDailyDuaPreferences, 
  getMotivationalDuaForDate, 
  sendTestDailyDuaNotification,
  DailyDuaPreferences 
} from '../lib/dailyDuaScheduler';
import { 
  getNotificationPermission, 
  requestNotificationPermission, 
  isNotificationSupported,
  NotificationPermissionState 
} from '../lib/notifications';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';
import { DUA_CATEGORIES } from '../data/duas';

const TIME_PRESETS = [
  { label: '07:30 AM', value: '07:30', desc: 'Morning Start' },
  { label: '09:00 AM', value: '09:00', desc: 'Default' },
  { label: '01:30 PM', value: '13:30', desc: 'Midday Solace' },
  { label: '08:00 PM', value: '20:00', desc: 'Evening Peace' },
  { label: '10:00 PM', value: '22:00', desc: 'Night Reflection' }
];

export default function DailyDuaNotificationCard() {
  const [prefs, setPrefs] = useState<DailyDuaPreferences>(() => getDailyDuaPreferences());
  const [permission, setPermission] = useState<NotificationPermissionState>(getNotificationPermission);
  const [testSent, setTestSent] = useState(false);
  const [feedbackNotice, setFeedbackNotice] = useState<string | null>(null);

  // Today's preview Dua
  const previewDua = getMotivationalDuaForDate(new Date(), prefs.category);

  useEffect(() => {
    const handleUpdate = (e: Event) => {
      const customEvent = e as CustomEvent<DailyDuaPreferences>;
      if (customEvent.detail) {
        setPrefs(customEvent.detail);
      } else {
        setPrefs(getDailyDuaPreferences());
      }
    };

    const handlePerm = () => {
      setPermission(getNotificationPermission());
    };

    window.addEventListener('daily-dua-notifications-updated', handleUpdate);
    window.addEventListener('notification-permission-changed', handlePerm);
    return () => {
      window.removeEventListener('daily-dua-notifications-updated', handleUpdate);
      window.removeEventListener('notification-permission-changed', handlePerm);
    };
  }, []);

  const handleToggleEnabled = async () => {
    triggerButtonClickHaptic();
    const nextState = !prefs.enabled;

    if (nextState && permission !== 'granted') {
      const granted = await requestNotificationPermission();
      setPermission(getNotificationPermission());
      if (!granted) {
        setFeedbackNotice('Please allow browser notifications to receive daily Duas.');
        setTimeout(() => setFeedbackNotice(null), 5000);
        return;
      }
    }

    const updated = { ...prefs, enabled: nextState };
    setPrefs(updated);
    saveDailyDuaPreferences(updated);

    if (nextState) {
      setFeedbackNotice(`Daily motivational Dua scheduled for ${formatTimeDisplay(updated.time)}`);
      setTimeout(() => setFeedbackNotice(null), 4000);
    }
  };

  const handleTimeChange = (newTime: string) => {
    triggerButtonClickHaptic();
    const updated = { ...prefs, time: newTime };
    setPrefs(updated);
    saveDailyDuaPreferences(updated);
    setFeedbackNotice(`Alert time updated to ${formatTimeDisplay(newTime)}`);
    setTimeout(() => setFeedbackNotice(null), 3000);
  };

  const handleCategoryChange = (newCat: string) => {
    triggerButtonClickHaptic();
    const updated = { ...prefs, category: newCat };
    setPrefs(updated);
    saveDailyDuaPreferences(updated);
  };

  const handleSoundToggle = () => {
    triggerButtonClickHaptic();
    const updated = { ...prefs, soundEnabled: !prefs.soundEnabled };
    setPrefs(updated);
    saveDailyDuaPreferences(updated);
  };

  const handleSendTest = async () => {
    triggerButtonClickHaptic();
    const sent = await sendTestDailyDuaNotification();
    setPermission(getNotificationPermission());
    if (sent) {
      triggerSuccessHaptic();
      setTestSent(true);
      setFeedbackNotice('Sample motivational Dua notification sent! Check your notification center.');
      setTimeout(() => {
        setTestSent(false);
        setFeedbackNotice(null), 4500;
      }, 4500);
    } else {
      setFeedbackNotice('Unable to send sample notification. Please verify browser notification permissions.');
      setTimeout(() => setFeedbackNotice(null), 5000);
    }
  };

  function formatTimeDisplay(time24: string): string {
    const parts = time24.split(':').map(Number);
    if (parts.length < 2 || isNaN(parts[0]) || isNaN(parts[1])) return time24;
    const hours = parts[0];
    const mins = parts[1].toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const displayHours = hours % 12 || 12;
    return `${displayHours}:${mins} ${ampm}`;
  }

  const isSupported = isNotificationSupported();

  return (
    <section 
      aria-label="Daily Motivational Dua Notification"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 shadow-xl space-y-4 relative overflow-hidden"
    >
      {/* Decorative ambient background glow */}
      <div 
        aria-hidden="true" 
        className="absolute -top-12 -right-12 w-36 h-36 rounded-full bg-rose-500/5 blur-3xl pointer-events-none"
      />

      {/* Header & Main Toggle Switch */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <span className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Heart size={20} className="text-amber-400" />
          </span>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-amber-500 flex items-center gap-2">
              <span>Daily Motivational Dua Alert</span>
              {prefs.enabled && permission === 'granted' && (
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400" title="Active" />
              )}
            </h3>
            <p className="text-xs text-slate-400">
              Receive a daily Quranic / Masnoon Dua reminder at your chosen time
            </p>
          </div>
        </div>

        {/* Master Toggle Switch */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            role="switch"
            aria-checked={prefs.enabled}
            onClick={handleToggleEnabled}
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
              prefs.enabled ? 'bg-amber-600' : 'bg-slate-800'
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-slate-950 shadow ring-0 transition duration-200 ease-in-out ${
                prefs.enabled ? 'translate-x-5 bg-white' : 'translate-x-0 bg-slate-400'
              }`}
            />
          </button>
          <span className="text-xs font-semibold text-slate-300">
            {prefs.enabled ? 'Enabled' : 'Disabled'}
          </span>
        </div>
      </div>

      {/* Status Feedback Notice */}
      {feedbackNotice && (
        <div className="p-3 bg-amber-950/40 border border-amber-500/30 rounded-xl text-xs text-amber-300 flex items-center justify-between animate-fadeIn">
          <span className="flex items-center gap-2">
            <Sparkles size={14} className="text-amber-400" />
            {feedbackNotice}
          </span>
          <button 
            type="button" 
            onClick={() => setFeedbackNotice(null)} 
            className="text-slate-400 hover:text-slate-200 ml-2"
          >
            ×
          </button>
        </div>
      )}

      {/* Settings Options (Visible when enabled) */}
      {prefs.enabled && (
        <div className="space-y-4 pt-1">
          {/* Time Picker & Quick Presets */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="font-semibold flex items-center gap-1.5">
                <Clock size={14} className="text-amber-500" />
                Scheduled Reminder Time:
              </span>
              <span className="font-mono text-amber-400 font-bold">
                {formatTimeDisplay(prefs.time)}
              </span>
            </div>

            {/* Direct Time Input */}
            <div className="flex items-center gap-3">
              <input
                type="time"
                value={prefs.time}
                onChange={(e) => handleTimeChange(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-200 font-mono text-sm px-3 py-2 rounded-xl focus:border-amber-500 outline-none w-36"
              />
              <span className="text-xs text-slate-500">
                Custom time (24h format)
              </span>
            </div>

            {/* Quick Presets Pills */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {TIME_PRESETS.map((preset) => (
                <button
                  key={preset.value}
                  type="button"
                  onClick={() => handleTimeChange(preset.value)}
                  className={`px-2.5 py-1 rounded-lg text-xs transition flex items-center gap-1 ${
                    prefs.time === preset.value
                      ? 'bg-amber-600 text-slate-950 font-bold shadow-sm'
                      : 'bg-slate-950/80 hover:bg-slate-850 text-slate-300 border border-slate-800'
                  }`}
                >
                  <span>{preset.label}</span>
                  <span className="text-[10px] opacity-75">({preset.desc})</span>
                </button>
              ))}
            </div>
          </div>

          {/* Dua Theme / Category Selection */}
          <div className="space-y-1.5 pt-2 border-t border-slate-800">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <BookOpen size={14} className="text-amber-500" />
              <span>Dua Theme Category:</span>
            </label>
            <div className="flex flex-wrap gap-1.5 text-xs">
              <button
                type="button"
                onClick={() => handleCategoryChange('all')}
                className={`px-3 py-1 rounded-lg transition ${
                  prefs.category === 'all'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                    : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                All Categories (Rotated Daily)
              </button>
              {DUA_CATEGORIES.filter(c => !['all', 'favorites'].includes(c.id)).map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => handleCategoryChange(cat.id)}
                  className={`px-2.5 py-1 rounded-lg transition ${
                    prefs.category === cat.id
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                      : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* Audio Alert Toggle & Sample Test Button */}
          <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {/* Sound Toggle */}
            <button
              type="button"
              onClick={handleSoundToggle}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium border transition ${
                prefs.soundEnabled 
                  ? 'bg-slate-950 border-slate-800 text-slate-200 hover:border-amber-500/30' 
                  : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              {prefs.soundEnabled ? <Volume2 size={14} className="text-amber-400" /> : <VolumeX size={14} />}
              <span>{prefs.soundEnabled ? 'Notification Sound Enabled' : 'Silent Notification'}</span>
            </button>

            {/* Test Sample Notification */}
            <button
              type="button"
              onClick={handleSendTest}
              disabled={testSent}
              className="flex items-center justify-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-400 text-xs font-semibold transition active:scale-95 self-start sm:self-auto"
            >
              {testSent ? <Check size={14} className="text-emerald-400" /> : <Send size={14} />}
              <span>{testSent ? 'Sample Sent!' : 'Send Sample Notification'}</span>
            </button>
          </div>

          {/* Today's Dua Preview Card */}
          <div className="mt-3 p-3.5 bg-slate-950/70 border border-amber-900/20 rounded-xl space-y-1.5">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-amber-500 font-semibold uppercase tracking-wider flex items-center gap-1">
                <Sparkles size={12} /> Today's Scheduled Dua:
              </span>
              <span className="text-slate-500 font-mono">{previewDua.reference}</span>
            </div>
            <h4 className="text-xs font-bold text-slate-200">{previewDua.title}</h4>
            <p dir="rtl" className="text-xs text-amber-200/90 font-serif leading-relaxed text-right">
              {previewDua.arabic}
            </p>
            <p className="text-xs text-slate-300 italic leading-relaxed">
              "{previewDua.meaning}"
            </p>
          </div>
        </div>
      )}
    </section>
  );
}
