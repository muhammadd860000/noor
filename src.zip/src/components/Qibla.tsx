
import React, { useState, useEffect, useRef } from 'react';
import { Compass, AlertCircle } from 'lucide-react';

// Kaaba coordinates
const KAABA_LAT = 21.4225;
const KAABA_LNG = 39.8262;

export default function Qibla() {
  const [isStarted, setIsStarted] = useState(false);
  const [direction, setDirection] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [qiblaBearing, setQiblaBearing] = useState<number | null>(null);

  const startCompass = async () => {
    try {
      // 1. Request Geolocation
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject);
      });

      const userLat = position.coords.latitude;
      const userLng = position.coords.longitude;
      
      // Calculate Qibla Bearing
      const lat1 = (userLat * Math.PI) / 180;
      const lat2 = (KAABA_LAT * Math.PI) / 180;
      const deltaLng = ((KAABA_LNG - userLng) * Math.PI) / 180;
      
      const y = Math.sin(deltaLng) * Math.cos(lat2);
      const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(deltaLng);
      const bearing = (Math.atan2(y, x) * 180) / Math.PI;
      setQiblaBearing((bearing + 360) % 360);

      // 2. Request Orientation Permission (iOS 13+)
      if (typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
        const permission = await (DeviceOrientationEvent as any).requestPermission();
        if (permission !== 'granted') throw new Error("Orientation permission denied.");
      }

      window.addEventListener('deviceorientation', (event: any) => {
        // webkitCompassHeading is the compass heading in degrees, better than alpha on iOS
        const heading = event.webkitCompassHeading || event.alpha;
        if (heading !== null) setDirection(heading);
      });

      setIsStarted(true);
    } catch (err: any) {
      setError(err.message || "Failed to initialize compass.");
    }
  };

  return (
    <div className="space-y-6">
      <header>
        <h2 className="text-2xl text-amber-500 font-serif mb-6">Qibla Direction</h2>
      </header>

      {error ? (
        <div className="bg-slate-900 border border-red-900/30 rounded-2xl p-6 text-center text-red-500 flex items-center gap-3">
          <AlertCircle />
          <p>{error}</p>
        </div>
      ) : !isStarted ? (
        <button 
            onClick={startCompass}
            className="w-full bg-amber-600 text-white font-bold p-6 rounded-2xl text-center"
        >
            Start Qibla Compass
        </button>
      ) : (
        <div className="bg-slate-900 border border-amber-900/30 rounded-3xl p-8 flex flex-col items-center shadow-2xl relative">
          <div 
            className="w-64 h-64 border-4 border-amber-900/30 rounded-full flex items-center justify-center mb-6 transition-transform duration-100 relative"
            style={{ transform: `rotate(${direction ? -direction + (qiblaBearing || 0) : 0}deg)` }}
          >
            <Compass size={120} className="text-amber-500/50" />
            <div className="absolute top-2 text-amber-600 font-bold text-lg">N</div>
            <div className="absolute bottom-2 text-amber-600 font-bold text-lg">S</div>
            <div className="absolute left-2 text-amber-600 font-bold text-lg">W</div>
            <div className="absolute right-2 text-amber-600 font-bold text-lg">E</div>
            <div className="absolute top-1/2 w-1 h-32 bg-amber-500 rounded-full" />
          </div>
          <p className="text-slate-200">
            {qiblaBearing ? `Kaaba is at ${Math.round(qiblaBearing)}°` : 'Calculating direction...'}
          </p>
        </div>
      )}
    </div>
  );
}
