
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft, Settings, Play, Heart, Share, Book, Eye, EyeOff, Maximize2, Minimize2, Headphones } from 'lucide-react';
import { surahs } from '../data/surahs';
import { useAudio } from '../context/AudioContext.tsx';
import { triggerHaptic } from '../lib/haptics';
import { saveToDB, getFromDB, deleteFromDB } from '../lib/db';

interface Ayah {
  numberInSurah: number;
  globalNumber: number;
  text: string;
  translation: string;
}

export default function QuranReader() {
  console.log('[QuranReader Debug] QuranReader component loading...', window.location.pathname);
  const { surah, para } = useParams<{ surah: string; para: string }>();
  const [verses, setVerses] = useState<Ayah[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredVerses = useMemo(() => {
    return verses.filter(v => 
      v.text.includes(searchTerm) || v.translation.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [verses, searchTerm]);

  const filteredVersesRef = useRef(filteredVerses);
  filteredVersesRef.current = filteredVerses;

  const [tafsirMap, setTafsirMap] = useState<Record<number, string>>({});
  const [selectedTafsir, setSelectedTafsir] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showTranslation, setShowTranslation] = useState(true);
  const [distractionFree, setDistractionFree] = useState(false);
  const [fontSize, setFontSize] = useState(20);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isFavorite, setIsFavorite] = useState(false);
  const { setCurrentUrl, currentUrl, isPlaying, setIsPlaying, playTrack, audioRef, setOnNext, setOnPrevious } = useAudio();
  const [listenedAyahs, setListenedAyahs] = useState<number[]>([]);
  const [bookmarkedAyahs, setBookmarkedAyahs] = useState<number[]>([]);
  const [highlightedAyahs, setHighlightedAyahs] = useState<number[]>([]);
  const [currentlyPlayingGlobalNumber, setCurrentlyPlayingGlobalNumber] = useState<number | null>(null);
  const [isReciterMode, setIsReciterMode] = useState<boolean>(() => {
    return localStorage.getItem('isReciterMode') === 'true';
  });

  const ayahRefs = useRef<Record<number, HTMLDivElement | null>>({});

  const toggleReciterMode = () => {
    triggerHaptic(15);
    setIsReciterMode(prev => {
      const next = !prev;
      localStorage.setItem('isReciterMode', String(next));
      return next;
    });
  };

  // Auto-scroll active verse into center view in Reciter Mode
  useEffect(() => {
    if (isReciterMode && currentlyPlayingGlobalNumber && ayahRefs.current[currentlyPlayingGlobalNumber]) {
      ayahRefs.current[currentlyPlayingGlobalNumber]?.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });
    }
  }, [currentlyPlayingGlobalNumber, isReciterMode]);

  const surahInfo = surahs.find(s => s.id === parseInt(surah || '1', 10));

  useEffect(() => {
      if (isPlaying && currentUrl) {
          const match = currentUrl.match(/\/(\d+)\.mp3$/) || currentUrl.match(/\/(\d+)$/);
          if (match) {
              setCurrentlyPlayingGlobalNumber(parseInt(match[1], 10));
          }
      } else {
          setCurrentlyPlayingGlobalNumber(null);
      }
  }, [currentUrl, isPlaying]);

  useEffect(() => {
      const handleScroll = () => {
          const totalScroll = document.documentElement.scrollTop;
          const windowHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
          const scroll = windowHeight > 0 ? (totalScroll / windowHeight) : 0;
          setScrollProgress(scroll * 100);
      };
      window.addEventListener('scroll', handleScroll);
      return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const favorites = JSON.parse(localStorage.getItem('quranFavorites') || '[]');
    setIsFavorite(favorites.some((f: any) => f.id === surahInfo?.id));
    
    // Load listened ayahs for this surah/para
    const id = surah || `para-${para}`;
    const allListened = JSON.parse(localStorage.getItem('listenedAyahs') || '{}');
    setListenedAyahs(allListened[id] || []);

    // Load bookmarked ayahs
    setBookmarkedAyahs(JSON.parse(localStorage.getItem('bookmarkedAyahs') || '[]'));
    setHighlightedAyahs(JSON.parse(localStorage.getItem('highlightedAyahs') || '[]'));

    // Save last read
    if (surahInfo) {
      localStorage.setItem('lastReadSurah', JSON.stringify(surahInfo));
      
      const recentRead = JSON.parse(localStorage.getItem('recentRead') || '[]');
      const updatedRecent = [
          surahInfo,
          ...recentRead.filter((s: any) => s.id !== surahInfo.id)
      ].slice(0, 5);
      localStorage.setItem('recentRead', JSON.stringify(updatedRecent));
    }
  }, [surah, para, surahInfo]);

  const currentUrlRef = useRef(currentUrl);
  currentUrlRef.current = currentUrl;

  const playAyah = useCallback((globalNumber: number, numberInSurah: number) => {
    const audioUrl = `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${globalNumber}.mp3`;
    console.log(`[QuranAudio Debug]
Surah: ${surah || 'Para ' + para}
Ayah: ${numberInSurah}
Global Ayah: ${globalNumber}
Audio URL: ${audioUrl}
Audio source: cdn.islamic.network`);
    playTrack(audioUrl);
  }, [surah, para, playTrack]);

  const playAyahRef = useRef(playAyah);
  playAyahRef.current = playAyah;

  const handleNextAyah = useCallback(() => {
    const list = filteredVersesRef.current;
    const url = currentUrlRef.current;
    const currentIndex = list.findIndex(v => `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${v.globalNumber}.mp3` === url);
    if (currentIndex !== -1 && currentIndex < list.length - 1) {
      const nextAyah = list[currentIndex + 1];
      playAyahRef.current(nextAyah.globalNumber, nextAyah.numberInSurah);
    }
  }, []);

  const handlePreviousAyah = useCallback(() => {
    const list = filteredVersesRef.current;
    const url = currentUrlRef.current;
    const currentIndex = list.findIndex(v => `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${v.globalNumber}.mp3` === url);
    if (currentIndex > 0) {
      const prevAyah = list[currentIndex - 1];
      playAyahRef.current(prevAyah.globalNumber, prevAyah.numberInSurah);
    }
  }, []);

  useEffect(() => {
    setOnNext(handleNextAyah);
    setOnPrevious(handlePreviousAyah);
    return () => {
      setOnNext(null);
      setOnPrevious(null);
    };
  }, [handleNextAyah, handlePreviousAyah, setOnNext, setOnPrevious]);
  
  const toggleBookmark = (e: React.MouseEvent, globalNumber: number) => {
    e.preventDefault();
    e.stopPropagation();
    console.log(`[QuranReader Debug] !!! BOOKMARK CLICKED !!! - ${new Date().toISOString()}`, { globalNumber });
    setBookmarkedAyahs(prev => {
        const next = prev.includes(globalNumber) 
            ? prev.filter(n => n !== globalNumber)
            : [...prev, globalNumber];
        localStorage.setItem('bookmarkedAyahs', JSON.stringify(next));
        return next;
    });
  };

  const toggleHighlight = (globalNumber: number) => {
    setHighlightedAyahs(prev => {
        const next = prev.includes(globalNumber) 
            ? prev.filter(n => n !== globalNumber)
            : [...prev, globalNumber];
        localStorage.setItem('highlightedAyahs', JSON.stringify(next));
        return next;
    });
  };

  const handleShare = (e: React.MouseEvent, ayah: Ayah) => {
    triggerHaptic();
    e.preventDefault();
    e.stopPropagation();
    console.log(`[QuranReader Debug] !!! SHARE CLICKED !!! - ${new Date().toISOString()}`, { 
        surah, para, ayah, 
        location: window.location.pathname,
        defaultPrevented: e.defaultPrevented 
    });
    const text = `Quran - Surah, Ayah ${ayah.numberInSurah}: ${ayah.text} (${ayah.translation})`;
    if (navigator.share) {
        navigator.share({
            title: 'Share Ayah',
            text: text,
            url: window.location.href
        }).catch(err => {
            console.error('Share failed', err);
            navigator.clipboard.writeText(text).then(() => alert("Copied to clipboard"));
        });
    } else {
        navigator.clipboard.writeText(text).then(() => alert("Copied to clipboard")).catch(err => console.error('Clipboard copy failed', err));
    }
  };

  const handleTafsir = async (e: React.MouseEvent, globalNumber: number) => {
    triggerHaptic();
    e.preventDefault();
    e.stopPropagation();
    console.log(`[QuranReader Debug] !!! TAFSIR CLICKED !!! - ${new Date().toISOString()}`, { 
        surah, para, globalNumber, 
        location: window.location.pathname,
        defaultPrevented: e.defaultPrevented 
    });
    
    setSelectedTafsir("Loading Tafsir...");
    try {
        const res = await fetch(`https://api.alquran.cloud/v1/ayah/${globalNumber}/ar.muyassar`);
        const data = await res.json();
        if (data.code === 200) {
            setSelectedTafsir(data.data.text);
        } else {
            setSelectedTafsir("Tafsir not found for this Ayah.");
        }
    } catch (e) {
        console.error('Tafsir fetch error', e);
        setSelectedTafsir("Failed to load Tafsir. Please check your connection.");
    }
  };


  const toggleFavorite = async (item: any) => {
    if (isFavorite) {
      await deleteFromDB('favorites', item.id);
      setIsFavorite(false);
    } else {
      await saveToDB('favorites', item);
      setIsFavorite(true);
    }
  };

  const handleListen = (e: React.MouseEvent, globalNumber: number, numberInSurah: number) => {
    triggerHaptic();
    e.preventDefault();
    e.stopPropagation();
    playAyah(globalNumber, numberInSurah);
    
    // Mark as listened
    const id = surah || `para-${para}`;
    const allListened = JSON.parse(localStorage.getItem('listenedAyahs') || '{}');
    const currentListened = allListened[id] || [];
    if (!currentListened.includes(numberInSurah)) {
        const newListened = [...currentListened, numberInSurah];
        allListened[id] = newListened;
        localStorage.setItem('listenedAyahs', JSON.stringify(allListened));
        setListenedAyahs(newListened);
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if the user is typing in an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) return;

      if (e.code === 'Space') {
        e.preventDefault();
        setIsPlaying(!isPlaying);
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        handleNextAyah();
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        handlePreviousAyah();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, setIsPlaying, handleNextAyah, handlePreviousAyah]);

  useEffect(() => {
    const fetchQuranData = async () => {
      console.log('QuranReader: Fetching:', surah ? `Surah ${surah}` : `Para ${para}`);
      setLoading(true);
      setError(null);
      
      const id = surah || `para-${para}`;
      
      // Try IndexedDB first
      try {
        const cached = await getFromDB('quran', id);
        if (cached) {
            console.log('QuranReader: Found in cache');
            setVerses(cached.verses);
            setLoading(false);
            return;
        }
      } catch (e) {
          console.warn('QuranReader: Failed to load from cache', e);
      }

      try {
        // Fetch Quran data from Al-Quran Cloud API
        const url = surah 
            ? `https://api.alquran.cloud/v1/surah/${surah}/editions/quran-uthmani`
            : `https://api.alquran.cloud/v1/juz/${para}/quran-uthmani`;
        console.log('QuranReader: Fetching from API:', url);
        
        const res = await fetch(url);
        
        if (!res.ok) {
            throw new Error(`API returned status ${res.status}`);
        }
        
        const responseData = await res.json();
        
        // Extract ayahs robustly
        let ayahs: any[] = [];
        if (responseData?.data) {
            if (para) {
                // Para response structure: { data: { ayahs: [...] } }
                ayahs = responseData.data.ayahs;
            } else {
                // Surah response structure
                if (Array.isArray(responseData.data)) {
                    // Handle structure { data: [ { ayahs: [...] } ] }
                    if (responseData.data[0]?.ayahs) {
                        ayahs = responseData.data[0].ayahs;
                    } else {
                        // Fallback to array if direct structure
                        ayahs = responseData.data;
                    }
                } else if (responseData.data.ayahs) {
                    // Handle structure { data: { ayahs: [...] } }
                    ayahs = responseData.data.ayahs;
                }
            }
        }

        if (ayahs.length === 0) {
            console.error('QuranReader: Could not find ayahs in response', responseData);
            throw new Error("Invalid API response format: No ayahs found");
        }

        const mappedVerses = ayahs.map((ayah: any) => ({
          numberInSurah: ayah.numberInSurah || (ayah.number % 1000) || 0,
          globalNumber: ayah.number,
          text: ayah.text,
          translation: "Translation not available via this endpoint"
        }));
        
        setVerses(mappedVerses);
        
        try {
            await saveToDB('quran', { id, verses: mappedVerses });
        } catch (e) {
            console.warn('QuranReader: Failed to save to cache', e);
        }

      } catch (err) {
        console.error('QuranReader: Error fetching:', err);
        setError(err instanceof Error ? err.message : "Unable to connect to Quran service. Please check your internet connection.");
      } finally {
        setLoading(false);
      }
    };
    fetchQuranData();
  }, [surah, para, setCurrentUrl, surahInfo]);

  if (loading) return <div className="text-amber-500">Loading Surah...</div>;
  if (error) return (
    <div className="bg-slate-900 border border-red-900/30 rounded-2xl p-6 text-center text-red-500">
        <p>{error}</p>
        <button onClick={() => window.location.reload()} className="mt-4 bg-red-900 text-white px-4 py-2 rounded">Retry</button>
    </div>
  );

  return (
    <div className="space-y-6 pb-20">
      <header className="flex flex-col gap-2 sticky top-0 bg-[var(--color-noor-navy)] p-4 border-b border-amber-900/30 z-10">
        <div className="flex justify-between items-center">
            <Link to="/quran" className="text-amber-600"><ChevronLeft /></Link>
            <div className="flex-1 px-4">
                <h2 className="text-xl text-amber-500 font-serif text-center">
                    {surah ? `${surahInfo?.name} (${surahInfo?.arabic})` : `Para ${para}`}
                </h2>
                <div className="flex justify-between text-xs text-amber-600 mt-1">
                    <span>{Math.round((listenedAyahs.length / (verses.length || 1)) * 100)}% Completed</span>
                </div>
                <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden flex flex-col">
                    <div 
                        className="bg-amber-500 h-1 transition-all duration-300"
                        style={{ width: `${(listenedAyahs.length / (verses.length || 1)) * 100}%` }}
                        title="Listened progress"
                    />
                    <div 
                        className="bg-emerald-500 h-1 transition-all duration-75"
                        style={{ width: `${scrollProgress}%` }}
                        title="Scroll progress"
                    />
                </div>
            </div>
            <div className="flex gap-2 items-center">
                <button
                    type="button"
                    onClick={toggleReciterMode}
                    className={`p-1.5 px-2.5 rounded-lg border text-xs font-bold transition-all flex items-center gap-1.5 ${
                        isReciterMode 
                            ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20' 
                            : 'text-amber-400 border-amber-900/40 hover:bg-slate-800'
                    }`}
                    title={isReciterMode ? "Reciter Mode Enabled (Auto-Follow Recitation)" : "Enable Reciter Mode"}
                >
                    <Headphones size={16} className={isReciterMode ? "animate-pulse" : ""} />
                    <span className="hidden sm:inline">Reciter Mode</span>
                </button>
                <button
                    type="button"
                    onClick={() => {
                        triggerHaptic(15);
                        setDistractionFree(!distractionFree);
                    }}
                    className={`p-1.5 rounded-lg border transition-all ${
                        distractionFree 
                            ? 'bg-amber-500 text-slate-950 font-bold border-amber-400' 
                            : 'text-amber-400 border-amber-900/40 hover:bg-slate-800'
                    }`}
                    title={distractionFree ? "Exit Distraction-Free Mode" : "Enter Distraction-Free Mode"}
                >
                    {distractionFree ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
                </button>
                <button onClick={() => surahInfo && toggleFavorite(surahInfo)} className={isFavorite ? "text-red-500" : "text-slate-400"}>
                    <Heart size={18} fill={isFavorite ? "currentColor" : "none"} />
                </button>
                <button onClick={() => setFontSize(f => Math.max(12, f - 2))} className="text-slate-400">A-</button>
                <button onClick={() => setFontSize(f => Math.min(32, f + 2))} className="text-slate-400">A+</button>
                <button onClick={() => setShowTranslation(!showTranslation)}><Settings size={18} className="text-amber-500"/></button>
            </div>
        </div>
        <input 
            type="text"
            placeholder="Search verses..."
            className="w-full bg-slate-800 text-amber-100 p-2 rounded-lg border border-amber-900/30 focus:outline-none focus:border-amber-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
        />
      </header>

      {/* Floating Exit Button for Distraction-Free Mode */}
      {distractionFree && (
        <div className="fixed top-4 right-4 z-50">
          <button
            type="button"
            onClick={() => {
              triggerHaptic(15);
              setDistractionFree(false);
            }}
            className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500 text-slate-950 font-bold text-xs shadow-xl hover:bg-amber-400 transition active:scale-95"
          >
            <Minimize2 size={14} />
            <span>Exit Focus Mode</span>
          </button>
        </div>
      )}

      {/* Main Verses Rendering */}
      <div className={`space-y-6 px-4 transition-all ${distractionFree ? 'pt-8 max-w-3xl mx-auto' : ''}`}>
        {filteredVerses.map((ayah, index) => {
          const isCurrentlyPlaying = currentlyPlayingGlobalNumber === ayah.globalNumber;

          return (
            <div 
              key={`ayah-${ayah.globalNumber ?? index}`} 
              ref={(el) => {
                if (ayah.globalNumber) {
                  ayahRefs.current[ayah.globalNumber] = el;
                }
              }}
              onDoubleClick={() => toggleHighlight(ayah.globalNumber)}
              className={`pb-4 transition-all duration-300 rounded-2xl ${
                isCurrentlyPlaying
                  ? 'bg-gradient-to-r from-amber-950/80 via-slate-900 to-amber-950/80 border-2 border-amber-400 p-4 shadow-2xl shadow-amber-500/20 ring-2 ring-amber-500/30 scale-[1.01]'
                  : 'border-b border-amber-900/20 p-2'
              } ${listenedAyahs.includes(ayah.numberInSurah) && !isCurrentlyPlaying ? 'opacity-60' : ''} ${
                highlightedAyahs.includes(ayah.globalNumber) && !isCurrentlyPlaying ? 'bg-amber-900/20' : ''
              }`}
            >
              {/* Reciter Mode Active Banner */}
              {isCurrentlyPlaying && (
                <div className="flex items-center justify-between px-3 py-1.5 mb-3 bg-amber-500/15 border border-amber-500/40 rounded-xl text-amber-300 text-xs font-mono font-bold animate-fadeIn">
                  <div className="flex items-center gap-2">
                    <Headphones size={14} className="text-amber-400 animate-bounce" />
                    <span>Reciter Mode • Reciting Verse {ayah.numberInSurah}</span>
                  </div>
                  <div className="flex items-center gap-1 h-3">
                    {[30, 80, 50, 100, 40].map((h, i) => (
                      <span
                        key={i}
                        style={{ height: `${h}%` }}
                        className="w-0.5 bg-amber-400 rounded-full animate-pulse"
                      />
                    ))}
                  </div>
                </div>
              )}
            
              {/* Action Bar (Hidden in Distraction-Free Mode) */}
            {!distractionFree ? (
              <div className="flex justify-between items-center mb-2">
                  <p className="text-slate-500 text-sm">{ayah.numberInSurah}</p>
                  <button type="button" onClick={(e) => handleListen(e, ayah.globalNumber, ayah.numberInSurah)} className="text-amber-500 flex items-center gap-1 text-sm">
                      <Play size={14} /> Listen
                  </button>
                  <button type="button" onClick={(e) => toggleBookmark(e, ayah.globalNumber)} className={`${bookmarkedAyahs.includes(ayah.globalNumber) ? 'text-amber-400' : 'text-amber-500'} flex items-center gap-1 text-sm`}>
                      <Book size={14} /> {bookmarkedAyahs.includes(ayah.globalNumber) ? 'Bookmarked' : 'Bookmark'}
                  </button>
                  <button type="button" onClick={(e) => handleShare(e, ayah)} className="text-amber-500 flex items-center gap-1 text-sm">
                      <Share size={14} /> Share
                  </button>
                  <button type="button" onClick={(e) => handleTafsir(e, ayah.globalNumber)} className="text-amber-500 flex items-center gap-1 text-sm">
                      <Book size={14} /> Tafsir
                  </button>
              </div>
            ) : (
              <div className="flex justify-between items-center mb-1 text-[11px] text-amber-500/60 font-mono">
                <span>﴿{ayah.numberInSurah}﴾</span>
              </div>
            )}

            <p className="text-slate-100 text-right font-arabic mb-3 leading-loose" style={{ fontSize: `${distractionFree ? fontSize + 4 : fontSize}px` }}>
              {ayah.text}
            </p>
            {showTranslation && <p className="text-slate-400 text-lg leading-relaxed">{ayah.translation}</p>}
          </div>
        );
      })}
      </div>

      {selectedTafsir && (
          <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setSelectedTafsir(null)}>
              <div className="bg-slate-900 border border-amber-900/50 p-6 rounded-2xl max-w-lg w-full max-h-[80vh] overflow-y-auto text-amber-100" onClick={e => e.stopPropagation()}>
                  <h3 className="text-lg font-serif text-amber-500 mb-4">Tafsir</h3>
                  <p className="italic">{selectedTafsir}</p>
                  <button onClick={() => setSelectedTafsir(null)} className="mt-6 w-full bg-amber-900/30 text-amber-500 py-2 rounded-lg">Close</button>
              </div>
          </div>
      )}
    </div>
  );
}


