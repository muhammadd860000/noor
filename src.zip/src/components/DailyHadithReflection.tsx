import React, { useState, useEffect } from 'react';
import { BookOpen, Sparkles, CheckCircle2, Heart, Edit3, Send } from 'lucide-react';
import { initDB } from '../lib/db';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

interface DailyHadithReflectionProps {
  hadithText?: string;
  hadithSource?: string;
}

export default function DailyHadithReflection({ 
  hadithText = "The best among you are those who learn the Quran and teach it.",
  hadithSource = "Sahih al-Bukhari"
}: DailyHadithReflectionProps) {
  const [reflectionText, setReflectionText] = useState('');
  const [savedReflections, setSavedReflections] = useState<any[]>([]);
  const [isSaved, setIsSaved] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];

  useEffect(() => {
    loadReflections();
  }, [todayStr]);

  const loadReflections = async () => {
    try {
      const db = await initDB();
      if (!db) return;
      const all = await db.getAll('reflections');
      setSavedReflections(all.reverse());
      
      // Check if today's hadith reflection exists
      const todayRef = all.find((r: any) => r.date === todayStr && r.scriptureType === 'hadith');
      if (todayRef) {
        setReflectionText(todayRef.journalText || '');
        setIsSaved(true);
      }
    } catch (e) {
      console.warn(e);
    }
  };

  const handleSaveReflection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reflectionText.trim()) return;

    triggerButtonClickHaptic();
    try {
      const db = await initDB();
      if (!db) return;

      const record = {
        id: `hadith-ref-${todayStr}`,
        date: todayStr,
        scriptureType: 'hadith' as const,
        arabic: '',
        translation: hadithText,
        source: hadithSource,
        journalText: reflectionText.trim(),
        timestamp: Date.now(),
        updatedAt: Date.now()
      };

      await db.put('reflections', record);
      triggerSuccessHaptic();
      setIsSaved(true);
      loadReflections();
    } catch (err) {
      console.error('Failed to save reflection:', err);
    }
  };

  return (
    <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-4 sm:p-5 shadow-lg space-y-4 relative overflow-hidden">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="p-2 rounded-xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <Edit3 size={18} />
          </span>
          <div>
            <h4 className="text-sm font-bold text-slate-100">Daily Hadith Reflection</h4>
            <p className="text-[11px] text-slate-400">Write 2-3 sentences on how to apply today's Hadith in your life</p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            triggerHaptic(10);
            setIsOpen(!isOpen);
          }}
          className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-850 text-amber-400 border border-slate-800 transition"
        >
          {isOpen ? 'Close' : isSaved ? 'View / Edit Reflection' : 'Write Reflection'}
        </button>
      </div>

      {isOpen && (
        <form onSubmit={handleSaveReflection} className="space-y-3 pt-2 animate-fadeIn">
          <div className="p-3.5 bg-slate-950/80 border border-amber-900/20 rounded-xl space-y-1">
            <span className="text-[10px] font-mono uppercase text-amber-400 font-semibold">{hadithSource}</span>
            <p className="text-xs text-slate-200 italic">"{hadithText}"</p>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-slate-300 font-medium block">
              My Personal Application (2-3 sentences):
            </label>
            <textarea
              value={reflectionText}
              onChange={(e) => setReflectionText(e.target.value)}
              placeholder="e.g. I will dedicate 15 minutes each evening to share what I learned with my family..."
              rows={3}
              className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 p-3 text-xs text-slate-100 rounded-xl outline-none resize-none leading-relaxed"
            />
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-[11px] text-slate-500">
              {reflectionText.trim().split(/\s+/).filter(Boolean).length} words written
            </span>
            <button
              type="submit"
              disabled={!reflectionText.trim()}
              className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-slate-950 font-bold text-xs rounded-xl transition shadow-md shadow-amber-600/20"
            >
              <Send size={14} />
              <span>{isSaved ? 'Update Reflection' : 'Save Reflection'}</span>
            </button>
          </div>
        </form>
      )}

      {isSaved && !isOpen && (
        <div className="flex items-center justify-between p-3 bg-emerald-950/20 border border-emerald-500/30 rounded-xl text-xs text-emerald-300">
          <span className="flex items-center gap-2">
            <CheckCircle2 size={16} className="text-emerald-400 flex-shrink-0" />
            <span>Today's Hadith reflection saved to IndexedDB.</span>
          </span>
          <button
            type="button"
            onClick={() => setIsOpen(true)}
            className="text-emerald-400 hover:underline font-semibold"
          >
            Edit
          </button>
        </div>
      )}
    </div>
  );
}
