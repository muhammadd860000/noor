import React, { useState, useEffect } from 'react';
import { Check } from 'lucide-react';
import { triggerHaptic } from '../lib/haptics';

const SUNNAH_PRAYERS = [
  { id: 'fajr', name: 'Fajr Sunnah' },
  { id: 'dhuhr_pre', name: 'Dhuhr Pre-Sunnah' },
  { id: 'dhuhr_post', name: 'Dhuhr Post-Sunnah' },
  { id: 'maghrib_post', name: 'Maghrib Post-Sunnah' },
  { id: 'isha_post', name: 'Isha Post-Sunnah' },
];

export default function PrayerGoals() {
  const [completed, setCompleted] = useState<Record<string, boolean>>(() => {
    const saved = localStorage.getItem('sunnahGoals');
    return saved ? JSON.parse(saved) : {};
  });

  useEffect(() => {
    localStorage.setItem('sunnahGoals', JSON.stringify(completed));
  }, [completed]);

  const togglePrayer = (id: string) => {
    setCompleted(prev => ({ ...prev, [id]: !prev[id] }));
    triggerHaptic(20);
  };

  const completedCount = Object.values(completed).filter(Boolean).length;
  const progress = (completedCount / SUNNAH_PRAYERS.length) * 100;

  const radius = 30;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 shadow-lg md:col-span-2">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-amber-600 font-semibold">Sunnah Prayer Goals</h3>
        <div className="relative w-16 h-16">
          <svg className="w-16 h-16" viewBox="0 0 70 70">
            <circle cx="35" cy="35" r={radius} fill="none" stroke="#334155" strokeWidth="6" />
            <circle
              cx="35" cy="35" r={radius} fill="none" stroke="#d97706" strokeWidth="6"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              className="transition-all duration-500 ease-in-out"
              style={{ transform: 'rotate(-90deg)', transformOrigin: '35px 35px' }}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center text-amber-500 font-bold text-xs">
            {completedCount}/{SUNNAH_PRAYERS.length}
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 gap-2">
        {SUNNAH_PRAYERS.map(p => (
          <button key={p.id} onClick={() => togglePrayer(p.id)} className="flex items-center gap-3 bg-slate-800 p-2 rounded-lg">
            <div className={`w-5 h-5 rounded flex items-center justify-center border ${completed[p.id] ? 'bg-amber-600 border-amber-600' : 'border-slate-600'}`}>
              {completed[p.id] && <Check size={14} className="text-slate-950" />}
            </div>
            <span className={completed[p.id] ? 'line-through text-slate-500' : 'text-slate-200'}>{p.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
