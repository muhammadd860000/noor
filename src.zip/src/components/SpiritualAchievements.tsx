import React, { useState, useEffect } from 'react';
import { 
  Award, 
  ShieldCheck, 
  Sun, 
  BookOpen, 
  PenTool, 
  Sparkles, 
  Heart, 
  Flame, 
  Lock, 
  CheckCircle2, 
  Trophy, 
  Star,
  Layers,
  ChevronRight
} from 'lucide-react';
import { getStoredBadges, SpiritualBadge } from '../lib/spiritualBadges';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export default function SpiritualAchievements() {
  const [badges, setBadges] = useState<SpiritualBadge[]>(getStoredBadges);
  const [activeCategory, setActiveCategory] = useState<string>('All');

  useEffect(() => {
    // Refresh badges when mounted
    setBadges(getStoredBadges());

    const handleStorage = () => setBadges(getStoredBadges());
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const totalUnlocked = badges.filter(b => b.unlocked).length;
  const unlockPercentage = Math.round((totalUnlocked / badges.length) * 100);

  const categories = ['All', 'Unlocked', 'Prayer', 'Quran', 'Journal', 'Dhikr', 'Quiz'];

  const filteredBadges = badges.filter(badge => {
    if (activeCategory === 'Unlocked') return badge.unlocked;
    if (activeCategory !== 'All' && badge.category !== activeCategory) return false;
    return true;
  });

  const getIcon = (iconName: string, unlocked: boolean) => {
    const size = 22;
    const colorClass = unlocked ? 'text-amber-400' : 'text-slate-600';

    switch (iconName) {
      case 'ShieldCheck':
        return <ShieldCheck size={size} className={colorClass} />;
      case 'Sun':
        return <Sun size={size} className={colorClass} />;
      case 'BookOpen':
        return <BookOpen size={size} className={colorClass} />;
      case 'PenTool':
        return <PenTool size={size} className={colorClass} />;
      case 'Sparkles':
        return <Sparkles size={size} className={colorClass} />;
      case 'Heart':
        return <Heart size={size} className={colorClass} />;
      case 'Flame':
        return <Flame size={size} className={colorClass} />;
      default:
        return <Award size={size} className={colorClass} />;
    }
  };

  const getTierBadge = (tier: SpiritualBadge['tier']) => {
    switch (tier) {
      case 'Diamond':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-mono">Diamond</span>;
      case 'Gold':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-500/40 font-mono">Gold</span>;
      case 'Silver':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-200 border border-slate-600/40 font-mono">Silver</span>;
      default:
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-orange-950 text-orange-300 border border-orange-500/40 font-mono">Bronze</span>;
    }
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-5 shadow-xl space-y-5">
      {/* Header & Overall Unlock Progress */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-900/30">
        <div className="flex items-center gap-2.5">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30 shrink-0">
            <Trophy size={22} />
          </div>
          <div>
            <h3 className="text-base font-serif font-bold text-slate-100 flex items-center gap-2">
              <span>Spiritual Badges & Achievements</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold">
                {totalUnlocked}/{badges.length} Unlocked
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Earn virtual badges and spiritual reward points for consistent prayer, Quran, dhikr & reflections
            </p>
          </div>
        </div>

        {/* Unlock Percentage Badge */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-950 border border-amber-900/40 text-amber-400 text-xs font-bold font-mono self-start sm:self-auto">
          <Star size={15} className="fill-amber-400 text-amber-400" />
          <span>{unlockPercentage}% Mastered</span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="space-y-1">
        <div className="flex justify-between text-[11px] font-mono text-slate-400 font-semibold">
          <span>Overall Spiritual Journey Progress</span>
          <span className="text-amber-400">{totalUnlocked} / {badges.length} Badges</span>
        </div>
        <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800 p-0.5">
          <div
            className="bg-gradient-to-r from-amber-600 to-amber-400 h-full rounded-full transition-all duration-700 shadow-sm"
            style={{ width: `${unlockPercentage}%` }}
          />
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {categories.map(cat => (
          <button
            key={cat}
            type="button"
            onClick={() => {
              triggerButtonClickHaptic();
              setActiveCategory(cat);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition border ${
              activeCategory === cat
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm font-bold'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Badges Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {filteredBadges.map(badge => {
          const pct = Math.min(100, Math.round((badge.progress / badge.maxProgress) * 100));

          return (
            <div
              key={badge.id}
              className={`p-4 rounded-xl border transition-all duration-300 space-y-2.5 relative overflow-hidden ${
                badge.unlocked
                  ? 'bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border-amber-500/60 shadow-lg shadow-amber-500/5'
                  : 'bg-slate-950/70 border-slate-800/80 opacity-75'
              }`}
            >
              {/* Top Row: Icon + Title + Tier */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center border shrink-0 ${
                      badge.unlocked
                        ? 'bg-amber-500/15 border-amber-500/40 shadow-inner'
                        : 'bg-slate-900 border-slate-800'
                    }`}
                  >
                    {badge.unlocked ? (
                      getIcon(badge.iconName, true)
                    ) : (
                      <Lock size={18} className="text-slate-600" />
                    )}
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
                      <span>{badge.title}</span>
                      {badge.unlocked && <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />}
                    </h4>
                    <span className="text-[10px] text-slate-400 block mt-0.5">{badge.description}</span>
                  </div>
                </div>

                {getTierBadge(badge.tier)}
              </div>

              {/* Bottom Row: Progress or Unlocked Timestamp */}
              {badge.unlocked ? (
                <div className="flex items-center justify-between text-[10px] font-mono text-emerald-400 pt-1 border-t border-slate-800/60">
                  <span>✨ Unlocked ({badge.rewardPoints} pts)</span>
                  <span className="text-slate-500">{badge.unlockedAt}</span>
                </div>
              ) : (
                <div className="space-y-1 pt-1 border-t border-slate-800/60">
                  <div className="flex justify-between text-[10px] font-mono text-slate-400">
                    <span>Progress: {badge.progress} / {badge.maxProgress}</span>
                    <span>{pct}%</span>
                  </div>
                  <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className="bg-amber-500/80 h-full rounded-full transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
