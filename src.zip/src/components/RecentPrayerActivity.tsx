import React, { useState, useEffect } from 'react';
import { getFromDB } from '../lib/db';
import { Clock } from 'lucide-react';

export default function RecentPrayerActivity() {
  const [recentPrayers, setRecentPrayers] = useState<any[]>([]);

  useEffect(() => {
    const loadRecent = async () => {
      // Assuming 'prayerHistory' stores individual logs or we can derive it.
      // For now, let's try to fetch a history collection.
      const history = await getFromDB('prayer', 'history') || [];
      // Assuming history is an array of { prayer, timestamp }
      setRecentPrayers(history.slice(-5).reverse());
    };
    loadRecent();
  }, []);

  if (recentPrayers.length === 0) return null;

  return (
    <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 shadow-lg">
      <h3 className="text-amber-600 font-semibold mb-3 flex items-center gap-2">
        <Clock size={18} /> Recent Prayer Activity
      </h3>
      <div className="space-y-2">
        {recentPrayers.map((log, index) => (
          <div key={index} className="flex justify-between text-slate-300 text-sm p-2 bg-slate-800 rounded-lg">
            <span>{log.prayer}</span>
            <span className="text-slate-500">{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
