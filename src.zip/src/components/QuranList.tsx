import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Link } from 'react-router-dom';
import { 
  Search, 
  X, 
  Sparkles, 
  History, 
  BookOpen, 
  CheckCircle2, 
  Star, 
  Layers, 
  SlidersHorizontal,
  Flame,
  Clock,
  BookMarked
} from 'lucide-react';
import { surahs } from '../data/surahs';
import { searchSurahs, extractSurahNumber, Surah } from '../lib/quranSearch';
import { triggerHaptic, triggerButtonClickHaptic } from '../lib/haptics';

const POPULAR_SURAHS: Array<{ id: number; name: string }> = [
  { id: 18, name: 'Al-Kahf' },
  { id: 36, name: 'Ya-Sin' },
  { id: 55, name: 'Ar-Rahman' },
  { id: 67, name: 'Al-Mulk' },
  { id: 56, name: 'Al-Waqi\'ah' },
  { id: 1, name: 'Al-Fatihah' },
  { id: 2, name: 'Al-Baqarah' }
];

export default function QuranList() {
  const [view, setView] = useState<'surah' | 'para'>('surah');
  const [search, setSearch] = useState('');
  const [revelationFilter, setRevelationFilter] = useState<'all' | 'Meccan' | 'Medinan'>('all');
  const [isFocused, setIsFocused] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const [searchHistory, setSearchHistory] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('quranSearchHistory');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const favorites = useMemo(() => {
    try {
      const saved = localStorage.getItem('quranFavorites');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  }, []);

  const history = useMemo(() => {
    try {
      const saved = localStorage.getItem('quranHistory');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  }, []);

  const [surahMetadata, setSurahMetadata] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('surahMetadata');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const listenedAyahs = useMemo(() => {
    try {
      const saved = localStorage.getItem('listenedAyahs');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  }, []);

  useEffect(() => {
    if (surahMetadata.length === 0) {
      fetch('https://api.alquran.cloud/v1/surah')
        .then(res => res.json())
        .then(data => {
          if (data && data.data) {
            localStorage.setItem('surahMetadata', JSON.stringify(data.data));
            setSurahMetadata(data.data);
          }
        })
        .catch(err => {
          console.warn('[QuranList] Failed to fetch metadata:', err);
        });
    }
  }, [surahMetadata.length]);

  const metadataMap = useMemo(() => {
    const map: Record<number, any> = {};
    surahMetadata.forEach((meta) => {
      map[meta.number] = meta;
    });
    return map;
  }, [surahMetadata]);

  // Comprehensive Search Matching
  const filteredSurahs = useMemo(() => {
    let list: Surah[] = searchSurahs(surahs, search, metadataMap);

    if (revelationFilter !== 'all') {
      list = list.filter((s) => {
        const meta = metadataMap[s.id];
        return meta ? meta.revelationType === revelationFilter : true;
      });
    }

    return list;
  }, [search, metadataMap, revelationFilter]);

  const getProgress = (surahId: number) => {
    const meta = metadataMap[surahId];
    if (!meta || !meta.numberOfAyahs) return 0;
    const listened = listenedAyahs[surahId] || [];
    return Math.round((listened.length / meta.numberOfAyahs) * 100);
  };

  const saveToHistory = (term: string) => {
    const cleanTerm = term.trim();
    if (!cleanTerm) return;
    try {
      const currentHistory = JSON.parse(localStorage.getItem('quranSearchHistory') || '[]');
      const newHistory = [cleanTerm, ...currentHistory.filter((t: string) => t.toLowerCase() !== cleanTerm.toLowerCase())].slice(0, 6);
      localStorage.setItem('quranSearchHistory', JSON.stringify(newHistory));
      setSearchHistory(newHistory);
    } catch (err) {
      console.warn('Error saving search history:', err);
    }
  };

  const handleHistoryClick = (term: string) => {
    triggerButtonClickHaptic();
    setSearch(term);
    saveToHistory(term);
    setIsFocused(false);
  };

  const clearSearchHistory = (e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic(15);
    localStorage.removeItem('quranSearchHistory');
    setSearchHistory([]);
  };

  const handleClearSearch = () => {
    triggerButtonClickHaptic();
    setSearch('');
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl text-amber-500 font-serif font-bold">Noble Quran</h2>
          <p className="text-xs text-slate-400 mt-0.5">Explore 114 Surahs and 30 Juz with recitation & translations</p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <Link
            to="/quran-journal"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-400 border border-amber-500/30 text-xs font-bold transition active:scale-95 shadow-md"
          >
            <BookMarked size={15} />
            <span>Daily Quran Journal</span>
          </Link>
          <span className="text-lg text-amber-400 font-serif hidden sm:inline" dir="rtl">
            القرآن الكريم
          </span>
        </div>
      </header>
      
      {/* View Switcher: Surah vs Para / Juz */}
      <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800">
        <button 
          type="button"
          className={`flex-1 py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
            view === 'surah' ? 'bg-amber-600 text-slate-950 shadow-sm font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
          onClick={() => {
            triggerButtonClickHaptic();
            setView('surah');
          }}
        >
          <BookOpen size={14} />
          <span>Surah (114 Chapters)</span>
        </button>
        <button 
          type="button"
          className={`flex-1 py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
            view === 'para' ? 'bg-amber-600 text-slate-950 shadow-sm font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
          onClick={() => {
            triggerButtonClickHaptic();
            setView('para');
          }}
        >
          <Layers size={14} />
          <span>Juz / Para (30 Parts)</span>
        </button>
      </div>

      {view === 'surah' && (
        <div className="space-y-3">
          {/* Enhanced Search Input Bar */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <Search size={18} className="text-amber-500/80" />
            </div>

            <input
              ref={searchInputRef}
              type="text"
              placeholder="Full-Text Offline Search (e.g. Kahf, Cave, Moses, Sleepers, Throne, 18, 36)..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onFocus={() => setIsFocused(true)}
              onBlur={() => {
                setTimeout(() => setIsFocused(false), 250);
                if (search.trim()) {
                  saveToHistory(search);
                }
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && search.trim()) {
                  saveToHistory(search);
                }
              }}
              className="w-full bg-slate-900/90 border border-amber-900/40 text-slate-100 pl-10 pr-10 py-3 rounded-xl focus:border-amber-500 focus:ring-1 focus:ring-amber-500/40 outline-none text-xs sm:text-sm placeholder-slate-500 transition shadow-inner"
            />

            {search && (
              <button
                type="button"
                onClick={handleClearSearch}
                aria-label="Clear Search"
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-200"
              >
                <X size={16} />
              </button>
            )}
          </div>

          {/* Quick Revelation Filter & Results Count */}
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-slate-500 text-[11px]">Filter:</span>
              {(['all', 'Meccan', 'Medinan'] as const).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => {
                    triggerButtonClickHaptic();
                    setRevelationFilter(type);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs capitalize transition ${
                    revelationFilter === type
                      ? 'bg-amber-600/20 text-amber-300 border border-amber-500/40 font-semibold'
                      : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {type === 'all' ? 'All Surahs' : `${type} (مكية/مدنية)`}
                </button>
              ))}

              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20 font-semibold flex items-center gap-1">
                <span>⚡ FlexSearch Offline Full-Text Index</span>
              </span>
            </div>

            <span className="text-[11px] font-mono text-slate-400">
              {filteredSurahs.length} of {surahs.length} Surahs
            </span>
          </div>

          {/* Recent Search History Chips */}
          {searchHistory.length > 0 && (
            <div className="space-y-1 pt-1">
              <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium">
                <span className="flex items-center gap-1">
                  <History size={12} className="text-amber-500" /> Recent Searches:
                </span>
                <button
                  type="button"
                  onClick={clearSearchHistory}
                  className="text-[10px] text-slate-500 hover:text-amber-400 transition"
                >
                  Clear History
                </button>
              </div>
              <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar flex-wrap">
                {searchHistory.slice(0, 5).map((term, idx) => (
                  <button
                    key={`${term}-${idx}`}
                    type="button"
                    onClick={() => handleHistoryClick(term)}
                    className="bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-amber-300 border border-slate-800 hover:border-amber-500/40 px-2.5 py-1 rounded-xl text-xs font-mono transition active:scale-95 flex items-center gap-1"
                  >
                    <span>🔍 {term}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quick Popular Surah Shortcut Chips */}
          {!search && !isFocused && (
            <div className="space-y-1 pt-1">
              <span className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
                <Sparkles size={11} className="text-amber-500" /> Popular Surahs:
              </span>
              <div className="flex gap-1.5 overflow-x-auto pb-1.5 no-scrollbar">
                {POPULAR_SURAHS.map((s) => (
                  <Link
                    key={s.id}
                    to={`/quran/${s.id}`}
                    className="flex-none bg-slate-950 hover:bg-slate-850 text-amber-400 hover:text-amber-300 border border-amber-900/30 hover:border-amber-500/40 px-3 py-1.5 rounded-xl text-xs font-medium transition active:scale-95 flex items-center gap-1.5"
                  >
                    <span className="text-[10px] font-mono text-amber-600">#{s.id}</span>
                    <span>{s.name}</span>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Recent Searches Dropdown */}
          {searchHistory.length > 0 && isFocused && (
            <section className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-2 animate-fadeIn">
              <div className="flex items-center justify-between">
                <h3 className="text-slate-400 text-xs font-semibold flex items-center gap-1.5">
                  <History size={13} className="text-amber-500" />
                  <span>Recent Searches</span>
                </h3>
                <button
                  type="button"
                  onClick={clearSearchHistory}
                  className="text-[10px] text-slate-500 hover:text-red-400 transition"
                >
                  Clear All
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {searchHistory.map((term: string) => (
                  <button
                    key={term}
                    type="button"
                    onClick={() => handleHistoryClick(term)}
                    className="flex items-center gap-1 bg-slate-900 hover:bg-amber-950/30 text-slate-300 hover:text-amber-400 border border-slate-800 hover:border-amber-500/30 px-2.5 py-1 rounded-lg text-xs transition"
                  >
                    <Clock size={11} className="text-slate-500" />
                    <span>{term}</span>
                  </button>
                ))}
              </div>
            </section>
          )}

          {/* Favorites Ribbon */}
          {favorites.length > 0 && !search && !isFocused && (
            <section className="space-y-1.5">
              <h3 className="text-slate-400 text-xs font-semibold flex items-center gap-1.5">
                <Star size={13} className="text-amber-500 fill-amber-500/20" />
                <span>Bookmarked Surahs</span>
              </h3>
              <div className="flex gap-2 overflow-x-auto pb-1.5">
                {favorites.map((s: any) => (
                  <Link 
                    key={s.id} 
                    to={`/quran/${s.id}`} 
                    className="flex-none bg-amber-500/10 text-amber-300 border border-amber-500/20 px-3 py-1.5 rounded-xl text-xs font-medium hover:border-amber-500/40 transition"
                  >
                    {s.name}
                  </Link>
                ))}
              </div>
            </section>
          )}

          {/* List of Filtered Surahs */}
          <div className="space-y-2 pr-1 max-h-[calc(100vh-280px)] overflow-y-auto">
            {filteredSurahs.length > 0 ? (
              filteredSurahs.map((surah) => {
                const progress = getProgress(surah.id);
                const meta = metadataMap[surah.id];

                return (
                  <Link
                    key={surah.id}
                    to={`/quran/${surah.id}`}
                    className="flex items-center justify-between p-3.5 sm:p-4 bg-slate-900/80 border border-amber-900/30 hover:border-amber-500/50 rounded-2xl hover:bg-slate-900 transition-all group"
                  >
                    <div className="flex items-center gap-3 sm:gap-4">
                      {/* Surah Number Badge */}
                      <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-mono text-xs font-bold shrink-0 group-hover:scale-105 transition-transform">
                        {surah.id}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-slate-100 font-semibold text-sm sm:text-base group-hover:text-amber-300 transition-colors">
                            {surah.name}
                          </span>
                          {meta?.revelationType && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 border border-slate-700">
                              {meta.revelationType === 'Meccan' ? 'Makkah' : 'Madinah'}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                          <span>{meta?.numberOfAyahs || 'Ayahs'} verses</span>
                          {meta?.englishNameTranslation && (
                            <>
                              <span>•</span>
                              <span className="text-slate-500 truncate max-w-[120px] sm:max-w-none">
                                {meta.englishNameTranslation}
                              </span>
                            </>
                          )}
                          {progress > 0 && (
                            <>
                              <span>•</span>
                              <span className="text-amber-400 font-semibold">{progress}% read</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Arabic Calligraphy Name */}
                    <span className="text-amber-400 font-arabic text-xl sm:text-2xl group-hover:text-amber-300 transition-colors" dir="rtl">
                      {surah.arabic}
                    </span>
                  </Link>
                );
              })
            ) : (
              <div className="text-center py-12 bg-slate-950/60 rounded-2xl border border-dashed border-slate-800 space-y-2">
                <Search size={28} className="mx-auto text-slate-600" />
                <p className="text-slate-300 text-sm font-medium">No Surahs found matching "{search}"</p>
                <p className="text-slate-500 text-xs">Try searching by Surah number (e.g. 18, 36) or transliterated name (e.g. Fatihah, Baqarah).</p>
                <button
                  type="button"
                  onClick={handleClearSearch}
                  className="px-3 py-1.5 rounded-xl bg-amber-600/20 text-amber-400 border border-amber-500/30 text-xs font-semibold hover:bg-amber-600/30 transition"
                >
                  Clear Search Filter
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {view === 'para' && (
        <div className="space-y-2 pr-1 max-h-[calc(100vh-240px)] overflow-y-auto">
          {Array.from({ length: 30 }, (_, i) => i + 1).map((para) => (
            <Link
              key={para}
              to={`/quran/para/${para}`}
              className="flex items-center justify-between p-3.5 sm:p-4 bg-slate-900/80 border border-amber-900/30 hover:border-amber-500/50 rounded-2xl hover:bg-slate-900 transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-mono text-xs font-bold shrink-0">
                  {para}
                </div>
                <div>
                  <span className="text-slate-100 font-semibold text-sm sm:text-base block group-hover:text-amber-300 transition-colors">
                    Juz {para}
                  </span>
                  <span className="text-slate-400 text-xs">Para {para} of 30</span>
                </div>
              </div>
              <span className="text-amber-500 font-arabic text-lg" dir="rtl">
                الجزء {para}
              </span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
