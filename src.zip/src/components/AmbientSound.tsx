import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Play, Pause, Disc, Waves, Wind, CloudRain, Sparkles } from 'lucide-react';
import { triggerButtonClickHaptic } from '../lib/haptics';

interface SoundTrack {
  id: string;
  name: string;
  category: 'nature' | 'recitation';
  icon: React.ReactNode;
  // Using Web Audio API synthetic generative ambience or reliable public audio stream
  synthType: 'rain' | 'waves' | 'breeze' | 'recitation';
}

const tracks: SoundTrack[] = [
  { id: 'rain', name: 'Gentle Rain & Sanctuary', category: 'nature', icon: <CloudRain size={18} />, synthType: 'rain' },
  { id: 'waves', name: 'Calm Ocean Waves', category: 'nature', icon: <Waves size={18} />, synthType: 'waves' },
  { id: 'breeze', name: 'Quiet Night Breeze', category: 'nature', icon: <Wind size={18} />, synthType: 'breeze' },
  { id: 'recitation', name: 'Soft Quranic Recitation', category: 'recitation', icon: <Sparkles size={18} />, synthType: 'recitation' },
];

export default function AmbientSound() {
  const [activeTrackId, setActiveTrackId] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.5);

  const audioContextRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const sourceNodeRef = useRef<AudioNode | null>(null);
  const intervalRef = useRef<any>(null);

  const stopAudio = () => {
    if (audioContextRef.current) {
      try {
        audioContextRef.current.close();
      } catch {}
      audioContextRef.current = null;
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsPlaying(false);
    setActiveTrackId(null);
  };

  const startTrack = (track: SoundTrack) => {
    triggerButtonClickHaptic();
    stopAudio();

    setActiveTrackId(track.id);
    setIsPlaying(true);

    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(volume, ctx.currentTime);
      gain.connect(ctx.destination);
      gainNodeRef.current = gain;

      if (track.synthType === 'recitation') {
        // Soft meditative harmonic chord simulation
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        osc1.type = 'sine';
        osc2.type = 'sine';
        osc1.frequency.setValueAtTime(130.81, ctx.currentTime); // C3
        osc2.frequency.setValueAtTime(196.00, ctx.currentTime); // G3

        osc1.connect(gain);
        osc2.connect(gain);
        osc1.start();
        osc2.start();
        sourceNodeRef.current = osc1;
      } else {
        // Pink / White noise generator for rain / waves / breeze
        const bufferSize = 2 * ctx.sampleRate;
        const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;

        for (let i = 0; i < bufferSize; i++) {
          const white = Math.random() * 2 - 1;
          if (track.synthType === 'rain') {
            // Pink noise approximation
            b0 = 0.99886 * b0 + white * 0.0555179;
            output[i] = b0 * 0.15;
          } else if (track.synthType === 'waves') {
            // Low-pass filtered noise modulated for waves
            output[i] = white * 0.1;
          } else {
            // Breeze
            output[i] = white * 0.08;
          }
        }

        const whiteNoise = ctx.createBufferSource();
        whiteNoise.buffer = noiseBuffer;
        whiteNoise.loop = true;

        const filter = ctx.createBiquadFilter();
        filter.type = track.synthType === 'waves' ? 'lowpass' : 'bandpass';
        filter.frequency.setValueAtTime(track.synthType === 'waves' ? 300 : 800, ctx.currentTime);

        whiteNoise.connect(filter);
        filter.connect(gain);
        whiteNoise.start();
        sourceNodeRef.current = whiteNoise;
      }
    } catch (e) {
      console.warn('Web Audio API not fully supported or blocked', e);
    }
  };

  useEffect(() => {
    if (gainNodeRef.current && audioContextRef.current) {
      gainNodeRef.current.gain.setValueAtTime(volume, audioContextRef.current.currentTime);
    }
  }, [volume]);

  useEffect(() => {
    return () => {
      stopAudio();
    };
  }, []);

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-6 shadow-xl space-y-4">
      <div className="flex items-center justify-between border-b border-amber-900/20 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Disc className={isPlaying ? "animate-spin text-amber-400" : ""} size={20} />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100">Prayer Ambient Soundscapes</h3>
            <p className="text-xs text-slate-400">Calming background tracks to help you maintain khushoo and focus</p>
          </div>
        </div>

        {isPlaying && (
          <button
            type="button"
            onClick={stopAudio}
            className="px-3 py-1.5 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-200 border border-rose-800 text-xs font-medium transition"
          >
            Stop Audio
          </button>
        )}
      </div>

      {/* Track Selection Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {tracks.map((track) => {
          const isActive = activeTrackId === track.id && isPlaying;
          return (
            <button
              key={track.id}
              type="button"
              onClick={() => (isActive ? stopAudio() : startTrack(track))}
              className={`p-4 rounded-xl border text-left transition-all flex items-center justify-between ${
                isActive 
                  ? 'bg-amber-950/50 border-amber-500 text-amber-200 shadow-lg' 
                  : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:border-amber-900/50 hover:bg-slate-900'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className={`p-2 rounded-lg ${isActive ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-amber-400'}`}>
                  {track.icon}
                </span>
                <div>
                  <h4 className="text-sm font-semibold">{track.name}</h4>
                  <p className="text-[11px] text-slate-400 capitalize">{track.category} soundscape</p>
                </div>
              </div>

              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${isActive ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'}`}>
                {isActive ? <Pause size={14} /> : <Play size={14} />}
              </div>
            </button>
          );
        })}
      </div>

      {/* Volume Control */}
      {isPlaying && (
        <div className="pt-2 flex items-center gap-3 bg-slate-950/60 p-3 rounded-xl border border-amber-900/20">
          {volume === 0 ? <VolumeX size={16} className="text-slate-400" /> : <Volume2 size={16} className="text-amber-400" />}
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={volume}
            onChange={(e) => setVolume(parseFloat(e.target.value))}
            className="w-full accent-amber-500 cursor-pointer"
          />
          <span className="text-xs font-mono text-amber-400 w-10 text-right">{Math.round(volume * 100)}%</span>
        </div>
      )}
    </div>
  );
}
