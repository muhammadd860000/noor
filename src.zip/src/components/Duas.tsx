import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  Search, 
  Bookmark, 
  BookmarkCheck, 
  Share2, 
  Copy, 
  Check, 
  BookOpen, 
  Sparkles, 
  Sun, 
  Moon, 
  Utensils, 
  Compass, 
  Home as HomeIcon, 
  Shield, 
  Heart, 
  RotateCcw,
  Type,
  Volume2,
  X,
  Tag,
  Bell
} from 'lucide-react';
import { 
  allDuas, 
  DUA_CATEGORIES, 
  DuaItem, 
  getBookmarkedDuaIds, 
  saveBookmarkedDuaIds 
} from '../data/duas';
import DailyDuaNotificationCard from './DailyDuaNotificationCard';
import { triggerHaptic, triggerButtonClickHaptic } from '../lib/haptics';
import { filterDuas, POPULAR_DUA_SEARCH_TAGS } from '../lib/duaSearch';

export default function Duas() {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(getBookmarkedDuaIds);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isLargeArabic, setIsLargeArabic] = useState<boolean>(() => {
    try {
      return localStorage.getItem('dua_large_arabic') === 'true';
    } catch {
      return false;
    }
  });
  const [showNotificationCard, setShowNotificationCard] = useState(false);

  // Tap counters for repetitive adhkar (e.g., 3x): { [duaId]: currentCount }
  const [repetitionCounts, setRepetitionCounts] = useState<Record<string, number>>({});

  // Sync bookmarks across tabs or custom events
  useEffect(() => {
    const handleBookmarkSync = (e: Event) => {
      const customEvent = e as CustomEvent<string[]>;
      if (customEvent.detail) {
        setBookmarkedIds(customEvent.detail);
      } else {
        setBookmarkedIds(getBookmarkedDuaIds());
      }
    };

    window.addEventListener('dua-bookmarks-changed', handleBookmarkSync);
    return () => window.removeEventListener('dua-bookmarks-changed', handleBookmarkSync);
  }, []);

  const toggleBookmark = useCallback((duaId: string) => {
    triggerHaptic(20);
    setBookmarkedIds(prev => {
      const isBookmarked = prev.includes(duaId);
      const updated = isBookmarked ? prev.filter(id => id !== duaId) : [...prev, duaId];
      saveBookmarkedDuaIds(updated);
      return updated;
    });
  }, []);

  const toggleFontSize = () => {
    triggerHaptic(10);
    setIsLargeArabic(prev => {
      const next = !prev;
      localStorage.setItem('dua_large_arabic', String(next));
      return next;
    });
  };

  const handleCopy = async (dua: DuaItem) => {
    triggerHaptic(15);
    const textToCopy = `🕌 ${dua.title}\n\n${dua.arabic}\n\n"${dua.meaning}"\n\nTransliteration: ${dua.transliteration}\nReference: ${dua.reference}\n\nShared via Noor`;
    
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopiedId(dua.id);
      setTimeout(() => setCopiedId(null), 2500);
    } catch (err) {
      console.warn('Failed to copy text:', err);
    }
  };

  const handleShare = async (dua: DuaItem) => {
    triggerHaptic(15);
    const textToShare = `🕌 ${dua.title}\n\n${dua.arabic}\n\n"${dua.meaning}"\n\nReference: ${dua.reference}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: dua.title,
          text: textToShare,
          url: window.location.href
        });
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          handleCopy(dua);
        }
      }
    } else {
      handleCopy(dua);
    }
  };

  const handleIncrementCount = (duaId: string, maxCount: number) => {
    triggerHaptic(25);
    setRepetitionCounts(prev => {
      const current = prev[duaId] || 0;
      const next = current + 1;
      return {
        ...prev,
        [duaId]: next > maxCount ? 0 : next
      };
    });
  };

  // Filtered duas based on category, bookmarks, and search term
  const filteredDuas = useMemo(() => {
    return filterDuas(allDuas, {
      query: search,
      category: selectedCategory,
      bookmarkedIds
    });
  }, [search, selectedCategory, bookmarkedIds]);

  const bookmarkedCount = bookmarkedIds.length;

  const handleQuickTagClick = (tagQuery: string) => {
    triggerButtonClickHaptic();
    if (search.toLowerCase() === tagQuery.toLowerCase()) {
      setSearch('');
    } else {
      setSearch(tagQuery);
    }
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Header Bar */}
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl text-amber-500 font-serif font-bold">Du'a Library</h2>
            <span className="text-xs font-serif text-slate-400 opacity-80" dir="rtl">
              الأدعية المأثورة
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Authentic Quranic and prophetic supplications for your daily moments
          </p>
        </div>

        {/* View Options: Daily Dua Alerts & Text size toggle */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => {
              triggerButtonClickHaptic();
              setShowNotificationCard(!showNotificationCard);
            }}
            className={`px-3 py-1.5 rounded-xl border text-xs font-medium flex items-center gap-1.5 transition-colors ${
              showNotificationCard
                ? 'bg-amber-600 text-slate-950 font-bold border-amber-500'
                : 'bg-slate-900 border-amber-900/30 text-amber-400 hover:bg-slate-800'
            }`}
            title="Configure Daily Motivational Dua Notification"
          >
            <Bell size={14} />
            <span>Daily Dua Alert</span>
          </button>

          <button
            type="button"
            onClick={toggleFontSize}
            className={`px-3 py-1.5 rounded-xl border text-xs font-medium flex items-center gap-1.5 transition-colors ${
              isLargeArabic
                ? 'bg-amber-600/20 text-amber-400 border-amber-500/40'
                : 'bg-slate-900 border-amber-900/30 text-slate-300 hover:text-amber-400'
            }`}
            title="Toggle Arabic script size"
          >
            <Type size={14} />
            <span>{isLargeArabic ? 'Large Font' : 'Standard'}</span>
          </button>
        </div>
      </header>

      {/* Expandable Daily Dua Notification Scheduler */}
      {showNotificationCard && (
        <div className="animate-fadeIn">
          <DailyDuaNotificationCard />
        </div>
      )}

      {/* Search Input Bar */}
      <div className="space-y-2.5">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Search size={18} />
          </div>
          <input
            type="text"
            placeholder="Search supplications (e.g. waking up, eating, traveling, protection, forgiveness)..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-900/90 border border-amber-900/40 text-slate-100 pl-10 pr-10 py-3.5 rounded-2xl text-sm placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors shadow-inner"
          />
          {search && (
            <button
              type="button"
              onClick={() => {
                triggerButtonClickHaptic();
                setSearch('');
              }}
              className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200"
              aria-label="Clear search"
            >
              <X size={18} />
            </button>
          )}
        </div>

        {/* Quick Search Suggestions & Tags */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
          <span className="text-slate-500 flex items-center gap-1 pl-1 shrink-0 font-medium">
            <Tag size={12} /> Popular:
          </span>
          {POPULAR_DUA_SEARCH_TAGS.map((tag) => {
            const isTagActive = search.toLowerCase() === tag.query.toLowerCase();
            return (
              <button
                key={tag.query}
                type="button"
                onClick={() => handleQuickTagClick(tag.query)}
                className={`px-2.5 py-1 rounded-lg shrink-0 transition text-[11px] font-medium border ${
                  isTagActive
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/60 font-semibold'
                    : 'bg-slate-950/40 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-300'
                }`}
              >
                {tag.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Category Pills Navigation */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none pt-1">
        {DUA_CATEGORIES.map(category => {
          const isSelected = selectedCategory === category.id;
          const isBookmarkCategory = category.id === 'favorites';

          return (
            <button
              key={category.id}
              type="button"
              onClick={() => {
                triggerButtonClickHaptic();
                setSelectedCategory(category.id);
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-200 flex items-center gap-1.5 ${
                isSelected
                  ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20 scale-[1.02]'
                  : 'bg-slate-900/90 hover:bg-slate-850 text-slate-300 border border-amber-900/30'
              }`}
            >
              {isBookmarkCategory ? (
                <Bookmark size={13} className={isSelected ? 'fill-slate-950' : 'fill-amber-400/40 text-amber-400'} />
              ) : null}
              <span>{category.name}</span>
              {isBookmarkCategory && (
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                  isSelected ? 'bg-slate-950 text-amber-400' : 'bg-slate-800 text-slate-300'
                }`}>
                  {bookmarkedCount}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Category & Results Status Bar */}
      <div className="flex items-center justify-between text-xs text-slate-400 pb-1 border-b border-slate-800/60">
        <span className="font-semibold text-slate-300 flex items-center gap-2">
          {search ? (
            <>
              <span>Matching Duas: <strong className="text-amber-400 font-mono">{filteredDuas.length}</strong></span>
              <span className="text-slate-500">for "{search}"</span>
            </>
          ) : selectedCategory === 'favorites' ? (
            `Your Bookmarked Supplications (${filteredDuas.length})`
          ) : selectedCategory !== 'all' ? (
            `${DUA_CATEGORIES.find(c => c.id === selectedCategory)?.name} (${filteredDuas.length})`
          ) : (
            `Showing All ${filteredDuas.length} Supplications`
          )}
        </span>

        {(selectedCategory !== 'all' || search) && (
          <button
            type="button"
            onClick={() => {
              triggerButtonClickHaptic();
              setSelectedCategory('all');
              setSearch('');
            }}
            className="text-amber-500 hover:text-amber-400 font-medium text-xs flex items-center gap-1"
          >
            Reset Filters
          </button>
        )}
      </div>

      {/* Main List of Dua Cards */}
      {filteredDuas.length > 0 ? (
        <div className="space-y-4">
          {filteredDuas.map(dua => {
            const isBookmarked = bookmarkedIds.includes(dua.id);
            const isCopied = copiedId === dua.id;
            const currentRepetition = repetitionCounts[dua.id] || 0;
            const maxRepetitions = dua.repetitions || 1;
            const hasMultipleRepetitions = maxRepetitions > 1;

            return (
              <article
                key={dua.id}
                className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-200 hover:border-amber-700/50 group"
              >
                {/* Header: Title & Action Icons */}
                <div className="flex items-start justify-between gap-4 mb-4">
                  <div>
                    <span className="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-amber-500/10 text-amber-400 border border-amber-500/20 mb-2">
                      {dua.categoryName}
                    </span>
                    <h3 className="text-lg font-bold text-slate-100 group-hover:text-amber-300 transition-colors">
                      {dua.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    {/* Share Button */}
                    <button
                      type="button"
                      onClick={() => handleShare(dua)}
                      className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-xl transition"
                      title="Share supplication"
                      aria-label="Share supplication"
                    >
                      <Share2 size={16} />
                    </button>

                    {/* Copy Button */}
                    <button
                      type="button"
                      onClick={() => handleCopy(dua)}
                      className={`p-2 rounded-xl transition ${
                        isCopied 
                          ? 'bg-emerald-500/20 text-emerald-400' 
                          : 'text-slate-400 hover:text-amber-400 hover:bg-slate-800/80'
                      }`}
                      title={isCopied ? 'Copied to clipboard' : 'Copy supplication text'}
                      aria-label="Copy supplication"
                    >
                      {isCopied ? <Check size={16} /> : <Copy size={16} />}
                    </button>

                    {/* Bookmark Toggle */}
                    <button
                      type="button"
                      onClick={() => toggleBookmark(dua.id)}
                      className={`p-2 rounded-xl transition ${
                        isBookmarked 
                          ? 'bg-amber-500/20 text-amber-400' 
                          : 'text-slate-400 hover:text-amber-400 hover:bg-slate-800/80'
                      }`}
                      title={isBookmarked ? 'Remove bookmark' : 'Bookmark supplication'}
                      aria-label="Bookmark supplication"
                    >
                      {isBookmarked ? (
                        <BookmarkCheck size={16} className="fill-amber-400" />
                      ) : (
                        <Bookmark size={16} />
                      )}
                    </button>
                  </div>
                </div>

                {/* Arabic Supplication Script */}
                <div 
                  className={`bg-slate-950/70 border border-amber-900/20 rounded-xl p-4 sm:p-5 text-right font-serif text-amber-200/95 leading-loose tracking-wide mb-4 select-text ${
                    isLargeArabic ? 'text-2xl sm:text-3xl' : 'text-xl sm:text-2xl'
                  }`}
                  dir="rtl"
                >
                  {dua.arabic}
                </div>

                {/* Transliteration */}
                <div className="mb-3 text-xs sm:text-sm text-slate-400 italic leading-relaxed font-sans select-text">
                  <span className="text-amber-500/80 font-semibold not-italic mr-1.5">Pronunciation:</span>
                  {dua.transliteration}
                </div>

                {/* English Meaning */}
                <div className="mb-3 text-xs sm:text-sm text-slate-200 leading-relaxed font-medium select-text">
                  <span className="text-amber-400 font-semibold mr-1.5">Meaning:</span>
                  "{dua.meaning}"
                </div>

                {/* Urdu Translation if available */}
                {dua.urdu && (
                  <div className="mb-3 text-xs sm:text-sm text-amber-100/90 font-serif leading-relaxed text-right select-text border-t border-slate-800/50 pt-2" dir="rtl">
                    <span className="text-amber-500 font-sans text-xs ml-1.5">ترجمہ:</span>
                    {dua.urdu}
                  </div>
                )}

                {/* Spiritual Benefit / Context */}
                {dua.benefit && (
                  <div className="p-3 bg-amber-950/20 border border-amber-900/30 rounded-xl mb-3 text-xs text-amber-300/90 leading-relaxed flex items-start gap-2">
                    <Sparkles size={14} className="text-amber-400 flex-shrink-0 mt-0.5" />
                    <span>{dua.benefit}</span>
                  </div>
                )}

                {/* Footer Bar: Reference Citation & Repetition Counter */}
                <div className="pt-3 border-t border-amber-900/20 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-1.5 text-amber-500/80 font-mono">
                    <BookOpen size={13} />
                    <span>{dua.reference}</span>
                  </div>

                  {/* Interactive Repetition Stepper */}
                  {hasMultipleRepetitions && (
                    <button
                      type="button"
                      onClick={() => handleIncrementCount(dua.id, maxRepetitions)}
                      className={`px-3 py-1 rounded-xl border text-xs font-mono font-semibold flex items-center gap-2 transition-all active:scale-95 ${
                        currentRepetition >= maxRepetitions
                          ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-400'
                          : 'bg-slate-800/90 border-slate-700 text-slate-300 hover:border-amber-500/50'
                      }`}
                      title="Tap to count repetitions"
                    >
                      <span>Repeat:</span>
                      <span className="font-bold text-amber-400">{currentRepetition}</span>
                      <span className="text-slate-500">/ {maxRepetitions}</span>
                      {currentRepetition >= maxRepetitions && (
                        <Check size={12} className="text-emerald-400" />
                      )}
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      ) : (
        /* Zero States */
        <div className="bg-slate-900/80 border border-amber-900/30 rounded-2xl p-8 sm:p-12 text-center space-y-4">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500">
            {selectedCategory === 'favorites' ? <Bookmark size={28} /> : <Search size={28} />}
          </div>

          <div className="space-y-1">
            <h3 className="text-lg font-bold text-slate-100">
              {selectedCategory === 'favorites' 
                ? 'No Bookmarked Duas Yet' 
                : 'No Supplications Found'}
            </h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              {selectedCategory === 'favorites'
                ? 'Tap the bookmark icon on any supplication in the library to save it here for fast daily access.'
                : `We couldn't find any supplications matching "${search}". Try searching for waking up, eating, traveling, or forgiveness.`}
            </p>
          </div>

          {selectedCategory === 'favorites' ? (
            <button
              type="button"
              onClick={() => {
                triggerButtonClickHaptic();
                setSelectedCategory('all');
              }}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded-xl text-xs transition-colors shadow-md shadow-amber-600/20 active:scale-95"
            >
              Browse All Supplications
            </button>
          ) : (
            <div className="flex justify-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  triggerButtonClickHaptic();
                  setSearch('');
                  setSelectedCategory('all');
                }}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium rounded-xl text-xs transition-colors border border-slate-700"
              >
                Clear Search & Filters
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
