import React, { useState } from 'react';
import { Sparkles, Heart, Copy, Check, Volume2, BookOpen, Sun, Moon, Sunrise, Sunset, Clock } from 'lucide-react';
import { triggerHaptic } from '../lib/haptics';

export type PrayerName = 'Fajr' | 'Dhuhr' | 'Asr' | 'Maghrib' | 'Isha' | 'General';

export interface PostSalahDua {
  id: string;
  prayer: PrayerName;
  title: string;
  arabic: string;
  transliteration: string;
  translation: string;
  reference: string;
  repeatCount?: number;
  significance?: string;
}

const PRAYER_DUAS: PostSalahDua[] = [
  // GENERAL COMMON POST-SALAH ADHKAR
  {
    id: 'gen-1',
    prayer: 'General',
    title: 'Istighfar & Greeting of Peace',
    arabic: 'أَسْتَغْفِرُ اللهَ (ثَلاَثاً) اللَّهُمَّ أَنْتَ السَّلاَمُ، وَمِنْكَ السَّلاَمُ، تَبَارَكْتَ يَا ذَا الْجَلاَلِ وَالإِكْرَامِ',
    transliteration: "Astaghfirullah (3x). Allahumma Antas-Salam wa minkas-salam, tabarakta ya Dhal-Jalali wal-Ikram.",
    translation: "I ask Allah for forgiveness (3 times). O Allah, You are Peace and from You comes peace. Blessed are You, O Owner of majesty and honor.",
    reference: "Sahih Muslim 591",
    repeatCount: 3,
    significance: "Recited immediately after giving Salam at the end of every obligatory prayer."
  },
  {
    id: 'gen-2',
    prayer: 'General',
    title: 'Tasbeeh Fatimah (SubhanAllah, Alhamdulillah, Allahu Akbar)',
    arabic: 'سُبْحَانَ اللهِ (٣٣) ، اَلْحَمْدُ لِلَّهِ (٣٣) ، اَللَّهُ أَكْبَرُ (٣٣)\nلَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
    transliteration: "SubhanAllah (33x), Alhamdulillah (33x), Allahu Akbar (33x). La ilaha illallahu wahdahu la sharika lahu, lahul-mulku wa lahul-hamdu wa huwa 'ala kulli shay'in qadir (1x).",
    translation: "Glory be to Allah (33x), Praise be to Allah (33x), Allah is the Greatest (33x). None has the right to be worshipped except Allah alone; His is the sovereignty and praise, and He is over all things Omnipotent.",
    reference: "Sahih Muslim 597",
    repeatCount: 100,
    significance: "Whoever recites this after every prayer, their sins will be forgiven even if they were like the foam of the sea."
  },
  {
    id: 'gen-3',
    prayer: 'General',
    title: 'Ayat al-Kursi (The Verse of the Throne)',
    arabic: 'اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ',
    transliteration: "Allahu la ilaha illa Huwal-Hayyul-Qayyum. La ta'khudhuhu sinatuw-wa la nawm...",
    translation: "Allah! There is no deity except Him, the Ever-Living, the Sustainer of all existence. Neither drowsiness overtakes Him nor sleep...",
    reference: "Al-Nasa'i, Al-Sunan al-Kubra 9848",
    repeatCount: 1,
    significance: "Whoever recites Ayat al-Kursi after every obligatory prayer, nothing stands between him and entering Paradise except death."
  },

  // FAJR SPECIFIC
  {
    id: 'fajr-1',
    prayer: 'Fajr',
    title: 'Dua for Beneficial Knowledge, Provision & Accepted Deeds',
    arabic: 'اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا',
    transliteration: "Allahumma inni as'aluka 'ilman nafi'an, wa rizqan tayyiban, wa 'amalan mutaqabbala.",
    translation: "O Allah, I ask You for knowledge that is beneficial, provision that is pure, and deeds that will be accepted.",
    reference: "Sunan Ibn Majah 925",
    repeatCount: 1,
    significance: "The Prophet ﷺ used to recite this specific supplication every morning after the Fajr prayer."
  },
  {
    id: 'fajr-2',
    prayer: 'Fajr',
    title: '10x Affirmation of Tawheed after Fajr',
    arabic: 'لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ يُحْيِي وَيُمِيتُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
    transliteration: "La ilaha illallahu wahdahu la sharika lahu, lahul-mulku wa lahul-hamdu yuhyi wa yumitu wa huwa 'ala kulli shay'in qadir.",
    translation: "None has the right to be worshipped except Allah alone, without partner. To Him belongs sovereignty and praise; He gives life and causes death, and He is over all things Omnipotent.",
    reference: "Jami' at-Tirmidhi 3474",
    repeatCount: 10,
    significance: "Recited 10 times after Fajr before speaking or changing position. Protects from harm until evening."
  },

  // DHUHR SPECIFIC
  {
    id: 'dhuhr-1',
    prayer: 'Dhuhr',
    title: 'Dua for Assistance in Remembrance & Worship',
    arabic: 'اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ',
    transliteration: "Allahumma a'inni 'ala dhikrika wa shukrika wa husni 'ibadatik.",
    translation: "O Allah, help me to remember You, to give thanks to You, and to worship You in the best manner.",
    reference: "Sunan Abi Dawud 1522",
    repeatCount: 1,
    significance: "The Prophet ﷺ advised Mu'adh ibn Jabal never to omit this supplication at the end of prayer."
  },
  {
    id: 'dhuhr-2',
    prayer: 'Dhuhr',
    title: 'Dua for Steadfastness of the Heart',
    arabic: 'يَا مُقَلِّبَ الْقُلُوبِ ثَبِّتْ قَلْبِي عَلَى دِينِكَ',
    transliteration: "Ya Muqallibal-qulubi thabbit qalbi 'ala dinik.",
    translation: "O Turner of the hearts, make my heart steadfast upon Your religion.",
    reference: "Jami' at-Tirmidhi 2140",
    repeatCount: 1,
    significance: "Keeps the heart firm during midday affairs and busy routine."
  },

  // ASR SPECIFIC
  {
    id: 'asr-1',
    prayer: 'Asr',
    title: 'Protection from Anxiety, Laziness & Debts',
    arabic: 'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ، وَالْعَجْزِ وَالْكَسَلِ، وَالْبُخْلِ وَالْجُبْنِ، وَضَلَعِ الدَّيْنِ وَغَلَبَةِ الرِّجَالِ',
    transliteration: "Allahumma inni a'udhu bika minal-hammi wal-hazan, wal-'ajzi wal-kasal, wal-bukhli wal-jubn, wa dala'id-dayni wa ghalabatir-rijal.",
    translation: "O Allah, I seek refuge in You from anxiety and grief, incapacity and laziness, miserliness and cowardice, the burden of debt and oppression by men.",
    reference: "Sahih al-Bukhari 2893",
    repeatCount: 1,
    significance: "Recited in late afternoon to cleanse stress, worry, and fatigue after the workday."
  },
  {
    id: 'asr-2',
    prayer: 'Asr',
    title: 'Dua for Protection from Hellfire',
    arabic: 'اللَّهُمَّ أَجِرْنِي مِنَ النَّارِ',
    transliteration: "Allahumma ajirni minan-nar.",
    translation: "O Allah, protect me from the Fire.",
    reference: "Sunan Abi Dawud 5079",
    repeatCount: 7,
    significance: "Reciting this 7 times shields the servant from Hellfire."
  },

  // MAGHRIB SPECIFIC
  {
    id: 'maghrib-1',
    prayer: 'Maghrib',
    title: 'Post-Maghrib 7x Refuge from Hellfire',
    arabic: 'اللَّهُمَّ أَجِرْنِي مِنَ النَّارِ',
    transliteration: "Allahumma ajirni minan-nar.",
    translation: "O Allah, protect me from the Fire.",
    reference: "Sunan Abi Dawud 5079",
    repeatCount: 7,
    significance: "Whoever says this 7 times after Maghrib before speaking to anyone, if he dies that night, immunity from the Fire is decreed for him."
  },
  {
    id: 'maghrib-2',
    prayer: 'Maghrib',
    title: '10x Tawheed & Protection after Sunset',
    arabic: 'لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ يُحْيِي وَيُمِيتُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
    transliteration: "La ilaha illallahu wahdahu la sharika lahu, lahul-mulku wa lahul-hamdu yuhyi wa yumitu wa huwa 'ala kulli shay'in qadir.",
    translation: "None has the right to be worshipped except Allah alone, without partner. To Him belongs sovereignty and praise; He gives life and causes death, and He is over all things Omnipotent.",
    reference: "Jami' at-Tirmidhi 3534",
    repeatCount: 10,
    significance: "Recited 10 times immediately after Maghrib prayer while still folded in prayer sitting."
  },

  // ISHA SPECIFIC
  {
    id: 'isha-1',
    prayer: 'Isha',
    title: 'Dua for Divine Forgiveness',
    arabic: 'اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي',
    transliteration: "Allahumma innaka 'Afuwwun tuhibbul-'afwa fa'fu 'anni.",
    translation: "O Allah, You are Most Forgiving, and You love forgiveness, so forgive me.",
    reference: "Jami' at-Tirmidhi 3513",
    repeatCount: 1,
    significance: "Cleanses the record of deeds at the end of the day before retiring to rest."
  },
  {
    id: 'isha-2',
    prayer: 'Isha',
    title: 'Supplication for Light in Heart, Sight & Hearing',
    arabic: 'اللَّهُمَّ اجْعَلْ فِي قَلْبِي نُورًا، وَفِي بَصَرِي نُورًا، وَفِي سَمْعِي نُورًا، وَعَنْ يَمِينِي نُورًا، وَعَنْ يَسَارِي نُورًا، وَفَوْقِي نُورًا، وَتَحْتِي نُورًا، وَأَمَامِي نُورًا، وَخَلْفِي نُورًا، وَاجْعَلْ لِي نُورًا',
    transliteration: "Allahumma-j'al fi qalbi nura, wa fi basari nura, wa fi sam'i nura, wa 'an yamini nura, wa 'an yasari nura, wa fawqi nura, wa tahti nura, wa amami nura, wa khalfi nura, waj'al li nura.",
    translation: "O Allah, place light in my heart, light in my sight, light in my hearing, light on my right, light on my left, light above me, light below me, light before me, light behind me, and make for me light.",
    reference: "Sahih Muslim 763",
    repeatCount: 1,
    significance: "Surrounds the soul with spiritual light for the night."
  }
];

export default function PrayerSpecificDuas() {
  const [selectedFilter, setSelectedFilter] = useState<PrayerName>('Fajr');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredDuas = PRAYER_DUAS.filter(
    d => d.prayer === selectedFilter || d.prayer === 'General'
  );

  const handleCopy = (text: string, id: string) => {
    triggerHaptic(15);
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const PRAYER_TABS: Array<{ key: PrayerName; label: string; icon: React.ReactNode }> = [
    { key: 'Fajr', label: 'Fajr', icon: <Sunrise size={14} className="text-amber-400" /> },
    { key: 'Dhuhr', label: 'Dhuhr', icon: <Sun size={14} className="text-amber-300" /> },
    { key: 'Asr', label: 'Asr', icon: <Clock size={14} className="text-amber-500" /> },
    { key: 'Maghrib', label: 'Maghrib', icon: <Sunset size={14} className="text-orange-400" /> },
    { key: 'Isha', label: 'Isha', icon: <Moon size={14} className="text-indigo-400" /> },
    { key: 'General', label: 'All Adhkar', icon: <Sparkles size={14} className="text-emerald-400" /> }
  ];

  return (
    <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 space-y-4 shadow-xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <Sparkles size={16} className="text-amber-500" />
            <span>Prayer-Specific Post-Salah Duas (أذكار دبر الصلاة)</span>
          </h3>
          <p className="text-xs text-slate-400">Authentic prophetic supplications to recite after each of the five daily prayers</p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 overflow-x-auto scrollbar-none">
        {PRAYER_TABS.map(tab => (
          <button
            key={tab.key}
            type="button"
            onClick={() => {
              triggerHaptic(10);
              setSelectedFilter(tab.key);
            }}
            className={`flex-1 min-w-[85px] py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
              selectedFilter === tab.key
                ? 'bg-amber-600 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Duas List */}
      <div className="space-y-4">
        {filteredDuas.map(dua => (
          <div
            key={dua.id}
            className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-3 hover:border-amber-900/40 transition"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-amber-400">{dua.title}</span>
                  {dua.repeatCount && dua.repeatCount > 1 && (
                    <span className="text-[10px] font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded-full">
                      Recite {dua.repeatCount}x
                    </span>
                  )}
                </div>
                <span className="text-[10px] text-slate-500 font-mono">{dua.reference}</span>
              </div>

              <button
                type="button"
                onClick={() => handleCopy(`${dua.arabic}\n\n${dua.translation}\n\n[${dua.reference}]`, dua.id)}
                className="p-1.5 text-slate-400 hover:text-amber-400 bg-slate-900 border border-slate-800 rounded-lg text-xs transition flex items-center gap-1"
                title="Copy dua text"
              >
                {copiedId === dua.id ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                <span>{copiedId === dua.id ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            {/* Arabic Text */}
            <p className="text-slate-100 font-arabic text-right text-base sm:text-lg leading-loose bg-slate-900/60 p-3 rounded-xl border border-slate-800/80" dir="rtl">
              {dua.arabic}
            </p>

            {/* Transliteration */}
            <p className="text-amber-300/90 text-xs italic leading-relaxed">
              "{dua.transliteration}"
            </p>

            {/* Translation */}
            <p className="text-slate-300 text-xs leading-relaxed">
              {dua.translation}
            </p>

            {/* Significance Note */}
            {dua.significance && (
              <div className="p-2.5 bg-amber-950/20 border border-amber-500/20 rounded-xl text-[11px] text-amber-200/90 flex items-center gap-2">
                <BookOpen size={13} className="text-amber-400 shrink-0" />
                <span>{dua.significance}</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
