import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Trash2, Bookmark, ExternalLink, HardDrive, CheckCircle2 } from 'lucide-react';
import { 
  getCachedQuranBookmarks, 
  removeCachedQuranBookmark, 
  cacheQuranBookmarksBulk,
  QuranBookmarkRecord 
} from '../lib/db';
import { triggerHaptic } from '../lib/haptics';

export default function Bookmarks() {
  const [bookmarks, setBookmarks] = useState<QuranBookmarkRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadBookmarks = async () => {
      setIsLoading(true);
      try {
        // 1. Try to load from IndexedDB
        const cached = await getCachedQuranBookmarks();
        
        // 2. Also check localStorage to merge any recent changes
        const localRaw = localStorage.getItem('bookmarkedAyahs');
        const localNumbers: number[] = localRaw ? JSON.parse(localRaw) : [];

        // Build combined map
        const map = new Map<number, QuranBookmarkRecord>();

        // Populate from IndexedDB
        cached.forEach(b => {
          map.set(Number(b.globalNumber), b);
        });

        // Populate from localStorage numbers
        localNumbers.forEach(globalNumber => {
          if (!map.has(globalNumber)) {
            map.set(globalNumber, {
              id: globalNumber,
              globalNumber,
              surahId: Math.floor(globalNumber / 1000) || 1,
              timestamp: Date.now()
            });
          }
        });

        const merged = Array.from(map.values()).sort((a, b) => a.globalNumber - b.globalNumber);
        setBookmarks(merged);

        // Keep IndexedDB synced with merged set
        if (merged.length > 0) {
          await cacheQuranBookmarksBulk(merged);
        }
      } catch (err) {
        console.warn('Failed to load bookmarks from IndexedDB:', err);
        const localRaw = localStorage.getItem('bookmarkedAyahs');
        const localNumbers: number[] = localRaw ? JSON.parse(localRaw) : [];
        setBookmarks(localNumbers.map(n => ({
          id: n,
          globalNumber: n,
          surahId: Math.floor(n / 1000) || 1,
          timestamp: Date.now()
        })));
      } finally {
        setIsLoading(false);
      }
    };

    loadBookmarks();
  }, []);

  const removeBookmark = async (globalNumber: number) => {
    triggerHaptic(20);
    const next = bookmarks.filter(b => b.globalNumber !== globalNumber);
    setBookmarks(next);

    // Update localStorage
    const numbers = next.map(b => b.globalNumber);
    localStorage.setItem('bookmarkedAyahs', JSON.stringify(numbers));

    // Update IndexedDB
    try {
      await removeCachedQuranBookmark(globalNumber);
    } catch (err) {
      console.warn('Failed to remove from IndexedDB:', err);
    }
  };

  return (
    <div className="space-y-5 pb-12">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-amber-900/30 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl text-amber-500 font-serif font-bold">Saved Quran Bookmarks</h2>
            <span className="p-1 rounded-lg bg-amber-500/10 text-amber-400">
              <Bookmark size={20} />
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Your saved verses are stored in local IndexedDB and available offline at all times.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-3 py-1.5 rounded-xl self-start sm:self-auto">
          <HardDrive size={14} />
          <span>Offline Cached ({bookmarks.length})</span>
        </div>
      </header>

      {isLoading ? (
        <div className="p-8 text-center text-slate-500 text-sm">
          Loading saved bookmarks from IndexedDB...
        </div>
      ) : bookmarks.length === 0 ? (
        <div className="bg-slate-900/80 border border-amber-900/30 rounded-2xl p-8 text-center space-y-3">
          <div className="w-12 h-12 mx-auto rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
            <Bookmark size={24} />
          </div>
          <h3 className="text-base font-bold text-slate-200">No Bookmarked Verses Yet</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            While reading the Quran, tap the bookmark icon on any Ayah to save it here for instant offline reading.
          </p>
          <Link
            to="/quran"
            className="inline-block mt-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition"
          >
            Explore Holy Quran
          </Link>
        </div>
      ) : (
        <div className="grid gap-3">
          {bookmarks.map(item => {
            const surahTarget = item.surahId || Math.floor(item.globalNumber / 1000) || 1;
            return (
              <div 
                key={item.globalNumber} 
                className="flex items-center justify-between p-4 bg-slate-900/90 border border-amber-900/30 hover:border-amber-700/50 rounded-2xl shadow-md transition group"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-100 group-hover:text-amber-300 transition-colors">
                      Ayah #{item.globalNumber}
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                      Surah {surahTarget}
                    </span>
                    <span className="text-[10px] text-emerald-400 flex items-center gap-0.5">
                      <CheckCircle2 size={11} /> Saved in IndexedDB
                    </span>
                  </div>
                  {item.text && (
                    <p className="text-xs text-amber-200/90 font-serif line-clamp-1" dir="rtl">
                      {item.text}
                    </p>
                  )}
                  {item.translation && (
                    <p className="text-xs text-slate-400 line-clamp-1 italic">
                      "{item.translation}"
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Link 
                    to={`/quran/${surahTarget}`} 
                    className="flex items-center gap-1 text-xs font-semibold px-3 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-xl transition"
                  >
                    <span>Read</span>
                    <ExternalLink size={12} />
                  </Link>

                  <button 
                    type="button"
                    onClick={() => removeBookmark(item.globalNumber)} 
                    className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800/80 rounded-xl transition"
                    title="Remove Bookmark"
                    aria-label="Remove Bookmark"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
