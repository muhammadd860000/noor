import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Volume2, VolumeX, Sparkles, RefreshCw, ChevronRight, Check } from 'lucide-react';
import { duas } from '../data/dua_content';
import { triggerHaptic, triggerButtonClickHaptic } from '../lib/haptics';

const FAVORITE_DUAS_KEY = 'noor_favorite_duas';

export default function DailyDuaWidget() {
  const scheduledIndex = useMemo(() => {
    const now = new Date();
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now.getTime() - start.getTime();
    const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));
    return dayOfYear % duas.length;
  }, []);

  const [currentIndex, setCurrentIndex] = useState(scheduledIndex);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [favoriteIds, setFavoriteIds] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem(FAVORITE_DUAS_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const currentDua = duas[currentIndex] || duas[0];
  const isFavorited = favoriteIds.includes(currentIndex);

  useEffect(() => {
    try {
      localStorage.setItem(FAVORITE_DUAS_KEY, JSON.stringify(favoriteIds));
    } catch (e) {
      console.warn(e);
    }
  }, [favoriteIds]);

  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleToggleFavorite = () => {
    triggerHaptic(15);
    setFavoriteIds(prev => 
      prev.includes(currentIndex)
        ? prev.filter(id => id !== currentIndex)
        : [...prev, currentIndex]
    );
  };

  const handleShuffle = () => {
    triggerHaptic(20);
    let nextIdx = Math.floor(Math.random() * duas.length);
    if (nextIdx === currentIndex && duas.length > 1) {
      nextIdx = (nextIdx + 1) % duas.length;
    }
    setCurrentIndex(nextIdx);
    if (isPlayingAudio && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
    }
  };

  const handleToggleSpeech = () => {
    triggerButtonClickHaptic();
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(currentDua.arabic);
    utterance.lang = 'ar-SA';
    utterance.rate = 0.9;
    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <section 
      aria-label="Daily Dua Widget"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-600/50"
    >
      {/* Ambient background glow */}
      <div aria-hidden="true" className="absolute -top-16 -right-16 w-40 h-40 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" />

      {/* Header bar */}
      <div className="flex items-center justify-between pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-2.5">
          <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Sparkles size={18} />
          </span>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>Daily Dua of the Day</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30">
                {currentDua.title}
              </span>
            </h3>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={handleShuffle}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition"
            title="Discover another Dua"
            aria-label="Shuffle Dua"
          >
            <RefreshCw size={15} />
          </button>

          <button
            type="button"
            onClick={handleToggleFavorite}
            className={`p-2 rounded-lg transition ${
              isFavorited ? 'text-rose-400 bg-rose-500/10 border border-rose-500/30' : 'text-slate-400 hover:text-rose-400 hover:bg-slate-800'
            }`}
            title={isFavorited ? 'Remove from favorites' : 'Mark as favorite'}
            aria-label="Toggle favorite Dua"
          >
            <Heart size={16} fill={isFavorited ? 'currentColor' : 'none'} />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="pt-4 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <p 
            dir="rtl" 
            lang="ar"
            className="text-xl sm:text-2xl text-amber-100 font-serif leading-[2.2] text-right w-full select-text"
          >
            {currentDua.arabic}
          </p>
          <button
            type="button"
            onClick={handleToggleSpeech}
            className={`p-2 rounded-xl shrink-0 transition ${
              isPlayingAudio ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-900 text-amber-400 hover:bg-slate-800 border border-amber-900/30'
            }`}
            title="Listen to pronunciation"
          >
            {isPlayingAudio ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>
        </div>

        <p className="text-slate-300 text-xs sm:text-sm italic leading-relaxed">
          "{currentDua.meaning}"
        </p>
      </div>

      {/* Footer Navigation */}
      <div className="pt-4 mt-4 border-t border-amber-900/20 flex items-center justify-between text-xs">
        <span className="text-slate-400">
          {isFavorited ? 'Saved to your quick favorites ⭐' : 'Tap heart icon to save for quick access'}
        </span>
        <Link 
          to="/duas" 
          className="text-amber-500 hover:text-amber-400 font-medium flex items-center gap-1 transition-colors"
        >
          <span>Explore All Duas</span>
          <ChevronRight size={14} />
        </Link>
      </div>
    </section>
  );
}
