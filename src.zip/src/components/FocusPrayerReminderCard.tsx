import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  Heart, 
  Sparkles, 
  Bell, 
  BellOff, 
  RotateCcw, 
  Send, 
  Check, 
  ShieldCheck, 
  Coffee, 
  SlidersHorizontal 
} from 'lucide-react';
import { 
  getFocusPrayerPreferences, 
  saveFocusPrayerPreferences, 
  getActiveFocusMinutes, 
  resetFocusSession, 
  getNextUpcomingPrayer, 
  checkAndTriggerIntelligentPrayerReminder, 
  FocusPrayerPreferences 
} from '../lib/focusPrayerReminder';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export default function FocusPrayerReminderCard() {
  const [prefs, setPrefs] = useState<FocusPrayerPreferences>(getFocusPrayerPreferences);
  const [focusMinutes, setFocusMinutes] = useState(getActiveFocusMinutes);
  const [nextPrayer, setNextPrayer] = useState(getNextUpcomingPrayer);
  const [testAlertSent, setTestAlertSent] = useState(false);
  const [activeAlert, setActiveAlert] = useState<{
    title: string;
    message: string;
    prayerName: string;
  } | null>(null);

  useEffect(() => {
    // Update live focus time and next prayer countdown every 10 seconds
    const interval = setInterval(() => {
      setFocusMinutes(getActiveFocusMinutes());
      setNextPrayer(getNextUpcomingPrayer());
    }, 10000);

    const handlePrefsUpdate = (e: Event) => {
      const customEvent = e as CustomEvent<FocusPrayerPreferences>;
      if (customEvent.detail) setPrefs(customEvent.detail);
      else setPrefs(getFocusPrayerPreferences());
    };

    const handleSessionReset = () => {
      setFocusMinutes(0);
    };

    const handleInAppAlert = (e: Event) => {
      const customEvent = e as CustomEvent<{ title: string; message: string; prayerName: string }>;
      if (customEvent.detail) {
        setActiveAlert(customEvent.detail);
      }
    };

    window.addEventListener('focus-prayer-prefs-updated', handlePrefsUpdate);
    window.addEventListener('focus-session-reset', handleSessionReset);
    window.addEventListener('intelligent-prayer-break-alert', handleInAppAlert);

    return () => {
      clearInterval(interval);
      window.removeEventListener('focus-prayer-prefs-updated', handlePrefsUpdate);
      window.removeEventListener('focus-session-reset', handleSessionReset);
      window.removeEventListener('intelligent-prayer-break-alert', handleInAppAlert);
    };
  }, []);

  const handleToggleEnable = () => {
    triggerHaptic(20);
    const updated = { ...prefs, enabled: !prefs.enabled };
    setPrefs(updated);
    saveFocusPrayerPreferences(updated);
    if (updated.enabled) triggerSuccessHaptic();
  };

  const handleThresholdChange = (minutes: number) => {
    triggerButtonClickHaptic();
    const updated = { ...prefs, focusThresholdMinutes: minutes };
    setPrefs(updated);
    saveFocusPrayerPreferences(updated);
  };

  const handleWindowChange = (minutes: number) => {
    triggerButtonClickHaptic();
    const updated = { ...prefs, approachingWindowMinutes: minutes };
    setPrefs(updated);
    saveFocusPrayerPreferences(updated);
  };

  const handleResetFocusSession = () => {
    triggerButtonClickHaptic();
    resetFocusSession();
    setFocusMinutes(0);
  };

  const handleTestTrigger = async () => {
    triggerButtonClickHaptic();
    const currentNext = getNextUpcomingPrayer();

    const title = `🕊️ Gentle Break for ${currentNext.name} Approaching`;
    const message = `You've been focused in Noor for ${Math.max(focusMinutes, prefs.focusThresholdMinutes)} minutes. ${currentNext.name} is in ${currentNext.minutesRemaining} minutes (${currentNext.timeStr}). Take a peaceful break to make Wudu and refresh your heart for Salah.`;

    setActiveAlert({
      title,
      message,
      prayerName: currentNext.name,
    });

    setTestAlertSent(true);
    triggerSuccessHaptic();

    // Trigger custom event so banner appears globally
    window.dispatchEvent(
      new CustomEvent('intelligent-prayer-break-alert', {
        detail: {
          title,
          message,
          prayerName: currentNext.name,
          minutesRemaining: currentNext.minutesRemaining,
          focusMinutes: Math.max(focusMinutes, prefs.focusThresholdMinutes),
        },
      })
    );

    setTimeout(() => setTestAlertSent(false), 4000);
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-5 shadow-xl space-y-4">
      {/* Card Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30">
            <Coffee size={20} />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>Intelligent Prayer Reminder</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold">
                Salah Break Protection
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Gently alerts you to pause for Salah when you've been reading or active in the app for a long duration
            </p>
          </div>
        </div>

        {/* Enable / Disable Toggle Button */}
        <button
          type="button"
          onClick={handleToggleEnable}
          className={`px-3 py-1.5 rounded-xl font-bold text-xs transition flex items-center gap-1.5 self-start sm:self-auto ${
            prefs.enabled
              ? 'bg-amber-600 text-slate-950 shadow-md shadow-amber-600/20'
              : 'bg-slate-950 text-slate-400 border border-slate-800'
          }`}
        >
          {prefs.enabled ? <Bell size={14} className="fill-slate-950" /> : <BellOff size={14} />}
          <span>{prefs.enabled ? 'Reminders Active' : 'Enable Reminders'}</span>
        </button>
      </div>

      {/* Live Active Session & Prayer Status Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="p-3.5 bg-slate-950/80 border border-amber-900/30 rounded-xl flex items-center justify-between">
          <div className="space-y-0.5">
            <span className="text-[11px] text-slate-400 block font-medium">Active App Session</span>
            <span className="text-sm font-bold text-amber-400 flex items-center gap-1.5 font-mono">
              <Clock size={15} />
              <span>{focusMinutes} mins focus</span>
            </span>
          </div>
          <button
            type="button"
            onClick={handleResetFocusSession}
            title="Reset focus session counter"
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-amber-300 border border-slate-800 transition"
          >
            <RotateCcw size={14} />
          </button>
        </div>

        <div className="p-3.5 bg-slate-950/80 border border-amber-900/30 rounded-xl space-y-0.5">
          <span className="text-[11px] text-slate-400 block font-medium">Next Upcoming Prayer</span>
          <span className="text-sm font-bold text-amber-300 flex items-center gap-1.5">
            <span>🕌 {nextPrayer.name}</span>
            <span className="text-xs font-mono text-slate-400">in {nextPrayer.minutesRemaining} mins ({nextPrayer.timeStr})</span>
          </span>
        </div>
      </div>

      {/* Active Gentle Alert Banner (If triggered or tested) */}
      {activeAlert && (
        <div className="p-4 bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-950 border border-amber-500/50 rounded-xl space-y-2 animate-fadeIn">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
              <Sparkles size={15} />
              <span>{activeAlert.title}</span>
            </span>
            <button
              type="button"
              onClick={() => setActiveAlert(null)}
              className="text-slate-400 hover:text-slate-200 text-xs font-bold"
            >
              Dismiss
            </button>
          </div>
          <p className="text-xs text-slate-200 leading-relaxed">{activeAlert.message}</p>
        </div>
      )}

      {/* Configuration Sliders & Toggles */}
      <div className="space-y-3 pt-1">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
          <SlidersHorizontal size={14} className="text-amber-400" />
          <span>Reminder Sensitivity Settings</span>
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          {/* Active Focus Threshold Option */}
          <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
            <span className="text-slate-300 font-semibold block">Continuous Focus Threshold</span>
            <p className="text-[11px] text-slate-400">Remind after this duration of active app usage:</p>
            <div className="flex items-center gap-1.5 pt-1">
              {[15, 20, 30, 45].map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => handleThresholdChange(m)}
                  className={`flex-1 py-1.5 rounded-lg border text-[11px] font-bold font-mono transition ${
                    prefs.focusThresholdMinutes === m
                      ? 'bg-amber-500 text-slate-950 border-amber-400'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {m}m
                </button>
              ))}
            </div>
          </div>

          {/* Prayer Approaching Window Option */}
          <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
            <span className="text-slate-300 font-semibold block">Prayer Approaching Window</span>
            <p className="text-[11px] text-slate-400">Notify when next prayer is within:</p>
            <div className="flex items-center gap-1.5 pt-1">
              {[15, 20, 25, 30].map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => handleWindowChange(m)}
                  className={`flex-1 py-1.5 rounded-lg border text-[11px] font-bold font-mono transition ${
                    prefs.approachingWindowMinutes === m
                      ? 'bg-amber-500 text-slate-950 border-amber-400'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {m}m
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Live Test Trigger Button */}
      <button
        type="button"
        onClick={handleTestTrigger}
        className="w-full py-2.5 px-3 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold text-xs rounded-xl transition flex items-center justify-center gap-2"
      >
        <Send size={14} />
        <span>Test Gentle Salah Break Alert</span>
      </button>

      {testAlertSent && (
        <div className="p-2.5 bg-emerald-950/30 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
          <Check size={14} className="text-emerald-400" />
          <span>Gentle prayer reminder dispatched as in-app alert and push notification!</span>
        </div>
      )}
    </div>
  );
}
