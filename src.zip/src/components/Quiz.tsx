import React, { useState, useMemo } from 'react';
import { 
  BookOpen, 
  HelpCircle, 
  CheckCircle2, 
  RotateCcw, 
  Award, 
  Sparkles, 
  ChevronRight,
  Filter,
  Trophy,
  Zap
} from 'lucide-react';
import { quizQuestions, QuizQuestion, QuestionCategory } from '../data/quiz';
import DailyQuranicQuiz from './DailyQuranicQuiz';
import QuizLeaderboard from './QuizLeaderboard';
import { recordQuizAttempt, calculatePoints } from '../lib/quizLeaderboard';
import { triggerHaptic, triggerSuccessHaptic } from '../lib/haptics';

type TabMode = 'daily' | 'practice' | 'leaderboard';

export default function Quiz() {
  const [activeTab, setActiveTab] = useState<TabMode>('daily');
  const [selectedCategory, setSelectedCategory] = useState<'All' | QuestionCategory>('All');
  const [questionIndex, setQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [lastEarnedPoints, setLastEarnedPoints] = useState<number | null>(null);

  const filteredQuestions: QuizQuestion[] = useMemo(() => {
    return selectedCategory === 'All' 
      ? quizQuestions 
      : quizQuestions.filter(q => q.category === selectedCategory);
  }, [selectedCategory]);

  const currentQuestion: QuizQuestion = filteredQuestions[questionIndex] || filteredQuestions[0];

  const handleOptionSelect = (index: number) => {
    if (selectedOption !== null) return;
    const isCorrect = index === currentQuestion.answer;
    triggerHaptic(isCorrect ? 35 : 15);
    setSelectedOption(index);
    if (isCorrect) setScore(prev => prev + 1);
  };

  const handleNext = () => {
    triggerHaptic(15);
    if (questionIndex < filteredQuestions.length - 1) {
      setQuestionIndex(prev => prev + 1);
      setSelectedOption(null);
    } else {
      triggerSuccessHaptic();
      const record = recordQuizAttempt('practice', selectedCategory, score, filteredQuestions.length);
      setLastEarnedPoints(record.pointsEarned);
      setShowResults(true);
    }
  };

  const resetQuiz = () => {
    triggerHaptic(20);
    setQuestionIndex(0);
    setScore(0);
    setShowResults(false);
    setSelectedOption(null);
    setLastEarnedPoints(null);
  };

  const handleCategoryChange = (cat: 'All' | QuestionCategory) => {
    triggerHaptic(15);
    setSelectedCategory(cat);
    resetQuiz();
  };

  const optionLetters = ['A', 'B', 'C', 'D'];
  const progressPercent = Math.round(((questionIndex + (selectedOption !== null ? 1 : 0)) / filteredQuestions.length) * 100);

  return (
    <div className="space-y-6 pb-12">
      {/* Page Header */}
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-2xl text-amber-500 font-serif">Islamic Quiz & Leaderboard</h2>
          <p className="text-xs text-slate-400 mt-1">
            Strengthen your knowledge of the Holy Quran, Prophetic Seerah, and Islamic history
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex bg-slate-900 border border-amber-900/30 p-1 rounded-xl self-start sm:self-auto text-xs">
          <button
            type="button"
            onClick={() => {
              triggerHaptic(15);
              setActiveTab('daily');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
              activeTab === 'daily'
                ? 'bg-amber-600 text-slate-950 font-bold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles size={14} />
            <span>Daily Quiz</span>
          </button>
          <button
            type="button"
            onClick={() => {
              triggerHaptic(15);
              setActiveTab('practice');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
              activeTab === 'practice'
                ? 'bg-amber-600 text-slate-950 font-bold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen size={14} />
            <span>Practice Arena</span>
          </button>
          <button
            type="button"
            onClick={() => {
              triggerHaptic(15);
              setActiveTab('leaderboard');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
              activeTab === 'leaderboard'
                ? 'bg-amber-600 text-slate-950 font-bold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Trophy size={14} />
            <span>Leaderboard & Stats</span>
          </button>
        </div>
      </header>

      {/* Featured Daily Quranic Quiz Component */}
      {activeTab === 'daily' && (
        <div className="block">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-semibold tracking-wider uppercase text-amber-500/90 flex items-center gap-1.5">
              <Sparkles size={13} />
              Featured Challenge of the Day
            </span>
          </div>
          <DailyQuranicQuiz />
        </div>
      )}

      {/* Leaderboard & Stats Tab */}
      {activeTab === 'leaderboard' && (
        <div className="block">
          <QuizLeaderboard />
        </div>
      )}

      {/* Practice Mode Arena */}
      {activeTab === 'practice' && (
        <section 
          aria-label="Practice Arena" 
          className="space-y-4 block"
        >
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h3 className="text-base font-semibold text-slate-200 flex items-center gap-2">
              <BookOpen size={16} className="text-amber-500" />
              <span>Practice Arena & Question Library</span>
            </h3>
            <p className="text-xs text-slate-400">
              Explore {filteredQuestions.length} curated questions across core Islamic subjects
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {(['All', 'Quran', 'Seerah', 'History', 'Prophets'] as const).map(cat => (
              <button
                key={cat}
                type="button"
                onClick={() => handleCategoryChange(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? 'bg-amber-600 text-slate-950 font-bold shadow-sm'
                    : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-amber-900/30'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Practice Quiz Active Card or Results */}
        {showResults ? (
          <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-8 text-center space-y-5 shadow-xl animate-fadeIn">
            <div className="w-16 h-16 mx-auto rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500">
              <Award size={32} />
            </div>

            <div className="space-y-1">
              <h4 className="text-2xl text-amber-500 font-serif font-bold">Quiz Complete!</h4>
              <p className="text-xs text-slate-400">Category: {selectedCategory}</p>
            </div>

            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 max-w-xs mx-auto space-y-1">
              <span className="text-4xl font-mono font-bold text-slate-100">{score}</span>
              <span className="text-slate-400 font-mono text-lg"> / {filteredQuestions.length}</span>
              <p className="text-xs text-amber-400 font-medium">
                {Math.round((score / (filteredQuestions.length || 1)) * 100)}% Correct
              </p>
              {lastEarnedPoints !== null && (
                <div className="pt-2 border-t border-slate-800 flex items-center justify-center gap-1.5 text-xs font-mono font-bold text-amber-400">
                  <Zap size={14} className="text-amber-500" />
                  <span>+{lastEarnedPoints} XP Added to Leaderboard</span>
                </div>
              )}
            </div>

            <p className="text-sm text-slate-300 max-w-md mx-auto italic">
              {score === filteredQuestions.length 
                ? "Masha'Allah! Outstanding mastery of Islamic knowledge!" 
                : score >= Math.ceil(filteredQuestions.length * 0.7)
                  ? "Great achievement! Continue studying to sharpen your understanding." 
                  : "A noble effort! Review the explanations to deepen your Quranic reflection."}
            </p>

            <div className="flex flex-wrap items-center justify-center gap-3">
              <button 
                type="button"
                onClick={resetQuiz} 
                className="bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold py-2.5 px-5 rounded-xl flex items-center justify-center gap-2 transition-colors shadow-lg shadow-amber-600/20 active:scale-95 text-xs"
              >
                <RotateCcw size={15} />
                <span>Practice Again</span>
              </button>

              <button 
                type="button"
                onClick={() => {
                  triggerHaptic(15);
                  setActiveTab('leaderboard');
                }} 
                className="bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold py-2.5 px-5 rounded-xl flex items-center justify-center gap-2 border border-amber-900/30 transition-colors active:scale-95 text-xs"
              >
                <Trophy size={15} />
                <span>View Leaderboard</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 space-y-5 shadow-xl">
            {/* Top Bar: Question Index & Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs text-slate-400">
                <span className="font-medium text-amber-500/90 flex items-center gap-1.5">
                  <HelpCircle size={14} />
                  Question {questionIndex + 1} of {filteredQuestions.length}
                </span>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                    {currentQuestion.category} · {currentQuestion.difficulty}
                  </span>
                  <span className="font-mono text-slate-400">Score: {score}</span>
                </div>
              </div>

              {/* Progress track */}
              <div className="w-full bg-slate-800/80 rounded-full h-1.5 overflow-hidden">
                <div 
                  className="bg-amber-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            {/* Question Text */}
            <h4 className="text-base sm:text-lg text-slate-100 font-medium leading-relaxed">
              {currentQuestion.question}
            </h4>
            
            {/* Options List */}
            <div className="space-y-2.5">
              {currentQuestion.options.map((option, index) => {
                const isSelected = selectedOption === index;
                const isCorrect = index === currentQuestion.answer;

                let btnStyle = 'bg-slate-950/60 hover:bg-slate-800/60 border-slate-800 text-slate-200';
                let badgeStyle = 'bg-slate-800 text-slate-400 border-slate-700';

                if (selectedOption !== null) {
                  if (isCorrect) {
                    btnStyle = 'bg-emerald-950/40 border-emerald-500/70 text-emerald-200 font-medium ring-1 ring-emerald-500/30';
                    badgeStyle = 'bg-emerald-500 text-slate-950 font-bold border-emerald-400';
                  } else if (isSelected && !isCorrect) {
                    btnStyle = 'bg-red-950/40 border-red-500/60 text-red-200 line-through opacity-85';
                    badgeStyle = 'bg-red-500 text-slate-950 font-bold border-red-400';
                  } else {
                    btnStyle = 'bg-slate-950/30 border-slate-900 text-slate-500 opacity-60';
                  }
                }

                return (
                  <button 
                    key={index}
                    type="button"
                    disabled={selectedOption !== null}
                    onClick={() => handleOptionSelect(index)}
                    className={`w-full p-3.5 rounded-xl text-left border flex items-center gap-3 transition-all duration-200 select-none ${
                      selectedOption === null ? 'active:scale-[0.99] cursor-pointer' : 'cursor-default'
                    } ${btnStyle}`}
                  >
                    <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-mono font-semibold border flex-shrink-0 transition-colors ${badgeStyle}`}>
                      {selectedOption !== null && isCorrect ? (
                        '✓'
                      ) : selectedOption !== null && isSelected ? (
                        '✕'
                      ) : (
                        optionLetters[index]
                      )}
                    </span>
                    <span className="text-sm">{option}</span>
                  </button>
                );
              })}
            </div>
            
            {/* Answer Explanation Box revealed after selection */}
            {selectedOption !== null && (
              <div className="p-4 bg-slate-950/80 border border-amber-900/30 rounded-xl space-y-2 text-xs animate-fadeIn">
                <div className="flex items-center gap-1.5 font-semibold text-amber-400">
                  <BookOpen size={14} />
                  <span>Explanation & Context</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  {currentQuestion.explanation}
                </p>
                {currentQuestion.reference && (
                  <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400">
                    <span className="text-slate-500 font-mono">Reference: </span>
                    <span className="text-slate-300">{currentQuestion.reference}</span>
                  </div>
                )}
              </div>
            )}

            {/* Next Question / Finish Button */}
            {selectedOption !== null && (
              <div className="pt-2">
                <button 
                  type="button"
                  onClick={handleNext} 
                  className="w-full bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors shadow-lg shadow-amber-600/20 active:scale-95"
                >
                  <span>{questionIndex < filteredQuestions.length - 1 ? 'Next Question' : 'View Results'}</span>
                  <ChevronRight size={16} />
                </button>
              </div>
            )}
          </div>
        )}
      </section>
      )}
    </div>
  );
}
