import React, { useState, useEffect, useMemo } from 'react';
import { 
  BookHeart, 
  PenLine, 
  Sparkles, 
  Check, 
  Trash2, 
  Star, 
  Copy, 
  Share2, 
  Lock, 
  ChevronDown, 
  ChevronUp, 
  Clock, 
  Plus, 
  Filter, 
  Search,
  Smile,
  Edit3
} from 'lucide-react';
import { triggerHaptic } from '../lib/haptics';

export type JournalTag = 'intention' | 'reflection' | 'gratitude' | 'tadabbur' | 'dua';

export interface JournalEntry {
  id: string;
  date: string; // "YYYY-MM-DD"
  timestamp: number;
  tag: JournalTag;
  content: string;
  mood?: string;
  isPinned?: boolean;
}

const TAG_CONFIG: Record<JournalTag, { label: string; arabic: string; color: string; prompt: string }> = {
  intention: {
    label: 'Intention',
    arabic: 'النية',
    color: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    prompt: 'Set a sincere intention for today (e.g., praying on time, smiling, controlling anger)...'
  },
  gratitude: {
    label: 'Gratitude (Shukr)',
    arabic: 'الشكر',
    color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    prompt: 'Name 3 blessings Allah granted you today that you often overlook...'
  },
  reflection: {
    label: 'Daily Reflection',
    arabic: 'التفكر',
    color: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    prompt: 'What spiritual lesson or test did you encounter today?'
  },
  tadabbur: {
    label: 'Quran Tadabbur',
    arabic: 'التدبر',
    color: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
    prompt: 'Note an Ayah that touched your heart today and how you will act upon it...'
  },
  dua: {
    label: 'Personal Du\'a',
    arabic: 'المناجاة',
    color: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
    prompt: 'Pour out your heart in a personal, intimate supplication to Allah...'
  }
};

const MOODS = [
  { icon: '🤲', label: 'Peaceful / Khushu\'' },
  { icon: '🌿', label: 'Grateful' },
  { icon: '💡', label: 'Inspired' },
  { icon: '🛡️', label: 'Seeking Strength' },
  { icon: '🤍', label: 'Seeking Forgiveness' }
];

const STORAGE_KEY = 'noor_spiritual_journal_entries';

export default function SpiritualJournaling() {
  const todayStr = useMemo(() => new Date().toISOString().slice(0, 10), []);

  const [entries, setEntries] = useState<JournalEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }

    // Default gentle initial entries to demonstrate feature
    return [
      {
        id: 'seed-1',
        date: todayStr,
        timestamp: Date.now() - 1000 * 60 * 60 * 3,
        tag: 'intention',
        content: 'Bismillah. My intention today is to perform all five prayers with full presence of heart (Khushu\'), and to maintain patience with family throughout the day.',
        mood: '🤲',
        isPinned: true
      },
      {
        id: 'seed-2',
        date: new Date(Date.now() - 86400000).toISOString().slice(0, 10),
        timestamp: Date.now() - 86400000,
        tag: 'gratitude',
        content: 'Alhamdulillah for good health, peaceful shelter, and the serenity found after reciting Surah Al-Mulk before sleeping.',
        mood: '🌿',
        isPinned: false
      }
    ];
  });

  // Form states
  const [selectedTag, setSelectedTag] = useState<JournalTag>('intention');
  const [content, setContent] = useState('');
  const [selectedMood, setSelectedMood] = useState<string>('🤲');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilterTag, setActiveFilterTag] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Persist entries
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
    } catch (e) {
      console.warn(e);
    }
  }, [entries]);

  // Handle Save
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    triggerHaptic(25);

    if (editingId) {
      setEntries(prev => prev.map(entry => {
        if (entry.id === editingId) {
          return {
            ...entry,
            tag: selectedTag,
            content: content.trim(),
            mood: selectedMood,
            timestamp: Date.now()
          };
        }
        return entry;
      }));
      setEditingId(null);
    } else {
      const newEntry: JournalEntry = {
        id: `journal_${Date.now()}`,
        date: todayStr,
        timestamp: Date.now(),
        tag: selectedTag,
        content: content.trim(),
        mood: selectedMood,
        isPinned: false
      };
      setEntries(prev => [newEntry, ...prev]);
    }

    setContent('');
    setIsFormOpen(false);
  };

  // Start edit
  const handleEdit = (entry: JournalEntry) => {
    triggerHaptic(15);
    setEditingId(entry.id);
    setSelectedTag(entry.tag);
    setContent(entry.content);
    setSelectedMood(entry.mood || '🤲');
    setIsFormOpen(true);
  };

  // Delete
  const handleDelete = (id: string) => {
    triggerHaptic(20);
    setEntries(prev => prev.filter(e => e.id !== id));
    if (editingId === id) {
      setEditingId(null);
      setContent('');
      setIsFormOpen(false);
    }
  };

  // Pin/Star
  const handleTogglePin = (id: string) => {
    triggerHaptic(15);
    setEntries(prev => prev.map(e => e.id === id ? { ...e, isPinned: !e.isPinned } : e));
  };

  // Copy entry
  const handleCopy = async (entry: JournalEntry) => {
    triggerHaptic(15);
    const dateFormatted = new Date(entry.timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
    const text = `📓 Spiritual Reflection (${dateFormatted} · ${TAG_CONFIG[entry.tag].label})\n\n"${entry.content}"\n\n— Recorded in Noor`;
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(entry.id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (err) {
      console.warn(err);
    }
  };

  // Filtered and sorted entries (pinned first, then chronological)
  const filteredEntries = useMemo(() => {
    return entries
      .filter(entry => {
        if (activeFilterTag !== 'all' && entry.tag !== activeFilterTag) return false;
        if (!searchQuery.trim()) return true;
        const q = searchQuery.toLowerCase();
        return entry.content.toLowerCase().includes(q) || TAG_CONFIG[entry.tag].label.toLowerCase().includes(q);
      })
      .sort((a, b) => {
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        return b.timestamp - a.timestamp;
      });
  }, [entries, activeFilterTag, searchQuery]);

  const hasWrittenToday = entries.some(e => e.date === todayStr);

  return (
    <section 
      aria-label="Spiritual Journaling"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-700/50 md:col-span-2 space-y-5"
    >
      {/* Decorative ambient flares */}
      <div 
        aria-hidden="true" 
        className="absolute -top-16 -right-16 w-48 h-48 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" 
      />
      <div 
        aria-hidden="true" 
        className="absolute -bottom-16 -left-16 w-48 h-48 rounded-full bg-purple-500/5 blur-3xl pointer-events-none" 
      />

      {/* Header bar: Title, Privacy Badge, and Write Button */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <span className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <BookHeart size={20} />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-100 tracking-tight">
                Spiritual Journaling
              </h3>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Daily Reflections & Niyyah
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Record daily intentions, moments of gratitude (Shukr), and Quranic reflections
            </p>
          </div>
        </div>

        {/* Action button & Local Privacy Badge */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="flex items-center gap-1 text-[11px] text-slate-500 bg-slate-950/60 border border-slate-800 px-2.5 py-1 rounded-xl font-mono">
            <Lock size={11} /> Saved locally
          </span>

          <button
            type="button"
            onClick={() => {
              triggerHaptic(15);
              if (isFormOpen && editingId) {
                setEditingId(null);
                setContent('');
              }
              setIsFormOpen(!isFormOpen);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs transition-all shadow-md shadow-amber-600/20 active:scale-95"
          >
            {isFormOpen ? (
              <>
                <ChevronUp size={14} />
                <span>Close</span>
              </>
            ) : (
              <>
                <PenLine size={14} />
                <span>{hasWrittenToday ? 'New Entry' : 'Write Today\'s Reflection'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Interactive Writing Composer Form (Collapsible) */}
      {isFormOpen && (
        <form onSubmit={handleSave} className="p-4 sm:p-5 bg-slate-950/90 border border-amber-500/30 rounded-2xl space-y-4 animate-fadeIn shadow-2xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <span className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
              <Sparkles size={14} />
              {editingId ? 'Edit Spiritual Note' : 'Compose Today\'s Spiritual Note'}
            </span>

            {/* Mood picker */}
            <div className="flex items-center gap-1">
              <span className="text-[11px] text-slate-400 mr-1 hidden sm:inline">Spiritual State:</span>
              <div className="flex gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1">
                {MOODS.map(m => (
                  <button
                    key={m.label}
                    type="button"
                    onClick={() => {
                      triggerHaptic(10);
                      setSelectedMood(m.icon);
                    }}
                    title={m.label}
                    className={`w-7 h-7 rounded-lg text-sm flex items-center justify-center transition-all ${
                      selectedMood === m.icon
                        ? 'bg-amber-500/20 scale-110 ring-1 ring-amber-500/50'
                        : 'opacity-60 hover:opacity-100 hover:bg-slate-800'
                    }`}
                  >
                    {m.icon}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Tag Selector Buttons */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-mono text-slate-400">Select Focus:</span>
            <div className="flex flex-wrap gap-1.5">
              {(Object.keys(TAG_CONFIG) as JournalTag[]).map(tagKey => {
                const conf = TAG_CONFIG[tagKey];
                const isSelected = selectedTag === tagKey;
                return (
                  <button
                    key={tagKey}
                    type="button"
                    onClick={() => {
                      triggerHaptic(10);
                      setSelectedTag(tagKey);
                    }}
                    className={`px-3 py-1 rounded-xl text-xs font-semibold border transition-all ${
                      isSelected
                        ? 'bg-amber-600 text-slate-950 border-amber-500 font-bold shadow-sm'
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <span>{conf.label}</span>
                    <span className="text-[10px] ml-1 font-serif opacity-75" dir="rtl">{conf.arabic}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Text Area */}
          <div className="space-y-1">
            <textarea
              rows={4}
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder={TAG_CONFIG[selectedTag].prompt}
              className="w-full bg-slate-900 border border-slate-700/80 rounded-xl p-3 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors leading-relaxed resize-none shadow-inner"
              autoFocus
            />
            <div className="flex justify-between items-center text-[10px] text-slate-500 px-1">
              <span>Saved securely on this browser. Never transmitted to third parties.</span>
              <span>{content.length} characters</span>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                setIsFormOpen(false);
                setEditingId(null);
                setContent('');
              }}
              className="px-3.5 py-1.5 rounded-xl border border-slate-700 text-slate-400 hover:text-slate-200 text-xs font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!content.trim()}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all shadow-md ${
                content.trim()
                  ? 'bg-amber-600 hover:bg-amber-500 text-slate-950 shadow-amber-600/20 active:scale-95'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              {editingId ? 'Update Note' : 'Save Reflection'}
            </button>
          </div>
        </form>
      )}

      {/* Filter and Search Bar for Existing Entries */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-1">
        {/* Category Filter Pills */}
        <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none text-xs">
          <button
            type="button"
            onClick={() => setActiveFilterTag('all')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-colors whitespace-nowrap ${
              activeFilterTag === 'all'
                ? 'bg-amber-600 text-slate-950 font-bold'
                : 'bg-slate-850 text-slate-400 hover:text-slate-200'
            }`}
          >
            All Notes ({entries.length})
          </button>
          {(Object.keys(TAG_CONFIG) as JournalTag[]).map(t => {
            const count = entries.filter(e => e.tag === t).length;
            if (count === 0 && activeFilterTag !== t) return null;
            return (
              <button
                key={t}
                type="button"
                onClick={() => setActiveFilterTag(t)}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors whitespace-nowrap ${
                  activeFilterTag === t
                    ? 'bg-amber-600 text-slate-950 font-bold'
                    : 'bg-slate-850 text-slate-400 hover:text-slate-200'
                }`}
              >
                {TAG_CONFIG[t].label} ({count})
              </button>
            );
          })}
        </div>

        {/* Quick Search Input */}
        <div className="relative min-w-[180px]">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search notes..."
            className="w-full pl-7 pr-3 py-1 bg-slate-950/70 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
          />
        </div>
      </div>

      {/* List of Entries */}
      {filteredEntries.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredEntries.map(entry => {
            const tagConf = TAG_CONFIG[entry.tag] || TAG_CONFIG.reflection;
            const isToday = entry.date === todayStr;
            const formattedDate = new Date(entry.timestamp).toLocaleDateString('en-US', {
              weekday: 'short',
              month: 'short',
              day: 'numeric'
            });

            return (
              <div
                key={entry.id}
                className={`group bg-slate-950/60 border rounded-xl p-4 transition-all duration-200 flex flex-col justify-between space-y-3 relative hover:border-amber-700/50 ${
                  entry.isPinned
                    ? 'border-amber-500/40 ring-1 ring-amber-500/20 shadow-md shadow-amber-500/5'
                    : 'border-slate-800'
                }`}
              >
                {/* Entry Top Header */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-base" title="Spiritual mood">{entry.mood || '🤲'}</span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded-md border font-semibold ${tagConf.color}`}>
                      {tagConf.label}
                    </span>
                    {isToday && (
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        Today
                      </span>
                    )}
                  </div>

                  {/* Actions: Pin, Copy, Edit, Delete */}
                  <div className="flex items-center gap-1 opacity-70 group-hover:opacity-100 transition-opacity">
                    <button
                      type="button"
                      onClick={() => handleTogglePin(entry.id)}
                      className={`p-1 rounded hover:bg-slate-800 transition-colors ${
                        entry.isPinned ? 'text-amber-400' : 'text-slate-500 hover:text-amber-400'
                      }`}
                      title={entry.isPinned ? 'Unpin note' : 'Pin to top'}
                    >
                      <Star size={13} className={entry.isPinned ? 'fill-amber-400' : ''} />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleCopy(entry)}
                      className="p-1 text-slate-500 hover:text-slate-300 hover:bg-slate-800 rounded transition-colors"
                      title="Copy reflection"
                    >
                      {copiedId === entry.id ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleEdit(entry)}
                      className="p-1 text-slate-500 hover:text-amber-400 hover:bg-slate-800 rounded transition-colors"
                      title="Edit note"
                    >
                      <Edit3 size={13} />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(entry.id)}
                      className="p-1 text-slate-500 hover:text-red-400 hover:bg-slate-800 rounded transition-colors"
                      title="Delete note"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>

                {/* Entry Content Body */}
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-wrap font-normal">
                  {entry.content}
                </p>

                {/* Entry Footer Date & Timestamp */}
                <div className="pt-2 border-t border-slate-900 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                  <span>{formattedDate}</span>
                  <span>
                    {new Date(entry.timestamp).toLocaleTimeString('en-US', {
                      hour: '2-digit',
                      minute: '2-digit',
                      hour12: true
                    })}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Empty State */
        <div className="p-6 bg-slate-950/40 border border-slate-800/80 rounded-xl text-center space-y-2">
          <BookHeart size={28} className="mx-auto text-amber-500/50" />
          <p className="text-xs font-semibold text-slate-300">
            {searchQuery ? 'No reflections match your search' : 'No notes written yet'}
          </p>
          <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
            Take a moment to record your morning intention, a heartfelt Du'a, or a blessing you received today.
          </p>
          <button
            type="button"
            onClick={() => setIsFormOpen(true)}
            className="mt-2 text-xs text-amber-500 hover:underline font-semibold"
          >
            Start your first entry →
          </button>
        </div>
      )}
    </section>
  );
}
