import React, { useState, useMemo, useEffect } from 'react';
import { 
  Moon, 
  Sparkles, 
  Calendar as CalendarIcon, 
  Clock, 
  ChevronRight, 
  SlidersHorizontal, 
  Info, 
  Compass, 
  Star,
  ChevronDown,
  ChevronUp,
  Award,
  Sun
} from 'lucide-react';
import { triggerHaptic } from '../lib/haptics';

// Islamic Months metadata
export const HIJRI_MONTHS = [
  { id: 1, name: 'Muharram', arabic: 'مُحَرَّم', isSacred: true, description: 'First month of the Islamic year; contains the Day of Ashura (10th Muharram).' },
  { id: 2, name: 'Safar', arabic: 'صَفَر', isSacred: false, description: 'Second month; time for renewed devotion and travel.' },
  { id: 3, name: 'Rabi\' al-Awwal', arabic: 'رَبِيع الأَوَّل', isSacred: false, description: 'Third month; blessed month in which the Prophet Muhammad (ﷺ) was born.' },
  { id: 4, name: 'Rabi\' al-Thani', arabic: 'رَبِيع الآخِر', isSacred: false, description: 'Fourth month; following the spring season of remembrance.' },
  { id: 5, name: 'Jumada al-Ula', arabic: 'جُمَادَى الأُولَى', isSacred: false, description: 'Fifth month of the Hijri lunar calendar.' },
  { id: 6, name: 'Jumada al-Akhirah', arabic: 'جُمَادَى الآخِرَة', isSacred: false, description: 'Sixth month; mid-point of the Islamic calendar year.' },
  { id: 7, name: 'Rajab', arabic: 'رَجَب', isSacred: true, description: 'Sacred month; commemorates Al-Isra\' wal-Mi\'raj (The Night Journey).' },
  { id: 8, name: 'Sha\'ban', arabic: 'شَعْبَان', isSacred: false, description: 'Month of raising deeds to Allah and spiritual preparation for Ramadan.' },
  { id: 9, name: 'Ramadan', arabic: 'رَمَضَان', isSacred: true, isRamadan: true, description: 'The blessed month of fasting, revelation of the Quran, and Laylat al-Qadr.' },
  { id: 10, name: 'Shawwal', arabic: 'شَوَّال', isSacred: false, description: 'Tenth month; begins with Eid al-Fitr and carries the 6 Sunnah fasting days.' },
  { id: 11, name: 'Dhu al-Qi\'dah', arabic: 'ذُو القَعْدَة', isSacred: true, description: 'Sacred month; the month of peace and readiness for the Hajj pilgrimage.' },
  { id: 12, name: 'Dhu al-Hijjah', arabic: 'ذُو الحِجَّة', isSacred: true, isHajj: true, description: 'Sacred month of Hajj, the Day of Arafah (9th), and Eid al-Adha (10th).' }
];

// Reference synodic month (29.53058867 days)
const SYNODIC_MONTH = 29.53058867;
// Reference New Moon: Jan 11, 2024, 11:57 UTC
const REFERENCE_NEW_MOON_UTC = new Date('2024-01-11T11:57:00Z').getTime();

export interface MoonPhaseInfo {
  ageInDays: number;
  phaseFraction: number; // 0 (New) to 0.5 (Full) to 1.0 (New)
  illuminationPct: number; // 0% to 100%
  phaseName: string;
  arabicName: string;
  stage: 'new' | 'waxing_crescent' | 'first_quarter' | 'waxing_gibbous' | 'full' | 'waning_gibbous' | 'last_quarter' | 'waning_crescent';
}

// Compute accurate astronomical moon phase
export function getMoonPhase(date: Date): MoonPhaseInfo {
  const msDiff = date.getTime() - REFERENCE_NEW_MOON_UTC;
  const daysDiff = msDiff / (1000 * 60 * 60 * 24);
  const ageInDays = ((daysDiff % SYNODIC_MONTH) + SYNODIC_MONTH) % SYNODIC_MONTH;
  const phaseFraction = ageInDays / SYNODIC_MONTH;

  // Illumination from phase angle
  const phaseAngle = phaseFraction * 2 * Math.PI;
  const illuminationPct = Math.round(((1 - Math.cos(phaseAngle)) / 2) * 100);

  let phaseName = 'Waxing Crescent';
  let arabicName = 'هلال متزايد';
  let stage: MoonPhaseInfo['stage'] = 'waxing_crescent';

  if (ageInDays < 1.84) {
    phaseName = 'New Moon (Hilal)';
    arabicName = 'محاق / ولادة الهلال';
    stage = 'new';
  } else if (ageInDays < 7.38) {
    phaseName = 'Waxing Crescent';
    arabicName = 'هلال متزايد';
    stage = 'waxing_crescent';
  } else if (ageInDays < 9.22) {
    phaseName = 'First Quarter';
    arabicName = 'التربيع الأول';
    stage = 'first_quarter';
  } else if (ageInDays < 13.84) {
    phaseName = 'Waxing Gibbous';
    arabicName = 'أحدب متزايد';
    stage = 'waxing_gibbous';
  } else if (ageInDays < 15.68) {
    phaseName = 'Full Moon (Badr)';
    arabicName = 'بدر التمام';
    stage = 'full';
  } else if (ageInDays < 20.30) {
    phaseName = 'Waning Gibbous';
    arabicName = 'أحدب متناقص';
    stage = 'waning_gibbous';
  } else if (ageInDays < 22.14) {
    phaseName = 'Last Quarter';
    arabicName = 'التربيع الأخير';
    stage = 'last_quarter';
  } else if (ageInDays < 27.68) {
    phaseName = 'Waning Crescent';
    arabicName = 'هلال متناقص';
    stage = 'waning_crescent';
  } else {
    phaseName = 'Dark Moon';
    arabicName = 'محاق';
    stage = 'new';
  }

  return {
    ageInDays: Math.round(ageInDays * 10) / 10,
    phaseFraction,
    illuminationPct,
    phaseName,
    arabicName,
    stage
  };
}

// Helper to extract Hijri parts from Intl
export function getHijriDate(date: Date, offsetDays: number = 0) {
  const adjusted = new Date(date);
  adjusted.setDate(adjusted.getDate() + offsetDays);

  const formatter = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', {
    day: 'numeric',
    month: 'numeric',
    year: 'numeric'
  });

  const arabicFormatter = new Intl.DateTimeFormat('ar-u-ca-islamic-umalqura', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const parts = formatter.formatToParts(adjusted);
  const m = parseInt(parts.find(p => p.type === 'month')?.value || '1', 10);
  const d = parseInt(parts.find(p => p.type === 'day')?.value || '1', 10);
  const y = parseInt(parts.find(p => p.type === 'year')?.value || '1448', 10);

  const monthMeta = HIJRI_MONTHS.find(item => item.id === m) || HIJRI_MONTHS[0];
  const arabicFull = arabicFormatter.format(adjusted);

  return {
    day: d,
    month: m,
    year: y,
    monthName: monthMeta.name,
    monthArabic: monthMeta.arabic,
    isSacred: monthMeta.isSacred,
    arabicFull,
    formattedEn: `${d} ${monthMeta.name} ${y} AH`,
    adjustedDate: adjusted
  };
}

export default function LunarCalendar() {
  const currentDate = useMemo(() => new Date(), []);

  // Moon sighting adjustment offset (-2 to +2 days)
  const [offsetDays, setOffsetDays] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('hijri_date_offset') || '0', 10);
    } catch {
      return 0;
    }
  });

  const [showAdjuster, setShowAdjuster] = useState(false);
  const [showAllMonths, setShowAllMonths] = useState(false);

  const handleSetOffset = (val: number) => {
    triggerHaptic(15);
    setOffsetDays(val);
    try {
      localStorage.setItem('hijri_date_offset', String(val));
    } catch (e) {
      console.warn(e);
    }
  };

  // Current Hijri & Moon phase data
  const hijri = useMemo(() => getHijriDate(currentDate, offsetDays), [currentDate, offsetDays]);
  const moonPhase = useMemo(() => getMoonPhase(hijri.adjustedDate), [hijri.adjustedDate]);

  // Check if today is one of the White Days (13, 14, 15)
  const isWhiteDay = hijri.day >= 13 && hijri.day <= 15;

  // Search ahead for upcoming significant dates:
  // 1. Ramadan (m=9, d=1)
  // 2. Dhu al-Hijjah (m=12, d=1) and Day of Arafah (m=12, d=9)
  // 3. Next White Days (d=13 of current or next month)
  const upcomingEvents = useMemo(() => {
    let ramadanDays = 0;
    let ramadanDate: Date | null = null;
    let dhuHijjahDays = 0;
    let dhuHijjahDate: Date | null = null;
    let arafahDate: Date | null = null;
    let whiteDaysDiff = 0;

    const check = new Date(hijri.adjustedDate);

    // Days until next White Days
    if (hijri.day < 13) {
      whiteDaysDiff = 13 - hijri.day;
    } else if (hijri.day > 15) {
      // roughly next month's 13th
      whiteDaysDiff = (30 - hijri.day) + 13;
    } else {
      whiteDaysDiff = 0; // Today is a White Day!
    }

    // Look ahead up to 380 days
    for (let i = 1; i <= 380; i++) {
      check.setDate(check.getDate() + 1);
      const h = getHijriDate(check, 0);

      if (!ramadanDate && h.month === 9 && h.day === 1) {
        ramadanDays = i;
        ramadanDate = new Date(check);
      }

      if (!dhuHijjahDate && h.month === 12 && h.day === 1) {
        dhuHijjahDays = i;
        dhuHijjahDate = new Date(check);
      }

      if (!arafahDate && h.month === 12 && h.day === 9) {
        arafahDate = new Date(check);
      }

      if (ramadanDate && dhuHijjahDate) break;
    }

    return {
      ramadanDays,
      ramadanDate,
      dhuHijjahDays,
      dhuHijjahDate,
      arafahDate,
      whiteDaysDiff
    };
  }, [hijri.adjustedDate, hijri.day]);

  // Gregorian formatted date
  const gregorianStr = useMemo(() => {
    return currentDate.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  }, [currentDate]);

  return (
    <section 
      aria-label="Lunar Calendar and Islamic Dates"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-700/50 md:col-span-2 space-y-6"
    >
      {/* Ambient celestial lighting */}
      <div 
        aria-hidden="true" 
        className="absolute -top-24 -right-24 w-60 h-60 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" 
      />
      <div 
        aria-hidden="true" 
        className="absolute -bottom-24 -left-24 w-60 h-60 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none" 
      />

      {/* Header bar: Title, Badge, and Hijri Sighting Adjustment Trigger */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <span className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <Moon size={20} />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-100 tracking-tight">
                Lunar & Islamic Calendar
              </h3>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Umm al-Qura
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Current Hijri date, real-time moon phase illumination, and significant date milestones
            </p>
          </div>
        </div>

        {/* Hijri Adjustment Trigger */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          {offsetDays !== 0 && (
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
              {offsetDays > 0 ? `+${offsetDays}` : offsetDays} Day Sighting
            </span>
          )}

          <button
            type="button"
            onClick={() => {
              triggerHaptic(10);
              setShowAdjuster(!showAdjuster);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-slate-300 hover:text-amber-400 text-xs font-medium transition-colors"
            title="Adjust Hijri date to match your regional moon sighting"
          >
            <SlidersHorizontal size={13} />
            <span>Sighting Adjustment</span>
          </button>
        </div>
      </div>

      {/* Regional Moon Sighting Offset Panel (Collapsible) */}
      {showAdjuster && (
        <div className="p-3.5 bg-slate-950/90 border border-amber-500/30 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs animate-fadeIn shadow-inner">
          <div className="space-y-0.5">
            <span className="font-semibold text-amber-400 flex items-center gap-1">
              <Info size={13} /> Regional Moon Sighting Offset
            </span>
            <p className="text-[11px] text-slate-400">
              Select an offset if your local Hilal committee declared the month 1-2 days earlier or later:
            </p>
          </div>

          <div className="flex items-center gap-1 self-start sm:self-auto">
            {[-2, -1, 0, 1, 2].map(num => (
              <button
                key={num}
                type="button"
                onClick={() => handleSetOffset(num)}
                className={`px-2.5 py-1 rounded-lg font-mono text-xs font-bold transition-all ${
                  offsetDays === num
                    ? 'bg-amber-600 text-slate-950 shadow-md shadow-amber-600/20'
                    : 'bg-slate-900 border border-slate-700 text-slate-300 hover:border-amber-500'
                }`}
              >
                {num === 0 ? 'Standard (0)' : num > 0 ? `+${num}` : num}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Main Grid: Left = Islamic Date & Moon Phase Card, Right = Milestones (Ramadan & Dhu al-Hijjah) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left Column: Current Hijri Date & Moon Visualization (7 cols) */}
        <div className="lg:col-span-7 bg-slate-950/70 border border-amber-900/30 rounded-2xl p-5 sm:p-6 flex flex-col justify-between space-y-6 shadow-inner">
          {/* Top row: Hijri date display */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div>
              {/* Sacred Month Badge */}
              {hijri.isSacred && (
                <span className="inline-flex items-center gap-1 text-[10px] font-mono uppercase tracking-wider text-emerald-400 bg-emerald-950/60 border border-emerald-500/40 px-2.5 py-0.5 rounded-full mb-2">
                  <Star size={11} className="fill-emerald-400" />
                  Sacred Month (الأشهر الحرم)
                </span>
              )}

              {/* Hijri Date English */}
              <h4 className="text-xl sm:text-2xl font-serif font-bold text-slate-100 tracking-tight">
                {hijri.formattedEn}
              </h4>

              {/* Arabic Calligraphy Date */}
              <p className="text-lg sm:text-xl font-arabic text-amber-400 mt-1 leading-relaxed" dir="rtl">
                {hijri.arabicFull}
              </p>

              {/* Gregorian Date Equivalent */}
              <p className="text-xs text-slate-400 font-mono mt-1 flex items-center gap-1.5">
                <CalendarIcon size={12} className="text-slate-500" />
                {gregorianStr}
              </p>
            </div>

            {/* Moon Phase Visual representation */}
            <div className="flex items-center sm:flex-col items-end sm:items-center gap-3 sm:gap-2 self-start bg-slate-900/80 border border-amber-900/40 p-3 rounded-2xl shadow-lg">
              {/* Dynamic SVG Moon Graphic */}
              <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-slate-950 flex items-center justify-center overflow-hidden shadow-inner ring-2 ring-amber-500/30">
                {/* Celestial stars behind */}
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,#334155,transparent_70%)]" />

                {/* Simulated Illuminated Lunar Disc */}
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <defs>
                    <radialGradient id="moonGlow" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="#fef08a" />
                      <stop offset="70%" stopColor="#fde047" />
                      <stop offset="100%" stopColor="#eab308" />
                    </radialGradient>
                    <radialGradient id="darkSide" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="#0f172a" />
                      <stop offset="100%" stopColor="#020617" />
                    </radialGradient>
                  </defs>

                  {/* Base dark moon circle */}
                  <circle cx="50" cy="50" r="42" fill="url(#darkSide)" />

                  {/* Dynamic illumination mask or path depending on phase */}
                  {moonPhase.illuminationPct > 0 && (
                    <circle 
                      cx="50" 
                      cy="50" 
                      r="42" 
                      fill="url(#moonGlow)" 
                      opacity={Math.max(0.2, moonPhase.illuminationPct / 100)} 
                    />
                  )}

                  {/* Crater accents */}
                  <circle cx="40" cy="35" r="4" fill="#ca8a04" opacity="0.3" />
                  <circle cx="62" cy="45" r="6" fill="#ca8a04" opacity="0.25" />
                  <circle cx="48" cy="65" r="5" fill="#ca8a04" opacity="0.2" />
                </svg>

                {/* Ambient glow flare */}
                <div 
                  className="absolute inset-0 rounded-full pointer-events-none" 
                  style={{
                    boxShadow: `0 0 ${moonPhase.illuminationPct / 5}px rgba(251, 191, 36, 0.4)`
                  }}
                />
              </div>

              {/* Illumination % */}
              <div className="text-right sm:text-center">
                <span className="text-xs font-mono font-bold text-amber-400 block">
                  {moonPhase.illuminationPct}%
                </span>
                <span className="text-[10px] text-slate-400">Illuminated</span>
              </div>
            </div>
          </div>

          {/* Phase Name & Lunar Cycle Info Footer */}
          <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div>
              <span className="text-slate-400 block text-[11px]">Current Moon Phase:</span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="font-semibold text-slate-100">{moonPhase.phaseName}</span>
                <span className="text-amber-400/90 font-arabic text-sm" dir="rtl">({moonPhase.arabicName})</span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-slate-400 block text-[11px]">Lunar Month Age:</span>
              <span className="font-mono font-medium text-slate-300">
                Day {moonPhase.ageInDays} of 29.5
              </span>
            </div>
          </div>
        </div>

        {/* Right Column: Significant Milestones Tracker (5 cols) */}
        <div className="lg:col-span-5 space-y-3 flex flex-col justify-between">
          {/* Milestone 1: Ramadan Tracker */}
          <div className="p-4 bg-gradient-to-br from-amber-950/30 via-slate-900 to-slate-950 border border-amber-900/40 rounded-2xl space-y-2 relative overflow-hidden shadow-lg group hover:border-amber-700/60 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                <h5 className="text-xs font-bold text-amber-400 uppercase tracking-wider font-mono">
                  Holy Ramadan 1448 AH
                </h5>
              </div>
              <span className="text-sm font-arabic text-amber-300/80" dir="rtl">رَمَضَان</span>
            </div>

            <div className="flex items-baseline justify-between pt-1">
              <div>
                <span className="text-2xl sm:text-3xl font-mono font-bold text-slate-100">
                  {upcomingEvents.ramadanDays}
                </span>
                <span className="text-xs text-slate-400 ml-1.5 font-medium">Days remaining</span>
              </div>
              {upcomingEvents.ramadanDate && (
                <span className="text-[11px] font-mono text-amber-400/90 bg-amber-500/10 px-2 py-0.5 rounded-lg border border-amber-500/20">
                  Est. {upcomingEvents.ramadanDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                </span>
              )}
            </div>

            <p className="text-[11px] text-slate-400 leading-tight">
              The holy month of obligatory fasting, nightly Taraweeh, and the revelation of the Holy Quran.
            </p>
          </div>

          {/* Milestone 2: Dhu al-Hijjah & Hajj Tracker */}
          <div className="p-4 bg-gradient-to-br from-emerald-950/20 via-slate-900 to-slate-950 border border-emerald-900/30 rounded-2xl space-y-2 relative overflow-hidden shadow-lg group hover:border-emerald-700/60 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <h5 className="text-xs font-bold text-emerald-400 uppercase tracking-wider font-mono">
                  Dhu al-Hijjah & Hajj
                </h5>
              </div>
              <span className="text-sm font-arabic text-emerald-300/80" dir="rtl">ذُو الحِجَّة</span>
            </div>

            <div className="flex items-baseline justify-between pt-1">
              <div>
                <span className="text-2xl sm:text-3xl font-mono font-bold text-slate-100">
                  {upcomingEvents.dhuHijjahDays}
                </span>
                <span className="text-xs text-slate-400 ml-1.5 font-medium">Days remaining</span>
              </div>
              {upcomingEvents.dhuHijjahDate && (
                <span className="text-[11px] font-mono text-emerald-400/90 bg-emerald-500/10 px-2 py-0.5 rounded-lg border border-emerald-500/20">
                  Est. {upcomingEvents.dhuHijjahDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </span>
              )}
            </div>

            <p className="text-[11px] text-slate-400 leading-tight">
              Includes the greatest 10 Days of the year, the Day of Arafah (9th), and Eid al-Adha (10th).
            </p>
          </div>

          {/* Milestone 3: The White Days (Ayyam al-Beed) Notification */}
          <div className={`p-3 rounded-xl border text-xs flex items-center justify-between transition-colors ${
            isWhiteDay
              ? 'bg-amber-500/20 border-amber-500/50 text-amber-200 font-semibold'
              : 'bg-slate-950/60 border-slate-800 text-slate-300'
          }`}>
            <div className="flex items-center gap-2">
              <span className="text-base">🌕</span>
              <div>
                <span className="font-semibold text-slate-100 block">
                  {isWhiteDay ? 'Blessed White Days (الأيام البيض) Active!' : 'The White Days (13th, 14th, 15th)'}
                </span>
                <p className="text-[11px] text-slate-400">
                  {isWhiteDay 
                    ? 'Today is a Sunnah fasting day during full moon illumination.' 
                    : `${upcomingEvents.whiteDaysDiff} days until the next Sunnah fasting days.`}
                </p>
              </div>
            </div>
            <span className="text-[11px] font-mono text-amber-400 font-bold hidden sm:inline">
              Sunnah Sawm
            </span>
          </div>
        </div>
      </div>

      {/* Expandable Guide: All 12 Islamic Months Reference */}
      <div className="pt-2 border-t border-amber-900/20">
        <button
          type="button"
          onClick={() => {
            triggerHaptic(10);
            setShowAllMonths(!showAllMonths);
          }}
          className="w-full flex items-center justify-between text-xs text-slate-400 hover:text-amber-400 transition-colors py-1"
        >
          <span className="flex items-center gap-1.5 font-medium">
            <Compass size={14} className="text-amber-500" />
            Explore All 12 Islamic Months & Significance
          </span>
          <span className="flex items-center gap-1 text-[11px]">
            <span>{showAllMonths ? 'Hide Guide' : 'Show Guide'}</span>
            {showAllMonths ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </span>
        </button>

        {showAllMonths && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 pt-3 animate-fadeIn">
            {HIJRI_MONTHS.map(m => {
              const isCurrent = hijri.month === m.id;
              return (
                <div
                  key={m.id}
                  className={`p-3 rounded-xl border text-xs space-y-1 transition-all ${
                    isCurrent
                      ? 'bg-amber-600/15 border-amber-500/50 ring-1 ring-amber-500/30'
                      : 'bg-slate-950/60 border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-100 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-slate-800 text-[10px] font-mono flex items-center justify-center text-amber-400">
                        {m.id}
                      </span>
                      {m.name}
                    </span>
                    <span className="font-arabic text-amber-300" dir="rtl">{m.arabic}</span>
                  </div>

                  <p className="text-[11px] text-slate-400 leading-snug">
                    {m.description}
                  </p>

                  <div className="flex items-center justify-between pt-1 text-[10px]">
                    {m.isSacred && (
                      <span className="text-emerald-400 font-mono font-medium">
                        ✦ Sacred Month
                      </span>
                    )}
                    {isCurrent && (
                      <span className="text-amber-400 font-mono font-bold ml-auto">
                        Current Month
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
