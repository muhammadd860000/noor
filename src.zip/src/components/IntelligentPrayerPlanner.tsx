import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Sparkles, Sun, Moon, Clock, CheckCircle2, TrendingUp, Zap, Award, Flame, Brain } from 'lucide-react';
import { triggerHaptic, triggerSuccessHaptic } from '../lib/haptics';
import { getWeeklyPrayerSummary, WeeklyPrayerSummary } from '../lib/prayerLog';

interface IntelligentPrayerPlannerProps {
  times: Record<string, string> | null;
}

interface NawafilSuggestion {
  id: string;
  name: string;
  arabicName: string;
  rakats: string;
  timeWindow: string;
  benefit: string;
  type: 'duha' | 'tahajjud' | 'rawatib' | 'awabin';
  recommendedReason: string;
  priorityScore: number;
}

export default function IntelligentPrayerPlanner({ times }: IntelligentPrayerPlannerProps) {
  const todayKey = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const storageKey = `noor_nawafil_tracker_${todayKey}`;

  const [weeklySummary, setWeeklySummary] = useState<WeeklyPrayerSummary>(() => getWeeklyPrayerSummary(new Date()));

  const [completedNawafil, setCompletedNawafil] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const refreshPatternAnalytics = useCallback(() => {
    setWeeklySummary(getWeeklyPrayerSummary(new Date()));
  }, []);

  useEffect(() => {
    refreshPatternAnalytics();
    const handleSync = () => refreshPatternAnalytics();
    window.addEventListener('prayer-status-changed', handleSync);
    return () => window.removeEventListener('prayer-status-changed', handleSync);
  }, [refreshPatternAnalytics]);

  useEffect(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(completedNawafil));
    } catch {}
  }, [completedNawafil, storageKey]);

  // Analyze Logged Prayer Patterns
  const patternInsights = useMemo(() => {
    const { weekDays, weeklyPercentage, currentStreak } = weeklySummary;

    // Count individual prayer completion rates across the week
    const prayerCounts: Record<string, number> = { Fajr: 0, Dhuhr: 0, Asr: 0, Maghrib: 0, Isha: 0 };
    weekDays.forEach(day => {
      Object.entries(day.prayers).forEach(([prayer, done]) => {
        if (done && prayerCounts[prayer] !== undefined) {
          prayerCounts[prayer] += 1;
        }
      });
    });

    const totalDays = Math.max(1, weekDays.length);
    const fajrPct = Math.round((prayerCounts.Fajr / totalDays) * 100);
    const dhuhrPct = Math.round((prayerCounts.Dhuhr / totalDays) * 100);
    const asrPct = Math.round((prayerCounts.Asr / totalDays) * 100);
    const maghribPct = Math.round((prayerCounts.Maghrib / totalDays) * 100);
    const ishaPct = Math.round((prayerCounts.Isha / totalDays) * 100);

    let peakFocusSlot = 'Morning (Fajr & Duha)';
    let peakFocusReason = 'High Fajr consistency detected in your logged history.';

    if (fajrPct >= 70) {
      peakFocusSlot = 'Early Morning & Pre-Dawn (Fajr & Tahajjud)';
      peakFocusReason = 'Strong Fajr routine detected! Ideal for Tahajjud and Ishraq.';
    } else if (maghribPct >= 70 || ishaPct >= 70) {
      peakFocusSlot = 'Evening Twilight (Maghrib & Awabin)';
      peakFocusReason = 'Consistent night prayer pattern. Awabin & Qiyam al-Layl fit your rhythm.';
    } else if (dhuhrPct >= 70 || asrPct >= 70) {
      peakFocusSlot = 'Midday Focus (Dhuhr & Rawatib)';
      peakFocusReason = 'Strong daytime consistency. Focus on 12 Sunnah Rawatib rakats.';
    }

    return {
      weeklyPercentage,
      currentStreak,
      fajrPct,
      dhuhrPct,
      asrPct,
      maghribPct,
      ishaPct,
      peakFocusSlot,
      peakFocusReason
    };
  }, [weeklySummary]);

  // Helper to parse time string like "05:14" into minutes from midnight
  const parseTimeMinutes = (timeStr?: string): number | null => {
    if (!timeStr) return null;
    const clean = timeStr.replace(/[^0-9:]/g, '');
    const [h, m] = clean.split(':').map(Number);
    if (isNaN(h) || isNaN(m)) return null;
    return h * 60 + m;
  };

  const formatMinutesToTime = (totalMinutes: number): string => {
    const normalized = (totalMinutes + 1440) % 1440;
    const h = Math.floor(normalized / 60);
    const m = normalized % 60;
    const period = h >= 12 ? 'PM' : 'AM';
    const h12 = h % 12 === 0 ? 12 : h % 12;
    return `${h12}:${m.toString().padStart(2, '0')} ${period}`;
  };

  // Calculate intelligent timings based on times prop and logged patterns
  const scheduleSuggestions = useMemo((): NawafilSuggestion[] => {
    const sunriseMins = parseTimeMinutes(times?.Sunrise) || 360;
    const dhuhrMins = parseTimeMinutes(times?.Dhuhr) || 750;
    const maghribMins = parseTimeMinutes(times?.Maghrib) || 1095;
    const ishaMins = parseTimeMinutes(times?.Isha) || 1185;
    const fajrMins = parseTimeMinutes(times?.Fajr) || 300;

    const ishraqStart = sunriseMins + 15;
    const duhaPeak = Math.round((sunriseMins + dhuhrMins) / 2);
    const tahajjudStart = fajrMins - 120;
    const awabinStart = maghribMins + 20;
    const awabinEnd = ishaMins - 15;

    const suggestions: NawafilSuggestion[] = [
      {
        id: 'tahajjud',
        name: 'Tahajjud (Night Prayer)',
        arabicName: 'صلاة التهجد',
        rakats: '2 to 8 Rakats',
        timeWindow: `${formatMinutesToTime(tahajjudStart)} – ${formatMinutesToTime(fajrMins - 15)}`,
        benefit: 'The habit of the righteous. Supplication is most readily accepted in the last third of the night.',
        type: 'tahajjud',
        recommendedReason: patternInsights.fajrPct >= 60 
          ? 'Highly Recommended: Your high Fajr completion rate shows readiness for pre-dawn Qiyam.'
          : 'Recommended: Perform 2 light rakats before Fajr to build night devotion.',
        priorityScore: patternInsights.fajrPct >= 60 ? 95 : 75
      },
      {
        id: 'ishraq_duha',
        name: 'Ishraq & Duha (Morning Prayer)',
        arabicName: 'صلاة الضحى',
        rakats: '2 to 8 Rakats',
        timeWindow: `${formatMinutesToTime(ishraqStart)} – ${formatMinutesToTime(duhaPeak)}`,
        benefit: 'Equals the reward of a complete Hajj and Umrah when performed after sunrise with Dhikr.',
        type: 'duha',
        recommendedReason: 'Optimal for morning energy and spiritual focus before starting daily work.',
        priorityScore: 90
      },
      {
        id: 'sunnah_rawatib',
        name: 'Sunnah Rawatib (Before/After Fardh)',
        arabicName: 'السنن الراتبة',
        rakats: '12 Rakats Daily',
        timeWindow: 'Attached to Fajr (2), Dhuhr (4+2), Maghrib (2) & Isha (2)',
        benefit: 'Allah builds a palace in Paradise for whoever prays 12 voluntary Sunnah rakats daily.',
        type: 'rawatib',
        recommendedReason: `Tailored to your ${patternInsights.weeklyPercentage}% obligatory prayer consistency. Perfect for completing obligatory prayers.`,
        priorityScore: 98
      },
      {
        id: 'awabin',
        name: 'Awabin Prayer (Between Maghrib & Isha)',
        arabicName: 'صلاة الأوابين',
        rakats: '6 Rakats',
        timeWindow: `${formatMinutesToTime(awabinStart)} – ${formatMinutesToTime(awabinEnd)}`,
        benefit: 'Prayer of the repentant and those returning to Allah during twilight.',
        type: 'awabin',
        recommendedReason: patternInsights.maghribPct >= 60
          ? 'Top Recommendation: Your strong Maghrib habit makes this twilight window very effective.'
          : 'Calming evening prayer window between dusk and Isha.',
        priorityScore: patternInsights.maghribPct >= 60 ? 92 : 70
      }
    ];

    return suggestions.sort((a, b) => b.priorityScore - a.priorityScore);
  }, [times, patternInsights]);

  const toggleNawafil = (id: string) => {
    triggerHaptic(25);
    const isDone = !!completedNawafil[id];
    const updated = {
      ...completedNawafil,
      [id]: !isDone
    };
    setCompletedNawafil(updated);
    if (!isDone) triggerSuccessHaptic();
  };

  const completedCount = Object.values(completedNawafil).filter(Boolean).length;
  const totalNawafil = scheduleSuggestions.length;
  const progressPct = Math.round((completedCount / totalNawafil) * 100);

  return (
    <section 
      aria-label="Intelligent Prayer Planner for Nawafil"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
            <Brain size={22} />
          </div>
          <div>
            <h3 className="text-base font-serif font-bold text-slate-100 flex items-center gap-2">
              <span>Intelligent Nawafil Prayer Planner</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold">
                Pattern Analyzed
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Analyzes your 7-day prayer log to recommend optimal voluntary Nawafil windows
            </p>
          </div>
        </div>

        {/* Completion badge */}
        <div className="flex items-center gap-2 bg-slate-950/80 border border-amber-900/30 px-3 py-2 rounded-xl self-start sm:self-auto">
          <span className="text-xs text-slate-300 font-medium">Today's Nawafil:</span>
          <span className="text-xs font-mono font-bold text-amber-400">{completedCount} / {totalNawafil}</span>
          <div className="w-12 bg-slate-800 rounded-full h-2 overflow-hidden ml-1">
            <div className="bg-amber-500 h-full transition-all duration-300" style={{ width: `${progressPct}%` }} />
          </div>
        </div>
      </div>

      {/* Pattern Analysis Insight Summary Card */}
      <div className="p-4 bg-slate-950/80 border border-amber-900/30 rounded-xl space-y-2.5">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 font-bold text-amber-400">
            <TrendingUp size={15} />
            <span>Logged Pattern Insights (7-Day Analysis)</span>
          </div>
          <span className="text-[11px] font-mono text-slate-400">
            Obligatory Rate: <strong className="text-amber-300">{patternInsights.weeklyPercentage}%</strong>
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          <strong className="text-amber-200">{patternInsights.peakFocusSlot}:</strong> {patternInsights.peakFocusReason}
        </p>

        {/* 5 Prayers Completion Micro-Bar */}
        <div className="grid grid-cols-5 gap-1.5 text-center text-[10px] pt-1">
          <div className="p-1.5 bg-slate-900 rounded-lg border border-slate-800">
            <span className="text-slate-400 block">Fajr</span>
            <span className="font-mono font-bold text-amber-400">{patternInsights.fajrPct}%</span>
          </div>
          <div className="p-1.5 bg-slate-900 rounded-lg border border-slate-800">
            <span className="text-slate-400 block">Dhuhr</span>
            <span className="font-mono font-bold text-amber-400">{patternInsights.dhuhrPct}%</span>
          </div>
          <div className="p-1.5 bg-slate-900 rounded-lg border border-slate-800">
            <span className="text-slate-400 block">Asr</span>
            <span className="font-mono font-bold text-amber-400">{patternInsights.asrPct}%</span>
          </div>
          <div className="p-1.5 bg-slate-900 rounded-lg border border-slate-800">
            <span className="text-slate-400 block">Maghrib</span>
            <span className="font-mono font-bold text-amber-400">{patternInsights.maghribPct}%</span>
          </div>
          <div className="p-1.5 bg-slate-900 rounded-lg border border-slate-800">
            <span className="text-slate-400 block">Isha</span>
            <span className="font-mono font-bold text-amber-400">{patternInsights.ishaPct}%</span>
          </div>
        </div>
      </div>

      {/* Grid of Intelligent Suggestions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {scheduleSuggestions.map((item) => {
          const isDone = !!completedNawafil[item.id];

          return (
            <div 
              key={item.id}
              className={`p-4 rounded-xl border transition-all flex flex-col justify-between space-y-3 ${
                isDone 
                  ? 'bg-amber-950/20 border-amber-500/40 shadow-sm shadow-amber-500/10'
                  : 'bg-slate-900/90 border-slate-800 hover:border-amber-900/50'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/20 font-semibold">
                      {item.rakats}
                    </span>
                    <h4 className="text-sm font-bold text-slate-100 mt-1.5 flex items-center gap-2">
                      <span>{item.name}</span>
                    </h4>
                  </div>
                  <span className="text-xs text-amber-300 font-serif" dir="rtl">
                    {item.arabicName}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-xs text-amber-400 font-mono bg-slate-950/80 px-2.5 py-1.5 rounded-lg border border-slate-800/80 w-fit">
                  <Clock size={13} className="text-amber-500 shrink-0" />
                  <span>Optimal Window: {item.timeWindow}</span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {item.benefit}
                </p>

                <p className="text-[11px] text-amber-300/80 italic bg-amber-950/30 p-2 rounded-lg border border-amber-500/20">
                  ⚡ {item.recommendedReason}
                </p>
              </div>

              {/* Action Toggle Button */}
              <button
                type="button"
                onClick={() => toggleNawafil(item.id)}
                className={`w-full py-2.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition ${
                  isDone
                    ? 'bg-amber-500 text-slate-950 font-bold shadow'
                    : 'bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-slate-100'
                }`}
              >
                <CheckCircle2 size={15} className={isDone ? 'text-slate-950' : 'text-slate-500'} />
                <span>{isDone ? 'Completed Masha\'Allah!' : 'Mark as Completed'}</span>
              </button>
            </div>
          );
        })}
      </div>
    </section>
  );
}

