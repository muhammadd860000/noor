import React, { useState, useMemo } from 'react';
import { 
  MessageSquare, 
  Heart, 
  Plus, 
  Search, 
  Filter, 
  Tag, 
  User, 
  Send, 
  Sparkles, 
  X, 
  Clock, 
  MessageCircle, 
  Share2, 
  CheckCircle2, 
  HelpCircle, 
  BookOpen, 
  HandHeart, 
  ThumbsUp,
  Layers
} from 'lucide-react';
import { 
  getStoredForumPosts, 
  addForumPost, 
  likeForumPost, 
  addForumReply, 
  likeForumReply, 
  ForumPost, 
  ForumReply 
} from '../lib/communityForum';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export default function CommunityForum() {
  const [posts, setPosts] = useState<ForumPost[]>(getStoredForumPosts);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'latest' | 'likes' | 'replies'>('latest');
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [expandedPostIds, setExpandedPostIds] = useState<Record<string, boolean>>({});

  // New Post Form State
  const [newTitle, setNewTitle] = useState('');
  const [newAuthor, setNewAuthor] = useState('');
  const [newCategory, setNewCategory] = useState<ForumPost['category']>('Reflections');
  const [newContent, setNewContent] = useState('');
  const [newTags, setNewTags] = useState('');

  // Reply Drafts State (postId -> string)
  const [replyDrafts, setReplyDrafts] = useState<Record<string, { author: string; content: string }>>({});

  const categories = ['All', 'Questions', 'Reflections', 'Dua Request', 'Quran Study', 'General'];

  // Relative Time Helper
  const formatTimeAgo = (timestamp: number) => {
    const diffMs = Date.now() - timestamp;
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };

  const handleLikePost = (postId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic(15);
    const updated = likeForumPost(postId);
    setPosts(updated);
  };

  const handleLikeReply = (postId: string, replyId: string) => {
    triggerHaptic(15);
    const updated = likeForumReply(postId, replyId);
    setPosts(updated);
  };

  const toggleExpandPost = (postId: string) => {
    triggerButtonClickHaptic();
    setExpandedPostIds(prev => ({ ...prev, [postId]: !prev[postId] }));
  };

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    triggerSuccessHaptic();
    const parsedTags = newTags
      .split(',')
      .map(t => t.trim().replace(/^#/, ''))
      .filter(Boolean);

    addForumPost(
      newAuthor || 'Servant of Allah',
      newCategory,
      newTitle,
      newContent,
      parsedTags
    );

    setPosts(getStoredForumPosts());
    setNewTitle('');
    setNewContent('');
    setNewTags('');
    setShowCreateModal(false);
  };

  const handleAddReply = (postId: string, e: React.FormEvent) => {
    e.preventDefault();
    const draft = replyDrafts[postId];
    if (!draft || !draft.content.trim()) return;

    triggerSuccessHaptic();
    addForumReply(postId, draft.author || 'Servant of Allah', draft.content);
    setPosts(getStoredForumPosts());

    // Clear draft for this post
    setReplyDrafts(prev => ({ ...prev, [postId]: { author: draft.author || '', content: '' } }));
  };

  const handleDraftChange = (postId: string, field: 'author' | 'content', value: string) => {
    setReplyDrafts(prev => ({
      ...prev,
      [postId]: {
        author: field === 'author' ? value : prev[postId]?.author || '',
        content: field === 'content' ? value : prev[postId]?.content || ''
      }
    }));
  };

  // Filter and Sort Logic
  const filteredAndSortedPosts = useMemo(() => {
    return posts
      .filter(post => {
        // Category Filter
        if (activeCategory !== 'All' && post.category !== activeCategory) {
          return false;
        }

        // Search Query Filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchTitle = post.title.toLowerCase().includes(q);
          const matchContent = post.content.toLowerCase().includes(q);
          const matchAuthor = post.authorName.toLowerCase().includes(q);
          const matchTags = post.tags?.some(t => t.toLowerCase().includes(q));
          return matchTitle || matchContent || matchAuthor || matchTags;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'likes') return b.likesCount - a.likesCount;
        if (sortBy === 'replies') return b.replies.length - a.replies.length;
        return b.timestamp - a.timestamp; // 'latest'
      });
  }, [posts, activeCategory, searchQuery, sortBy]);

  const getCategoryIcon = (cat: ForumPost['category']) => {
    switch (cat) {
      case 'Questions':
        return <HelpCircle size={14} className="text-amber-400" />;
      case 'Reflections':
        return <Sparkles size={14} className="text-emerald-400" />;
      case 'Dua Request':
        return <HandHeart size={14} className="text-rose-400" />;
      case 'Quran Study':
        return <BookOpen size={14} className="text-blue-400" />;
      default:
        return <MessageSquare size={14} className="text-purple-400" />;
    }
  };

  return (
    <div className="space-y-6 pb-16 max-w-4xl mx-auto">
      {/* Header */}
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-br from-slate-900 via-slate-900/90 to-slate-950 border border-amber-900/40 rounded-2xl p-5 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
            <MessageSquare size={22} />
          </div>
          <div>
            <h2 className="text-xl font-serif font-bold text-slate-100 flex items-center gap-2">
              <span>Ummah Community Forum</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold">
                Faith & Knowledge Board
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Connect with fellow believers, ask Islamic questions, share Quran reflections & request Duas
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            triggerButtonClickHaptic();
            setShowCreateModal(true);
          }}
          className="py-2.5 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 shrink-0 active:scale-95"
        >
          <Plus size={16} />
          <span>New Community Post</span>
        </button>
      </header>

      {/* Search & Sorting Toolbar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Search Bar */}
        <div className="md:col-span-2 relative">
          <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search discussions, questions, author names, or tags (#Tawakkul, #Khushu)..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900/90 border border-amber-900/30 text-slate-100 pl-10 pr-10 py-2.5 rounded-xl focus:border-amber-500 focus:ring-1 focus:ring-amber-500/40 outline-none text-xs placeholder-slate-500 transition shadow-inner"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
            >
              <X size={16} />
            </button>
          )}
        </div>

        {/* Sort Selector */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 border border-slate-800 rounded-xl">
          <span className="text-[11px] text-slate-500 pl-2 font-medium">Sort:</span>
          {(['latest', 'likes', 'replies'] as const).map(mode => (
            <button
              key={mode}
              type="button"
              onClick={() => {
                triggerButtonClickHaptic();
                setSortBy(mode);
              }}
              className={`flex-1 py-1.5 rounded-lg text-xs capitalize transition font-semibold ${
                sortBy === mode
                  ? 'bg-amber-600 text-slate-950 shadow-sm font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {categories.map(cat => (
          <button
            key={cat}
            type="button"
            onClick={() => {
              triggerButtonClickHaptic();
              setActiveCategory(cat);
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition border ${
              activeCategory === cat
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm font-bold'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Posts Feed List */}
      <div className="space-y-4">
        {filteredAndSortedPosts.length === 0 ? (
          <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-8 text-center space-y-3">
            <MessageSquare size={32} className="text-slate-600 mx-auto" />
            <p className="text-sm text-slate-300 font-semibold">No discussions found matching your search or category filter.</p>
            <p className="text-xs text-slate-500">Be the first to create a post and start a beneficial reflection!</p>
            <button
              type="button"
              onClick={() => setShowCreateModal(true)}
              className="py-2 px-4 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl hover:bg-amber-400 transition"
            >
              Post a Question or Reflection
            </button>
          </div>
        ) : (
          filteredAndSortedPosts.map(post => {
            const isExpanded = !!expandedPostIds[post.id];

            return (
              <article
                key={post.id}
                className="bg-slate-900/90 border border-amber-900/30 rounded-2xl p-5 shadow-lg space-y-3 transition hover:border-amber-900/50"
              >
                {/* Author Info & Category Bar */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 text-xs font-bold uppercase">
                      {post.authorName.charAt(0)}
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-200 block">{post.authorName}</span>
                      <span className="text-[10px] text-slate-500 flex items-center gap-1 font-mono">
                        <Clock size={11} />
                        <span>{formatTimeAgo(post.timestamp)}</span>
                      </span>
                    </div>
                  </div>

                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-950 text-slate-300 border border-slate-800">
                    {getCategoryIcon(post.category)}
                    <span>{post.category}</span>
                  </span>
                </div>

                {/* Post Title & Content */}
                <div className="space-y-1.5">
                  <h3 className="text-base font-serif font-bold text-slate-100 leading-snug">{post.title}</h3>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-line">{post.content}</p>
                </div>

                {/* Tags Bar */}
                {post.tags && post.tags.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    {post.tags.map((tag, idx) => (
                      <span key={idx} className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 text-amber-400/90 border border-slate-800">
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}

                {/* Engagement Bar */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs">
                  <div className="flex items-center gap-3">
                    {/* Like Button */}
                    <button
                      type="button"
                      onClick={(e) => handleLikePost(post.id, e)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition ${
                        post.userLiked
                          ? 'bg-rose-950/60 text-rose-400 border border-rose-500/40 font-bold'
                          : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                      }`}
                    >
                      <Heart size={14} className={post.userLiked ? 'fill-rose-400' : ''} />
                      <span>{post.likesCount}</span>
                    </button>

                    {/* Replies Toggle Button */}
                    <button
                      type="button"
                      onClick={() => toggleExpandPost(post.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-950 text-slate-300 hover:text-amber-300 border border-slate-800 rounded-xl transition"
                    >
                      <MessageCircle size={14} />
                      <span>{post.replies.length} {post.replies.length === 1 ? 'Reply' : 'Replies'}</span>
                    </button>
                  </div>
                </div>

                {/* Expanded Replies Section */}
                {isExpanded && (
                  <div className="pt-3 border-t border-slate-800 space-y-3 animate-fadeIn">
                    {/* List of Replies */}
                    {post.replies.length > 0 && (
                      <div className="space-y-2.5 pl-2 border-l-2 border-amber-900/30">
                        {post.replies.map(reply => (
                          <div key={reply.id} className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-amber-300">{reply.authorName}</span>
                              <span className="text-[10px] text-slate-500 font-mono">{formatTimeAgo(reply.timestamp)}</span>
                            </div>
                            <p className="text-xs text-slate-300 leading-relaxed">{reply.content}</p>

                            <div className="flex justify-end pt-1">
                              <button
                                type="button"
                                onClick={() => handleLikeReply(post.id, reply.id)}
                                className={`text-[10px] font-mono flex items-center gap-1 transition ${
                                  reply.userLiked ? 'text-rose-400 font-bold' : 'text-slate-500 hover:text-slate-300'
                                }`}
                              >
                                <Heart size={11} className={reply.userLiked ? 'fill-rose-400' : ''} />
                                <span>{reply.likesCount}</span>
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Add Reply Form */}
                    <form onSubmit={(e) => handleAddReply(post.id, e)} className="space-y-2 pt-2">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <input
                          type="text"
                          placeholder="Your name (optional)..."
                          value={replyDrafts[post.id]?.author || ''}
                          onChange={e => handleDraftChange(post.id, 'author', e.target.value)}
                          className="bg-slate-950 border border-slate-800 text-slate-200 px-3 py-1.5 rounded-xl text-xs outline-none focus:border-amber-500"
                        />
                        <div className="sm:col-span-2 flex items-center gap-2">
                          <input
                            type="text"
                            placeholder="Write a beneficial reply or words of encouragement..."
                            value={replyDrafts[post.id]?.content || ''}
                            onChange={e => handleDraftChange(post.id, 'content', e.target.value)}
                            className="flex-1 bg-slate-950 border border-slate-800 text-slate-200 px-3 py-1.5 rounded-xl text-xs outline-none focus:border-amber-500"
                          />
                          <button
                            type="submit"
                            disabled={!replyDrafts[post.id]?.content?.trim()}
                            className="py-1.5 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl disabled:opacity-40 transition shrink-0"
                          >
                            <Send size={13} />
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                )}
              </article>
            );
          })
        )}
      </div>

      {/* Create New Post Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-900/50 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 animate-scaleUp">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-base font-serif font-bold text-slate-100 flex items-center gap-2">
                <Sparkles size={18} className="text-amber-400" />
                <span>Create Community Discussion</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreatePost} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Your Name</label>
                <input
                  type="text"
                  placeholder="e.g. Zayd, Maryam (or leave blank for Anonymous)"
                  value={newAuthor}
                  onChange={e => setNewAuthor(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2.5 rounded-xl outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Category</label>
                <select
                  value={newCategory}
                  onChange={e => setNewCategory(e.target.value as ForumPost['category'])}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2.5 rounded-xl outline-none focus:border-amber-500"
                >
                  <option value="Reflections">Reflections</option>
                  <option value="Questions">Questions</option>
                  <option value="Dua Request">Dua Request</option>
                  <option value="Quran Study">Quran Study</option>
                  <option value="General">General</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Discussion Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. How do you stay consistent with Morning Adhkar?"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2.5 rounded-xl outline-none focus:border-amber-500 font-semibold"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Content / Message *</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Share your thoughts, Quran reflection, question, or Dua request here..."
                  value={newContent}
                  onChange={e => setNewContent(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2.5 rounded-xl outline-none focus:border-amber-500 leading-relaxed"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Tags (comma separated)</label>
                <input
                  type="text"
                  placeholder="e.g. Tawakkul, Prayer, Adhkar"
                  value={newTags}
                  onChange={e => setNewTags(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2.5 rounded-xl outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="py-2.5 px-4 bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!newTitle.trim() || !newContent.trim()}
                  className="py-2.5 px-5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl shadow-md disabled:opacity-40 transition"
                >
                  Publish Post
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
