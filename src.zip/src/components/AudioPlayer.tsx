import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  Clock, 
  Repeat, 
  Mic, 
  MicOff, 
  WifiOff, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  VolumeX, 
  RotateCcw 
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { triggerHaptic } from '../lib/haptics';
import { useVoiceCommand } from '../hooks/useVoiceCommand';

export default function AudioPlayer() {
  const { 
    isPlaying, 
    setIsPlaying, 
    audioRef, 
    currentUrl, 
    progress, 
    duration, 
    error, 
    audioDebug,
    reciterInfo,
    retry,
    volume,
    setVolume,
    isMuted,
    toggleMute,
    triggerNext,
    triggerPrevious,
    seek
  } = useAudio();

  const { isListening, setIsListening } = useVoiceCommand((command) => {
    if (command === 'play' && !isPlaying) togglePlay();
    else if (command === 'pause' && isPlaying) togglePlay();
  });

  const sleepTimerRef = useRef<NodeJS.Timeout | null>(null);
  const [sleepTime, setSleepTime] = useState<number | null>(null);
  const [isLooping, setIsLooping] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isOffline, setIsOffline] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;
      
      switch (e.code) {
        case 'Space':
          e.preventDefault();
          togglePlay();
          break;
        case 'ArrowLeft':
          if (audioRef.current) {
            seek(Math.max(0, audioRef.current.currentTime - 5));
          }
          break;
        case 'ArrowRight':
          if (audioRef.current) {
            seek(Math.min(duration || 0, audioRef.current.currentTime + 5));
          }
          break;
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, duration, audioRef, seek]);

  // Visualizer Animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let phase = 0;

    const render = () => {
      animationId = requestAnimationFrame(render);
      const width = canvas.width;
      const height = canvas.height;
      const centerY = height / 2;

      ctx.fillStyle = 'rgb(15, 23, 42)'; // Navy
      ctx.fillRect(0, 0, width, height);

      ctx.lineWidth = 2;
      ctx.strokeStyle = isPlaying ? 'rgb(245, 158, 11)' : 'rgb(71, 85, 105)'; // Amber or subtle slate
      ctx.beginPath();

      if (!isPlaying) {
        ctx.moveTo(0, centerY);
        ctx.lineTo(width, centerY);
      } else {
        phase += 0.05;
        for (let x = 0; x < width; x++) {
          const wave1 = Math.sin(x * 0.04 + phase) * 8;
          const wave2 = Math.cos(x * 0.02 - phase * 0.5) * 5;
          const y = centerY + wave1 + wave2;
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
      }
      ctx.stroke();
    };

    render();
    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [isPlaying]);

  const isLoading = !error && (duration === 0 || !audioRef.current?.duration);

  useEffect(() => {
    if (!audioRef.current) return;
    const checkCache = async () => {
      try {
        const cache = await caches.open('quran-audio-cache');
        const response = await cache.match(audioRef.current!.src);
        setIsOffline(!!response);
      } catch {
        setIsOffline(false);
      }
    };
    audioRef.current.addEventListener('play', checkCache);
    return () => audioRef.current?.removeEventListener('play', checkCache);
  }, [currentUrl, audioRef]);

  if (!currentUrl) return null;

  const togglePlay = () => {
    triggerHaptic(30);
    setIsPlaying(!isPlaying);
  };

  const toggleLoop = () => {
    triggerHaptic(20);
    if (audioRef.current) {
      audioRef.current.loop = !isLooping;
      setIsLooping(!isLooping);
    }
  };

  const setSleepTimer = (minutes: number | null) => {
    triggerHaptic(20);
    if (sleepTimerRef.current) clearTimeout(sleepTimerRef.current);
    setSleepTime(minutes);
    
    if (minutes) {
      sleepTimerRef.current = setTimeout(() => {
        setIsPlaying(false);
        setSleepTime(null);
      }, minutes * 60 * 1000);
    }
  };

  const changeSpeed = () => {
    triggerHaptic(20);
    const speeds = [0.5, 1, 1.25, 1.5, 2];
    const nextSpeed = speeds[(speeds.indexOf(playbackSpeed) + 1) % speeds.length];
    if (audioRef.current) {
      audioRef.current.playbackRate = nextSpeed;
    }
    setPlaybackSpeed(nextSpeed);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    triggerHaptic(10);
    const targetTime = parseFloat(e.target.value);
    seek(targetTime);
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || !isFinite(secs)) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed bottom-[65px] left-0 right-0 bg-slate-900/95 backdrop-blur border-t border-amber-900/30 p-3 flex flex-col gap-2 z-40">
      <canvas ref={canvasRef} className="w-full h-8 rounded bg-slate-950/60" />

      {error ? (
        <div className="flex flex-col gap-2 bg-red-950/30 border border-red-900/50 rounded-lg p-2.5">
          <div className="flex justify-between items-center">
            <span className="text-xs text-red-400 font-medium">Unable to load Quran audio. Please try again.</span>
            <button 
              onClick={retry} 
              className="flex items-center gap-1 text-xs bg-amber-600 hover:bg-amber-500 text-white font-medium px-2.5 py-1 rounded transition-colors"
            >
              <RotateCcw size={12} /> Retry
            </button>
          </div>
          {audioDebug && (
            <div className="text-[10px] text-slate-400 font-mono break-all bg-slate-950/80 p-1.5 rounded space-y-0.5">
              <div>URL: {audioDebug.url}</div>
              <div>Error code: {audioDebug.errorCode ?? 'N/A'} | Message: {audioDebug.errorMessage ?? 'N/A'}</div>
              <div>Ready state: {audioDebug.readyState} | Network state: {audioDebug.networkState}</div>
            </div>
          )}
        </div>
      ) : isLoading ? (
        <div className="flex items-center justify-between text-xs text-amber-500 font-medium py-1">
          <span className="animate-pulse">Loading recitation...</span>
          <span className="text-slate-400 font-mono">0:00 / 0:00</span>
        </div>
      ) : (
        <>
          <div className="flex justify-between items-center text-xs text-slate-400">
            <span className="truncate">{reciterInfo?.englishName || 'Mishary Rashid Alafasy'}</span>
            <div className="flex items-center gap-2">
              {isOffline && (
                <span className="bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded text-[10px] flex items-center gap-1 border border-slate-700" title="Playing Offline">
                  <WifiOff size={10} /> Offline
                </span>
              )}
              <span className="text-[11px] text-slate-500">{reciterInfo?.format || '128 kbps'}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* Previous */}
            <button 
              onClick={triggerPrevious} 
              className="text-slate-400 hover:text-amber-500 transition-colors"
              title="Previous Ayah"
            >
              <SkipBack size={18} />
            </button>

            {/* Play/Pause */}
            <button 
              onClick={togglePlay} 
              className="w-8 h-8 rounded-full bg-amber-600 hover:bg-amber-500 text-white flex items-center justify-center transition-colors shadow"
              title={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? <Pause size={18} /> : <Play size={18} className="translate-x-0.5" />}
            </button>

            {/* Next */}
            <button 
              onClick={triggerNext} 
              className="text-slate-400 hover:text-amber-500 transition-colors"
              title="Next Ayah"
            >
              <SkipForward size={18} />
            </button>

            {/* Voice Command */}
            <button 
              onClick={() => setIsListening(!isListening)} 
              className={`text-slate-400 hover:text-amber-500 transition-colors ${isListening ? 'animate-pulse text-red-500' : ''}`}
              title="Voice Commands"
            >
              {isListening ? <Mic size={16} /> : <MicOff size={16} />}
            </button>

            {/* Repeat */}
            <button 
              onClick={toggleLoop} 
              className={`text-slate-400 hover:text-amber-500 transition-colors ${isLooping ? 'text-amber-400' : ''}`}
              title="Repeat Ayah"
            >
              <Repeat size={16} />
            </button>

            {/* Speed */}
            <button 
              onClick={changeSpeed} 
              className="text-[11px] text-amber-500 font-medium px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 hover:border-amber-500/50"
              title="Playback Speed"
            >
              {playbackSpeed}x
            </button>

            {/* Volume */}
            <div className="relative flex items-center">
              <button 
                onClick={toggleMute} 
                onMouseEnter={() => setShowVolumeSlider(true)}
                className="text-slate-400 hover:text-amber-500 transition-colors"
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted || volume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}
              </button>
              {showVolumeSlider && (
                <div 
                  className="absolute bottom-full mb-2 -left-2 bg-slate-800 p-2 rounded shadow-lg border border-slate-700 flex items-center z-50"
                  onMouseLeave={() => setShowVolumeSlider(false)}
                >
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={isMuted ? 0 : volume}
                    onChange={(e) => setVolume(parseFloat(e.target.value))}
                    className="w-16 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-600"
                  />
                </div>
              )}
            </div>

            {/* Sleep Timer */}
            <div className="relative group">
              <button className={`text-slate-400 hover:text-amber-500 transition-colors ${sleepTime ? 'text-amber-400' : ''}`} title="Sleep Timer">
                <Clock size={16} />
              </button>
              <div className="absolute bottom-full mb-2 right-0 bg-slate-800 p-2 rounded shadow-lg border border-slate-700 hidden group-hover:flex flex-col gap-1 text-xs text-slate-300 z-50">
                <button className="hover:text-amber-400 text-left" onClick={() => setSleepTimer(null)}>Off</button>
                <button className="hover:text-amber-400 text-left" onClick={() => setSleepTimer(15)}>15m</button>
                <button className="hover:text-amber-400 text-left" onClick={() => setSleepTimer(30)}>30m</button>
                <button className="hover:text-amber-400 text-left" onClick={() => setSleepTimer(60)}>60m</button>
              </div>
            </div>

            {/* Progress Slider */}
            <input 
              type="range" 
              min={0} 
              max={duration || 0} 
              value={progress} 
              onChange={handleSeek}
              className="flex-grow h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-600"
            />

            {/* Duration Display */}
            <span className="text-xs text-slate-400 font-mono whitespace-nowrap">
              {formatTime(progress)} / {formatTime(duration)}
            </span>
          </div>
        </>
      )}
    </div>
  );
}
