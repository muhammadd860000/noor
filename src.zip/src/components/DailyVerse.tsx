import DailyAyah from './DailyAyah';

export default DailyAyah;
