import React, { useState, useMemo } from 'react';
import { 
  BookOpen, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  Award, 
  RotateCcw, 
  ChevronRight, 
  Share2,
  HelpCircle,
  Volume2
} from 'lucide-react';
import { getDailyVerseQuizForDate, dailyVerseQuizPool, VerseQuizItem } from '../lib/dailyVerseQuizData';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export default function DailyVerseQuiz() {
  const todayDateStr = useMemo(() => new Date().toISOString().split('T')[0], []);
  const scheduledQuiz = useMemo(() => getDailyVerseQuizForDate(), []);

  const [quizItem, setQuizItem] = useState<VerseQuizItem>(scheduledQuiz);
  const [selectedOption, setSelectedOption] = useState<string | null>(() => {
    return localStorage.getItem(`verseQuiz_answered_${todayDateStr}`) || null;
  });
  const [isCorrect, setIsCorrect] = useState<boolean>(() => {
    const saved = localStorage.getItem(`verseQuiz_answered_${todayDateStr}`);
    return saved === scheduledQuiz.surahName;
  });
  const [scoreStreak, setScoreStreak] = useState<number>(() => {
    return parseInt(localStorage.getItem('verseQuizStreak') || '0', 10);
  });
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const handleSelectOption = (option: string) => {
    if (selectedOption !== null) return; // already answered today

    triggerButtonClickHaptic();
    const correct = option === quizItem.surahName;
    setIsCorrect(correct);
    setSelectedOption(option);

    localStorage.setItem(`verseQuiz_answered_${todayDateStr}`, option);

    if (correct) {
      triggerSuccessHaptic();
      const newStreak = scoreStreak + 1;
      setScoreStreak(newStreak);
      localStorage.setItem('verseQuizStreak', newStreak.toString());
    } else {
      triggerHaptic(25);
    }
  };

  const handlePlayAudio = () => {
    triggerButtonClickHaptic();
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(quizItem.arabic);
    utterance.lang = 'ar-SA';
    utterance.rate = 0.9;
    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleNextRandom = () => {
    triggerButtonClickHaptic();
    const randomIndex = Math.floor(Math.random() * dailyVerseQuizPool.length);
    const nextItem = dailyVerseQuizPool[randomIndex];
    setQuizItem(nextItem);
    setSelectedOption(null);
    setIsCorrect(false);
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
    }
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-6 shadow-xl space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-amber-900/20 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <BookOpen size={22} />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <span>Daily Quran Verse Quiz</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30">
                Streak: {scoreStreak}🔥
              </span>
            </h3>
            <p className="text-xs text-slate-400">Identify the Surah of today's featured verse</p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleNextRandom}
          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-amber-400 border border-slate-700 text-xs font-medium transition flex items-center gap-1.5"
        >
          <RotateCcw size={13} />
          <span>Practice More</span>
        </button>
      </div>

      {/* Verse Scripture Box */}
      <div className="bg-slate-950/80 border border-amber-900/30 rounded-2xl p-5 space-y-4 text-center relative overflow-hidden">
        <div className="absolute top-3 right-3 flex items-center gap-2">
          <button
            type="button"
            onClick={handlePlayAudio}
            className={`p-2 rounded-xl transition ${
              isPlayingAudio ? 'bg-amber-500 text-slate-950' : 'bg-slate-900 text-amber-400 hover:bg-slate-800'
            }`}
            title="Listen to Arabic recitation"
          >
            <Volume2 size={16} />
          </button>
        </div>

        <span className="text-[11px] uppercase tracking-wider text-amber-500 font-mono">
          Ayah {quizItem.ayahNumber} • Test Your Knowledge
        </span>

        {/* Arabic Ayah */}
        <p 
          dir="rtl" 
          lang="ar"
          className="text-2xl sm:text-3xl text-amber-100 font-serif leading-[2.2] py-2 select-text"
        >
          {quizItem.arabic}
        </p>

        {/* Translation Hint */}
        <p className="text-slate-300 text-xs sm:text-sm italic max-w-xl mx-auto">
          "{quizItem.translation}"
        </p>
      </div>

      {/* Question Prompt */}
      <div className="space-y-3">
        <h4 className="text-sm font-semibold text-slate-200 text-center">
          Which Surah does this noble verse belong to?
        </h4>

        {/* Multiple Choice Options */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {quizItem.options.map((option) => {
            let btnStyle = 'bg-slate-900 border-slate-800 text-slate-200 hover:border-amber-600/50';
            if (selectedOption !== null) {
              if (option === quizItem.surahName) {
                btnStyle = 'bg-emerald-950/80 border-emerald-500 text-emerald-200 shadow-lg';
              } else if (option === selectedOption) {
                btnStyle = 'bg-rose-950/80 border-rose-500 text-rose-200';
              } else {
                btnStyle = 'bg-slate-900/50 border-slate-900 text-slate-500 opacity-50';
              }
            }

            return (
              <button
                key={option}
                type="button"
                onClick={() => handleSelectOption(option)}
                disabled={selectedOption !== null}
                className={`p-4 rounded-xl border text-sm font-semibold transition-all flex items-center justify-between ${btnStyle}`}
              >
                <span>{option}</span>
                {selectedOption !== null && option === quizItem.surahName && (
                  <CheckCircle2 size={18} className="text-emerald-400 shrink-0" />
                )}
                {selectedOption !== null && option === selectedOption && option !== quizItem.surahName && (
                  <XCircle size={18} className="text-rose-400 shrink-0" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Result feedback */}
      {selectedOption !== null && (
        <div className={`p-4 rounded-xl border text-xs sm:text-sm flex items-center gap-3 animate-fadeIn ${
          isCorrect ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300' : 'bg-rose-950/30 border-rose-500/40 text-rose-300'
        }`}>
          {isCorrect ? <CheckCircle2 size={20} className="text-emerald-400 shrink-0" /> : <XCircle size={20} className="text-rose-400 shrink-0" />}
          <div>
            <p className="font-semibold">
              {isCorrect ? 'Correct! MashaAllah!' : `Incorrect. The correct Surah is ${quizItem.surahName}.`}
            </p>
            <p className="text-slate-400 text-xs mt-0.5">
              Come back tomorrow for a brand new Quran verse quiz!
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
