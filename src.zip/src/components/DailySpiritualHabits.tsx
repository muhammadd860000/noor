import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  Flame, 
  Calendar as CalendarIcon, 
  Check, 
  Plus, 
  Trash2, 
  Sparkles, 
  Moon, 
  BookOpen, 
  Heart, 
  ChevronLeft, 
  ChevronRight,
  Award,
  RotateCcw
} from 'lucide-react';
import { triggerHaptic } from '../lib/haptics';

export interface SpiritualHabit {
  id: string;
  name: string;
  arabic?: string;
  category: 'adhkar' | 'fasting' | 'quran' | 'charity' | 'general';
  description?: string;
  iconName?: string;
  isDefault?: boolean;
}

export interface DayHabitLog {
  [habitId: string]: boolean;
}

export interface HabitsLogHistory {
  [dateStr: string]: DayHabitLog; // "YYYY-MM-DD" -> { habitId: boolean }
}

const DEFAULT_HABITS: SpiritualHabit[] = [
  {
    id: 'habit_adhkar',
    name: 'Morning & Evening Adhkar',
    arabic: 'أذكار الصباح والمساء',
    category: 'adhkar',
    description: 'Recite the prophetic morning or evening fortress of remembrance',
    isDefault: true,
  },
  {
    id: 'habit_fasting',
    name: 'Fasting (Sawm)',
    arabic: 'صيام التطوع',
    category: 'fasting',
    description: 'Sunnah fasting on Mondays, Thursdays, or the 13th-15th White Days',
    isDefault: true,
  },
  {
    id: 'habit_quran',
    name: 'Daily Quran Tilawah & Tadabbur',
    arabic: 'تلاوة القرآن وتدبره',
    category: 'quran',
    description: 'Read at least 1 Rub/Hizb or reflect deeply upon 5 verses',
    isDefault: true,
  },
  {
    id: 'habit_salawat',
    name: '100× Salawat & Istighfar',
    arabic: 'الصلاة على النبي والاستغفار',
    category: 'adhkar',
    description: 'Send blessings upon the Prophet (ﷺ) and seek forgiveness',
    isDefault: true,
  },
  {
    id: 'habit_charity',
    name: 'Sadaqah & Daily Kindness',
    arabic: 'الصدقة والإحسان',
    category: 'charity',
    description: 'Give monetary charity, share food, or offer a sincere smiling kindness',
    isDefault: true,
  },
];

export default function DailySpiritualHabits() {
  const todayDate = useMemo(() => new Date(), []);
  const todayStr = useMemo(() => todayDate.toISOString().slice(0, 10), [todayDate]);

  // Calendar view navigation (Year & Month)
  const [viewYear, setViewYear] = useState(() => todayDate.getFullYear());
  const [viewMonth, setViewMonth] = useState(() => todayDate.getMonth()); // 0-indexed

  // Selected date for viewing/marking habits (defaults to today)
  const [selectedDateStr, setSelectedDateStr] = useState<string>(todayStr);

  // Habits list
  const [habits, setHabits] = useState<SpiritualHabit[]>(() => {
    try {
      const saved = localStorage.getItem('spiritualHabits_list');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return DEFAULT_HABITS;
  });

  // History logs: { "2026-09-28": { "habit_adhkar": true, "habit_fasting": true } }
  const [logs, setLogs] = useState<HabitsLogHistory>(() => {
    try {
      const saved = localStorage.getItem('spiritualHabits_logs');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    // Seed sample recent days for visual richness if first time
    const initialSeed: HabitsLogHistory = {};
    const d = new Date();
    // Mark yesterday as completed for demonstration of streak
    d.setDate(d.getDate() - 1);
    const yStr = d.toISOString().slice(0, 10);
    initialSeed[yStr] = {
      habit_adhkar: true,
      habit_quran: true,
      habit_salawat: true,
    };
    return initialSeed;
  });

  // New habit input state
  const [isAdding, setIsAdding] = useState(false);
  const [newHabitName, setNewHabitName] = useState('');
  const [newHabitCategory, setNewHabitCategory] = useState<SpiritualHabit['category']>('general');

  // Persist habits
  useEffect(() => {
    try {
      localStorage.setItem('spiritualHabits_list', JSON.stringify(habits));
    } catch (e) {
      console.warn(e);
    }
  }, [habits]);

  // Persist logs
  useEffect(() => {
    try {
      localStorage.setItem('spiritualHabits_logs', JSON.stringify(logs));
    } catch (e) {
      console.warn(e);
    }
  }, [logs]);

  // Check if today is Monday or Thursday (Sunnah fasting days)
  const isMondayOrThursday = useMemo(() => {
    const day = todayDate.getDay();
    return day === 1 || day === 4; // 1 = Monday, 4 = Thursday
  }, [todayDate]);

  // Calculate current active streak (consecutive days with at least 1 habit completed)
  const currentStreak = useMemo(() => {
    let streak = 0;
    const checkDate = new Date();

    // Check today: if has completed habits, start with today, else check if yesterday had completion
    const todayLog = logs[todayStr] || {};
    const todayHasHabits = Object.values(todayLog).some(Boolean);

    if (todayHasHabits) {
      streak += 1;
      checkDate.setDate(checkDate.getDate() - 1);
    } else {
      // If not yet completed today, streak is valid if yesterday was completed
      checkDate.setDate(checkDate.getDate() - 1);
    }

    while (true) {
      const key = checkDate.toISOString().slice(0, 10);
      const dayLog = logs[key] || {};
      const hasCompleted = Object.values(dayLog).some(Boolean);

      if (hasCompleted) {
        streak += 1;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        break;
      }
    }

    return streak;
  }, [logs, todayStr]);

  // Longest streak calculation
  const longestStreak = useMemo(() => {
    let max = currentStreak;
    try {
      const savedMax = parseInt(localStorage.getItem('spiritualHabits_maxStreak') || '0', 10);
      if (currentStreak > savedMax) {
        localStorage.setItem('spiritualHabits_maxStreak', currentStreak.toString());
        return currentStreak;
      }
      return Math.max(savedMax, currentStreak);
    } catch {
      return max;
    }
  }, [currentStreak]);

  // Toggle a habit on the selected date
  const handleToggleHabit = useCallback((habitId: string) => {
    triggerHaptic(25);
    setLogs(prev => {
      const currentDayLog = prev[selectedDateStr] || {};
      const isCurrentlyDone = !!currentDayLog[habitId];
      const updatedDayLog = {
        ...currentDayLog,
        [habitId]: !isCurrentlyDone,
      };

      return {
        ...prev,
        [selectedDateStr]: updatedDayLog,
      };
    });
  }, [selectedDateStr]);

  // Add custom habit
  const handleAddHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabitName.trim()) return;

    triggerHaptic(20);
    const newHabit: SpiritualHabit = {
      id: `habit_custom_${Date.now()}`,
      name: newHabitName.trim(),
      category: newHabitCategory,
      isDefault: false,
    };

    setHabits(prev => [...prev, newHabit]);
    setNewHabitName('');
    setIsAdding(false);
  };

  // Remove custom habit
  const handleRemoveHabit = (habitId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic(15);
    setHabits(prev => prev.filter(h => h.id !== habitId));
  };

  // Navigation for calendar month
  const handlePrevMonth = () => {
    triggerHaptic(10);
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear(prev => prev - 1);
    } else {
      setViewMonth(prev => prev - 1);
    }
  };

  const handleNextMonth = () => {
    triggerHaptic(10);
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear(prev => prev + 1);
    } else {
      setViewMonth(prev => prev + 1);
    }
  };

  // Calendar days generation for viewYear & viewMonth
  const calendarDays = useMemo(() => {
    const firstDay = new Date(viewYear, viewMonth, 1);
    const lastDay = new Date(viewYear, viewMonth + 1, 0);
    const daysInMonth = lastDay.getDate();

    // 0 = Sunday, 1 = Monday, ... we align Monday as first column or Sunday
    // Standard Sunday = 0
    const startDayOfWeek = firstDay.getDay();

    const days = [];
    // Padding days from previous month
    for (let i = 0; i < startDayOfWeek; i++) {
      days.push({ dayNumber: null, dateStr: null, isCurrentMonth: false });
    }

    // Days in current month
    for (let day = 1; day <= daysInMonth; day++) {
      const monthStr = String(viewMonth + 1).padStart(2, '0');
      const dayStr = String(day).padStart(2, '0');
      const dateStr = `${viewYear}-${monthStr}-${dayStr}`;

      const dayLog = logs[dateStr] || {};
      const completedList = Object.values(dayLog).filter(Boolean);
      const completedCount = completedList.length;
      const isFasted = !!dayLog['habit_fasting'];

      days.push({
        dayNumber: day,
        dateStr,
        isCurrentMonth: true,
        isToday: dateStr === todayStr,
        completedCount,
        isFasted,
      });
    }

    return days;
  }, [viewYear, viewMonth, logs, todayStr]);

  const monthName = useMemo(() => {
    return new Date(viewYear, viewMonth, 1).toLocaleDateString('en-US', {
      month: 'long',
      year: 'numeric',
    });
  }, [viewYear, viewMonth]);

  // Selected date log stats
  const selectedDayLog = logs[selectedDateStr] || {};
  const selectedCompletedCount = habits.filter(h => !!selectedDayLog[h.id]).length;
  const selectedIsToday = selectedDateStr === todayStr;

  const selectedDateFormatted = useMemo(() => {
    const [y, m, d] = selectedDateStr.split('-').map(Number);
    return new Date(y, m - 1, d).toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });
  }, [selectedDateStr]);

  return (
    <section 
      aria-label="Daily Spiritual Habits"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-700/50 md:col-span-2 space-y-6"
    >
      {/* Subtle ambient lighting */}
      <div 
        aria-hidden="true" 
        className="absolute -top-20 -right-20 w-52 h-52 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" 
      />
      <div 
        aria-hidden="true" 
        className="absolute -bottom-20 -left-20 w-52 h-52 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none" 
      />

      {/* Header bar: Title, Streak Counter, Today's Completion */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <span className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <Sparkles size={20} />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-100 tracking-tight">
                Daily Spiritual Habits
              </h3>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Non-Prayer Devotions
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Adhkar, voluntary fasting, Quran reflection, and daily deeds with visual calendar consistency
            </p>
          </div>
        </div>

        {/* Badges: Active Streak and Today's Score */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <div 
            title={`Current active streak: ${currentStreak} consecutive days (Best: ${longestStreak} days)`}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold"
          >
            <Flame size={15} className="fill-amber-400 text-amber-500 animate-pulse" />
            <span>{currentStreak} {currentStreak === 1 ? 'Day Streak' : 'Days Streak'}</span>
          </div>

          <div className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700/60 text-slate-200 text-xs font-mono font-medium">
            <span className="text-emerald-400 font-bold">{selectedCompletedCount}</span>
            <span className="text-slate-400">/{habits.length}</span>
            <span className="text-[11px] text-slate-400 ml-0.5">Done</span>
          </div>
        </div>
      </div>

      {/* Prophetic Sunnah Fasting Banner (if Monday or Thursday) */}
      {isMondayOrThursday && (
        <div className="p-3 bg-emerald-950/30 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Moon size={15} className="text-emerald-400 flex-shrink-0" />
            <span>
              <strong>Prophetic Sunnah:</strong> Today is {todayDate.toLocaleDateString('en-US', { weekday: 'long' })} — a blessed day for voluntary fasting (Sawm).
            </span>
          </div>
          <span className="text-[11px] font-mono text-emerald-400 font-semibold hidden sm:inline">
            Sahih Muslim
          </span>
        </div>
      )}

      {/* Main Grid: Left = Habit Checklist, Right = Visual Calendar Streak Heatmap */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (Habits Checklist): 7 Cols on desktop */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 pb-1">
            <div className="flex items-center gap-1.5">
              <span className="font-semibold text-slate-200">
                {selectedIsToday ? "Today's Checklist" : `Habits for ${selectedDateFormatted}`}
              </span>
              {!selectedIsToday && (
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic(10);
                    setSelectedDateStr(todayStr);
                  }}
                  className="text-amber-500 hover:underline font-medium text-[11px]"
                >
                  (Back to Today)
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                triggerHaptic(10);
                setIsAdding(!isAdding);
              }}
              className="text-amber-500 hover:text-amber-400 font-medium flex items-center gap-1 transition-colors"
            >
              <Plus size={13} />
              <span>{isAdding ? 'Cancel' : 'Add Custom'}</span>
            </button>
          </div>

          {/* Add Custom Habit Form */}
          {isAdding && (
            <form onSubmit={handleAddHabit} className="p-3 bg-slate-950/70 border border-amber-900/40 rounded-xl space-y-2.5 animate-fadeIn">
              <input
                type="text"
                placeholder="Habit name (e.g. 20 Mins Islamic Reading, Dua Before Sleep)"
                value={newHabitName}
                onChange={e => setNewHabitName(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                autoFocus
              />
              <div className="flex items-center justify-between">
                <div className="flex gap-1.5 text-[11px]">
                  {(['general', 'adhkar', 'quran', 'charity'] as const).map(cat => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setNewHabitCategory(cat)}
                      className={`px-2 py-0.5 rounded capitalize ${
                        newHabitCategory === cat
                          ? 'bg-amber-600 text-slate-950 font-bold'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
                <button
                  type="submit"
                  className="px-3 py-1 bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-bold rounded-lg transition-colors"
                >
                  Save Habit
                </button>
              </div>
            </form>
          )}

          {/* Habits Items */}
          <div className="space-y-2">
            {habits.map(habit => {
              const isDone = !!selectedDayLog[habit.id];

              let iconElement = <Sparkles size={16} className="text-amber-400" />;
              if (habit.category === 'adhkar') iconElement = <Heart size={16} className="text-amber-400" />;
              if (habit.category === 'fasting') iconElement = <Moon size={16} className="text-emerald-400" />;
              if (habit.category === 'quran') iconElement = <BookOpen size={16} className="text-blue-400" />;

              return (
                <div
                  key={habit.id}
                  onClick={() => handleToggleHabit(habit.id)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={e => {
                    if (e.key === ' ' || e.key === 'Enter') {
                      e.preventDefault();
                      handleToggleHabit(habit.id);
                    }
                  }}
                  aria-pressed={isDone}
                  className={`group p-3 sm:p-3.5 rounded-xl border flex items-center justify-between cursor-pointer select-none transition-all duration-200 active:scale-[0.99] ${
                    isDone
                      ? 'bg-amber-950/20 border-amber-500/50 text-slate-200 shadow-sm shadow-amber-500/10'
                      : 'bg-slate-950/60 hover:bg-slate-800/50 border-slate-800/80 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {/* Checkbox button */}
                    <div className={`w-6 h-6 rounded-lg flex items-center justify-center border transition-all duration-200 ${
                      isDone
                        ? 'bg-amber-500 border-amber-400 text-slate-950 shadow-md shadow-amber-500/20'
                        : 'border-slate-600 text-transparent group-hover:border-amber-400'
                    }`}>
                      <Check size={14} strokeWidth={3} className={isDone ? 'block' : 'hidden'} />
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className={`text-xs sm:text-sm font-semibold transition-colors ${
                          isDone ? 'text-amber-300' : 'text-slate-200'
                        }`}>
                          {habit.name}
                        </span>
                        {habit.arabic && (
                          <span className="text-[11px] font-serif text-slate-400 opacity-70 hidden sm:inline" dir="rtl">
                            {habit.arabic}
                          </span>
                        )}
                        {habit.id === 'habit_fasting' && isMondayOrThursday && (
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                            Sunnah Today
                          </span>
                        )}
                      </div>

                      {habit.description && (
                        <p className="text-[11px] text-slate-400 leading-tight mt-0.5">
                          {habit.description}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="p-1 rounded-lg bg-slate-800/60 text-slate-400">
                      {iconElement}
                    </span>

                    {!habit.isDefault && (
                      <button
                        type="button"
                        onClick={e => handleRemoveHabit(habit.id, e)}
                        className="text-slate-600 hover:text-red-400 p-1 transition-colors"
                        title="Delete custom habit"
                      >
                        <Trash2 size={13} />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (Visual Calendar Streak Heatmap): 5 Cols on desktop */}
        <div className="lg:col-span-5 bg-slate-950/60 border border-amber-900/30 rounded-2xl p-4 sm:p-5 space-y-4 shadow-inner">
          {/* Calendar Header with Month Navigation */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-1.5">
              <CalendarIcon size={15} className="text-amber-500" />
              <span className="text-xs font-semibold text-slate-200">
                {monthName}
              </span>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handlePrevMonth}
                className="p-1 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition-colors"
                title="Previous month"
                aria-label="Previous month"
              >
                <ChevronLeft size={16} />
              </button>
              <button
                type="button"
                onClick={handleNextMonth}
                className="p-1 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition-colors"
                title="Next month"
                aria-label="Next month"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>

          {/* Days of Week Header */}
          <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-mono text-slate-400 font-semibold">
            <span>Su</span>
            <span>Mo</span>
            <span>Tu</span>
            <span>We</span>
            <span>Th</span>
            <span>Fr</span>
            <span>Sa</span>
          </div>

          {/* Calendar Day Grid Heatmap */}
          <div className="grid grid-cols-7 gap-1.5">
            {calendarDays.map((cell, idx) => {
              if (!cell.isCurrentMonth || !cell.dateStr) {
                return (
                  <div key={`empty-${idx}`} className="w-full aspect-square rounded-lg opacity-10" />
                );
              }

              const isSelected = cell.dateStr === selectedDateStr;
              const hasCompletion = cell.completedCount > 0;
              const isAllDone = cell.completedCount >= habits.length;

              // Heatmap color logic
              let bgStyle = 'bg-slate-900 text-slate-400 hover:bg-slate-800 border-slate-800';
              if (cell.isFasted && hasCompletion) {
                bgStyle = 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40 shadow-sm shadow-emerald-500/10 font-bold';
              } else if (isAllDone) {
                bgStyle = 'bg-amber-500/30 text-amber-200 border-amber-500/50 shadow-sm shadow-amber-500/20 font-bold';
              } else if (cell.completedCount >= 3) {
                bgStyle = 'bg-amber-600/20 text-amber-300 border-amber-600/30 font-medium';
              } else if (hasCompletion) {
                bgStyle = 'bg-amber-900/20 text-amber-400/90 border-amber-800/30';
              }

              return (
                <button
                  key={cell.dateStr}
                  type="button"
                  onClick={() => {
                    triggerHaptic(10);
                    setSelectedDateStr(cell.dateStr!);
                  }}
                  className={`relative w-full aspect-square rounded-lg flex flex-col items-center justify-center text-xs font-mono border transition-all duration-150 active:scale-90 ${bgStyle} ${
                    cell.isToday ? 'ring-2 ring-amber-400 font-bold text-amber-300' : ''
                  } ${
                    isSelected ? 'outline-none ring-2 ring-emerald-400 scale-105 z-10' : ''
                  }`}
                  title={`${cell.dateStr}: ${cell.completedCount} habits completed${cell.isFasted ? ' (Fasted 🌙)' : ''}`}
                >
                  <span>{cell.dayNumber}</span>

                  {/* Indicators for Fasting or Habit Dots */}
                  {cell.isFasted ? (
                    <span className="text-[9px] text-emerald-400 leading-none">🌙</span>
                  ) : hasCompletion ? (
                    <span className={`w-1 h-1 rounded-full mt-0.5 ${isAllDone ? 'bg-amber-400' : 'bg-amber-500/70'}`} />
                  ) : null}
                </button>
              );
            })}
          </div>

          {/* Calendar Heatmap Legend */}
          <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-400">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-slate-900 border border-slate-800" />
              <span>None</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-amber-900/30 border border-amber-700/30" />
              <span>1-2 Done</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-amber-500/30 border border-amber-500/50" />
              <span>All Done</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-bold">🌙</span>
              <span>Fasted</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
