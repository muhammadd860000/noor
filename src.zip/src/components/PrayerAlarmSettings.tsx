import React, { useState, useEffect } from 'react';
import { Bell, Volume2, Sparkles, Check, Play, Music } from 'lucide-react';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export interface PrayerSoundConfig {
  [prayerName: string]: string; // sound id
}

const ATHAN_SOUNDS = [
  { id: 'makkah', name: 'Al-Haram (Makkah) Athan', description: 'Melodic and majestic' },
  { id: 'madinah', name: 'Al-Masjid an-Nabawi Athan', description: 'Serene and spiritual' },
  { id: 'aqsa', name: 'Masjid al-Aqsa Athan', description: 'Deep and resonant' },
  { id: 'classic', name: 'Classicadhan', description: 'Traditional tone' },
  { id: 'chime', name: 'Gentle Chime', description: 'Soft subtle notification' }
];

const STORAGE_KEY = 'noor_prayer_alarm_sounds';

export default function PrayerAlarmSettings() {
  const [soundConfigs, setSoundConfigs] = useState<PrayerSoundConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : {
        Fajr: 'makkah',
        Dhuhr: 'madinah',
        Asr: 'madinah',
        Maghrib: 'makkah',
        Isha: 'aqsa'
      };
    } catch {
      return {
        Fajr: 'makkah',
        Dhuhr: 'madinah',
        Asr: 'madinah',
        Maghrib: 'makkah',
        Isha: 'aqsa'
      };
    }
  });

  const [playingSound, setPlayingSound] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(soundConfigs));
    } catch {}
  }, [soundConfigs]);

  const handleSoundChange = (prayer: string, soundId: string) => {
    triggerHaptic(10);
    setSoundConfigs(prev => ({
      ...prev,
      [prayer]: soundId
    }));
  };

  const handlePreviewSound = (soundId: string) => {
    triggerButtonClickHaptic();
    setPlayingSound(soundId);

    // Play synthesis chime / preview
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        const ctx = new AudioContextClass();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        
        osc.type = soundId === 'makkah' ? 'sine' : soundId === 'aqsa' ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(soundId === 'makkah' ? 440 : 330, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.4);

        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.8);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start();
        osc.stop(ctx.currentTime + 0.8);
      }
    } catch (e) {
      console.warn(e);
    }

    setTimeout(() => {
      setPlayingSound(null);
    }, 1000);
  };

  return (
    <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
      <div className="flex items-center justify-between pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <span className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <Music size={20} />
          </span>
          <div>
            <h3 className="text-base font-bold text-slate-100">Prayer Alarm & Custom Athan Sounds</h3>
            <p className="text-xs text-slate-400">Configure distinct notification audio clips for each individual prayer</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].map(prayer => {
          const selectedSound = soundConfigs[prayer] || 'makkah';

          return (
            <div key={prayer} className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-3 flex flex-col justify-between">
              <div className="space-y-1">
                <span className="text-xs font-mono uppercase text-amber-400 font-bold block">{prayer}</span>
                <p className="text-[11px] text-slate-400">Alarm Audio Clip</p>
              </div>

              <div className="space-y-2">
                <select
                  value={selectedSound}
                  onChange={(e) => handleSoundChange(prayer, e.target.value)}
                  className="w-full bg-slate-900 text-slate-200 border border-slate-800 focus:border-amber-500 p-2 text-xs rounded-xl outline-none"
                >
                  {ATHAN_SOUNDS.map(sound => (
                    <option key={sound.id} value={sound.id}>
                      {sound.name}
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={() => handlePreviewSound(selectedSound)}
                  className="w-full py-1.5 px-3 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-amber-400 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition"
                >
                  <Play size={12} className={playingSound === selectedSound ? 'animate-bounce text-emerald-400' : ''} />
                  <span>{playingSound === selectedSound ? 'Playing...' : 'Test Sound'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
