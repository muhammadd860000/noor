import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Printer, 
  Download, 
  Sparkles, 
  CheckCircle2, 
  TrendingUp, 
  Calendar, 
  Award, 
  Heart, 
  Flame, 
  Hash, 
  BarChart2 
} from 'lucide-react';
import { generateSpiritualReport, openPrintableSpiritualReport } from '../lib/pdfSummaryGenerator';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export default function Reports() {
  const [report, setReport] = useState(() => generateSpiritualReport());

  useEffect(() => {
    setReport(generateSpiritualReport());
  }, []);

  const handleDownloadPDF = () => {
    triggerButtonClickHaptic();
    openPrintableSpiritualReport();
    triggerSuccessHaptic();
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header */}
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-900/30 pb-4">
        <div>
          <h2 className="text-2xl text-amber-500 font-serif font-bold flex items-center gap-2">
            <FileText size={24} />
            <span>Spiritual Progress Reports</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Comprehensive aggregation of weekly prayer consistency, daily spiritual goals, and Dhikr progress
          </p>
        </div>

        <button
          type="button"
          onClick={handleDownloadPDF}
          className="px-4 py-2.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-600/20 flex items-center gap-2 transition active:scale-95 self-start sm:self-auto"
        >
          <Printer size={16} />
          <span>Download Printable PDF Report</span>
        </button>
      </header>

      {/* Highlights Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-4 flex items-center gap-3">
          <span className="p-3 rounded-xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <TrendingUp size={22} />
          </span>
          <div>
            <span className="text-xs text-slate-400 block font-medium">Prayer Consistency</span>
            <span className="text-xl font-bold text-slate-100">{report.prayerSummary.recentConsistencyPct}%</span>
            <span className="text-[10px] text-emerald-400 block font-mono">{report.prayerSummary.totalDaysTracked} Days Tracked</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-4 flex items-center gap-3">
          <span className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Award size={22} />
          </span>
          <div>
            <span className="text-xs text-slate-400 block font-medium">Active Spiritual Goals</span>
            <span className="text-xl font-bold text-slate-100">{report.goalsSummary.totalGoals} Goals</span>
            <span className="text-[10px] text-amber-400 block font-mono">Daily Striving</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-4 flex items-center gap-3">
          <span className="p-3 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Heart size={22} />
          </span>
          <div>
            <span className="text-xs text-slate-400 block font-medium">Total Charity / Zakat</span>
            <span className="text-xl font-bold text-slate-100">${report.zakatSummary.totalAmountContributed.toLocaleString()}</span>
            <span className="text-[10px] text-slate-400 block font-mono">{report.zakatSummary.totalContributionsCount} Recorded Donations</span>
          </div>
        </div>
      </div>

      {/* Detailed Prayer Breakdown */}
      <section className="bg-slate-900/80 border border-amber-900/30 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-amber-900/20">
          <div className="flex items-center gap-2">
            <BarChart2 size={18} className="text-amber-500" />
            <h3 className="text-base font-bold text-slate-100">Weekly Prayer Consistency Overview</h3>
          </div>
          <span className="text-xs font-mono text-amber-400">Rate: {report.prayerSummary.recentConsistencyPct}%</span>
        </div>

        {Object.keys(report.prayerSummary.breakdown).length === 0 ? (
          <p className="text-xs text-slate-400 italic py-2">No prayer records logged yet this week. Mark your prayers in the Prayer module to see live breakdown.</p>
        ) : (
          <div className="space-y-2">
            {Object.entries(report.prayerSummary.breakdown).slice(-7).map(([date, prayers]: [string, any]) => {
              const completedCount = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].filter(p => prayers?.[p]).length;

              return (
                <div key={date} className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between gap-3 text-xs">
                  <span className="font-mono text-slate-300 font-medium">{date}</span>
                  <div className="flex items-center gap-1.5">
                    {['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].map(p => (
                      <span 
                        key={p} 
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          prayers?.[p] ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-slate-900 text-slate-600'
                        }`}
                      >
                        {p}
                      </span>
                    ))}
                  </div>
                  <span className="text-amber-400 font-bold">{completedCount}/5</span>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Spiritual Goals & Habits Summary */}
      <section className="bg-slate-900/80 border border-amber-900/30 rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-amber-900/20">
          <Award size={18} className="text-amber-500" />
          <h3 className="text-base font-bold text-slate-100">Spiritual Goals & Daily Habits</h3>
        </div>

        <div className="space-y-2">
          {report.goalsSummary.activeGoalsList.length === 0 ? (
            <p className="text-xs text-slate-400 italic py-2">No active goals configured. Set goals in the Home or Prayer module to summarize here.</p>
          ) : (
            report.goalsSummary.activeGoalsList.map((g: any, idx: number) => (
              <div key={idx} className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={14} className="text-emerald-400" />
                  <span className="text-slate-200 font-medium">{g.title}</span>
                </div>
                <span className="text-[10px] font-mono text-amber-400 uppercase bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  {g.category || 'Habit'}
                </span>
              </div>
            ))
          )}
        </div>
      </section>

      {/* PDF Export Banner */}
      <div className="p-6 bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/30 rounded-2xl text-center space-y-3">
        <Sparkles size={24} className="mx-auto text-amber-400 animate-pulse" />
        <h4 className="text-sm font-bold text-slate-100">Need an Official Physical Printout?</h4>
        <p className="text-xs text-slate-400 max-w-md mx-auto">
          Generate an official formatted PDF containing your spiritual habits, prayer breakdown, and charity logs to save or print.
        </p>
        <button
          type="button"
          onClick={handleDownloadPDF}
          className="px-5 py-2.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-md transition"
        >
          Print / Save PDF Report
        </button>
      </div>
    </div>
  );
}
