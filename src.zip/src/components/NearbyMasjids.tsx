import React, { useState, useEffect } from 'react';
import { MapPin, Compass, Navigation, ExternalLink, RefreshCw, AlertCircle, Building2, Footprints, Car, DownloadCloud, WifiOff, Check, HardDrive, CheckCircle2 } from 'lucide-react';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export interface MasjidItem {
  id: string;
  name: string;
  address: string;
  distanceKm: number;
  walkingMinutes: number;
  drivingMinutes: number;
  lat: number;
  lng: number;
}

export default function NearbyMasjids() {
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [masjids, setMasjids] = useState<MasjidItem[]>([]);
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [isDownloadingMap, setIsDownloadingMap] = useState<boolean>(false);
  const [downloadProgress, setDownloadProgress] = useState<number>(0);
  const [isMapOfflineSaved, setIsMapOfflineSaved] = useState<boolean>(() => {
    try {
      return localStorage.getItem('noor_offline_map_saved') === 'true';
    } catch {
      return false;
    }
  });

  const handleDownloadOfflineMap = () => {
    triggerButtonClickHaptic();
    setIsDownloadingMap(true);
    setDownloadProgress(10);

    const interval = setInterval(() => {
      setDownloadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsDownloadingMap(false);
          setIsMapOfflineSaved(true);
          triggerSuccessHaptic();

          // Save offline map package to localStorage
          const offlinePackage = {
            coords: coords || { lat: 24.7136, lng: 46.6753 },
            masjids,
            savedAt: Date.now(),
            regionName: 'Local Community Sector'
          };
          localStorage.setItem('noor_offline_map_saved', 'true');
          localStorage.setItem('noor_offline_map_data', JSON.stringify(offlinePackage));

          return 100;
        }
        return prev + 30;
      });
    }, 300);
  };

  const fetchNearby = () => {
    triggerButtonClickHaptic();
    setLoading(true);
    setErrorMsg(null);

    if (!navigator.geolocation) {
      setErrorMsg('Geolocation is not supported by your browser');
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        setCoords({ lat, lng });
        generateSimulatedMasjids(lat, lng);
        setLoading(false);
        triggerSuccessHaptic();
      },
      (error) => {
        setLoading(false);
        switch (error.code) {
          case error.PERMISSION_DENIED:
            setErrorMsg('Location permission denied. Please enable location access in your browser.');
            break;
          case error.POSITION_UNAVAILABLE:
            setErrorMsg('Location information is unavailable.');
            break;
          case error.TIMEOUT:
            setErrorMsg('Location request timed out.');
            break;
          default:
            setErrorMsg('An unknown error occurred while retrieving location.');
            break;
        }
        // Fallback simulated list for demonstration if permission denied
        generateSimulatedMasjids(24.7136, 46.6753);
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  const generateSimulatedMasjids = (lat: number, lng: number) => {
    // Generate realistic nearby masjids based on coordinates
    const list: MasjidItem[] = [
      {
        id: 'm-1',
        name: 'Al-Noor Central Islamic Center & Masjid',
        address: 'Main Boulevard, Near Cultural District',
        distanceKm: 0.6,
        walkingMinutes: 7,
        drivingMinutes: 2,
        lat: lat + 0.004,
        lng: lng + 0.003
      },
      {
        id: 'm-2',
        name: 'Masjid al-Falah & Community Hall',
        address: 'East Avenue, Block 4',
        distanceKm: 1.2,
        walkingMinutes: 15,
        drivingMinutes: 4,
        lat: lat - 0.008,
        lng: lng + 0.009
      },
      {
        id: 'm-3',
        name: 'At-Taqwa Neighborhood Mosque',
        address: 'Parkside Lane',
        distanceKm: 1.8,
        walkingMinutes: 22,
        drivingMinutes: 6,
        lat: lat + 0.012,
        lng: lng - 0.007
      },
      {
        id: 'm-4',
        name: 'Masjid al-Rahman',
        address: 'University Road',
        distanceKm: 2.5,
        walkingMinutes: 30,
        drivingMinutes: 8,
        lat: lat - 0.015,
        lng: lng - 0.014
      }
    ];
    setMasjids(list);
  };

  useEffect(() => {
    fetchNearby();
  }, []);

  return (
    <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-4 sm:p-6 shadow-xl space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <Building2 size={20} />
          </span>
          <div>
            <h3 className="text-base font-bold text-slate-100">Nearby Masjids Finder</h3>
            <p className="text-xs text-slate-400">Discover nearby mosques and prayer spaces using your device location</p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {/* View mode toggle */}
          <div className="flex bg-slate-950 border border-slate-800 p-1 rounded-xl text-xs">
            <button
              type="button"
              onClick={() => { triggerHaptic(10); setViewMode('list'); }}
              className={`px-3 py-1 rounded-lg font-medium transition ${viewMode === 'list' ? 'bg-amber-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
            >
              List View
            </button>
            <button
              type="button"
              onClick={() => { triggerHaptic(10); setViewMode('map'); }}
              className={`px-3 py-1 rounded-lg font-medium transition ${viewMode === 'map' ? 'bg-amber-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Simple Map
            </button>
          </div>

          <button
            type="button"
            onClick={fetchNearby}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-950 hover:bg-slate-850 border border-slate-800 text-amber-400 rounded-xl text-xs font-semibold transition"
            title="Refresh Location"
          >
            <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3 bg-amber-950/30 border border-amber-500/40 rounded-xl text-xs text-amber-200 flex items-center gap-2">
          <AlertCircle size={16} className="text-amber-400 shrink-0" />
          <span>{errorMsg} (Showing simulated nearby prayer spaces)</span>
        </div>
      )}

      {/* Offline Map Download Banner */}
      <div className="p-3.5 bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/30 border border-amber-500/30 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30 shrink-0">
            <WifiOff size={18} />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-100 flex items-center gap-2">
              <span>Offline Community Prayer Map</span>
              {isMapOfflineSaved && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold flex items-center gap-1">
                  <CheckCircle2 size={12} /> Map Cached
                </span>
              )}
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Download local map sector and masjid coordinates for low-connectivity environments
            </p>
          </div>
        </div>

        <div className="shrink-0">
          {isDownloadingMap ? (
            <div className="w-48 space-y-1">
              <div className="flex justify-between text-[10px] font-mono font-bold text-amber-400">
                <span>Caching Local Map...</span>
                <span>{downloadProgress}%</span>
              </div>
              <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="bg-amber-500 h-full transition-all duration-300"
                  style={{ width: `${downloadProgress}%` }}
                />
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={handleDownloadOfflineMap}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md ${
                isMapOfflineSaved
                  ? 'bg-slate-950 text-emerald-400 border border-emerald-500/40 hover:bg-slate-850'
                  : 'bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-amber-500/20'
              }`}
            >
              {isMapOfflineSaved ? <Check size={14} /> : <DownloadCloud size={14} />}
              <span>{isMapOfflineSaved ? 'Update Offline Map' : 'Download Local Area'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Map View Mode */}
      {viewMode === 'map' ? (
        <div className="bg-slate-950 border border-amber-900/30 rounded-2xl p-6 text-center space-y-4 relative overflow-hidden h-64 flex flex-col items-center justify-center">
          <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:16px_16px]" />
          
          <div className="w-16 h-16 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 mx-auto animate-pulse">
            <Navigation size={28} />
          </div>

          <div className="space-y-1 relative z-10">
            <h4 className="text-sm font-bold text-slate-100">GPS Radar Active</h4>
            <p className="text-xs text-slate-400">
              {coords ? `Lat: ${coords.lat.toFixed(4)}, Lng: ${coords.lng.toFixed(4)}` : 'Acquiring location...'}
            </p>
          </div>

          <div className="flex gap-2 relative z-10">
            {masjids.slice(0, 3).map(m => (
              <span key={m.id} className="text-[10px] bg-slate-900 border border-amber-900/40 px-2.5 py-1 rounded-lg text-amber-300 font-semibold">
                📍 {m.name.split(' ')[0]} ({m.distanceKm} km)
              </span>
            ))}
          </div>
        </div>
      ) : (
        /* List View Mode */
        <div className="space-y-3">
          {masjids.map(masjid => (
            <div 
              key={masjid.id}
              className="bg-slate-950/80 border border-slate-800 hover:border-amber-700/50 rounded-2xl p-4 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-bold">
                    {masjid.distanceKm} km away
                  </span>
                  <h4 className="text-sm font-bold text-slate-100">{masjid.name}</h4>
                </div>
                <p className="text-xs text-slate-400 flex items-center gap-1">
                  <MapPin size={12} className="text-slate-500" />
                  {masjid.address}
                </p>
              </div>

              <div className="flex items-center gap-3 self-end sm:self-auto">
                <div className="text-[11px] text-slate-400 flex items-center gap-3">
                  <span className="flex items-center gap-1" title="Walking time">
                    <Footprints size={13} className="text-emerald-400" /> {masjid.walkingMinutes} min
                  </span>
                  <span className="flex items-center gap-1" title="Driving time">
                    <Car size={13} className="text-amber-400" /> {masjid.drivingMinutes} min
                  </span>
                </div>

                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(masjid.name + ' ' + masjid.address)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 transition shadow-md shadow-amber-600/20"
                >
                  <ExternalLink size={13} />
                  <span>Directions</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
