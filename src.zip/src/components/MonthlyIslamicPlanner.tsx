import React, { useState, useEffect, useMemo } from 'react';
import { 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  Sparkles, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Circle, 
  Moon, 
  Star, 
  Clock, 
  Tag, 
  Bell, 
  Filter, 
  X,
  BookOpen,
  Heart
} from 'lucide-react';
import { triggerHaptic } from '../lib/haptics';
import { getHijriDate, HIJRI_MONTHS } from './LunarCalendar';

export interface SpiritualReminder {
  id: string;
  dateKey: string; // YYYY-MM-DD
  title: string;
  category: 'fasting' | 'quran' | 'dhikr' | 'charity' | 'general';
  completed: boolean;
  createdAt: number;
}

const CATEGORY_CONFIG: Record<string, { label: string; color: string; badgeClass: string }> = {
  fasting: { label: 'Fasting (صيام)', color: '#f59e0b', badgeClass: 'bg-amber-500/15 text-amber-300 border-amber-500/30' },
  quran: { label: 'Quran (قرآن)', color: '#10b981', badgeClass: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' },
  dhikr: { label: 'Dua & Dhikr (ذكر)', color: '#6366f1', badgeClass: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30' },
  charity: { label: 'Charity (صدقة)', color: '#ec4899', badgeClass: 'bg-pink-500/15 text-pink-300 border-pink-500/30' },
  general: { label: 'General (عام)', color: '#38bdf8', badgeClass: 'bg-sky-500/15 text-sky-300 border-sky-500/30' }
};

const PRESET_REMINDERS = [
  { title: 'Fast Ayyam al-Beed (White Day)', category: 'fasting' as const },
  { title: 'Monday Sunnah Fast', category: 'fasting' as const },
  { title: 'Thursday Sunnah Fast', category: 'fasting' as const },
  { title: 'Recite Surah Al-Kahf (Jumu\'ah)', category: 'quran' as const },
  { title: 'Extra Night Tahajjud & Istighfar', category: 'dhikr' as const },
  { title: 'Give Friday Sadaqah', category: 'charity' as const }
];

const STORAGE_KEY = 'noor_spiritual_reminders';

export default function MonthlyIslamicPlanner() {
  const today = useMemo(() => new Date(), []);
  
  // Navigation month/year state
  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const [currentMonth, setCurrentMonth] = useState(today.getMonth()); // 0-indexed

  // Regional moon sighting offset (-2 to +2 days)
  const [offsetDays] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('hijri_date_offset') || '0', 10);
    } catch {
      return 0;
    }
  });

  // Selected date key for details drawer (defaults to today)
  const [selectedDateKey, setSelectedDateKey] = useState<string>(() => {
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, '0');
    const d = String(today.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  });

  // Filter option: 'all' | 'special' | 'reminders'
  const [filterMode, setFilterMode] = useState<'all' | 'special' | 'reminders'>('all');

  // Reminders state
  const [reminders, setReminders] = useState<SpiritualReminder[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    // Initial sample seed reminders
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, '0');
    const d = String(today.getDate()).padStart(2, '0');
    return [
      {
        id: 'seed-rem-1',
        dateKey: `${y}-${m}-${d}`,
        title: 'Recite morning & evening Adhkar with reflection',
        category: 'dhikr',
        completed: false,
        createdAt: Date.now() - 3600000
      }
    ];
  });

  // Form input for new reminder
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<SpiritualReminder['category']>('fasting');

  // Save reminders to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(reminders));
    } catch (e) {
      console.warn(e);
    }
  }, [reminders]);

  // Navigate to previous month
  const handlePrevMonth = () => {
    triggerHaptic(10);
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(prev => prev - 1);
    } else {
      setCurrentMonth(prev => prev - 1);
    }
  };

  // Navigate to next month
  const handleNextMonth = () => {
    triggerHaptic(10);
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(prev => prev + 1);
    } else {
      setCurrentMonth(prev => prev + 1);
    }
  };

  // Return to today
  const handleJumpToToday = () => {
    triggerHaptic(15);
    setCurrentYear(today.getFullYear());
    setCurrentMonth(today.getMonth());
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, '0');
    const d = String(today.getDate()).padStart(2, '0');
    setSelectedDateKey(`${y}-${m}-${d}`);
  };

  // Build the days of the current month
  const monthDays = useMemo(() => {
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const firstDayWeekday = new Date(currentYear, currentMonth, 1).getDay(); // 0 = Sun, 1 = Mon ...

    const list = [];

    // Prepend empty padding for calendar grid alignment
    for (let i = 0; i < firstDayWeekday; i++) {
      list.push(null);
    }

    for (let d = 1; d <= daysInMonth; d++) {
      const dateObj = new Date(currentYear, currentMonth, d);
      const dateKey = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const hijri = getHijriDate(dateObj, offsetDays);

      const isAyyamAlBeed = hijri.day >= 13 && hijri.day <= 15;
      const isFriday = dateObj.getDay() === 5;
      const isMondayOrThursday = dateObj.getDay() === 1 || dateObj.getDay() === 4;

      // Special Islamic Milestones
      let specialEvent: string | null = null;
      if (hijri.month === 9 && hijri.day === 1) specialEvent = '1st of Ramadan';
      else if (hijri.month === 9 && hijri.day >= 21) specialEvent = 'Laylat al-Qadr Nights';
      else if (hijri.month === 10 && hijri.day === 1) specialEvent = 'Eid al-Fitr';
      else if (hijri.month === 12 && hijri.day >= 1 && hijri.day <= 10) {
        if (hijri.day === 9) specialEvent = 'Day of Arafah';
        else if (hijri.day === 10) specialEvent = 'Eid al-Adha';
        else specialEvent = `10 Blessed Days of Dhu al-Hijjah (Day ${hijri.day})`;
      } else if (hijri.month === 1 && hijri.day === 1) specialEvent = 'Islamic New Year (1448 AH)';
      else if (hijri.month === 1 && hijri.day === 10) specialEvent = 'Day of Ashura';
      else if (hijri.month === 7 && hijri.day === 27) specialEvent = 'Al-Isra\' wal-Mi\'raj';
      else if (hijri.month === 8 && hijri.day === 15) specialEvent = 'Nisf Sha\'ban';

      list.push({
        dayNumber: d,
        dateObj,
        dateKey,
        hijri,
        isAyyamAlBeed,
        isFriday,
        isMondayOrThursday,
        specialEvent,
        isToday: dateObj.toDateString() === today.toDateString()
      });
    }

    return list;
  }, [currentYear, currentMonth, offsetDays, today]);

  // Selected date info
  const selectedDayInfo = useMemo(() => {
    if (!selectedDateKey) return null;
    const [y, m, d] = selectedDateKey.split('-').map(Number);
    const dateObj = new Date(y, m - 1, d);
    const hijri = getHijriDate(dateObj, offsetDays);
    const isAyyamAlBeed = hijri.day >= 13 && hijri.day <= 15;
    const isFriday = dateObj.getDay() === 5;
    const isMondayOrThursday = dateObj.getDay() === 1 || dateObj.getDay() === 4;

    let specialEvent: string | null = null;
    if (hijri.month === 9 && hijri.day === 1) specialEvent = '1st of Ramadan';
    else if (hijri.month === 9 && hijri.day >= 21) specialEvent = 'Laylat al-Qadr Nights';
    else if (hijri.month === 10 && hijri.day === 1) specialEvent = 'Eid al-Fitr';
    else if (hijri.month === 12 && hijri.day === 9) specialEvent = 'Day of Arafah';
    else if (hijri.month === 12 && hijri.day === 10) specialEvent = 'Eid al-Adha';
    else if (hijri.month === 1 && hijri.day === 10) specialEvent = 'Day of Ashura';

    return {
      dateObj,
      dateKey: selectedDateKey,
      hijri,
      isAyyamAlBeed,
      isFriday,
      isMondayOrThursday,
      specialEvent,
      formattedGregorian: dateObj.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      })
    };
  }, [selectedDateKey, offsetDays]);

  // Reminders for selected day
  const selectedDayReminders = useMemo(() => {
    return reminders.filter(r => r.dateKey === selectedDateKey);
  }, [reminders, selectedDateKey]);

  // Add new reminder
  const handleAddReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    triggerHaptic(20);
    const newRem: SpiritualReminder = {
      id: `rem_${Date.now()}`,
      dateKey: selectedDateKey,
      title: newTitle.trim(),
      category: newCategory,
      completed: false,
      createdAt: Date.now()
    };

    setReminders(prev => [newRem, ...prev]);
    setNewTitle('');
  };

  // Add preset reminder
  const handleAddPreset = (preset: typeof PRESET_REMINDERS[0]) => {
    triggerHaptic(15);
    const newRem: SpiritualReminder = {
      id: `rem_${Date.now()}`,
      dateKey: selectedDateKey,
      title: preset.title,
      category: preset.category,
      completed: false,
      createdAt: Date.now()
    };
    setReminders(prev => [newRem, ...prev]);
  };

  // Toggle reminder completion
  const handleToggleReminder = (id: string) => {
    triggerHaptic(15);
    setReminders(prev => prev.map(r => r.id === id ? { ...r, completed: !r.completed } : r));
  };

  // Delete reminder
  const handleDeleteReminder = (id: string) => {
    triggerHaptic(15);
    setReminders(prev => prev.filter(r => r.id !== id));
  };

  // Month title & Hijri month span
  const monthTitle = useMemo(() => {
    const d = new Date(currentYear, currentMonth, 15);
    const gregMonthStr = d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    const midHijri = getHijriDate(d, offsetDays);
    return {
      gregorian: gregMonthStr,
      hijri: `${midHijri.monthName} ${midHijri.year} AH`,
      hijriArabic: midHijri.monthArabic
    };
  }, [currentYear, currentMonth, offsetDays]);

  // Upcoming Ayyam al-Beed summary for the active month
  const ayyamAlBeedDates = useMemo(() => {
    return monthDays.filter(day => day && day.isAyyamAlBeed);
  }, [monthDays]);

  return (
    <section 
      aria-label="Monthly Islamic Planner"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-700/50 md:col-span-2 space-y-6"
    >
      {/* Decorative ambient flares */}
      <div 
        aria-hidden="true" 
        className="absolute -top-20 -right-20 w-56 h-56 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" 
      />
      <div 
        aria-hidden="true" 
        className="absolute -bottom-20 -left-20 w-56 h-56 rounded-full bg-indigo-500/5 blur-3xl pointer-events-none" 
      />

      {/* Header bar: Title, Month Controls, Jump to Today */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <span className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <CalendarIcon size={20} />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-100 tracking-tight">
                Monthly Islamic Planner
              </h3>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Spiritual Schedule
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Dual Hijri-Gregorian calendar with Ayyam al-Beed, Sunnah fasts, and personal spiritual reminders
            </p>
          </div>
        </div>

        {/* Month Navigation Controls */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={handleJumpToToday}
            className="text-xs px-2.5 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-amber-400 border border-slate-700 font-mono transition-colors"
          >
            Today
          </button>

          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl p-0.5">
            <button
              type="button"
              onClick={handlePrevMonth}
              className="p-1.5 text-slate-400 hover:text-amber-400 rounded-lg hover:bg-slate-900 transition-colors"
              title="Previous month"
            >
              <ChevronLeft size={16} />
            </button>
            <span className="text-xs font-mono font-bold text-slate-200 px-2 min-w-[130px] text-center">
              {monthTitle.gregorian}
            </span>
            <button
              type="button"
              onClick={handleNextMonth}
              className="p-1.5 text-slate-400 hover:text-amber-400 rounded-lg hover:bg-slate-900 transition-colors"
              title="Next month"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Hijri Month Subheader & Ayyam al-Beed Notice */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 bg-slate-950/70 border border-amber-900/30 rounded-xl text-xs shadow-inner">
        <div className="flex items-center gap-2">
          <Moon size={16} className="text-amber-400 flex-shrink-0" />
          <div>
            <span className="font-bold text-slate-100 mr-2">{monthTitle.hijri}</span>
            <span className="font-arabic text-amber-300" dir="rtl">{monthTitle.hijriArabic}</span>
          </div>
        </div>

        {/* Quick legend for Islamic events */}
        <div className="flex items-center gap-3 text-[11px] text-slate-400 overflow-x-auto pb-1 sm:pb-0">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80 border border-amber-400" />
            <span>Ayyam al-Beed (13-15)</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
            <span>Jumu'ah</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-indigo-400" />
            <span>Has Reminder</span>
          </span>
        </div>
      </div>

      {/* Main Grid & Reminder Inspector Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Calendar Grid (7 cols on lg) */}
        <div className="lg:col-span-7 space-y-2">
          {/* Weekday Labels (Sun to Sat) */}
          <div className="grid grid-cols-7 gap-1 text-center font-mono text-[11px] text-slate-400 font-semibold pb-1">
            <span>Sun</span>
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span className="text-emerald-400">Fri</span>
            <span>Sat</span>
          </div>

          {/* 7-column Calendar Days Grid */}
          <div className="grid grid-cols-7 gap-1.5">
            {monthDays.map((cell, index) => {
              if (!cell) {
                return (
                  <div 
                    key={`empty-${index}`} 
                    className="h-16 sm:h-20 bg-slate-950/20 border border-transparent rounded-xl" 
                  />
                );
              }

              const isSelected = selectedDateKey === cell.dateKey;
              const hasReminders = reminders.some(r => r.dateKey === cell.dateKey);

              return (
                <button
                  key={cell.dateKey}
                  type="button"
                  onClick={() => {
                    triggerHaptic(10);
                    setSelectedDateKey(cell.dateKey);
                  }}
                  className={`h-16 sm:h-20 p-1.5 rounded-xl border text-left flex flex-col justify-between transition-all relative overflow-hidden group select-none ${
                    isSelected
                      ? 'border-amber-500 ring-2 ring-amber-500/30 bg-slate-900 shadow-md'
                      : cell.isToday
                      ? 'border-amber-600/60 bg-amber-950/15'
                      : cell.isAyyamAlBeed
                      ? 'bg-amber-950/20 border-amber-500/40 hover:border-amber-400'
                      : cell.isFriday
                      ? 'bg-emerald-950/15 border-emerald-900/40 hover:border-emerald-600'
                      : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  {/* Top Bar: Gregorian Day + Reminder Indicator */}
                  <div className="flex items-center justify-between w-full">
                    <span className={`text-xs font-mono font-bold leading-none ${
                      cell.isToday
                        ? 'w-5 h-5 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center font-bold'
                        : isSelected
                        ? 'text-amber-400'
                        : 'text-slate-200'
                    }`}>
                      {cell.dayNumber}
                    </span>

                    {/* Indicator dots: Reminder, Special Event */}
                    <div className="flex items-center gap-1">
                      {hasReminders && (
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 shadow-sm" title="Has spiritual reminders" />
                      )}
                      {cell.isAyyamAlBeed && (
                        <span className="text-[10px]" title="Ayyam al-Beed">🌕</span>
                      )}
                    </div>
                  </div>

                  {/* Middle / Bottom: Hijri Day Number & Label */}
                  <div className="w-full">
                    <div className="flex items-center justify-between text-[10px] font-mono leading-none">
                      <span className={`font-semibold ${
                        cell.isAyyamAlBeed ? 'text-amber-300 font-bold' : 'text-slate-400'
                      }`}>
                        {cell.hijri.day} {cell.hijri.monthName.slice(0, 3)}
                      </span>
                    </div>

                    {/* Badge if Ayyam al-Beed or Special Event */}
                    {cell.isAyyamAlBeed ? (
                      <span className="text-[9px] font-mono text-amber-400/90 truncate block mt-0.5 font-bold">
                        Ayyam al-Beed
                      </span>
                    ) : cell.specialEvent ? (
                      <span className="text-[9px] font-mono text-emerald-400 truncate block mt-0.5">
                        {cell.specialEvent.slice(0, 12)}
                      </span>
                    ) : cell.isFriday ? (
                      <span className="text-[9px] font-mono text-emerald-400/80 truncate block mt-0.5">
                        Jumu'ah
                      </span>
                    ) : null}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Date Inspector & Reminders Manager (5 cols on lg) */}
        <div className="lg:col-span-5 bg-slate-950/70 border border-amber-900/30 rounded-2xl p-4 sm:p-5 space-y-4 shadow-inner">
          {selectedDayInfo && (
            <>
              {/* Date Details Header */}
              <div className="pb-3 border-b border-slate-800 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold">
                    Date Details & Intentions
                  </span>
                  {selectedDayInfo.isAyyamAlBeed && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold flex items-center gap-1">
                      🌕 Ayyam al-Beed
                    </span>
                  )}
                </div>

                <h4 className="text-base font-bold text-slate-100">
                  {selectedDayInfo.formattedGregorian}
                </h4>

                <div className="flex items-center justify-between pt-0.5">
                  <p className="text-xs text-amber-400 font-mono">
                    {selectedDayInfo.hijri.formattedEn}
                  </p>
                  <p className="text-xs font-arabic text-amber-300" dir="rtl">
                    {selectedDayInfo.hijri.arabicFull}
                  </p>
                </div>

                {/* Sunnah advice badge */}
                {selectedDayInfo.isAyyamAlBeed && (
                  <div className="p-2.5 bg-amber-950/30 border border-amber-500/30 rounded-xl text-[11px] text-amber-200 mt-2 space-y-0.5">
                    <strong className="block font-semibold">🌕 Recommended Sunnah Fasting</strong>
                    <p className="text-slate-300">
                      The Prophet (ﷺ) encouraged fasting the 13th, 14th, and 15th of every lunar month when the moon is full.
                    </p>
                  </div>
                )}

                {selectedDayInfo.isFriday && (
                  <div className="p-2.5 bg-emerald-950/30 border border-emerald-500/30 rounded-xl text-[11px] text-emerald-200 mt-2 space-y-0.5">
                    <strong className="block font-semibold">🕌 Blessed Friday (Jumu'ah)</strong>
                    <p className="text-slate-300">
                      Send abundant blessings upon the Prophet (ﷺ), recite Surah Al-Kahf, and seek the hour of answered prayer (Sa'at al-Ijabah).
                    </p>
                  </div>
                )}

                {selectedDayInfo.specialEvent && (
                  <div className="p-2.5 bg-indigo-950/30 border border-indigo-500/30 rounded-xl text-[11px] text-indigo-200 mt-2">
                    <strong className="block font-semibold">✦ {selectedDayInfo.specialEvent}</strong>
                  </div>
                )}
              </div>

              {/* Quick Presets Buttons */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-semibold text-slate-400 block">
                  Quick Spiritual Presets:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {PRESET_REMINDERS.map(preset => (
                    <button
                      key={preset.title}
                      type="button"
                      onClick={() => handleAddPreset(preset)}
                      className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-amber-400 hover:border-amber-500/40 transition-colors flex items-center gap-1 active:scale-95"
                    >
                      <Plus size={11} className="text-amber-500" />
                      <span>{preset.title}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Add Custom Reminder Form */}
              <form onSubmit={handleAddReminder} className="space-y-2 pt-2 border-t border-slate-800">
                <span className="text-[11px] font-semibold text-slate-400 block">
                  Add Custom Reminder / Intention:
                </span>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newTitle}
                    onChange={e => setNewTitle(e.target.value)}
                    placeholder="e.g. Recite Juz 15, Give charity..."
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none focus:border-amber-500 shadow-inner"
                  />
                  <select
                    value={newCategory}
                    onChange={e => setNewCategory(e.target.value as any)}
                    className="bg-slate-900 border border-slate-700 text-slate-300 text-xs px-2.5 py-2 rounded-xl outline-none focus:border-amber-500"
                  >
                    <option value="fasting">Fasting</option>
                    <option value="quran">Quran</option>
                    <option value="dhikr">Dhikr</option>
                    <option value="charity">Charity</option>
                    <option value="general">General</option>
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={!newTitle.trim()}
                  className="w-full bg-amber-600 hover:bg-amber-500 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-bold text-xs py-2 rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5 active:scale-95"
                >
                  <Plus size={14} />
                  <span>Save Spiritual Reminder</span>
                </button>
              </form>

              {/* List of Reminders for Selected Date */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200">
                    Reminders for this Day ({selectedDayReminders.length})
                  </span>
                </div>

                {selectedDayReminders.length > 0 ? (
                  <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                    {selectedDayReminders.map(rem => {
                      const catConf = CATEGORY_CONFIG[rem.category] || CATEGORY_CONFIG.general;

                      return (
                        <div
                          key={rem.id}
                          className={`p-2.5 rounded-xl border text-xs flex items-center justify-between gap-2 transition-all ${
                            rem.completed
                              ? 'bg-emerald-950/20 border-emerald-500/30 text-slate-400'
                              : 'bg-slate-900 border-slate-800 text-slate-200'
                          }`}
                        >
                          <div className="flex items-center gap-2 flex-1 min-w-0">
                            <button
                              type="button"
                              onClick={() => handleToggleReminder(rem.id)}
                              className="text-slate-400 hover:text-emerald-400 transition-colors flex-shrink-0"
                            >
                              {rem.completed ? (
                                <CheckCircle2 size={16} className="text-emerald-400" />
                              ) : (
                                <Circle size={16} className="text-slate-600" />
                              )}
                            </button>
                            <div className="min-w-0">
                              <span className={`block truncate ${rem.completed ? 'line-through text-slate-500' : 'font-medium'}`}>
                                {rem.title}
                              </span>
                              <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded border inline-block mt-0.5 ${catConf.badgeClass}`}>
                                {catConf.label}
                              </span>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleDeleteReminder(rem.id)}
                            className="p-1 text-slate-500 hover:text-red-400 rounded-lg transition-colors flex-shrink-0"
                            title="Delete reminder"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-500 text-center py-4 bg-slate-900/40 rounded-xl border border-dashed border-slate-800">
                    No reminders yet for this day. Click a preset above or type your own intention!
                  </p>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
}
