import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { 
  BookOpen, 
  Calendar, 
  Plus, 
  Trash2, 
  Sparkles, 
  CheckCircle2, 
  Search, 
  Heart, 
  Flame, 
  Smile, 
  Feather, 
  BookMarked, 
  ArrowRight 
} from 'lucide-react';
import { surahs } from '../data/surahs';
import { 
  DailyQuranJournalRecord, 
  saveDailyQuranJournalEntry, 
  getAllDailyQuranJournalEntries, 
  deleteDailyQuranJournalEntry 
} from '../lib/db';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

const SURAH_AYAH_COUNTS: Record<number, number> = {
  1: 7, 2: 286, 3: 200, 4: 176, 5: 120, 6: 165, 7: 206, 8: 75, 9: 129, 10: 109,
  11: 123, 12: 111, 13: 43, 14: 52, 15: 99, 16: 128, 17: 111, 18: 110, 19: 98, 20: 135,
  21: 112, 22: 78, 23: 118, 24: 64, 25: 77, 26: 227, 27: 93, 28: 88, 29: 69, 30: 60,
  31: 34, 32: 30, 33: 73, 34: 54, 35: 45, 36: 83, 37: 182, 38: 88, 39: 75, 40: 85,
  41: 54, 42: 53, 43: 89, 44: 59, 45: 37, 46: 35, 47: 38, 48: 29, 49: 18, 50: 45,
  51: 60, 52: 49, 53: 62, 54: 55, 55: 78, 56: 96, 57: 29, 58: 22, 59: 24, 60: 13,
  61: 14, 62: 11, 63: 11, 64: 18, 65: 12, 66: 12, 67: 30, 68: 52, 69: 52, 70: 44,
  71: 28, 72: 28, 73: 20, 74: 56, 75: 40, 76: 31, 77: 50, 78: 40, 79: 46, 80: 42,
  81: 29, 82: 19, 83: 36, 84: 25, 85: 22, 86: 17, 87: 19, 88: 26, 89: 30, 90: 20,
  91: 15, 92: 21, 93: 11, 94: 8, 95: 8, 96: 19, 97: 5, 98: 8, 99: 8, 100: 11,
  101: 11, 102: 8, 103: 3, 104: 9, 105: 5, 106: 4, 107: 7, 108: 3, 109: 6, 110: 3,
  111: 5, 112: 4, 113: 5, 114: 6
};

const surahsWithAyahs = surahs.map(s => ({
  ...s,
  totalAyahs: SURAH_AYAH_COUNTS[s.id] || 7
}));

const MOOD_OPTIONS: Array<{ key: DailyQuranJournalRecord['moodTag']; label: string; icon: string }> = [
  { key: 'inspired', label: 'Inspired', icon: '✨' },
  { key: 'peaceful', label: 'Peaceful', icon: '🕊️' },
  { key: 'seeking_guidance', label: 'Seeking Guidance', icon: '🤲' },
  { key: 'grateful', label: 'Grateful', icon: '🤍' },
  { key: 'humbled', label: 'Humbled', icon: '🌱' }
];

export default function DailyQuranJournal() {
  const [entries, setEntries] = useState<DailyQuranJournalRecord[]>([]);
  const [loading, setLoading] = useState(true);

  // Form State
  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [selectedSurahId, setSelectedSurahId] = useState<number>(18); // Default Al-Kahf
  const [startAyah, setStartAyah] = useState<number>(1);
  const [endAyah, setEndAyah] = useState<number>(10);
  const [reflectionNote, setReflectionNote] = useState('');
  const [selectedMood, setSelectedMood] = useState<DailyQuranJournalRecord['moodTag']>('peaceful');
  const [searchQuery, setSearchQuery] = useState('');

  // Selected Surah Info
  const selectedSurah = useMemo(() => {
    return surahsWithAyahs.find(s => s.id === Number(selectedSurahId)) || surahsWithAyahs[0];
  }, [selectedSurahId]);

  // Load entries from IndexedDB on mount
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      const loaded = await getAllDailyQuranJournalEntries();
      setEntries(loaded);
      setLoading(false);
    };
    loadData();
  }, []);

  const handleSaveEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reflectionNote.trim()) return;

    triggerButtonClickHaptic();

    const record: DailyQuranJournalRecord = {
      id: selectedDate, // Store per date key
      date: selectedDate,
      surahId: selectedSurah.id,
      surahName: selectedSurah.name,
      surahArabic: selectedSurah.arabic,
      startAyah: Number(startAyah) || 1,
      endAyah: Number(endAyah) || 1,
      totalAyahsInSurah: selectedSurah.totalAyahs,
      reflectionNote: reflectionNote.trim(),
      moodTag: selectedMood,
      timestamp: Date.now()
    };

    await saveDailyQuranJournalEntry(record);
    triggerSuccessHaptic();

    // Reload list
    const updated = await getAllDailyQuranJournalEntries();
    setEntries(updated);

    // Reset reflection note
    setReflectionNote('');
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic(20);
    await deleteDailyQuranJournalEntry(id);
    setEntries(prev => prev.filter(item => item.id !== id && item.date !== id));
  };

  const filteredEntries = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return entries;
    return entries.filter(item => 
      item.surahName.toLowerCase().includes(q) ||
      (item.surahArabic && item.surahArabic.includes(q)) ||
      item.reflectionNote.toLowerCase().includes(q) ||
      item.date.includes(q)
    );
  }, [entries, searchQuery]);

  return (
    <div className="space-y-6 pb-20">
      {/* Header */}
      <header className="border-b border-amber-900/30 pb-4">
        <div className="flex items-center gap-2">
          <BookMarked size={24} className="text-amber-500" />
          <h2 className="text-2xl text-amber-500 font-serif font-bold">Daily Quran Journal</h2>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          Track daily Surah progress, note ending Ayat, and record personal reflections saved directly to local IndexedDB
        </p>
      </header>

      {/* Main Grid Layout: Form on Left/Top, History on Right/Bottom */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Entry Logging Card */}
        <div className="lg:col-span-5 bg-slate-900 border border-amber-900/30 rounded-2xl p-5 space-y-4 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Feather size={16} className="text-amber-500" />
              <span>Log Today's Recitation</span>
            </h3>
            <span className="text-[10px] font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
              IndexedDB Persistent
            </span>
          </div>

          <form onSubmit={handleSaveEntry} className="space-y-3 text-xs">
            {/* Date Picker */}
            <div>
              <label className="text-slate-300 font-medium block mb-1">Recitation Date:</label>
              <input
                type="date"
                value={selectedDate}
                onChange={e => setSelectedDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 p-2 text-slate-100 rounded-xl outline-none font-mono"
                required
              />
            </div>

            {/* Surah Dropdown */}
            <div>
              <label className="text-slate-300 font-medium block mb-1">Select Surah:</label>
              <select
                value={selectedSurahId}
                onChange={e => {
                  const sId = Number(e.target.value);
                  setSelectedSurahId(sId);
                  const surahObj = surahsWithAyahs.find(s => s.id === sId);
                  if (surahObj) {
                    setEndAyah(Math.min(10, surahObj.totalAyahs));
                  }
                }}
                className="w-full bg-slate-950 text-amber-300 border border-slate-800 focus:border-amber-500 p-2.5 rounded-xl outline-none font-serif text-sm"
              >
                {surahsWithAyahs.map(s => (
                  <option key={s.id} value={s.id}>
                    {s.id}. {s.name} ({s.arabic}) — {s.totalAyahs} Verses
                  </option>
                ))}
              </select>
            </div>

            {/* Start & End Ayah Range */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-300 font-medium block mb-1">Start Ayah:</label>
                <input
                  type="number"
                  min="1"
                  max={selectedSurah?.totalAyahs || 286}
                  value={startAyah}
                  onChange={e => setStartAyah(Math.max(1, Number(e.target.value)))}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 p-2 text-slate-100 rounded-xl outline-none font-mono"
                />
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">Ayah Ended On:</label>
                <input
                  type="number"
                  min="1"
                  max={selectedSurah?.totalAyahs || 286}
                  value={endAyah}
                  onChange={e => setEndAyah(Math.max(1, Number(e.target.value)))}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 p-2 text-slate-100 rounded-xl outline-none font-mono"
                />
              </div>
            </div>

            {/* Spiritual State / Mood Tag */}
            <div>
              <label className="text-slate-300 font-medium block mb-1">Spiritual State / Mood:</label>
              <div className="flex flex-wrap gap-1.5">
                {MOOD_OPTIONS.map(m => (
                  <button
                    key={m.key}
                    type="button"
                    onClick={() => {
                      triggerHaptic(10);
                      setSelectedMood(m.key);
                    }}
                    className={`px-2.5 py-1 rounded-xl text-[11px] font-medium border transition ${
                      selectedMood === m.key
                        ? 'bg-amber-600 text-slate-950 border-amber-400 font-bold'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                    }`}
                  >
                    <span>{m.icon} {m.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Reflection Textarea */}
            <div>
              <label className="text-slate-300 font-medium block mb-1">Reflection & Personal Notes:</label>
              <textarea
                rows={4}
                value={reflectionNote}
                onChange={e => setReflectionNote(e.target.value)}
                placeholder="Write your thoughts, key lessons learned, or du'a inspired by today's recitation..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 p-3 text-slate-100 rounded-xl outline-none leading-relaxed text-xs"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-600/20 transition active:scale-95 flex items-center justify-center gap-1.5"
            >
              <Plus size={15} />
              <span>Save Journal Entry to IndexedDB</span>
            </button>
          </form>
        </div>

        {/* Journal History & Timeline Column */}
        <div className="lg:col-span-7 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search past reflections, Surahs, or dates..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-amber-900/30 text-slate-100 pl-9 pr-4 py-2.5 rounded-xl text-xs outline-none focus:border-amber-500"
            />
          </div>

          {/* History List */}
          {loading ? (
            <div className="p-8 text-center text-xs text-amber-500">Loading journal records from IndexedDB...</div>
          ) : filteredEntries.length === 0 ? (
            <div className="p-8 bg-slate-900/50 border border-slate-800 rounded-2xl text-center space-y-2">
              <BookOpen size={28} className="mx-auto text-amber-500/50" />
              <p className="text-sm font-semibold text-slate-200">No Journal Entries Yet</p>
              <p className="text-xs text-slate-500">Log your daily Quran recitation and personal reflections above.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredEntries.map(entry => {
                const moodObj = MOOD_OPTIONS.find(m => m.key === entry.moodTag) || MOOD_OPTIONS[0];

                return (
                  <div
                    key={entry.id}
                    className="p-4 bg-slate-900/90 border border-amber-900/30 rounded-2xl space-y-3 shadow-md hover:border-amber-700/50 transition-all"
                  >
                    <div className="flex items-start justify-between gap-2 border-b border-slate-800 pb-2">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-serif font-bold text-amber-400 text-sm">{entry.surahName}</span>
                          {entry.surahArabic && (
                            <span className="font-arabic text-amber-200 text-sm" dir="rtl">{entry.surahArabic}</span>
                          )}
                          <span className="text-[10px] font-mono bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded border border-amber-500/20">
                            Ayah {entry.startAyah} – {entry.endAyah}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1.5">
                          <Calendar size={12} className="text-slate-500" />
                          <span>{entry.date}</span>
                          <span>•</span>
                          <span>{moodObj.icon} {moodObj.label}</span>
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Link
                          to={`/quran/${entry.surahId}`}
                          className="px-2.5 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-lg text-xs font-semibold transition flex items-center gap-1"
                          title="Open Surah in Quran Reader"
                        >
                          <span>Read</span>
                          <ArrowRight size={12} />
                        </Link>

                        <button
                          type="button"
                          onClick={e => handleDelete(entry.id, e)}
                          className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition"
                          title="Delete entry"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>

                    <p className="text-slate-200 text-xs leading-relaxed italic bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                      "{entry.reflectionNote}"
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
