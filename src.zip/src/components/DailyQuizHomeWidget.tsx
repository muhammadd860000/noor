import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Flame, Trophy, Award, ArrowRight, Sparkles, HelpCircle, CheckCircle2 } from 'lucide-react';
import { getQuizLeaderboardStats, QuizLeaderboardStats } from '../lib/quizLeaderboard';
import { triggerButtonClickHaptic } from '../lib/haptics';

export default function DailyQuizHomeWidget() {
  const [stats, setStats] = useState<QuizLeaderboardStats>(getQuizLeaderboardStats);

  useEffect(() => {
    // Refresh stats when component mounts or focus changes
    setStats(getQuizLeaderboardStats());

    const handleStorageChange = () => setStats(getQuizLeaderboardStats());
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-5 shadow-xl space-y-4 relative overflow-hidden">
      {/* Background Subtle Accent */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
            <HelpCircle size={20} />
          </div>
          <div>
            <h3 className="text-base font-serif font-bold text-slate-100 flex items-center gap-2">
              <span>Daily Knowledge Quiz</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold">
                Today's Challenge
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Test your understanding of Quran, Hadith, Seerah & Islamic history</p>
          </div>
        </div>

        {/* Streak Counter Badge */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold shrink-0">
          <Flame size={16} className="text-amber-400 fill-amber-400/30 animate-pulse" />
          <span>{stats.currentStreak} Day Streak</span>
        </div>
      </div>

      {/* Stats Summary Row */}
      <div className="grid grid-cols-3 gap-2 text-center pt-1">
        <div className="p-2.5 bg-slate-950/80 border border-slate-800 rounded-xl">
          <span className="text-[10px] text-slate-400 block font-medium">Rank</span>
          <span className="text-xs font-bold text-amber-300 truncate block mt-0.5" title={stats.currentRank.title}>
            {stats.currentRank.title}
          </span>
        </div>

        <div className="p-2.5 bg-slate-950/80 border border-slate-800 rounded-xl">
          <span className="text-[10px] text-slate-400 block font-medium">Accuracy</span>
          <span className="text-xs font-mono font-bold text-amber-400 block mt-0.5">
            {stats.overallAccuracyPct}%
          </span>
        </div>

        <div className="p-2.5 bg-slate-950/80 border border-slate-800 rounded-xl">
          <span className="text-[10px] text-slate-400 block font-medium">Total Points</span>
          <span className="text-xs font-mono font-bold text-amber-400 block mt-0.5">
            {stats.cumulativeScore} pts
          </span>
        </div>
      </div>

      {/* Button to Jump Straight to Today's Challenge */}
      <Link
        to="/quiz"
        onClick={() => triggerButtonClickHaptic()}
        className="w-full py-3 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/15 transition flex items-center justify-center gap-2 group active:scale-[0.99]"
      >
        <Sparkles size={16} className="text-slate-950" />
        <span>Jump Straight into Today's Challenge</span>
        <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
      </Link>
    </div>
  );
}
