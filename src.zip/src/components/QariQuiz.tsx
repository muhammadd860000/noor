import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  CheckCircle2, 
  XCircle, 
  Sparkles, 
  Trophy, 
  Flame, 
  Music, 
  Award, 
  HelpCircle, 
  ArrowRight,
  Radio
} from 'lucide-react';
import { 
  QARI_QUESTIONS_POOL, 
  QariQuestion, 
  getQariQuizStats, 
  recordQariAnswer, 
  QariQuizStats 
} from '../lib/qariQuiz';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export default function QariQuiz() {
  const [questionIndex, setQuestionIndex] = useState<number>(0);
  const [stats, setStats] = useState<QariQuizStats>(getQariQuizStats);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [isCorrect, setIsCorrect] = useState<boolean>(false);
  const [muted, setMuted] = useState<boolean>(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  const currentQuestion: QariQuestion = QARI_QUESTIONS_POOL[questionIndex % QARI_QUESTIONS_POOL.length];

  useEffect(() => {
    // Reset audio state when question changes
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setIsPlaying(false);
    setSelectedOption(null);
    setIsAnswered(false);
  }, [questionIndex]);

  const togglePlayAudio = () => {
    triggerButtonClickHaptic();
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().catch(err => {
        console.warn('[QariQuiz] Audio playback error:', err);
      });
      setIsPlaying(true);
    }
  };

  const handleReplay = () => {
    triggerButtonClickHaptic();
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  const handleOptionSelect = (option: string) => {
    if (isAnswered) return;

    setSelectedOption(option);
    setIsAnswered(true);

    const correct = option === currentQuestion.correctAnswer;
    setIsCorrect(correct);

    if (correct) {
      triggerSuccessHaptic();
    } else {
      triggerHaptic(30);
    }

    const updatedStats = recordQariAnswer(correct, 15);
    setStats(updatedStats);
  };

  const handleNextQuestion = () => {
    triggerButtonClickHaptic();
    setQuestionIndex(prev => prev + 1);
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-5 shadow-xl space-y-5 max-w-2xl mx-auto">
      {/* Hidden HTML Audio Element */}
      <audio
        ref={audioRef}
        src={currentQuestion.audioUrl}
        muted={muted}
        onEnded={() => setIsPlaying(false)}
      />

      {/* Header & Stats Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-900/30">
        <div className="flex items-center gap-2.5">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30">
            <Radio size={22} className="animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-serif font-bold text-slate-100 flex items-center gap-2">
              <span>Qari & Recitation Quiz</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold">
                Audio Identification
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Listen to famous reciters & identify the Qari, Surah, or Tajweed style</p>
          </div>
        </div>

        {/* Learning Score & Streak Badges */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <div className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold font-mono">
            <Trophy size={14} className="text-amber-400" />
            <span>{stats.learningScorePoints} pts</span>
          </div>

          <div className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold font-mono">
            <Flame size={14} className="fill-amber-400/40" />
            <span>{stats.currentStreak} Streak</span>
          </div>
        </div>
      </div>

      {/* Question Card & Audio Player Box */}
      <div className="p-5 bg-slate-950/90 border border-amber-900/30 rounded-xl space-y-4 text-center">
        <span className="inline-block text-[10px] uppercase tracking-wider font-bold text-amber-400 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/20">
          Question {(questionIndex % QARI_QUESTIONS_POOL.length) + 1} of {QARI_QUESTIONS_POOL.length}
        </span>

        <h4 className="text-sm sm:text-base font-bold text-slate-100 leading-snug">
          {currentQuestion.questionPrompt}
        </h4>

        {/* Audio Recitation Player Widget */}
        <div className="p-4 bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/30 rounded-2xl flex flex-col items-center justify-center gap-3">
          {/* Animated Audio Wave Lines when Playing */}
          <div className="flex items-center justify-center gap-1 h-6">
            {[40, 70, 30, 90, 50, 80, 40, 60, 30].map((height, i) => (
              <div
                key={i}
                style={{ height: isPlaying ? `${height}%` : '20%' }}
                className={`w-1 rounded-full transition-all duration-300 ${
                  isPlaying ? 'bg-amber-400 animate-pulse' : 'bg-slate-700'
                }`}
              />
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={togglePlayAudio}
              className={`w-12 h-12 rounded-full flex items-center justify-center transition shadow-lg ${
                isPlaying
                  ? 'bg-amber-500 text-slate-950 scale-105 ring-4 ring-amber-500/30'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
              }`}
            >
              {isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} className="ml-0.5" fill="currentColor" />}
            </button>

            <button
              type="button"
              onClick={handleReplay}
              title="Replay Audio"
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition"
            >
              <RotateCcw size={16} />
            </button>

            <button
              type="button"
              onClick={() => setMuted(!muted)}
              title={muted ? 'Unmute' : 'Mute'}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition"
            >
              {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
            </button>
          </div>

          <p className="text-[11px] text-amber-300/80 font-mono">
            {isPlaying ? '▶ Playing Audio Sample...' : 'Click Play button above to listen'}
          </p>
        </div>
      </div>

      {/* Multiple Choice Options Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {currentQuestion.options.map((option, idx) => {
          let btnClass = 'bg-slate-950 border-slate-800 text-slate-200 hover:border-amber-500/50 hover:bg-slate-900';

          if (isAnswered) {
            if (option === currentQuestion.correctAnswer) {
              btnClass = 'bg-emerald-950/80 border-emerald-500/80 text-emerald-300 font-bold ring-2 ring-emerald-500/30';
            } else if (option === selectedOption) {
              btnClass = 'bg-rose-950/80 border-rose-500/80 text-rose-300 font-bold';
            } else {
              btnClass = 'bg-slate-950/50 border-slate-900 text-slate-600 opacity-50';
            }
          }

          return (
            <button
              key={idx}
              type="button"
              disabled={isAnswered}
              onClick={() => handleOptionSelect(option)}
              className={`p-3.5 rounded-xl border text-xs font-semibold text-left transition flex items-center justify-between gap-2 ${btnClass}`}
            >
              <span>{option}</span>
              {isAnswered && option === currentQuestion.correctAnswer && (
                <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
              )}
              {isAnswered && option === selectedOption && option !== currentQuestion.correctAnswer && (
                <XCircle size={16} className="text-rose-400 shrink-0" />
              )}
            </button>
          );
        })}
      </div>

      {/* Feedback Explanation Card & Next Question Button */}
      {isAnswered && (
        <div className="p-4 bg-slate-950 border border-amber-900/30 rounded-xl space-y-3 animate-fadeIn">
          <div className="flex items-center gap-2">
            {isCorrect ? (
              <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                <CheckCircle2 size={16} />
                <span>MashaAllah! Correct Answer (+15 pts)</span>
              </span>
            ) : (
              <span className="text-xs font-bold text-rose-400 flex items-center gap-1">
                <XCircle size={16} />
                <span>Incorrect Answer</span>
              </span>
            )}
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">{currentQuestion.explanation}</p>

          <button
            type="button"
            onClick={handleNextQuestion}
            className="w-full py-3 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 active:scale-95"
          >
            <span>Next Recitation Question</span>
            <ArrowRight size={16} />
          </button>
        </div>
      )}
    </div>
  );
}
