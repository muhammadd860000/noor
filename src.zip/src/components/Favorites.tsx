import React, { useEffect, useState } from 'react';
import { getAllFromDB } from '../lib/db';
import { Link } from 'react-router-dom';
import { Book } from 'lucide-react';

export default function Favorites() {
  const [favorites, setFavorites] = useState<any[]>([]);

  useEffect(() => {
    const fetchFavorites = async () => {
      const data = await getAllFromDB('favorites');
      setFavorites(data);
    };
    fetchFavorites();
  }, []);

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-2xl text-amber-500 font-serif">My Library</h2>
      {favorites.length === 0 ? (
        <p className="text-slate-400">No favorites yet.</p>
      ) : (
        <div className="grid gap-3">
          {favorites.map((surah) => (
            <Link key={surah.id} to={`/quran/${surah.id}`} className="bg-slate-900 border border-amber-900/30 p-4 rounded-xl flex items-center justify-between">
              <span className="text-slate-100">{surah.name}</span>
              <Book className="text-amber-500" size={20} />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
