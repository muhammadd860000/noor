import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, CheckCircle2, XCircle, ChevronRight, HelpCircle, Flame } from 'lucide-react';
import { getDailyQuizQuestion, QuizQuestion } from '../data/quiz';
import { triggerHaptic } from '../lib/haptics';

export default function DailyQuranQuizWidget() {
  const today = new Date();
  const dateKey = today.toISOString().slice(0, 10);
  const question: QuizQuestion = useMemo(() => getDailyQuizQuestion(today), [today]);

  const [selectedOption, setSelectedOption] = useState<number | null>(() => {
    try {
      const saved = localStorage.getItem(`dailyQuiz_answer_${dateKey}`);
      return saved !== null ? parseInt(saved, 10) : null;
    } catch {
      return null;
    }
  });

  const [streak, setStreak] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('dailyQuiz_streak');
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });

  const handleSelect = (index: number) => {
    if (selectedOption !== null) return;
    const isCorrect = index === question.answer;
    triggerHaptic(isCorrect ? 40 : 20);

    setSelectedOption(index);
    localStorage.setItem(`dailyQuiz_answer_${dateKey}`, index.toString());

    const lastAnsweredDate = localStorage.getItem('dailyQuiz_lastAnsweredDate');
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().slice(0, 10);

    let newStreak = streak;
    if (lastAnsweredDate === yesterdayStr) {
      newStreak += 1;
    } else if (lastAnsweredDate === dateKey) {
      // already today
    } else {
      newStreak = 1;
    }
    setStreak(newStreak);
    localStorage.setItem('dailyQuiz_streak', newStreak.toString());
    localStorage.setItem('dailyQuiz_lastAnsweredDate', dateKey);
  };

  const isAnswered = selectedOption !== null;
  const isCorrect = isAnswered && selectedOption === question.answer;

  return (
    <section 
      aria-label="Daily Quran Verse Quiz Widget"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-600/50 space-y-4"
    >
      {/* Ambient background glow */}
      <div aria-hidden="true" className="absolute -top-16 -right-16 w-40 h-40 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" />

      {/* Header bar */}
      <div className="flex items-center justify-between pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-2.5">
          <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Sparkles size={18} />
          </span>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>Daily Quran & Islamic Quiz</span>
              {streak > 0 && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center gap-1 font-bold">
                  <Flame size={12} className="text-amber-400 fill-amber-400" />
                  {streak} Day Streak
                </span>
              )}
            </h3>
          </div>
        </div>

        <Link
          to="/quiz"
          className="text-xs text-amber-500 hover:text-amber-400 font-medium flex items-center gap-1 transition"
        >
          <span>Full Quiz Arena</span>
          <ChevronRight size={14} />
        </Link>
      </div>

      {/* Question prompt */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/20">
            {question.category || 'Quranic Challenge'}
          </span>
          <span className="text-[11px] text-slate-400">Test your knowledge today</span>
        </div>

        <p className="text-sm sm:text-base font-serif text-slate-100 leading-relaxed select-text">
          "{question.question}"
        </p>

        {/* Options */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
          {question.options.map((option, idx) => {
            const isSelected = selectedOption === idx;
            const isThisCorrect = idx === question.answer;

            let btnStyle = 'bg-slate-900/90 border-slate-800 text-slate-300 hover:border-amber-700/50 hover:bg-slate-900';
            if (isAnswered) {
              if (isThisCorrect) {
                btnStyle = 'bg-emerald-950/40 border-emerald-500 text-emerald-200 font-semibold';
              } else if (isSelected && !isThisCorrect) {
                btnStyle = 'bg-rose-950/40 border-rose-500 text-rose-200';
              } else {
                btnStyle = 'bg-slate-900/60 border-slate-800 text-slate-500 opacity-60';
              }
            }

            return (
              <button
                key={idx}
                type="button"
                onClick={() => handleSelect(idx)}
                disabled={isAnswered}
                className={`p-3 rounded-xl border text-left text-xs sm:text-sm transition-all flex items-center justify-between ${btnStyle}`}
              >
                <span>{option}</span>
                {isAnswered && isThisCorrect && <CheckCircle2 size={16} className="text-emerald-400 shrink-0 ml-2" />}
                {isAnswered && isSelected && !isThisCorrect && <XCircle size={16} className="text-rose-400 shrink-0 ml-2" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Explanation if answered */}
      {isAnswered && (
        <div className="p-3 bg-slate-950/80 border border-amber-900/30 rounded-xl text-xs space-y-1 animate-fadeIn">
          <div className="flex items-center gap-1.5 font-bold text-amber-400">
            {isCorrect ? <CheckCircle2 size={15} className="text-emerald-400" /> : <HelpCircle size={15} />}
            <span>{isCorrect ? 'Correct Masha\'Allah!' : 'Good effort!'}</span>
          </div>
          <p className="text-slate-300 leading-relaxed">
            {question.explanation}
          </p>
        </div>
      )}
    </section>
  );
}
