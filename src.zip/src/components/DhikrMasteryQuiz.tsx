import React, { useState } from 'react';
import { Sparkles, Trophy, CheckCircle2, XCircle, Award, RotateCcw, ArrowRight } from 'lucide-react';
import { recordQuizAttempt } from '../lib/quizLeaderboard';
import { triggerHaptic, triggerSuccessHaptic, triggerWarningHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export interface DhikrQuestion {
  id: number;
  dhikrArabic: string;
  transliteration: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export const DHIKR_QUIZ_QUESTIONS: DhikrQuestion[] = [
  {
    id: 1,
    dhikrArabic: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
    transliteration: 'SubhanAllahi wa bihamdihi',
    question: 'What is the primary virtue mentioned in Hadith for reciting this 100 times daily?',
    options: [
      'Sins are forgiven even if they were as abundant as the foam of the sea',
      'One receives a house in Paradise instantly',
      'Protected from poverty for the entire month',
      'One attains angelic vision during sleep'
    ],
    correctIndex: 0,
    explanation: 'Prophet Muhammad (ﷺ) said: "Whoever says SubhanAllahi wa bihamdihi 100 times a day, his sins will be wiped away even if they were like the foam of the sea." (Sahih al-Bukhari 6405)'
  },
  {
    id: 2,
    dhikrArabic: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',
    transliteration: 'La hawla wa la quwwata illa billah',
    question: 'How did Prophet Muhammad (ﷺ) describe this sacred phrase to Abu Musa al-Ash’ari?',
    options: [
      'A key to worldly riches',
      'A treasure from the treasures of Paradise (Kanz min kunuz al-Jannah)',
      'A protection against night terrors',
      'The heaviest word on the scales'
    ],
    correctIndex: 1,
    explanation: 'The Prophet (ﷺ) told Abu Musa: "Shall I not guide you to a treasure from the treasures of Paradise? Say: La hawla wa la quwwata illa billah."'
  },
  {
    id: 3,
    dhikrArabic: 'لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ',
    transliteration: 'La ilaha illa anta subhanaka inni kuntu minadh-dhalimin',
    question: 'Which Prophet supplicated with this Dhikr while inside the belly of the whale?',
    options: [
      'Prophet Musa (AS)',
      'Prophet Yunus (Jonah, AS)',
      'Prophet Ibrahim (AS)',
      'Prophet Ayyub (AS)'
    ],
    correctIndex: 1,
    explanation: 'Prophet Yunus (AS) called out in the depths of darkness: "There is no deity except You; exalted are You. Indeed, I have been of the wrongdoers." (Surah al-Anbiya 21:87)'
  },
  {
    id: 4,
    dhikrArabic: 'أَسْتَغْفِرُ اللَّهَ العَظِيمَ الَّذِي لاَ إِلَهَ إِلاَّ هُوَ الحَيُّ القَيُّومُ وَأَتُوبُ إِلَيْهِ',
    transliteration: 'Astaghfirullahal-\'Adhim alladhi la ilaha illa Huwal-Hayyul-Qayyumu wa atubu ilayh',
    question: 'What is the literal translation and spiritual intent of Astaghfirullah?',
    options: [
      'I seek forgiveness from Allah',
      'All praise is due to Allah alone',
      'Allah is the Greatest',
      'Guide us to the Straight Path'
    ],
    correctIndex: 0,
    explanation: 'Astaghfirullah means "I seek forgiveness from Allah". Frequent istighfar opens doors of sustenance, relief, and spiritual clarity.'
  },
  {
    id: 5,
    dhikrArabic: 'الْحَمْدُ لِلَّهِ',
    transliteration: 'Alhamdulillah',
    question: 'How does Alhamdulillah impact the believer\'s scales on the Day of Judgment?',
    options: [
      'It fills the Mizan (the scale of good deeds)',
      'It grants 10 gold coins in charity',
      'It doubles the speed of crossing Sirat',
      'It brings rain during drought'
    ],
    correctIndex: 0,
    explanation: 'Prophet Muhammad (ﷺ) said: "Cleanliness is half of faith and Alhamdulillah fills the scale." (Sahih Muslim 223)'
  }
];

export default function DhikrMasteryQuiz() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  const currentQ = DHIKR_QUIZ_QUESTIONS[currentIndex];

  const handleSelectOption = (index: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(index);

    const isCorrect = index === currentQ.correctIndex;
    if (isCorrect) {
      triggerSuccessHaptic();
      setScore(prev => prev + 1);
    } else {
      triggerWarningHaptic();
    }
  };

  const handleNext = () => {
    triggerButtonClickHaptic();
    if (currentIndex + 1 < DHIKR_QUIZ_QUESTIONS.length) {
      setCurrentIndex(prev => prev + 1);
      setSelectedAnswer(null);
    } else {
      // Quiz completed! Record score to global leaderboard
      const finalScore = score + (selectedAnswer === currentQ.correctIndex ? 0 : 0);
      recordQuizAttempt(
        'practice',
        'Dhikr & Remembrance',
        finalScore,
        DHIKR_QUIZ_QUESTIONS.length
      );
      setIsFinished(true);
    }
  };

  const handleRestart = () => {
    triggerButtonClickHaptic();
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setScore(0);
    setIsFinished(false);
  };

  return (
    <div className="bg-slate-900 border border-amber-900/40 rounded-2xl p-5 shadow-xl space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-amber-900/30 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/30">
            <Trophy size={20} />
          </div>
          <div>
            <h3 className="text-base font-serif font-bold text-slate-100">Dhikr Mastery Quiz</h3>
            <p className="text-xs text-slate-400">Test your knowledge of sacred Dhikr meanings & virtues</p>
          </div>
        </div>

        {!isFinished && (
          <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-xl bg-slate-950 text-amber-400 border border-slate-800">
            {currentIndex + 1} / {DHIKR_QUIZ_QUESTIONS.length}
          </span>
        )}
      </div>

      {isFinished ? (
        <div className="bg-slate-950/80 border border-amber-500/30 rounded-2xl p-6 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 mx-auto">
            <Award size={32} />
          </div>

          <div className="space-y-1">
            <h4 className="text-lg font-serif font-bold text-slate-100">Dhikr Quiz Completed!</h4>
            <p className="text-xs text-slate-400">
              You scored <span className="text-amber-400 font-bold font-mono">{score}</span> out of {DHIKR_QUIZ_QUESTIONS.length} ({Math.round((score / DHIKR_QUIZ_QUESTIONS.length) * 100)}%)
            </p>
          </div>

          <p className="text-xs text-emerald-300 bg-emerald-950/40 border border-emerald-500/30 p-2.5 rounded-xl font-medium">
            🏆 Points recorded to your global Quiz Leaderboard & Rank progress!
          </p>

          <button
            type="button"
            onClick={handleRestart}
            className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs transition flex items-center justify-center gap-1.5 shadow-lg shadow-amber-500/20"
          >
            <RotateCcw size={16} />
            <span>Retake Dhikr Mastery Quiz</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Question Card */}
          <div className="bg-slate-950/90 border border-slate-800 rounded-2xl p-4 text-center space-y-2">
            <p className="text-xl font-serif font-bold text-amber-300 dir-rtl">
              {currentQ.dhikrArabic}
            </p>
            <p className="text-xs text-slate-400 italic font-mono">{currentQ.transliteration}</p>
            <p className="text-xs text-slate-100 font-semibold pt-2 border-t border-slate-800/80">
              {currentQ.question}
            </p>
          </div>

          {/* Answer Options */}
          <div className="space-y-2">
            {currentQ.options.map((opt, idx) => {
              const isSelected = selectedAnswer === idx;
              const isCorrect = idx === currentQ.correctIndex;
              let btnStyle = 'bg-slate-950/80 border-slate-800 text-slate-300 hover:border-amber-500/40';

              if (selectedAnswer !== null) {
                if (isCorrect) {
                  btnStyle = 'bg-emerald-950/80 border-emerald-500/60 text-emerald-300 font-bold';
                } else if (isSelected) {
                  btnStyle = 'bg-amber-950/80 border-amber-500/60 text-amber-300 font-bold';
                }
              }

              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSelectOption(idx)}
                  disabled={selectedAnswer !== null}
                  className={`w-full p-3 rounded-xl border text-left text-xs transition flex items-center justify-between gap-2 ${btnStyle}`}
                >
                  <span>{opt}</span>
                  {selectedAnswer !== null && isCorrect && <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />}
                  {selectedAnswer !== null && isSelected && !isCorrect && <XCircle size={16} className="text-amber-400 shrink-0" />}
                </button>
              );
            })}
          </div>

          {/* Explanation Banner when answered */}
          {selectedAnswer !== null && (
            <div className="p-3 bg-slate-950 border border-amber-900/40 rounded-xl space-y-2 animate-fadeIn">
              <p className="text-xs text-amber-200 leading-relaxed font-sans">
                💡 {currentQ.explanation}
              </p>
              <button
                type="button"
                onClick={handleNext}
                className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs transition flex items-center justify-center gap-1 shadow-md"
              >
                <span>{currentIndex + 1 < DHIKR_QUIZ_QUESTIONS.length ? 'Next Question' : 'View Quiz Results'}</span>
                <ArrowRight size={14} />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
