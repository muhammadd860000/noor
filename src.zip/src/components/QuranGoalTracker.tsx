import React, { useState, useEffect } from 'react';
import { BookOpen, Sparkles, CheckCircle2, Award, Plus, Minus } from 'lucide-react';
import { getFromDB, saveToDB } from '../lib/db';
import { logAnalytics } from '../lib/analytics';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export default function QuranGoalTracker() {
  const [goal, setGoal] = useState<number>(5);
  const [progress, setProgress] = useState<number>(0);
  const [isEditingGoal, setIsEditingGoal] = useState<boolean>(false);
  const [tempGoal, setTempGoal] = useState<string>('5');
  const today = new Date().toDateString();

  useEffect(() => {
    const loadData = async () => {
      try {
        const savedGoal = await getFromDB('settings', 'quranGoal');
        if (savedGoal) {
          setGoal(savedGoal.value);
          setTempGoal(String(savedGoal.value));
        }
        
        const savedProgress = await getFromDB('quranProgress', today);
        if (savedProgress) setProgress(savedProgress.pages);
      } catch (e) {
        console.warn(e);
      }
    };
    loadData();
  }, [today]);

  const updateProgress = async (val: number) => {
    triggerHaptic(15);
    const newProgress = Math.max(0, val);
    const wasMet = progress < goal && newProgress >= goal;
    setProgress(newProgress);
    await saveToDB('quranProgress', { date: today, pages: newProgress });
    logAnalytics('goal_updated', { newProgress });

    if (wasMet) {
      triggerSuccessHaptic();
    }
  };

  const saveNewGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseInt(tempGoal, 10);
    if (!isNaN(parsed) && parsed > 0) {
      triggerButtonClickHaptic();
      setGoal(parsed);
      setIsEditingGoal(false);
      await saveToDB('settings', { key: 'quranGoal', value: parsed });
    }
  };

  const percentage = Math.min(100, Math.round((progress / goal) * 100));
  const isGoalMet = progress >= goal;

  return (
    <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 shadow-xl space-y-4 relative overflow-hidden">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative w-16 h-16 shrink-0">
            <svg className="w-full h-full" viewBox="0 0 36 36">
              <path className="text-slate-800" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" />
              <path className="text-amber-500" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" strokeDasharray={`${percentage}, 100`} />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center font-bold text-amber-400 text-sm">{percentage}%</div>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-slate-100">Daily Quran Reading Goal</h3>
              {isGoalMet && (
                <span className="text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <CheckCircle2 size={10} /> Goal Met!
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400">
              Read <strong className="text-amber-400">{progress}</strong> of {goal} pages today
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => { triggerHaptic(10); setIsEditingGoal(!isEditingGoal); }}
          className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-slate-950 text-amber-400 border border-slate-800 hover:bg-slate-850 transition"
        >
          {isEditingGoal ? 'Cancel' : 'Set Goal'}
        </button>
      </div>

      {isEditingGoal && (
        <form onSubmit={saveNewGoal} className="flex gap-2 pt-2 animate-fadeIn">
          <input
            type="number"
            min="1"
            max="604"
            value={tempGoal}
            onChange={(e) => setTempGoal(e.target.value)}
            placeholder="Target pages"
            className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 p-2 text-xs text-slate-100 rounded-xl outline-none"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs rounded-xl transition"
          >
            Save
          </button>
        </form>
      )}

      {/* Progress controls */}
      <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
        <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
          <div 
            className="bg-amber-500 h-full transition-all duration-300 rounded-full"
            style={{ width: `${percentage}%` }}
          />
        </div>

        <div className="flex gap-1.5 shrink-0">
          <button 
            type="button"
            onClick={() => updateProgress(progress - 1)} 
            className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800"
            title="Decrement page count"
          >
            <Minus size={14} />
          </button>
          <button 
            type="button"
            onClick={() => updateProgress(progress + 1)} 
            className="px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1 shadow-md shadow-amber-600/20"
            title="Increment page count (+1 page)"
          >
            <Plus size={14} /> +1 Page
          </button>
        </div>
      </div>

      {isGoalMet && (
        <div className="p-3 bg-emerald-950/30 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-center gap-2 animate-fadeIn">
          <Award size={16} className="text-emerald-400 shrink-0" />
          <span>Masha'Allah! You have achieved your daily Quran reading goal of {goal} pages!</span>
        </div>
      )}
    </div>
  );
}
