import React from 'react';
import PrayerNotificationManager from './PrayerNotificationManager';

interface NotificationSettingsProps {
  notifications?: Record<string, boolean>;
  togglePrayerNotification?: (prayer: string) => void;
}

export default function NotificationSettings({ notifications, togglePrayerNotification }: NotificationSettingsProps) {
  return (
    <div>
      <PrayerNotificationManager />
    </div>
  );
}
