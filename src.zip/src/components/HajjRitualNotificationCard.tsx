import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  BellOff, 
  Compass, 
  Check, 
  Sparkles, 
  MapPin, 
  Clock, 
  Volume2, 
  ShieldCheck, 
  Send 
} from 'lucide-react';
import { 
  HAJJ_RITUALS, 
  getHajjNotificationPreferences, 
  toggleHajjRitualNotification, 
  toggleMasterHajjNotifications, 
  sendTestHajjRitualNotification, 
  HajjNotificationPreferences 
} from '../lib/hajjScheduler';
import { triggerHaptic, triggerSuccessHaptic } from '../lib/haptics';

export default function HajjRitualNotificationCard() {
  const [prefs, setPrefs] = useState<HajjNotificationPreferences>(getHajjNotificationPreferences);
  const [testSent, setTestSent] = useState(false);

  useEffect(() => {
    const handleUpdate = (e: Event) => {
      const customEvent = e as CustomEvent<HajjNotificationPreferences>;
      if (customEvent.detail) {
        setPrefs(customEvent.detail);
      } else {
        setPrefs(getHajjNotificationPreferences());
      }
    };

    window.addEventListener('hajj-notifications-updated', handleUpdate);
    return () => window.removeEventListener('hajj-notifications-updated', handleUpdate);
  }, []);

  const handleMasterToggle = async () => {
    triggerHaptic(20);
    const result = await toggleMasterHajjNotifications(!prefs.enabled);
    if (result.success) {
      setPrefs(getHajjNotificationPreferences());
      triggerSuccessHaptic();
    }
  };

  const handleToggleRitual = async (id: string) => {
    triggerHaptic(15);
    const result = await toggleHajjRitualNotification(id);
    if (result.success) {
      setPrefs(getHajjNotificationPreferences());
    }
  };

  const handleSendTest = async (id: string) => {
    triggerHaptic(20);
    const sent = await sendTestHajjRitualNotification(id);
    if (sent) {
      setTestSent(true);
      triggerSuccessHaptic();
      setTimeout(() => setTestSent(false), 3000);
    }
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-5 shadow-xl space-y-4">
      {/* Card Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <Compass size={20} />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>Hajj & Umrah Ritual Reminders</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold">
                Arafat & Muzdalifah
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Push notifications for key pilgrimage rituals & milestone timings</p>
          </div>
        </div>

        {/* Master Switch Button */}
        <button
          type="button"
          onClick={handleMasterToggle}
          className={`px-3 py-1.5 rounded-xl font-bold text-xs transition flex items-center gap-1.5 self-start sm:self-auto ${
            prefs.enabled
              ? 'bg-amber-600 text-slate-950 shadow-md shadow-amber-600/20'
              : 'bg-slate-950 text-slate-400 border border-slate-800'
          }`}
        >
          {prefs.enabled ? <Bell size={14} className="fill-slate-950" /> : <BellOff size={14} />}
          <span>{prefs.enabled ? 'Hajj Alerts Active' : 'Enable Hajj Alerts'}</span>
        </button>
      </div>

      {/* Rituals Toggles List */}
      <div className="space-y-2.5">
        {HAJJ_RITUALS.map(ritual => {
          const isEnabled = prefs.enabled && !!prefs.enabledRituals[ritual.id];

          return (
            <div
              key={ritual.id}
              className={`p-3.5 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                isEnabled
                  ? 'bg-amber-950/20 border-amber-500/40 text-slate-100'
                  : 'bg-slate-950/70 border-slate-800/80 text-slate-400'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-bold text-slate-100">{ritual.name}</span>
                  <span className="text-[10px] font-serif text-amber-300" dir="rtl">{ritual.arabicName}</span>
                  <span className="text-[10px] font-mono bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded border border-amber-500/20">
                    {ritual.hijriDateStr}
                  </span>
                </div>

                <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
                  <span className="flex items-center gap-1 text-amber-400/90">
                    <Clock size={12} />
                    <span>{ritual.defaultTime}</span>
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <MapPin size={12} className="text-amber-500/80" />
                    <span>{ritual.location}</span>
                  </span>
                </div>

                <p className="text-[11px] text-slate-300/90 leading-relaxed">
                  {ritual.description}
                </p>
              </div>

              {/* Ritual Toggle & Test Buttons */}
              <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                <button
                  type="button"
                  onClick={() => handleSendTest(ritual.id)}
                  className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-amber-400 text-xs font-medium rounded-lg transition flex items-center gap-1"
                  title="Test notification"
                >
                  <Send size={12} />
                  <span>Test</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleToggleRitual(ritual.id)}
                  className={`p-2 rounded-xl transition ${
                    isEnabled
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                      : 'bg-slate-900 text-slate-500 border border-slate-800 hover:text-slate-300'
                  }`}
                  title={isEnabled ? `Disable alert for ${ritual.name}` : `Enable alert for ${ritual.name}`}
                >
                  {isEnabled ? <Bell size={16} className="fill-amber-400/30" /> : <BellOff size={16} />}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {testSent && (
        <div className="p-2.5 bg-emerald-950/30 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
          <Check size={14} className="text-emerald-400" />
          <span>Test Hajj ritual notification sent! Check your system browser alerts.</span>
        </div>
      )}
    </div>
  );
}
