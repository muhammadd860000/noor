import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getFromDB, saveToDB } from '../lib/db';
import { Check } from 'lucide-react';

const PRAYERS = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

export default function PrayerTracker() {
  const [dailyData, setDailyData] = useState<Record<string, boolean>>({});
  const [history, setHistory] = useState<any[]>([]);
  const today = new Date().toDateString();

  useEffect(() => {
    const loadData = async () => {
      const saved = await getFromDB('prayer', today);
      if (saved) setDailyData(saved.prayers);
      
      const all = await getFromDB('prayer', 'all') || []; // Simplified fetching
    };
    loadData();

    const handleSync = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail && customEvent.detail.prayers) {
        setDailyData(customEvent.detail.prayers);
      }
    };
    window.addEventListener('prayer-status-changed', handleSync);
    return () => window.removeEventListener('prayer-status-changed', handleSync);
  }, [today]);

  const togglePrayer = async (prayer: string) => {
    const newData = { ...dailyData, [prayer]: !dailyData[prayer] };
    setDailyData(newData);
    await saveToDB('prayer', { date: today, prayers: newData });
    localStorage.setItem(`dailyPrayers_${today}`, JSON.stringify(newData));
    
    // Log to history if completed
    if (newData[prayer]) {
        const history = await getFromDB('prayer', 'history') || [];
        const historyList = Array.isArray(history) ? history : (history.history || []);
        await saveToDB('prayer', { date: 'history', history: [...historyList, { prayer, timestamp: new Date().toISOString() }] });
    }

    window.dispatchEvent(new CustomEvent('prayer-status-changed', {
      detail: { date: today, prayers: newData, prayer, completed: newData[prayer] }
    }));
  };

  return (
    <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 shadow-lg md:col-span-2">
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-amber-600 font-semibold">Prayer Tracker</h3>
        <Link to="/prayer" className="text-xs text-amber-500 hover:text-amber-400 font-semibold">
          30-Day Insights →
        </Link>
      </div>
      <div className="flex justify-between mb-4">
        {PRAYERS.map(p => (
            <button key={p} onClick={() => togglePrayer(p)} className="flex flex-col items-center gap-1">
                <div className={`w-10 h-10 rounded-full border-2 border-amber-600 flex items-center justify-center ${dailyData[p] ? 'bg-amber-600' : 'bg-slate-800'}`}>
                    {dailyData[p] && <Check size={20} className="text-slate-950" />}
                </div>
                <span className="text-slate-400 text-xs">{p}</span>
            </button>
        ))}
      </div>
    </div>
  );
}
