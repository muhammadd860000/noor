import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  Heart, 
  Sparkles, 
  Share2, 
  Copy, 
  Check, 
  RefreshCw, 
  Volume2, 
  VolumeX, 
  CheckCircle2, 
  Bookmark, 
  BookOpen, 
  Sun, 
  Quote, 
  Flame,
  ChevronRight,
  Filter,
  Layers,
  ArrowRight
} from 'lucide-react';
import { 
  ISLAMIC_AFFIRMATIONS, 
  getDailyAffirmation, 
  IslamicAffirmation 
} from '../data/affirmations';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

export interface AffirmationsProps {
  isCompact?: boolean;
}

export default function Affirmations({ isCompact = false }: AffirmationsProps) {
  const todayDateStr = useMemo(() => new Date().toISOString().split('T')[0], []);
  const todayFormatted = useMemo(() => {
    return new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'short',
      day: 'numeric'
    });
  }, []);

  const defaultAffirmation = useMemo(() => getDailyAffirmation(new Date()), []);

  // Active affirmation index
  const [activeIndex, setActiveIndex] = useState(() => {
    const savedId = localStorage.getItem(`dailyAffirmation_selectedId_${todayDateStr}`);
    if (savedId) {
      const idx = ISLAMIC_AFFIRMATIONS.findIndex(a => a.id === savedId);
      if (idx !== -1) return idx;
    }
    const defIdx = ISLAMIC_AFFIRMATIONS.findIndex(a => a.id === defaultAffirmation.id);
    return defIdx !== -1 ? defIdx : 0;
  });

  const current: IslamicAffirmation = ISLAMIC_AFFIRMATIONS[activeIndex] || defaultAffirmation;

  // Internalized / Affirmation count for today
  const [internalizeCount, setInternalizeCount] = useState<number>(() => {
    const saved = localStorage.getItem(`affirmation_count_${todayDateStr}_${current.id}`);
    return saved ? parseInt(saved, 10) : 0;
  });

  // Favorites state
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('noor_favorite_affirmations');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const isFavorite = favoriteIds.includes(current.id);

  // Filter category for full browser mode
  const [selectedTheme, setSelectedTheme] = useState<string>('all');
  const [showFullLibrary, setShowFullLibrary] = useState(false);
  const [copied, setCopied] = useState(false);
  const [shared, setShared] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  // Sync count on active change
  useEffect(() => {
    localStorage.setItem(`dailyAffirmation_selectedId_${todayDateStr}`, current.id);
    const saved = localStorage.getItem(`affirmation_count_${todayDateStr}_${current.id}`);
    setInternalizeCount(saved ? parseInt(saved, 10) : 0);
  }, [current.id, todayDateStr]);

  // Clean up speech
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Handle Internalize (Spiritual affirmation repetition)
  const handleInternalize = () => {
    triggerSuccessHaptic();
    setInternalizeCount(prev => {
      const next = prev + 1;
      localStorage.setItem(`affirmation_count_${todayDateStr}_${current.id}`, String(next));
      return next;
    });
  };

  // Toggle Favorite
  const handleToggleFavorite = () => {
    triggerButtonClickHaptic();
    setFavoriteIds(prev => {
      const updated = prev.includes(current.id)
        ? prev.filter(id => id !== current.id)
        : [...prev, current.id];
      localStorage.setItem('noor_favorite_affirmations', JSON.stringify(updated));
      return updated;
    });
  };

  // Cycle next
  const handleNextAffirmation = () => {
    triggerButtonClickHaptic();
    setActiveIndex(prev => (prev + 1) % ISLAMIC_AFFIRMATIONS.length);
  };

  // Copy
  const handleCopy = async () => {
    triggerButtonClickHaptic();
    const content = `✨ Daily Islamic Affirmation\n\n"${current.affirmation}"\n\n"${current.arabic || ''}"\n${current.transliteration ? `(${current.transliteration})\n` : ''}📖 ${current.source}\n🌱 Action: ${current.practicalAction}\n\nShared via Noor`;

    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(content);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Share
  const handleShare = async () => {
    triggerButtonClickHaptic();
    const title = `Daily Islamic Affirmation: ${current.theme}`;
    const text = `✨ Daily Islamic Affirmation\n\n"${current.affirmation}"\n\n"${current.arabic || ''}"\n${current.transliteration ? `(${current.transliteration})\n` : ''}📖 ${current.source}\n🌱 Action: ${current.practicalAction}\n\nShared via Noor`;
    const url = window.location.origin;

    if (navigator.share) {
      try {
        await navigator.share({ title, text, url });
        triggerSuccessHaptic();
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          handleCopy();
        }
      }
    } else {
      handleCopy();
    }
  };

  // Speech Synth
  const handleToggleSpeech = () => {
    triggerButtonClickHaptic();
    if (!('speechSynthesis' in window)) return;

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(current.affirmation);
    utterance.rate = 0.95;
    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  // Filtered pool
  const filteredAffirmations = useMemo(() => {
    if (selectedTheme === 'all') return ISLAMIC_AFFIRMATIONS;
    if (selectedTheme === 'favorites') return ISLAMIC_AFFIRMATIONS.filter(a => favoriteIds.includes(a.id));
    return ISLAMIC_AFFIRMATIONS.filter(a => a.theme === selectedTheme);
  }, [selectedTheme, favoriteIds]);

  const themes = useMemo(() => {
    return Array.from(new Set(ISLAMIC_AFFIRMATIONS.map(a => a.theme)));
  }, []);

  return (
    <section 
      aria-label="Daily Islamic Affirmations & Positive Mindset"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-700/50"
    >
      {/* Decorative ambient background */}
      <div 
        aria-hidden="true" 
        className="absolute -top-16 -right-16 w-44 h-44 rounded-full bg-amber-500/5 blur-3xl pointer-events-none"
      />

      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-amber-900/20 gap-2.5">
        <div className="flex items-center gap-2">
          <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
            <Sparkles size={18} />
          </span>
          <div>
            <h2 className="text-sm font-semibold tracking-wide uppercase text-amber-500 flex items-center gap-1.5">
              Daily Islamic Affirmation · {current.theme}
            </h2>
            <p className="text-xs text-slate-400">
              {todayFormatted} · Positive Spiritual Mindset
            </p>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1.5 self-start sm:self-auto">
          {/* Favorite */}
          <button
            type="button"
            onClick={handleToggleFavorite}
            className={`p-2 rounded-lg transition-colors ${
              isFavorite ? 'text-rose-400 bg-rose-500/20' : 'text-slate-400 hover:text-rose-400 hover:bg-slate-800/80'
            }`}
            title={isFavorite ? 'Remove from favorites' : 'Save to favorites'}
            aria-label="Favorite affirmation"
          >
            <Heart size={15} className={isFavorite ? 'fill-rose-400' : ''} />
          </button>

          {/* Shuffle / Next */}
          <button
            type="button"
            onClick={handleNextAffirmation}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition-colors"
            title="Discover another affirmation"
            aria-label="Discover another affirmation"
          >
            <RefreshCw size={15} />
          </button>

          {/* Audio Pronunciation / Narration */}
          <button
            type="button"
            onClick={handleToggleSpeech}
            className={`p-2 rounded-lg transition-colors ${
              isPlayingAudio ? 'text-amber-400 bg-amber-500/20' : 'text-slate-400 hover:text-amber-400 hover:bg-slate-800/80'
            }`}
            title="Read affirmation aloud"
            aria-label="Read affirmation aloud"
          >
            {isPlayingAudio ? <VolumeX size={15} /> : <Volume2 size={15} />}
          </button>

          {/* Native Share */}
          <button
            type="button"
            onClick={handleShare}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition-colors"
            title="Share Affirmation"
            aria-label="Share Affirmation"
          >
            {shared ? <Check size={15} className="text-emerald-400" /> : <Share2 size={15} />}
          </button>

          {/* Copy */}
          <button
            type="button"
            onClick={handleCopy}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800/80 rounded-lg transition-colors"
            title="Copy Affirmation"
            aria-label="Copy Affirmation"
          >
            {copied ? <Check size={15} className="text-emerald-400" /> : <Copy size={15} />}
          </button>
        </div>
      </div>

      {/* Main Affirmation Card */}
      <div className="pt-4 space-y-4">
        {/* Affirmation Core Quote */}
        <div className="relative pl-6 sm:pl-8 border-l-2 border-amber-500/50 space-y-3">
          <Quote size={20} className="absolute left-0 top-0 text-amber-500/40 -translate-x-1/2 bg-slate-900 rounded-full" />
          
          <p className="text-base sm:text-lg lg:text-xl text-slate-100 font-serif font-medium leading-relaxed">
            "{current.affirmation}"
          </p>

          {/* Arabic scripture foundation if present */}
          {current.arabic && (
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-1.5">
              <p dir="rtl" lang="ar" className="text-base sm:text-lg text-amber-200/90 font-serif text-right leading-loose">
                {current.arabic}
              </p>
              {current.transliteration && (
                <p className="text-xs text-amber-400/80 font-medium">
                  {current.transliteration}
                </p>
              )}
              <p className="text-[11px] text-slate-400 font-mono">
                Scripture Source: {current.source}
              </p>
            </div>
          )}
        </div>

        {/* Practical Mindset Action Callout */}
        <div className="p-3.5 bg-gradient-to-r from-emerald-950/40 via-slate-950 to-emerald-950/30 border border-emerald-900/30 rounded-xl flex items-start gap-3">
          <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 mt-0.5">
            <Sun size={16} />
          </div>
          <div className="text-xs space-y-0.5">
            <span className="font-semibold text-emerald-400">Today's Mindset Shift:</span>
            <p className="text-slate-300 leading-relaxed">
              {current.practicalAction}
            </p>
          </div>
        </div>

        {/* Footer: Internalize Button & Library Toggle */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
          {/* Internalize / Repetition Counter Button */}
          <button
            type="button"
            onClick={handleInternalize}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition active:scale-95 shadow-md shadow-amber-500/20"
          >
            <CheckCircle2 size={15} />
            <span>I Internalize & Accept This ({internalizeCount}× today)</span>
          </button>

          {/* Library browser toggle */}
          <button
            type="button"
            onClick={() => {
              triggerButtonClickHaptic();
              setShowFullLibrary(!showFullLibrary);
            }}
            className="text-xs text-slate-400 hover:text-amber-400 transition flex items-center gap-1 self-start sm:self-auto py-1 font-medium"
          >
            <span>{showFullLibrary ? 'Hide Affirmations Library' : 'Explore All Islamic Affirmations'}</span>
            <ChevronRight size={14} className={`transition-transform ${showFullLibrary ? 'rotate-90' : ''}`} />
          </button>
        </div>

        {/* Expandable Library Browser */}
        {showFullLibrary && (
          <div className="mt-4 pt-4 border-t border-amber-900/30 space-y-3 animate-fadeIn">
            {/* Theme filter tabs */}
            <div className="flex gap-1.5 overflow-x-auto pb-1 text-xs">
              <button
                type="button"
                onClick={() => {
                  triggerButtonClickHaptic();
                  setSelectedTheme('all');
                }}
                className={`px-3 py-1 rounded-lg whitespace-nowrap transition ${
                  selectedTheme === 'all' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold' : 'bg-slate-950 border border-slate-800 text-slate-400'
                }`}
              >
                All ({ISLAMIC_AFFIRMATIONS.length})
              </button>
              <button
                type="button"
                onClick={() => {
                  triggerButtonClickHaptic();
                  setSelectedTheme('favorites');
                }}
                className={`px-3 py-1 rounded-lg whitespace-nowrap transition flex items-center gap-1 ${
                  selectedTheme === 'favorites' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-semibold' : 'bg-slate-950 border border-slate-800 text-slate-400'
                }`}
              >
                <Heart size={12} className={favoriteIds.length > 0 ? 'fill-rose-400 text-rose-400' : ''} />
                <span>Favorites ({favoriteIds.length})</span>
              </button>
              {themes.map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => {
                    triggerButtonClickHaptic();
                    setSelectedTheme(t);
                  }}
                  className={`px-3 py-1 rounded-lg whitespace-nowrap transition ${
                    selectedTheme === t ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold' : 'bg-slate-950 border border-slate-800 text-slate-400'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            {/* List of Affirmations */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-96 overflow-y-auto pr-1">
              {filteredAffirmations.map((item, idx) => (
                <div 
                  key={item.id}
                  onClick={() => {
                    triggerButtonClickHaptic();
                    const targetIdx = ISLAMIC_AFFIRMATIONS.findIndex(a => a.id === item.id);
                    if (targetIdx !== -1) setActiveIndex(targetIdx);
                  }}
                  className={`p-3.5 rounded-xl border transition cursor-pointer text-xs space-y-2 ${
                    current.id === item.id 
                      ? 'bg-amber-500/10 border-amber-500/50 shadow-sm'
                      : 'bg-slate-950/70 border-slate-800/80 hover:border-amber-700/40'
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-amber-400">{item.theme}</span>
                    <span className="text-slate-500">{item.source}</span>
                  </div>
                  <p className="text-slate-200 font-serif leading-relaxed">
                    "{item.affirmation}"
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
