import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Coins, Heart, ArrowUpRight, Target, Sparkles, CheckCircle2, Layers } from 'lucide-react';
import { triggerHaptic } from '../lib/haptics';

export default function ZakatWidget() {
  const [totalGiven, setTotalGiven] = useState(0);
  const [annualGoal, setAnnualGoal] = useState(3000);
  const [zakatDue, setZakatDue] = useState(0);
  const [zakatPaid, setZakatPaid] = useState(0);
  const [jariyahCount, setJariyahCount] = useState(3);
  const [jariyahFunded, setJariyahFunded] = useState(3950);

  useEffect(() => {
    try {
      const savedGoal = localStorage.getItem('noor_giving_annual_goal');
      if (savedGoal) setAnnualGoal(parseFloat(savedGoal) || 3000);

      const savedContributions = localStorage.getItem('noor_charity_contributions');
      if (savedContributions) {
        const parsed = JSON.parse(savedContributions);
        const currentYear = new Date().getFullYear();
        let sumTotal = 0;
        let sumZakat = 0;

        parsed.forEach((item: any) => {
          const itemYear = new Date(item.date).getFullYear();
          if (itemYear === currentYear) {
            sumTotal += item.amount || 0;
            if (item.type === 'zakat') sumZakat += item.amount || 0;
          }
        });

        setTotalGiven(sumTotal);
        setZakatPaid(sumZakat);
      } else {
        // Defaults to demo seeds
        setTotalGiven(1100);
        setZakatPaid(500);
      }

      const savedProjects = localStorage.getItem('noor_sadaqah_jariyah_projects');
      if (savedProjects) {
        const projs = JSON.parse(savedProjects);
        setJariyahCount(projs.length);
        const funded = projs.reduce((acc: number, p: any) => acc + (p.currentAmount || 0), 0);
        setJariyahFunded(funded);
      }

      const savedAssets = localStorage.getItem('noor_zakat_assets');
      if (savedAssets) {
        const a = JSON.parse(savedAssets);
        const gross = (a.cashInHand || 0) + (a.cashInBank || 0) + (a.goldSilverValue || 0) + (a.investments || 0) + (a.businessMerchandise || 0) + (a.loansOwedToYou || 0);
        const net = Math.max(0, gross - (a.immediateDebts || 0));
        if (net >= 6200) {
          setZakatDue(Math.round(net * 0.025 * 100) / 100);
        }
      }
    } catch {
      // ignore
    }
  }, []);

  const progressPct = Math.min(100, Math.round((totalGiven / (annualGoal || 1)) * 100));

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-700/50 flex flex-col justify-between space-y-4">
      <div className="flex items-center justify-between pb-2 border-b border-amber-900/20">
        <div className="flex items-center gap-2.5">
          <span className="p-2 rounded-xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <Coins size={18} />
          </span>
          <div>
            <h3 className="text-base font-bold text-slate-100">Zakat & Sadaqah Hub</h3>
            <span className="text-[10px] font-mono text-amber-400">Annual Giving & Sadaqah Jariyah</span>
          </div>
        </div>

        <Link
          to="/zakat"
          onClick={() => triggerHaptic(10)}
          className="text-xs text-amber-500 hover:text-amber-400 flex items-center gap-1 font-semibold"
        >
          <span>Open Hub</span>
          <ArrowUpRight size={14} />
        </Link>
      </div>

      <div className="space-y-3">
        <div className="flex items-baseline justify-between">
          <div>
            <span className="text-2xl font-mono font-bold text-slate-100">
              ${totalGiven.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400 font-mono ml-1.5">
              given this year
            </span>
          </div>
          <span className="text-xs text-amber-400 font-mono font-bold">
            {progressPct}% of Goal
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
          <div 
            className="bg-amber-500 h-full rounded-full transition-all duration-500"
            style={{ width: `${progressPct}%` }}
          />
        </div>

        <div className="grid grid-cols-3 gap-2 pt-1">
          <div className="p-2.5 bg-slate-950/60 rounded-xl border border-slate-800 text-xs space-y-0.5">
            <span className="text-[10px] text-slate-400 block truncate">Zakat Paid</span>
            <span className="font-mono font-bold text-amber-400">
              ${zakatPaid.toLocaleString()}
            </span>
          </div>
          <div className="p-2.5 bg-slate-950/60 rounded-xl border border-slate-800 text-xs space-y-0.5">
            <span className="text-[10px] text-slate-400 block truncate">Sadaqah Jariyah</span>
            <span className="font-mono font-bold text-pink-400">
              ${jariyahFunded.toLocaleString()}
            </span>
          </div>
          <div className="p-2.5 bg-slate-950/60 rounded-xl border border-slate-800 text-xs space-y-0.5">
            <span className="text-[10px] text-slate-400 block truncate">Annual Goal</span>
            <span className="font-mono font-bold text-slate-200">
              ${annualGoal.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      <Link
        to="/zakat"
        onClick={() => triggerHaptic(15)}
        className="w-full bg-amber-600/15 hover:bg-amber-600/25 border border-amber-500/40 text-amber-300 font-bold py-2 rounded-xl text-xs text-center transition-colors block"
      >
        Track Perpetual Projects & Calculate Zakat →
      </Link>
    </div>
  );
}
