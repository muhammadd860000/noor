import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { BarChart3 } from 'lucide-react';

export default function WeeklyConsistency() {
  const [data, setData] = useState<{ day: string, completed: number }[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('dailyHabits');
    const habits = saved ? JSON.parse(saved) : [];

    const aggregatedData = Array(7).fill(0).map((_, i) => ({
      day: ['M', 'T', 'W', 'T', 'F', 'S', 'S'][i],
      completed: 0
    }));

    habits.forEach((habit: any) => {
      habit.history.forEach((done: boolean, index: number) => {
        if (done) aggregatedData[index].completed += 1;
      });
    });

    setData(aggregatedData);
  }, []);

  return (
    <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 shadow-lg md:col-span-2">
      <h3 className="text-amber-600 font-semibold mb-3 flex items-center gap-2">
        <BarChart3 size={18} /> Weekly Consistency
      </h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <XAxis dataKey="day" stroke="#94a3b8" fontSize={12} axisLine={false} tickLine={false} />
            <YAxis stroke="#94a3b8" fontSize={12} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #78350f', borderRadius: '8px' }} />
            <Bar dataKey="completed" fill="#d97706" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
