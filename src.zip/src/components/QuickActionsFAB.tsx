import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Plus, 
  Zap, 
  Calendar, 
  Heart, 
  Sparkles, 
  BookOpen, 
  CheckCircle2, 
  DollarSign, 
  X, 
  Moon,
  Coins,
  Smile
} from 'lucide-react';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';
import { addSadaqahDonation } from '../lib/sadaqahTracker';
import { markPrayerCompleted, getCurrentPrayerName } from '../lib/prayerLog';

export default function QuickActionsFAB() {
  const [isOpen, setIsOpen] = useState(false);
  const [modalType, setModalType] = useState<'sadaqah' | 'fast' | 'prayer' | null>(null);
  
  // Quick Sadaqah modal state
  const [sadaqahAmount, setSadaqahAmount] = useState('10');
  const [sadaqahNote, setSadaqahNote] = useState('Daily Charity');

  // Quick Fasting state
  const [fastType, setFastType] = useState('Voluntary (Sunnah)');

  // Quick Prayer status
  const [currentPrayer, setCurrentPrayer] = useState('Dhuhr');
  const [prayerLogged, setPrayerLogged] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    try {
      const pName = getCurrentPrayerName();
      setCurrentPrayer(pName || 'Fajr');
    } catch {
      setCurrentPrayer('Fajr');
    }
  }, []);

  const toggleOpen = () => {
    triggerHaptic(15);
    setIsOpen(prev => !prev);
  };

  const handleSadaqahSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(sadaqahAmount);
    if (!isNaN(num) && num > 0) {
      addSadaqahDonation(num, sadaqahNote);
      triggerSuccessHaptic();
      setModalType(null);
      setIsOpen(false);
    }
  };

  const handleFastSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    triggerSuccessHaptic();
    const todayStr = new Date().toISOString().split('T')[0];
    const existing = JSON.parse(localStorage.getItem('noor_logged_fasts') || '[]');
    existing.push({ date: todayStr, type: fastType, timestamp: Date.now() });
    localStorage.setItem('noor_logged_fasts', JSON.stringify(existing));
    setModalType(null);
    setIsOpen(false);
  };

  const handleQuickPrayerLog = () => {
    triggerSuccessHaptic();
    markPrayerCompleted(currentPrayer, true);
    setPrayerLogged(true);
    setTimeout(() => {
      setPrayerLogged(false);
      setModalType(null);
      setIsOpen(false);
    }, 1500);
  };

  return (
    <>
      {/* Backdrop overlay when open */}
      {isOpen && (
        <div 
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-40 transition-opacity"
        />
      )}

      {/* Floating Action Speed Dial */}
      <div className="fixed bottom-20 right-4 sm:bottom-6 sm:right-6 z-50 flex flex-col items-end gap-3">
        {/* Expanded Quick Action Items */}
        {isOpen && (
          <div className="flex flex-col items-end gap-2.5 mb-2 animate-fadeIn">
            {/* Quick Sadaqah */}
            <button
              type="button"
              onClick={() => {
                triggerButtonClickHaptic();
                setModalType('sadaqah');
              }}
              className="flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-slate-900 border border-emerald-500/40 text-emerald-300 font-bold text-xs shadow-xl hover:bg-slate-850 transition active:scale-95 group"
            >
              <span>Record Sadaqah</span>
              <span className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 group-hover:scale-110 transition">
                <Coins size={16} />
              </span>
            </button>

            {/* Quick Fast Logging */}
            <button
              type="button"
              onClick={() => {
                triggerButtonClickHaptic();
                setModalType('fast');
              }}
              className="flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-slate-900 border border-amber-500/40 text-amber-300 font-bold text-xs shadow-xl hover:bg-slate-850 transition active:scale-95 group"
            >
              <span>Log Fasting</span>
              <span className="p-1.5 rounded-xl bg-amber-500/20 text-amber-400 group-hover:scale-110 transition">
                <Moon size={16} />
              </span>
            </button>

            {/* Quick Prayer Log */}
            <button
              type="button"
              onClick={() => {
                triggerButtonClickHaptic();
                setModalType('prayer');
              }}
              className="flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-slate-900 border border-indigo-500/40 text-indigo-300 font-bold text-xs shadow-xl hover:bg-slate-850 transition active:scale-95 group"
            >
              <span>Log {currentPrayer} Prayer</span>
              <span className="p-1.5 rounded-xl bg-indigo-500/20 text-indigo-400 group-hover:scale-110 transition">
                <CheckCircle2 size={16} />
              </span>
            </button>

            {/* Open Digital Tasbeeh Counter */}
            <button
              type="button"
              onClick={() => {
                triggerButtonClickHaptic();
                setIsOpen(false);
                navigate('/tasbeeh');
              }}
              className="flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-slate-900 border border-teal-500/40 text-teal-300 font-bold text-xs shadow-xl hover:bg-slate-850 transition active:scale-95 group"
            >
              <span>Digital Tasbeeh</span>
              <span className="p-1.5 rounded-xl bg-teal-500/20 text-teal-400 group-hover:scale-110 transition">
                <Sparkles size={16} />
              </span>
            </button>
          </div>
        )}

        {/* Main Floating Trigger Button */}
        <button
          type="button"
          onClick={toggleOpen}
          className={`w-13 h-13 sm:w-14 sm:h-14 rounded-full flex items-center justify-center font-bold text-slate-950 shadow-2xl border transition-all duration-300 active:scale-90 ${
            isOpen
              ? 'bg-amber-400 border-amber-300 rotate-45 ring-4 ring-amber-500/30'
              : 'bg-gradient-to-tr from-amber-600 via-amber-500 to-amber-400 border-amber-300 shadow-amber-500/30 hover:scale-105'
          }`}
          title={isOpen ? "Close Quick Actions" : "Quick Actions Menu"}
        >
          <Plus size={28} className="text-slate-950 stroke-[2.5]" />
        </button>
      </div>

      {/* MODAL: Record Quick Sadaqah */}
      {modalType === 'sadaqah' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl relative">
            <button
              type="button"
              onClick={() => setModalType(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200"
            >
              <X size={18} />
            </button>

            <div className="flex items-center gap-3">
              <span className="p-2.5 rounded-2xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                <Coins size={22} />
              </span>
              <div>
                <h3 className="text-base font-serif font-bold text-slate-100">Quick Sadaqah Entry</h3>
                <p className="text-xs text-slate-400">Record a charitable contribution</p>
              </div>
            </div>

            <form onSubmit={handleSadaqahSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Amount ($)</label>
                <div className="flex gap-2 mb-2">
                  {['5', '10', '25', '50'].map(val => (
                    <button
                      type="button"
                      key={val}
                      onClick={() => setSadaqahAmount(val)}
                      className={`flex-1 py-1.5 rounded-xl text-xs font-bold border transition ${
                        sadaqahAmount === val
                          ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                          : 'bg-slate-950 text-slate-300 border-slate-800'
                      }`}
                    >
                      ${val}
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  min="1"
                  step="any"
                  value={sadaqahAmount}
                  onChange={(e) => setSadaqahAmount(e.target.value)}
                  className="w-full bg-slate-950 text-slate-100 border border-slate-800 focus:border-emerald-500 p-2.5 rounded-xl text-sm outline-none font-mono"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Note / Intention</label>
                <input
                  type="text"
                  value={sadaqahNote}
                  onChange={(e) => setSadaqahNote(e.target.value)}
                  placeholder="e.g. Feeding a needy person, Mosque donation"
                  className="w-full bg-slate-950 text-slate-100 border border-slate-800 focus:border-emerald-500 p-2.5 rounded-xl text-xs outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs transition shadow-lg shadow-emerald-500/20"
              >
                Save Sadaqah Contribution
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Quick Fasting Log */}
      {modalType === 'fast' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl relative">
            <button
              type="button"
              onClick={() => setModalType(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200"
            >
              <X size={18} />
            </button>

            <div className="flex items-center gap-3">
              <span className="p-2.5 rounded-2xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
                <Moon size={22} />
              </span>
              <div>
                <h3 className="text-base font-serif font-bold text-slate-100">Log Today's Fast</h3>
                <p className="text-xs text-slate-400">Record your intention & Suhoor/Iftar</p>
              </div>
            </div>

            <form onSubmit={handleFastSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Fast Type</label>
                <select
                  value={fastType}
                  onChange={(e) => setFastType(e.target.value)}
                  className="w-full bg-slate-950 text-slate-100 border border-slate-800 focus:border-amber-500 p-2.5 rounded-xl text-xs outline-none"
                >
                  <option value="Voluntary (Sunnah)">Voluntary Sunnah Fast (Mon/Thu)</option>
                  <option value="Obligatory (Ramadan)">Obligatory Ramadan Fast</option>
                  <option value="Make-up (Qada)">Make-up (Qada) Fast</option>
                  <option value="White Days (Ayyam al-Bid)">White Days (13th, 14th, 15th)</option>
                </select>
              </div>

              <div className="p-3 bg-amber-950/30 border border-amber-800/40 rounded-xl text-[11px] text-amber-300 leading-relaxed">
                ✨ Intention (Niyyah): "I intend to fast today for the sake of Allah Almighty."
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs transition shadow-lg shadow-amber-500/20"
              >
                Log Fasting Day
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Quick Prayer Log */}
      {modalType === 'prayer' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-indigo-500/40 rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl relative text-center">
            <button
              type="button"
              onClick={() => setModalType(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200"
            >
              <X size={18} />
            </button>

            <div className="w-14 h-14 rounded-full bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 mx-auto">
              <CheckCircle2 size={28} />
            </div>

            <div>
              <h3 className="text-base font-serif font-bold text-slate-100">Log {currentPrayer} Prayer</h3>
              <p className="text-xs text-slate-400 mt-1">Mark today's {currentPrayer} prayer as completed on time.</p>
            </div>

            {prayerLogged ? (
              <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-2xl text-emerald-300 font-bold text-xs flex items-center justify-center gap-2">
                <CheckCircle2 size={16} />
                <span>{currentPrayer} Prayer Logged! May Allah accept it.</span>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleQuickPrayerLog}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs transition shadow-lg shadow-indigo-600/20"
              >
                Mark {currentPrayer} as Prayed
              </button>
            )}
          </div>
        </div>
      )}
    </>
  );
}
