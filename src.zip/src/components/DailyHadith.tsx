import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { 
  BookOpen, 
  Share2, 
  Copy, 
  Check, 
  RefreshCw, 
  Bookmark, 
  BookmarkCheck, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  ArrowRight,
  Compass,
  Calendar
} from 'lucide-react';
import { hadiths, HadithItem } from '../data/hadiths';
import { triggerHaptic } from '../lib/haptics';

const FAVORITES_STORAGE_KEY = 'noor_favorite_hadiths';

export default function DailyHadith() {
  // Deterministic daily index based on day of the year
  const scheduledIndex = useMemo(() => {
    const now = new Date();
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now.getTime() - start.getTime();
    const oneDay = 1000 * 60 * 60 * 24;
    const dayOfYear = Math.floor(diff / oneDay);
    return dayOfYear % hadiths.length;
  }, []);

  const [currentIndex, setCurrentIndex] = useState(scheduledIndex);
  const [copied, setCopied] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isRotating, setIsRotating] = useState(false);

  // Saved/Bookmarked Hadith IDs
  const [savedIds, setSavedIds] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem(FAVORITES_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const hadith = hadiths[currentIndex] || hadiths[0];
  const isScheduledToday = currentIndex === scheduledIndex;
  const isFavorited = savedIds.includes(hadith.id);

  // Save favorites to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(savedIds));
    } catch (e) {
      console.warn(e);
    }
  }, [savedIds]);

  // Clean up speech synthesis if component unmounts
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Shuffle random hadith
  const handleRandomize = () => {
    triggerHaptic(20);
    setIsRotating(true);
    setTimeout(() => setIsRotating(false), 500);

    let nextIdx = Math.floor(Math.random() * hadiths.length);
    if (nextIdx === currentIndex && hadiths.length > 1) {
      nextIdx = (nextIdx + 1) % hadiths.length;
    }
    setCurrentIndex(nextIdx);

    if (isPlayingAudio && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
    }
  };

  // Reset to today's scheduled Hadith
  const handleResetToToday = () => {
    triggerHaptic(15);
    setCurrentIndex(scheduledIndex);
  };

  // Toggle favorite
  const handleToggleFavorite = () => {
    triggerHaptic(15);
    setSavedIds(prev => 
      prev.includes(hadith.id) 
        ? prev.filter(id => id !== hadith.id) 
        : [...prev, hadith.id]
    );
  };

  // Copy Hadith
  const handleCopy = async () => {
    triggerHaptic(15);
    const content = `✨ Hadith of the Day\n\n"${hadith.arabic}"\n\n${hadith.narrator}:\n"${hadith.text}"\n\n📖 Reference: ${hadith.reference}\n\nShared via Noor`;
    try {
      await navigator.clipboard.writeText(content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.warn(err);
    }
  };

  // Native share
  const handleShare = async () => {
    triggerHaptic(15);
    const title = `Hadith of the Day: ${hadith.category}`;
    const text = `✨ Hadith of the Day\n\n"${hadith.arabic}"\n\n${hadith.narrator}:\n"${hadith.text}"\n\n📖 Reference: ${hadith.reference}\n\nShared via Noor`;
    if (navigator.share) {
      try {
        await navigator.share({
          title,
          text,
          url: window.location.origin
        });
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          handleCopy();
        }
      }
    } else {
      handleCopy();
    }
  };

  // Speech recitation
  const handleToggleAudio = () => {
    triggerHaptic(15);
    if (!('speechSynthesis' in window)) return;

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(hadith.text);
    utterance.rate = 0.95;
    utterance.pitch = 1.0;

    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    window.speechSynthesis.speak(utterance);
    setIsPlayingAudio(true);
  };

  return (
    <section 
      aria-label="Daily Hadith"
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-700/50 md:col-span-2 space-y-4"
    >
      {/* Decorative ambient flare */}
      <div 
        aria-hidden="true" 
        className="absolute -top-16 -right-16 w-48 h-48 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" 
      />

      {/* Top Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-amber-900/20">
        <div className="flex items-center gap-3">
          <span className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <BookOpen size={20} />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-100 tracking-tight">
                Daily Hadith
              </h3>
              {isScheduledToday ? (
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center gap-1">
                  <Calendar size={10} /> Today's Selection
                </span>
              ) : (
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20 flex items-center gap-1">
                  <Sparkles size={10} /> Inspired Random
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Prophetic wisdom and daily guidance from authentic traditions
            </p>
          </div>
        </div>

        {/* Action Buttons: Shuffle, Today, Bookmark, Copy, Share */}
        <div className="flex items-center gap-1.5 self-start sm:self-auto">
          {!isScheduledToday && (
            <button
              type="button"
              onClick={handleResetToToday}
              className="text-[11px] font-mono px-2.5 py-1 rounded-xl bg-slate-800 text-slate-300 hover:text-amber-400 border border-slate-700 transition-colors"
              title="Return to today's scheduled Hadith"
            >
              Today's Hadith
            </button>
          )}

          <button
            type="button"
            onClick={handleRandomize}
            className="flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-xl bg-slate-800/90 text-slate-300 hover:text-amber-400 border border-slate-700 hover:border-amber-500/40 transition-all active:scale-95"
            title="Random Hadith inspiration"
          >
            <RefreshCw size={13} className={`text-amber-500 transition-transform duration-500 ${isRotating ? 'rotate-180' : ''}`} />
            <span>Random</span>
          </button>

          <button
            type="button"
            onClick={handleToggleAudio}
            className={`p-1.5 rounded-xl border transition-colors ${
              isPlayingAudio 
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/40 animate-pulse' 
                : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border-slate-700'
            }`}
            title={isPlayingAudio ? 'Stop speech' : 'Listen to Hadith'}
          >
            {isPlayingAudio ? <VolumeX size={15} /> : <Volume2 size={15} />}
          </button>

          <button
            type="button"
            onClick={handleToggleFavorite}
            className={`p-1.5 rounded-xl border transition-colors ${
              isFavorited
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                : 'bg-slate-800/80 text-slate-400 hover:text-amber-400 border-slate-700'
            }`}
            title={isFavorited ? 'Remove from saved' : 'Bookmark Hadith'}
          >
            {isFavorited ? <BookmarkCheck size={15} className="fill-amber-400" /> : <Bookmark size={15} />}
          </button>

          <button
            type="button"
            onClick={handleCopy}
            className="p-1.5 rounded-xl bg-slate-800/80 text-slate-400 hover:text-slate-200 border border-slate-700 transition-colors"
            title="Copy Hadith"
          >
            {copied ? <Check size={15} className="text-emerald-400" /> : <Copy size={15} />}
          </button>

          <button
            type="button"
            onClick={handleShare}
            className="p-1.5 rounded-xl bg-slate-800/80 text-slate-400 hover:text-amber-400 border border-slate-700 transition-colors"
            title="Share Hadith"
          >
            <Share2 size={15} />
          </button>
        </div>
      </div>

      {/* Main Hadith Content Box */}
      <div className="space-y-4">
        {/* Category Pill & Narrator */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-400 border border-amber-500/20 font-semibold uppercase tracking-wider">
            {hadith.category}
          </span>
          <span className="text-xs text-slate-400 font-medium italic">
            {hadith.narrator}
          </span>
        </div>

        {/* Arabic Calligraphy Display */}
        {hadith.arabic && (
          <div className="p-4 bg-slate-950/70 border border-amber-900/30 rounded-xl shadow-inner">
            <p className="text-xl sm:text-2xl font-arabic text-amber-300 text-right leading-loose sm:leading-loose" dir="rtl">
              {hadith.arabic}
            </p>
          </div>
        )}

        {/* English Translation */}
        <div className="space-y-1">
          <p className="text-slate-200 text-sm sm:text-base font-medium leading-relaxed italic">
            "{hadith.text}"
          </p>
          <div className="flex items-center justify-between pt-1">
            <span className="text-xs font-mono text-amber-600/90 font-medium">
              📖 {hadith.reference}
            </span>
          </div>
        </div>

        {/* Daily Spiritual Takeaway / Practical Lesson */}
        {hadith.lesson && (
          <div className="p-3 bg-amber-950/20 border border-amber-500/20 rounded-xl flex items-start gap-2.5 text-xs text-slate-300">
            <Sparkles size={15} className="text-amber-400 flex-shrink-0 mt-0.5" />
            <div>
              <strong className="text-amber-300 block font-semibold">Today's Spiritual Action:</strong>
              <p className="text-slate-300 mt-0.5">{hadith.lesson}</p>
            </div>
          </div>
        )}
      </div>

      {/* Footer Link to Full Hadith Library */}
      <div className="pt-2 border-t border-amber-900/20 flex items-center justify-between text-xs">
        <span className="text-slate-500 text-[11px] font-mono">
          Hadith #{hadith.id} of {hadiths.length} in collection
        </span>
        <Link 
          to="/hadith" 
          onClick={() => triggerHaptic(10)}
          className="text-amber-500 hover:text-amber-400 font-semibold flex items-center gap-1 transition-colors"
        >
          <span>Explore All Hadiths</span>
          <ArrowRight size={13} />
        </Link>
      </div>
    </section>
  );
}
