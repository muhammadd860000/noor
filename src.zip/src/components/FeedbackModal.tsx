import React, { useState, useEffect } from 'react';
import { 
  MessageSquarePlus, 
  Bug, 
  Lightbulb, 
  BookOpen, 
  Heart, 
  Send, 
  X, 
  CheckCircle2, 
  Clock, 
  Trash2,
  HelpCircle,
  Star
} from 'lucide-react';
import { triggerHaptic } from '../lib/haptics';

export type FeedbackCategory = 'bug' | 'feature' | 'content_correction' | 'general';

export interface FeedbackSubmission {
  id: string;
  category: FeedbackCategory;
  title: string;
  description: string;
  email?: string;
  rating?: number;
  timestamp: string;
  deviceInfo?: string;
  status: 'received' | 'reviewed';
}

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultCategory?: FeedbackCategory;
}

const STORAGE_KEY = 'noor_user_feedback_history';

export default function FeedbackModal({ isOpen, onClose, defaultCategory = 'bug' }: FeedbackModalProps) {
  const [category, setCategory] = useState<FeedbackCategory>(defaultCategory);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [email, setEmail] = useState('');
  const [rating, setRating] = useState<number>(5);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'form' | 'history'>('form');
  const [feedbackHistory, setFeedbackHistory] = useState<FeedbackSubmission[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    if (isOpen) {
      setCategory(defaultCategory);
      setIsSuccess(false);
    }
  }, [isOpen, defaultCategory]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    triggerHaptic(25);
    setIsSubmitting(true);

    const newFeedback: FeedbackSubmission = {
      id: `fb_${Date.now()}`,
      category,
      title: title.trim(),
      description: description.trim(),
      email: email.trim() || undefined,
      rating,
      timestamp: new Date().toISOString(),
      deviceInfo: `${navigator.userAgent.slice(0, 80)}...`,
      status: 'received'
    };

    setTimeout(() => {
      const updated = [newFeedback, ...feedbackHistory];
      setFeedbackHistory(updated);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch (err) {
        console.warn('Failed to save feedback history:', err);
      }

      setIsSubmitting(false);
      setIsSuccess(true);
      setTitle('');
      setDescription('');
      setEmail('');
    }, 600);
  };

  const handleDeleteHistoryItem = (id: string) => {
    triggerHaptic(15);
    const updated = feedbackHistory.filter(item => item.id !== id);
    setFeedbackHistory(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  const getCategoryDetails = (cat: FeedbackCategory) => {
    switch (cat) {
      case 'bug':
        return {
          label: 'Bug Report / خرابی کی اطلاع',
          icon: Bug,
          color: 'text-rose-400',
          bg: 'bg-rose-500/10 border-rose-500/30'
        };
      case 'feature':
        return {
          label: 'Feature Request / نئی تجویز',
          icon: Lightbulb,
          color: 'text-amber-400',
          bg: 'bg-amber-500/10 border-amber-500/30'
        };
      case 'content_correction':
        return {
          label: 'Content Correction / متن کی تصحیح',
          icon: BookOpen,
          color: 'text-emerald-400',
          bg: 'bg-emerald-500/10 border-emerald-500/30'
        };
      case 'general':
      default:
        return {
          label: 'General Feedback / عمومی رائے',
          icon: Heart,
          color: 'text-sky-400',
          bg: 'bg-sky-500/10 border-sky-500/30'
        };
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div 
        className="bg-slate-900 border border-amber-500/30 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <MessageSquarePlus size={20} />
            </div>
            <div>
              <h3 className="font-semibold text-slate-100 text-lg">Send Feedback</h3>
              <p className="text-xs text-slate-400">رائے یا خرابی کی اطلاع بھیجیں</p>
            </div>
          </div>
          <button
            onClick={() => {
              triggerHaptic(10);
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition"
            aria-label="Close modal"
          >
            <X size={20} />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-900/50 px-6 pt-2">
          <button
            onClick={() => {
              triggerHaptic(10);
              setActiveTab('form');
              setIsSuccess(false);
            }}
            className={`pb-2 px-3 text-sm font-medium transition border-b-2 ${
              activeTab === 'form'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Submit Feedback
          </button>
          <button
            onClick={() => {
              triggerHaptic(10);
              setActiveTab('history');
            }}
            className={`pb-2 px-3 text-sm font-medium transition border-b-2 flex items-center gap-1.5 ${
              activeTab === 'history'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            My Submissions
            {feedbackHistory.length > 0 && (
              <span className="text-xs px-1.5 py-0.2 rounded-full bg-slate-800 text-amber-400 border border-amber-500/30">
                {feedbackHistory.length}
              </span>
            )}
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-grow">
          {activeTab === 'form' ? (
            isSuccess ? (
              <div className="text-center py-8 space-y-4">
                <div className="inline-flex items-center justify-center p-3 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 animate-bounce">
                  <CheckCircle2 size={40} />
                </div>
                <div className="space-y-1">
                  <h4 className="text-xl font-bold text-slate-100 font-serif">جزاك الله خيراً</h4>
                  <p className="text-sm text-emerald-400">Thank you! Your feedback has been recorded.</p>
                  <p className="text-xs text-slate-400 max-w-xs mx-auto pt-2">
                    آپ کی رائے اور رپورٹ محفوظ ہو چکی ہے۔ ہم جلد اس پر کام کریں گے۔
                  </p>
                </div>
                <div className="pt-4 flex justify-center gap-3">
                  <button
                    onClick={() => setIsSuccess(false)}
                    className="px-4 py-2 text-sm bg-slate-800 text-slate-200 rounded-xl hover:bg-slate-700 transition"
                  >
                    Submit Another
                  </button>
                  <button
                    onClick={onClose}
                    className="px-5 py-2 text-sm bg-amber-500 text-slate-950 font-bold rounded-xl hover:bg-amber-400 transition"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Category Selection */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-2">
                    Feedback Type / زمرہ
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {(['bug', 'feature', 'content_correction', 'general'] as FeedbackCategory[]).map((cat) => {
                      const details = getCategoryDetails(cat);
                      const Icon = details.icon;
                      const isSelected = category === cat;

                      return (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => {
                            triggerHaptic(10);
                            setCategory(cat);
                          }}
                          className={`p-2.5 rounded-xl border text-left flex items-start gap-2.5 transition ${
                            isSelected
                              ? 'bg-amber-500/20 border-amber-500/50 text-amber-200'
                              : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-300'
                          }`}
                        >
                          <Icon size={16} className={`mt-0.5 shrink-0 ${isSelected ? 'text-amber-400' : details.color}`} />
                          <div className="text-xs font-medium leading-tight">
                            {cat === 'bug' && 'Bug Report'}
                            {cat === 'feature' && 'Feature Request'}
                            {cat === 'content_correction' && 'Correction'}
                            {cat === 'general' && 'General'}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Rating (Optional) */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Experience Rating / تجربہ کا درجہ
                  </label>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => {
                          triggerHaptic(10);
                          setRating(star);
                        }}
                        className="p-1 hover:scale-110 transition text-amber-400 focus:outline-none"
                      >
                        <Star
                          size={20}
                          className={star <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-600'}
                        />
                      </button>
                    ))}
                    <span className="text-xs text-slate-400 ml-2 font-mono">
                      {rating === 5 ? '⭐⭐⭐⭐⭐ Excellent' : `${rating}/5 Stars`}
                    </span>
                  </div>
                </div>

                {/* Title */}
                <div>
                  <label htmlFor="fb-title" className="block text-xs font-semibold text-slate-300 mb-1">
                    Title / عنوان <span className="text-rose-400">*</span>
                  </label>
                  <input
                    id="fb-title"
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder={
                      category === 'bug'
                        ? 'e.g., Audio stopped playing on Surah Al-Mulk'
                        : category === 'feature'
                        ? 'e.g., Add Urdu Audio Tafseer support'
                        : 'e.g., Typo in Ayah 4 translation'
                    }
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                {/* Description */}
                <div>
                  <label htmlFor="fb-desc" className="block text-xs font-semibold text-slate-300 mb-1">
                    Details / تفصیلات <span className="text-rose-400">*</span>
                  </label>
                  <textarea
                    id="fb-desc"
                    required
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Please explain the issue or your suggestion in detail..."
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                {/* Email (Optional) */}
                <div>
                  <label htmlFor="fb-email" className="block text-xs font-semibold text-slate-300 mb-1">
                    Email for Follow-up (Optional) / ای میل
                  </label>
                  <input
                    id="fb-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 text-sm text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-xl transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting || !title.trim() || !description.trim()}
                    className="flex items-center gap-2 px-5 py-2 bg-amber-500 text-slate-950 font-bold text-sm rounded-xl hover:bg-amber-400 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-amber-500/20"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <Clock className="animate-spin" size={16} /> Submitting...
                      </span>
                    ) : (
                      <>
                        <Send size={16} /> Submit Feedback
                      </>
                    )}
                  </button>
                </div>
              </form>
            )
          ) : (
            /* Submissions History */
            <div className="space-y-3">
              {feedbackHistory.length === 0 ? (
                <div className="text-center py-10 space-y-2">
                  <HelpCircle className="mx-auto text-slate-600" size={36} />
                  <p className="text-sm text-slate-400">No previous feedback submitted yet.</p>
                  <button
                    onClick={() => setActiveTab('form')}
                    className="text-xs text-amber-400 hover:underline"
                  >
                    Click here to send feedback
                  </button>
                </div>
              ) : (
                feedbackHistory.map((item) => {
                  const details = getCategoryDetails(item.category);
                  const Icon = details.icon;

                  return (
                    <div
                      key={item.id}
                      className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-2 relative group"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className={`p-1 rounded-md ${details.bg} ${details.color}`}>
                            <Icon size={14} />
                          </span>
                          <h5 className="font-semibold text-sm text-slate-200">{item.title}</h5>
                        </div>
                        <button
                          onClick={() => handleDeleteHistoryItem(item.id)}
                          className="text-slate-500 hover:text-rose-400 p-1 opacity-60 hover:opacity-100 transition"
                          title="Delete from history"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>

                      <p className="text-xs text-slate-400 line-clamp-3">{item.description}</p>

                      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-900">
                        <span>{new Date(item.timestamp).toLocaleDateString()}</span>
                        <span className="inline-flex items-center gap-1 text-emerald-400">
                          <CheckCircle2 size={12} /> Received
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
