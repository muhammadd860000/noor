import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Clock, Check, Download, RefreshCw, Flame, Moon, Sparkles, SlidersHorizontal, Calendar as CalendarIcon, MessageSquare, ArrowRight } from 'lucide-react';
import jsPDF from 'jspdf';
import { triggerHaptic, triggerButtonClickHaptic } from '../lib/haptics';
import { calculateHijriDate, getStoredHijriOffset, setStoredHijriOffset } from '../lib/hijri';
import { reflections } from '../data/reflections';
import { duas } from '../data/dua_content';
import { PWAInstallButton } from './PWAInstallButton.tsx';
import { usePrayerNotifications } from '../hooks/usePrayerNotifications';
import PrayerTracker from './PrayerTracker.tsx';
import PrayerGoals from './PrayerGoals.tsx';
import QuranGoalTracker from './QuranGoalTracker.tsx';
import DailyHadith from './DailyHadith.tsx';
import DailyHadithQuiz from './DailyHadithQuiz.tsx';
import DailyQuizHomeWidget from './DailyQuizHomeWidget.tsx';
import SpiritualAchievements from './SpiritualAchievements.tsx';
import DailyAyah from './DailyAyah.tsx';
import DailyReflection from './DailyReflection.tsx';
import DailyDhikr from './DailyDhikr.tsx';
import DailyDuaWidget from './DailyDuaWidget.tsx';
import DailyDuaCard from './DailyDuaCard.tsx';
import DailyQuranQuizWidget from './DailyQuranQuizWidget.tsx';
import Affirmations from './Affirmations.tsx';
import DailySpiritualHabits from './DailySpiritualHabits.tsx';
import SpiritualJournaling from './SpiritualJournaling.tsx';
import LunarCalendar from './LunarCalendar.tsx';
import MonthlyIslamicPlanner from './MonthlyIslamicPlanner.tsx';
import HajjUmrahGuide from './HajjUmrahGuide.tsx';
import ZakatWidget from './ZakatWidget.tsx';
import SadaqahGoalTracker from './SadaqahGoalTracker.tsx';
import PrayerTimesProgress from './PrayerTimesProgress.tsx';
import QiblaWidget from './QiblaWidget.tsx';
import DailyGoals from './DailyGoals.tsx';
import WeeklyConsistency from './WeeklyConsistency.tsx';
import DailyHadithReflection from './DailyHadithReflection.tsx';
import QuranRecitationChallenge from './QuranRecitationChallenge.tsx';
import QuickActionsFAB from './QuickActionsFAB.tsx';
import { usePrayerTimes } from '../hooks/usePrayerTimes';

interface Habit {
  name: string;
  history: boolean[];
}

export default function Home() {
  const { nextPrayer, times } = usePrayerTimes();
  const [notifications] = useState(() => {
    const saved = localStorage.getItem('prayerNotificationPreferences');
    return saved ? JSON.parse(saved) : { Fajr: false, Sunrise: false, Dhuhr: false, Asr: false, Maghrib: false, Isha: false };
  });
  usePrayerNotifications(times, notifications);
  const displayName = "User";
  const [duaOfTheDay] = useState(() => {
    const dayOfYear = Math.floor((new Date().getTime() - new Date(new Date().getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24));
    return duas[dayOfYear % duas.length];
  });
  
  const [streak, setStreak] = useState(0);
  
  const [lastReadSurah] = useState(() => {
    const saved = localStorage.getItem('lastReadSurah');
    return saved ? JSON.parse(saved) : null;
  });

  const [recentRead] = useState(() => {
      const saved = localStorage.getItem('recentRead');
      return saved ? JSON.parse(saved) : [];
  });

  // Hijri Date Calculation & Sighting Offset State
  const [hijriOffset, setHijriOffset] = useState<number>(() => getStoredHijriOffset());
  const [showSightingAdjuster, setShowSightingAdjuster] = useState(false);

  const hijriDate = calculateHijriDate(new Date(), hijriOffset);
  const gregorianFormatted = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });

  const handleAdjustOffset = (val: number) => {
    triggerHaptic(15);
    setHijriOffset(val);
    setStoredHijriOffset(val);
  };

  useEffect(() => {
    const lastInteraction = localStorage.getItem('lastInteractionDate');
    const currentStreak = parseInt(localStorage.getItem('streak') || '0');
    const today = new Date().toDateString();

    if (lastInteraction !== today) {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        
        if (lastInteraction === yesterday.toDateString()) {
            setStreak(currentStreak + 1);
            localStorage.setItem('streak', (currentStreak + 1).toString());
        } else if (lastInteraction !== today) {
            setStreak(1);
            localStorage.setItem('streak', '1');
        }
        localStorage.setItem('lastInteractionDate', today);
    } else {
        setStreak(currentStreak);
    }
  }, []);

  const exportReport = () => {
    const doc = new jsPDF();
    doc.text("NOOR Daily Progress Report", 10, 10);
    doc.text(`User: ${displayName}`, 10, 20);
    doc.save("noor-progress-report.pdf");
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center">
        <div>
            <h1 className="text-2xl text-amber-500 font-serif">Assalamu Alaikum, {displayName}</h1>
            <div className="flex items-center gap-1 text-amber-600 mt-1">
                <Flame size={16} />
                <span className="text-sm font-semibold">{streak} Day Streak</span>
            </div>
        </div>
        <div className="flex gap-2">
            <PWAInstallButton />
            <button onClick={exportReport} className="text-amber-500 hover:text-amber-400">
                <Download size={24} />
            </button>
        </div>
      </header>

      {/* Hijri Date Centerpiece & Islamic Calendar Banner */}
      <section 
        aria-label="Current Islamic Hijri Date"
        className="bg-gradient-to-r from-amber-950/40 via-slate-900 to-amber-950/30 border border-amber-900/40 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20 mt-0.5">
              <Moon size={22} className="text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-mono font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1">
                  <Sparkles size={12} /> Islamic Lunar Date
                </span>
                {hijriDate.isSacred && (
                  <span className="text-[10px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded-full">
                    Sacred Month ({hijriDate.monthName})
                  </span>
                )}
                {hijriDate.isFriday && (
                  <span className="text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full">
                    Jumu'ah Mubarak
                  </span>
                )}
                {hijriDate.isWhiteDay && (
                  <span className="text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 px-2 py-0.5 rounded-full">
                    White Days Fasting (13-15)
                  </span>
                )}
                {hijriDate.upcomingOrCurrentEvent && (
                  <span className="text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded-full">
                    {hijriDate.upcomingOrCurrentEvent.title}
                  </span>
                )}
              </div>

              <div className="mt-1 flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-3">
                <h2 className="text-xl sm:text-2xl font-serif font-bold text-amber-100 tracking-tight">
                  {hijriDate.formattedEn}
                </h2>
                <span className="text-base sm:text-lg font-serif text-amber-400/90" dir="rtl">
                  {hijriDate.formattedAr}
                </span>
              </div>

              <p className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
                <CalendarIcon size={12} className="text-slate-500" />
                <span>{gregorianFormatted}</span>
                {hijriOffset !== 0 && (
                  <span className="text-amber-500/80 font-mono text-[11px]">
                    ({hijriOffset > 0 ? `+${hijriOffset}` : hijriOffset}d local offset)
                  </span>
                )}
              </p>
            </div>
          </div>

          {/* Sighting Calibrator Toggle */}
          <div className="flex items-center gap-2 self-start sm:self-center">
            <button
              type="button"
              onClick={() => {
                triggerHaptic(10);
                setShowSightingAdjuster(!showSightingAdjuster);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition active:scale-95 ${
                showSightingAdjuster || hijriOffset !== 0
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm'
                  : 'bg-slate-900/80 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
              title="Calibrate date for local moon sighting (-2 to +2 days)"
            >
              <SlidersHorizontal size={13} />
              <span>{hijriOffset !== 0 ? `Offset: ${hijriOffset > 0 ? `+${hijriOffset}` : hijriOffset}d` : 'Adjust Sighting'}</span>
            </button>
          </div>
        </div>

        {/* Expandable Moon Sighting Adjustment Bar */}
        {showSightingAdjuster && (
          <div className="mt-4 pt-3 border-t border-amber-900/30 flex flex-wrap items-center justify-between gap-3 text-xs animate-fadeIn">
            <div className="text-slate-400">
              <span className="font-semibold text-amber-400">Moon Sighting Calibration: </span>
              <span>Align with your local Islamic authority or physical moon sighting:</span>
            </div>
            <div className="flex items-center gap-1.5">
              {[-2, -1, 0, 1, 2].map(offset => (
                <button
                  key={offset}
                  type="button"
                  onClick={() => handleAdjustOffset(offset)}
                  className={`px-2.5 py-1 rounded-lg font-mono text-xs transition ${
                    hijriOffset === offset
                      ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                      : 'bg-slate-950 border border-slate-800 text-slate-300 hover:border-amber-500/40'
                  }`}
                >
                  {offset === 0 ? 'Default' : offset > 0 ? `+${offset}d` : `${offset}d`}
                </button>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Daily Ayah Centerpiece */}
      <DailyAyah />

      {/* Daily Islamic Affirmations Centerpiece */}
      <Affirmations />

      {/* Daily Dhikr Centerpiece */}
      <DailyDhikr />

      {/* Daily Dua Widget */}
      <DailyDuaWidget />

      {/* Interactive Daily Dua Curated Supplication Card */}
      <DailyDuaCard />

      {/* Daily Quran & Islamic Verse Quiz Widget */}
      <DailyQuranQuizWidget />

      {/* Main Dashboard Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Daily Spiritual Goals Centerpiece */}
        <DailyGoals />

        {/* Lunar Calendar & Islamic Date Tracker */}
        <LunarCalendar />

        {/* Monthly Islamic Planner */}
        <MonthlyIslamicPlanner />

        {/* Daily Spiritual Habits & Calendar Streak */}
        <DailySpiritualHabits />

        {/* Spiritual Journaling & Intentions */}
        <SpiritualJournaling />

        {/* Hajj & Umrah Pilgrim Companion Guide */}
        <HajjUmrahGuide />

        <DailyReflection />
        <PrayerTimesProgress />
        <PrayerTracker />
        <PrayerGoals />
        <SadaqahGoalTracker />
        <ZakatWidget />
        <QuranGoalTracker />
        <QiblaWidget />
        <DailyHadith />
        <DailyHadithQuiz />
        <DailyQuizHomeWidget />

        {/* Spiritual Badges & Achievements Dashboard */}
        <SpiritualAchievements />

        {/* Community Forum Discussion Card */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/40 rounded-2xl p-5 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <MessageSquare size={20} />
              </div>
              <div>
                <h3 className="text-base font-serif font-bold text-slate-100">Ummah Community Forum</h3>
                <p className="text-xs text-slate-400">Ask Islamic questions, share Quran reflections & request Duas</p>
              </div>
            </div>
          </div>
          <Link
            to="/forum"
            onClick={() => triggerButtonClickHaptic()}
            className="w-full py-2.5 px-4 bg-slate-950 hover:bg-slate-900 text-amber-300 border border-amber-500/30 font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-2"
          >
            <span>Visit Community Message Board</span>
            <ArrowRight size={15} />
          </Link>
        </div>

        <WeeklyConsistency />

        {/* Continue Quran Card */}
        {lastReadSurah && (
          <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 shadow-lg md:col-span-2">
            <div className="flex justify-between items-center mb-2">
              <span className="text-amber-600 flex items-center gap-2"><BookOpen size={18}/> Continue Reading</span>
            </div>
            <p className="text-slate-200">{lastReadSurah.name}</p>
            <Link to={`/quran/${lastReadSurah.id}`} className="mt-3 block text-center bg-amber-600 text-slate-950 font-bold py-2 px-4 rounded-lg w-full">Continue Reading</Link>
          </div>
        )}

        {/* Recently Read */}
        {recentRead.length > 0 && (
            <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 shadow-lg md:col-span-2">
                <h3 className="text-amber-600 font-semibold mb-3">Recently Read</h3>
                <div className="flex gap-2 overflow-x-auto pb-2">
                    {recentRead.map((surah: any) => (
                        <Link key={surah.id} to={`/quran/${surah.id}`} className="bg-slate-800 text-slate-200 px-3 py-1 rounded-full text-sm whitespace-nowrap border border-amber-900/30 hover:border-amber-600 transition">
                            {surah.name}
                        </Link>
                    ))}
                </div>
            </div>
        )}

        {/* Dua of the Day */}
        <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 shadow-lg md:col-span-2">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-amber-600 font-semibold">Dua of the Day</h3>
              <Link to="/duas" className="text-xs text-amber-500 hover:text-amber-400 font-semibold">
                Du'a Library →
              </Link>
            </div>
            <p className="text-2xl text-slate-100 text-right font-arabic mb-3">
                {duaOfTheDay.arabic}
            </p>
            <p className="text-slate-200 font-semibold mb-1">{duaOfTheDay.title}</p>
            <p className="text-slate-400 text-sm">"{duaOfTheDay.meaning}"</p>
        </div>
      </div>

      {/* Daily Hadith Reflection & Quran Recitation Challenge */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <DailyHadithReflection />
        <QuranRecitationChallenge />
      </div>

      {/* Quick Actions */}
      <section>
        <h3 className="text-amber-500 font-serif text-lg mb-4">Quick Actions</h3>
        <div className="grid grid-cols-3 gap-3">
            {[
              {name: 'Quran', path: '/quran'},
              {name: 'Prayer', path: '/prayer'},
              {name: 'Ramadan', path: '/ramadan'},
              {name: 'Affirmations', path: '/affirmations'},
              {name: 'Reflections', path: '/reflections'},
              {name: 'Duas', path: '/duas'},
              {name: 'Zakat', path: '/zakat'},
              {name: 'Hadith', path: '/hadith'},
              {name: 'Tasbeeh', path: '/tasbeeh'},
              {name: 'Quiz', path: '/quiz'}
            ].map(action => (
                <Link key={action.name} to={action.path} className="bg-slate-900 border border-amber-900/30 rounded-xl p-4 flex flex-col items-center gap-2 text-amber-600 hover:border-amber-600 transition">
                    <BookOpen size={24}/>
                    <span className="text-sm text-slate-200">{action.name}</span>
                </Link>
            ))}
        </div>
      </section>

      {/* Floating Action Speed Dial for Quick Tasks */}
      <QuickActionsFAB />
    </div>
  );
}
