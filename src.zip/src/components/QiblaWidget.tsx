import React, { useState, useEffect } from 'react';
import { Compass } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function QiblaWidget() {
  const [direction, setDirection] = useState<number | null>(null);

  useEffect(() => {
    const handleOrientation = (event: any) => {
      const heading = event.webkitCompassHeading || event.alpha;
      if (heading !== null) setDirection(heading);
    };

    window.addEventListener('deviceorientation', handleOrientation);
    return () => window.removeEventListener('deviceorientation', handleOrientation);
  }, []);

  return (
    <Link to="/qibla" className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 shadow-lg flex flex-col items-center justify-center text-center">
      <div className="w-16 h-16 border-2 border-amber-600 rounded-full flex items-center justify-center mb-3 transition-transform duration-300"
           style={{ transform: `rotate(${direction ? -direction : 0}deg)` }}>
        <Compass size={32} className="text-amber-500" />
      </div>
      <h3 className="text-amber-500 font-semibold text-sm">Qibla Direction</h3>
      <p className="text-slate-400 text-xs mt-1">Click to view</p>
    </Link>
  );
}
