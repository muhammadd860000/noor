import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Check, CheckCircle2, Clock, Sparkles, Award, RotateCcw } from 'lucide-react';
import { getFromDB, saveToDB } from '../lib/db';
import { triggerHaptic } from '../lib/haptics';

export interface DailyPrayerProgressProps {
  times?: Record<string, string> | null;
  onPrayerToggled?: (prayerName: string, isCompleted: boolean) => void;
}

const OBLIGATORY_PRAYERS = [
  { name: 'Fajr', arabic: 'الفجر', description: 'Dawn' },
  { name: 'Dhuhr', arabic: 'الظهر', description: 'Noon' },
  { name: 'Asr', arabic: 'العصر', description: 'Afternoon' },
  { name: 'Maghrib', arabic: 'المغرب', description: 'Sunset' },
  { name: 'Isha', arabic: 'العشاء', description: 'Night' }
];

export default function DailyPrayerProgress({ times, onPrayerToggled }: DailyPrayerProgressProps) {
  const today = useMemo(() => new Date().toDateString(), []);
  const todayFormatted = useMemo(() => {
    return new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'short',
      day: 'numeric'
    });
  }, []);

  // Synchronous cache for instant rendering without flash
  const [completedPrayers, setCompletedPrayers] = useState<Record<string, boolean>>(() => {
    try {
      const cached = localStorage.getItem(`dailyPrayers_${today}`);
      return cached ? JSON.parse(cached) : {};
    } catch {
      return {};
    }
  });

  const [loading, setLoading] = useState(true);

  // Load from IndexedDB on mount & sync
  useEffect(() => {
    let isMounted = true;
    const loadPrayers = async () => {
      try {
        const saved = await getFromDB('prayer', today);
        if (saved && saved.prayers && isMounted) {
          setCompletedPrayers(saved.prayers);
          localStorage.setItem(`dailyPrayers_${today}`, JSON.stringify(saved.prayers));
        }
      } catch (err) {
        console.warn('[DailyPrayerProgress] Error loading prayer state from DB:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    loadPrayers();

    // Listen for custom sync events across components
    const handleSync = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail && customEvent.detail.prayers) {
        setCompletedPrayers(customEvent.detail.prayers);
      }
    };

    window.addEventListener('prayer-status-changed', handleSync);
    return () => {
      isMounted = false;
      window.removeEventListener('prayer-status-changed', handleSync);
    };
  }, [today]);

  // Determine current/next prayer based on times
  const nextPrayerName = useMemo(() => {
    if (!times) return null;
    const now = new Date();
    const currentMinutes = now.getHours() * 60 + now.getMinutes();

    for (const prayer of OBLIGATORY_PRAYERS) {
      const timeStr = times[prayer.name];
      if (timeStr) {
        const [h, m] = timeStr.split(':').map(Number);
        if (h * 60 + m > currentMinutes) {
          return prayer.name;
        }
      }
    }
    return OBLIGATORY_PRAYERS[0].name; // Roll over to Fajr next day
  }, [times]);

  // Toggle prayer completion
  const handleTogglePrayer = useCallback(async (prayerName: string) => {
    triggerHaptic(25);
    const isCurrentlyDone = !!completedPrayers[prayerName];
    const updated = {
      ...completedPrayers,
      [prayerName]: !isCurrentlyDone
    };

    setCompletedPrayers(updated);
    localStorage.setItem(`dailyPrayers_${today}`, JSON.stringify(updated));

    // Save to IndexedDB
    try {
      await saveToDB('prayer', { date: today, prayers: updated });

      // If marked as completed, record history entry
      if (!isCurrentlyDone) {
        const history = (await getFromDB('prayer', 'history')) || [];
        const historyList = Array.isArray(history) ? history : (history.history || []);
        await saveToDB('prayer', {
          date: 'history',
          history: [...historyList, { prayer: prayerName, timestamp: new Date().toISOString() }]
        });
      }
    } catch (err) {
      console.warn('[DailyPrayerProgress] Error saving prayer to DB:', err);
    }

    // Broadcast change
    window.dispatchEvent(
      new CustomEvent('prayer-status-changed', {
        detail: { date: today, prayers: updated, prayer: prayerName, completed: !isCurrentlyDone }
      })
    );

    if (onPrayerToggled) {
      onPrayerToggled(prayerName, !isCurrentlyDone);
    }

    // Special celebratory haptic if all 5 completed
    const countAfter = Object.values(updated).filter(Boolean).length;
    if (countAfter === 5) {
      triggerHaptic(60);
    }
  }, [completedPrayers, today, onPrayerToggled]);

  // Reset all for the day
  const handleResetDay = async () => {
    triggerHaptic(30);
    const resetState: Record<string, boolean> = {
      Fajr: false,
      Dhuhr: false,
      Asr: false,
      Maghrib: false,
      Isha: false
    };
    setCompletedPrayers(resetState);
    localStorage.setItem(`dailyPrayers_${today}`, JSON.stringify(resetState));
    try {
      await saveToDB('prayer', { date: today, prayers: resetState });
    } catch (e) {
      console.warn(e);
    }
    window.dispatchEvent(
      new CustomEvent('prayer-status-changed', {
        detail: { date: today, prayers: resetState }
      })
    );
  };

  const completedCount = OBLIGATORY_PRAYERS.filter(p => !!completedPrayers[p.name]).length;
  const totalCount = OBLIGATORY_PRAYERS.length;
  const progressPercent = Math.round((completedCount / totalCount) * 100);
  const isAllCompleted = completedCount === totalCount;

  // Circular progress calculations
  const strokeRadius = 40;
  const circumference = 2 * Math.PI * strokeRadius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <section 
      aria-label="Daily Prayer Progress" 
      className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden transition-all duration-300 hover:border-amber-700/50"
    >
      {/* Decorative ambient background glows */}
      <div 
        aria-hidden="true" 
        className="absolute -top-16 -right-16 w-44 h-44 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none" 
      />
      <div 
        aria-hidden="true" 
        className="absolute -bottom-16 -left-16 w-44 h-44 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" 
      />

      {/* Header Bar */}
      <div className="flex items-center justify-between pb-4 border-b border-amber-900/20">
        <div className="flex items-center gap-2.5">
          <span className={`p-2 rounded-xl transition-colors ${
            isAllCompleted ? 'bg-emerald-500/15 text-emerald-400' : 'bg-amber-500/10 text-amber-500'
          }`}>
            {isAllCompleted ? <Award size={20} /> : <CheckCircle2 size={20} />}
          </span>
          <div>
            <h3 className="text-sm font-semibold tracking-wide uppercase text-amber-500 flex items-center gap-2">
              Prayer Progress
              <span className={`inline-block w-2 h-2 rounded-full ${isAllCompleted ? 'bg-emerald-400' : 'bg-amber-500/80'}`} />
            </h3>
            <p className="text-xs text-slate-400">
              {todayFormatted} · Daily Obligatory (Fard)
            </p>
          </div>
        </div>

        {/* Counter Badge */}
        <div className="flex items-center gap-2">
          {completedCount > 0 && (
            <button
              type="button"
              onClick={handleResetDay}
              className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800/80 transition-colors"
              title="Reset day's progress"
              aria-label="Reset today's prayer progress"
            >
              <RotateCcw size={14} />
            </button>
          )}

          <div className={`px-3 py-1 rounded-xl text-xs font-mono font-semibold border ${
            isAllCompleted 
              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
              : 'bg-slate-800 text-slate-200 border-amber-900/40'
          }`}>
            <span className="text-amber-400 font-bold">{completedCount}</span> / {totalCount} Completed
          </div>
        </div>
      </div>

      {/* Main Visual Progress Overview: Radial Dial & Segmented Stepper */}
      <div className="py-5 grid grid-cols-1 sm:grid-cols-12 gap-5 items-center">
        {/* Left: Circular Progress Gauge */}
        <div className="sm:col-span-4 flex flex-col items-center justify-center">
          <div className="relative w-28 h-28 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 96 96">
              {/* Background ring */}
              <circle
                cx="48"
                cy="48"
                r={strokeRadius}
                fill="transparent"
                stroke="currentColor"
                strokeWidth="7"
                className="text-slate-800/80"
              />
              {/* Animated Progress ring */}
              <circle
                cx="48"
                cy="48"
                r={strokeRadius}
                fill="transparent"
                stroke="currentColor"
                strokeWidth="7"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                className={`transition-all duration-500 ease-out ${
                  isAllCompleted ? 'text-emerald-400' : 'text-amber-500'
                }`}
              />
            </svg>

            {/* Inner text details */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-2xl font-mono font-bold text-slate-100">
                {progressPercent}%
              </span>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-medium">
                {completedCount === 5 ? 'All Offered' : `${5 - completedCount} left`}
              </span>
            </div>
          </div>

          <p className="text-xs text-center text-slate-400 mt-2 font-medium">
            {isAllCompleted ? (
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <Sparkles size={13} /> All 5 Prayers Completed!
              </span>
            ) : (
              <span>Tap a prayer to mark offered</span>
            )}
          </p>
        </div>

        {/* Right: 5-Segmented Multi-Step Timeline */}
        <div className="sm:col-span-8 space-y-3">
          {/* Segmented Progress Bar */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs text-slate-400 font-medium">
              <span>Today's Journey</span>
              <span className="font-mono text-amber-400 font-semibold">{completedCount} of 5 Prayers</span>
            </div>

            {/* 5 Distinct Pill Segments */}
            <div className="grid grid-cols-5 gap-1.5 h-2.5">
              {OBLIGATORY_PRAYERS.map((p, idx) => {
                const done = !!completedPrayers[p.name];
                return (
                  <div
                    key={p.name}
                    className={`rounded-full transition-all duration-300 ${
                      done 
                        ? 'bg-gradient-to-r from-amber-500 to-amber-400 shadow-sm shadow-amber-500/30' 
                        : 'bg-slate-800'
                    }`}
                    title={`${p.name}: ${done ? 'Completed' : 'Pending'}`}
                  />
                );
              })}
            </div>
          </div>

          {/* Individual Prayer Badges / Check buttons */}
          <div className="grid grid-cols-5 gap-1.5 sm:gap-2 pt-2">
            {OBLIGATORY_PRAYERS.map((prayer) => {
              const isDone = !!completedPrayers[prayer.name];
              const isNext = nextPrayerName === prayer.name && !isDone;
              const prayerTime = times ? times[prayer.name] : null;

              return (
                <button
                  key={prayer.name}
                  type="button"
                  onClick={() => handleTogglePrayer(prayer.name)}
                  aria-pressed={isDone}
                  aria-label={`Mark ${prayer.name} as ${isDone ? 'incomplete' : 'completed'}`}
                  className={`group relative flex flex-col items-center justify-between p-2 sm:p-2.5 rounded-xl border transition-all duration-200 active:scale-95 text-center ${
                    isDone 
                      ? 'bg-amber-600/15 border-amber-500/50 text-amber-200' 
                      : isNext 
                        ? 'bg-slate-800/80 border-amber-500/40 text-slate-200 ring-1 ring-amber-500/30' 
                        : 'bg-slate-950/60 hover:bg-slate-800/60 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {/* Status Indicator Icon */}
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors mb-1.5 ${
                    isDone 
                      ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20' 
                      : isNext 
                        ? 'border-2 border-amber-400 text-amber-400' 
                        : 'border border-slate-600 text-transparent'
                  }`}>
                    {isDone ? (
                      <Check size={14} strokeWidth={3} />
                    ) : isNext ? (
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                    ) : null}
                  </div>

                  {/* Prayer Name & Arabic */}
                  <span className={`text-xs font-semibold tracking-tight transition-colors ${
                    isDone ? 'text-amber-300' : isNext ? 'text-amber-400' : 'text-slate-300'
                  }`}>
                    {prayer.name}
                  </span>

                  <span className="text-[10px] font-serif text-slate-400 opacity-80" dir="rtl">
                    {prayer.arabic}
                  </span>

                  {/* Prayer Time if Available */}
                  {prayerTime && (
                    <span className="text-[10px] font-mono text-slate-400 mt-1">
                      {prayerTime}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Motivational Spiritual Hadith / Ayah Quote Banner */}
      <div className="pt-3 border-t border-amber-900/20 flex items-center justify-between text-xs text-slate-400">
        <p className="italic">
          {isAllCompleted 
            ? '“Successful indeed are the believers who are humble in their prayers.” — Surah Al-Mu’minun' 
            : '“Guard strictly your prayers, especially the middle prayer.” — Surah Al-Baqarah 2:238'}
        </p>
        <span className="text-[11px] text-amber-500/80 font-medium hidden sm:inline">
          Syncs with Prayer Tracker
        </span>
      </div>
    </section>
  );
}
