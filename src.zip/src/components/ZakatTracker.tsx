import React, { useState, useEffect, useMemo } from 'react';
import { 
  Coins, 
  Heart, 
  Calculator, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  TrendingUp, 
  DollarSign, 
  Target, 
  Calendar, 
  Sparkles, 
  Info, 
  Filter, 
  ArrowUpRight, 
  ShieldCheck, 
  PieChart as PieChartIcon, 
  BarChart3,
  Edit2,
  Layers,
  Droplets,
  Building2,
  BookOpen,
  TreePine,
  GraduationCap,
  HeartHandshake,
  Award,
  Check,
  Clock,
  ChevronRight,
  Download,
  FileText,
  Printer,
  Search,
  ArrowUpDown,
  List,
  Milestone
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { triggerHaptic } from '../lib/haptics';
import { cacheZakatContributions, getCachedZakatContributions } from '../lib/db';
import { 
  queueRecordForSync, 
  processSyncQueue, 
  subscribeToSyncStatus, 
  SyncStatusInfo 
} from '../lib/zakatSync';
import { Cloud, CloudOff, RefreshCw } from 'lucide-react';

export type CharityType = 'zakat' | 'sadaqah' | 'zakat_fitr' | 'waqf';

export interface Contribution {
  id: string;
  type: CharityType;
  amount: number;
  currency: string;
  cause: string;
  recipient: string;
  date: string; // YYYY-MM-DD
  notes?: string;
  projectId?: string; // Link to Sadaqah Jariyah project if applicable
  projectName?: string; // Explicit project name field for tracking
  timestamp: number;
}

export type JariyahCategory = 'water' | 'masjid' | 'quran' | 'education' | 'trees' | 'orphan' | 'healthcare' | 'custom';

export interface SadaqahJariyahProject {
  id: string;
  title: string;
  arabicCategory: string;
  category: JariyahCategory;
  targetAmount: number;
  currentAmount: number;
  currency: string;
  organization: string;
  dedication?: string;
  startDate: string;
  targetDate?: string;
  status: 'in_progress' | 'completed';
  notes?: string;
}

export interface ZakatAssets {
  cashInHand: number;
  cashInBank: number;
  goldSilverValue: number;
  investments: number;
  businessMerchandise: number;
  loansOwedToYou: number;
  immediateDebts: number;
}

const DEFAULT_ASSETS: ZakatAssets = {
  cashInHand: 0,
  cashInBank: 0,
  goldSilverValue: 0,
  investments: 0,
  businessMerchandise: 0,
  loansOwedToYou: 0,
  immediateDebts: 0
};

const CURRENCIES = ['USD ($)', 'EUR (€)', 'GBP (£)', 'CAD ($)', 'AUD ($)', 'SAR (﷼)', 'AED (د.إ)', 'PKR (₨)', 'INR (₹)'];

const CHARITY_TYPE_LABELS: Record<CharityType, { label: string; arabic: string; color: string }> = {
  zakat: { label: 'Zakat al-Mal', arabic: 'زكاة المال', color: '#f59e0b' },
  sadaqah: { label: 'Sadaqah (Voluntary)', arabic: 'صدقة', color: '#10b981' },
  zakat_fitr: { label: 'Zakat al-Fitr', arabic: 'زكاة الفطر', color: '#6366f1' },
  waqf: { label: 'Sadaqah Jariyah / Waqf', arabic: 'صدقة جارية', color: '#ec4899' }
};

const JARIYAH_CATEGORIES: Record<JariyahCategory, { label: string; arabic: string; icon: any; color: string; defaultTarget: number }> = {
  water: { label: 'Clean Water / Well', arabic: 'سقيا الماء', icon: Droplets, color: '#38bdf8', defaultTarget: 1500 },
  masjid: { label: 'Mosque Construction', arabic: 'إعمار المساجد', icon: Building2, color: '#f59e0b', defaultTarget: 3000 },
  quran: { label: 'Quran Distribution (Waqf)', arabic: 'وقف المصاحف', icon: BookOpen, color: '#10b981', defaultTarget: 500 },
  education: { label: 'Islamic Education / Madrasah', arabic: 'وقف تعليمي', icon: GraduationCap, color: '#818cf8', defaultTarget: 2000 },
  trees: { label: 'Tree / Orchard Planting', arabic: 'غرس الشجر والوقف الأخضر', icon: TreePine, color: '#34d399', defaultTarget: 300 },
  orphan: { label: 'Orphan Endowment Fund', arabic: 'كفالة ووقف الأيتام', icon: HeartHandshake, color: '#f472b6', defaultTarget: 1800 },
  healthcare: { label: 'Medical Equipment / Clinic', arabic: 'وقف صحي وعلاجي', icon: Heart, color: '#f87171', defaultTarget: 2500 },
  custom: { label: 'Custom Endowment', arabic: 'وقف مخصص', icon: Layers, color: '#e2e8f0', defaultTarget: 1000 }
};

const DEFAULT_JARIYAH_PROJECTS: SadaqahJariyahProject[] = [
  {
    id: 'sj-1',
    title: 'Community Solar Water Well',
    arabicCategory: 'سقيا الماء',
    category: 'water',
    targetAmount: 1800,
    currentAmount: 1250,
    currency: '$',
    organization: 'Clean Water Ummah Initiative',
    dedication: 'In loving memory of beloved grandparents (رحمهم الله)',
    startDate: '2026-02-15',
    targetDate: '2026-11-30',
    status: 'in_progress',
    notes: 'Solar-powered submersible well providing continuous clean drinking water to 400+ villagers and livestock.'
  },
  {
    id: 'sj-2',
    title: 'Village Masjid Ceiling & Solar Waqf',
    arabicCategory: 'إعمار المساجد',
    category: 'masjid',
    targetAmount: 3500,
    currentAmount: 2100,
    currency: '$',
    organization: 'Masjid Building Society',
    dedication: 'Perpetual family endowment',
    startDate: '2026-01-10',
    targetDate: '2026-12-31',
    status: 'in_progress',
    notes: 'Providing electricity and safe roofing for daily congregational prayers and Quran study circles.'
  },
  {
    id: 'sj-3',
    title: '150 Holy Quran Mus-haf Distribution',
    arabicCategory: 'وقف المصاحف',
    category: 'quran',
    targetAmount: 600,
    currentAmount: 600,
    currency: '$',
    organization: 'Quran Waqf Foundation',
    dedication: 'On behalf of our household',
    startDate: '2026-03-01',
    status: 'completed',
    notes: 'Distributed to newly enrolled students in rural memorization centers.'
  }
];

const PIE_COLORS = ['#f59e0b', '#10b981', '#6366f1', '#ec4899', '#38bdf8', '#34d399'];

const JARIYAH_STORAGE_KEY = 'noor_sadaqah_jariyah_projects';

export default function ZakatTracker() {
  const [activeTab, setActiveTab] = useState<'overview' | 'calculator' | 'sadaqah_calculator' | 'sadaqah_jariyah' | 'history'>('overview');
  const [currencySymbol, setCurrencySymbol] = useState('$');

  // Dedicated Sadaqah Calculator State
  const [sadaqahPresetAmount, setSadaqahPresetAmount] = useState<string>('5');
  const [sadaqahFrequency, setSadaqahFrequency] = useState<'daily' | 'weekly_friday' | 'monthly' | 'annual'>('weekly_friday');
  const [sadaqahCause, setSadaqahCause] = useState<string>('Friday Jumuah Sadaqah');
  const [sadaqahRecipient, setSadaqahRecipient] = useState<string>('Local Masjid & Community Relief');
  const [sadaqahMonthlyIncome, setSadaqahMonthlyIncome] = useState<string>('3000');
  const [sadaqahTargetPct, setSadaqahTargetPct] = useState<string>('2.5');

  // Nisab threshold configuration (Defaults to Gold Nisab ~85g)
  const [nisabStandard, setNisabStandard] = useState<'gold' | 'silver'>('gold');
  const [goldNisabValue, setGoldNisabValue] = useState<number>(6200); // approx 85g gold
  const [silverNisabValue, setSilverNisabValue] = useState<number>(550); // approx 595g silver

  // Annual Giving Goal
  const [annualGoal, setAnnualGoal] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('noor_giving_annual_goal');
      return saved ? parseFloat(saved) : 3000;
    } catch {
      return 3000;
    }
  });

  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [goalInput, setGoalInput] = useState(String(annualGoal));

  // Zakat Assets State
  const [assets, setAssets] = useState<ZakatAssets>(() => {
    try {
      const saved = localStorage.getItem('noor_zakat_assets');
      return saved ? JSON.parse(saved) : DEFAULT_ASSETS;
    } catch {
      return DEFAULT_ASSETS;
    }
  });

  // Recorded Contributions
  const [contributions, setContributions] = useState<Contribution[]>(() => {
    try {
      const saved = localStorage.getItem('noor_charity_contributions');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [
      {
        id: 'seed-c1',
        type: 'zakat',
        amount: 500,
        currency: '$',
        cause: 'Orphan Care & Relief',
        projectName: 'Orphan Sponsorship Initiative',
        recipient: 'Islamic Relief Global',
        date: new Date(Date.now() - 86400000 * 45).toISOString().slice(0, 10),
        notes: 'First installment of annual Zakat',
        timestamp: Date.now() - 86400000 * 45
      },
      {
        id: 'seed-c2',
        type: 'sadaqah',
        amount: 150,
        currency: '$',
        cause: 'Local Community Food Bank',
        projectName: 'Community Food Security',
        recipient: 'City Masjid Pantry',
        date: new Date(Date.now() - 86400000 * 18).toISOString().slice(0, 10),
        notes: 'Friday blessing charity',
        timestamp: Date.now() - 86400000 * 18
      },
      {
        id: 'seed-c3',
        type: 'waqf',
        amount: 450,
        currency: '$',
        cause: 'Community Solar Water Well',
        projectName: 'Community Solar Water Well',
        recipient: 'Clean Water Ummah Initiative',
        date: new Date(Date.now() - 86400000 * 25).toISOString().slice(0, 10),
        notes: 'Ongoing well project installment',
        projectId: 'sj-1',
        timestamp: Date.now() - 86400000 * 25
      }
    ];
  });

  // Background Sync Status State
  const [syncStatus, setSyncStatus] = useState<SyncStatusInfo>({
    state: 'synced',
    pendingCount: 0,
    lastSyncedAt: null
  });

  useEffect(() => {
    const unsub = subscribeToSyncStatus(setSyncStatus);
    return () => unsub();
  }, []);

  // Sadaqah Jariyah Projects State
  const [projects, setProjects] = useState<SadaqahJariyahProject[]>(() => {
    try {
      const saved = localStorage.getItem(JARIYAH_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return DEFAULT_JARIYAH_PROJECTS;
  });

  // Filter for Sadaqah Jariyah: 'all' | 'in_progress' | 'completed'
  const [jariyahFilter, setJariyahFilter] = useState<'all' | 'in_progress' | 'completed'>('all');

  // Modals state
  const [showAddContributionModal, setShowAddContributionModal] = useState(false);
  const [showAddProjectModal, setShowAddProjectModal] = useState(false);
  const [contributeToProject, setContributeToProject] = useState<SadaqahJariyahProject | null>(null);

  // New Contribution Form State
  const [newType, setNewType] = useState<CharityType>('sadaqah');
  const [newAmount, setNewAmount] = useState('');
  const [newProjectName, setNewProjectName] = useState('');
  const [newCause, setNewCause] = useState('');
  const [newRecipient, setNewRecipient] = useState('');
  const [newDate, setNewDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [newNotes, setNewNotes] = useState('');
  const [historyFilter, setHistoryFilter] = useState<string>('all');
  const [historyViewMode, setHistoryViewMode] = useState<'table' | 'timeline' | 'cards'>('table');
  const [historySearch, setHistorySearch] = useState('');
  const [historySort, setHistorySort] = useState<'newest' | 'oldest' | 'amount_high' | 'amount_low'>('newest');

  // New Project Form State
  const [projTitle, setProjTitle] = useState('');
  const [projCategory, setProjCategory] = useState<JariyahCategory>('water');
  const [projTarget, setProjTarget] = useState('1500');
  const [projOrg, setProjOrg] = useState('');
  const [projDedication, setProjDedication] = useState('');
  const [projTargetDate, setProjTargetDate] = useState('');
  const [projNotes, setProjNotes] = useState('');

  // Project Contribution Modal Form State
  const [projContribAmount, setProjContribAmount] = useState('');
  const [projContribDate, setProjContribDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [projContribNotes, setProjContribNotes] = useState('');

  // Report Generation State
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportFiscalYear, setReportFiscalYear] = useState<number | 'all'>(() => new Date().getFullYear());

  // Available Fiscal Years derived from contributions
  const availableFiscalYears = useMemo(() => {
    const years = new Set<number>();
    years.add(new Date().getFullYear());
    contributions.forEach(c => {
      const y = new Date(c.date).getFullYear();
      if (!isNaN(y)) years.add(y);
    });
    return Array.from(years).sort((a, b) => b - a);
  }, [contributions]);

  // Contributions for Selected Fiscal Year
  const fiscalContributions = useMemo(() => {
    if (reportFiscalYear === 'all') return contributions;
    return contributions.filter(c => new Date(c.date).getFullYear() === reportFiscalYear);
  }, [contributions, reportFiscalYear]);

  // Fiscal Summary Metrics
  const fiscalSummary = useMemo(() => {
    let total = 0;
    let zakat = 0;
    let sadaqah = 0;
    let waqf = 0;
    let fitr = 0;

    fiscalContributions.forEach(c => {
      total += c.amount;
      if (c.type === 'zakat') zakat += c.amount;
      else if (c.type === 'sadaqah') sadaqah += c.amount;
      else if (c.type === 'waqf') waqf += c.amount;
      else if (c.type === 'zakat_fitr') fitr += c.amount;
    });

    return { total, zakat, sadaqah, waqf, fitr, count: fiscalContributions.length };
  }, [fiscalContributions]);

  // Downloadable Text Summary Generator (.txt)
  const handleDownloadTextSummary = () => {
    triggerHaptic(20);
    const yrLabel = reportFiscalYear === 'all' ? 'ALL FISCAL YEARS' : `FISCAL YEAR ${reportFiscalYear}`;
    const dateStr = new Date().toISOString().slice(0, 10);
    const divider = '='.repeat(78);
    const subDivider = '-'.repeat(78);

    let text = `${divider}\n`;
    text += `       NOOR ISLAMIC LIFESTYLE - CHARITABLE GIVING & ZAKAT ANNUAL REPORT\n`;
    text += `                            ${yrLabel}\n`;
    text += `${divider}\n\n`;
    text += `Report Generated: ${dateStr}\n`;
    text += `Currency:         ${currencySymbol}\n`;
    text += `Total Records:    ${fiscalSummary.count}\n\n`;

    text += `${subDivider}\n`;
    text += `1. FINANCIAL SUMMARY & CATEGORY BREAKDOWN\n`;
    text += `${subDivider}\n`;
    text += `Total Charitable Contributions:    ${currencySymbol}${fiscalSummary.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
    text += ` • Zakat al-Mal (Obligatory):      ${currencySymbol}${fiscalSummary.zakat.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
    text += ` • Voluntary Sadaqah:              ${currencySymbol}${fiscalSummary.sadaqah.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
    text += ` • Sadaqah Jariyah / Waqf:         ${currencySymbol}${fiscalSummary.waqf.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
    text += ` • Zakat al-Fitr:                  ${currencySymbol}${fiscalSummary.fitr.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n\n`;

    text += `${subDivider}\n`;
    text += `2. ZAKAT AL-MAL ASSESSMENT (CURRENT RECORD)\n`;
    text += `${subDivider}\n`;
    text += `Nisab Standard:                    ${nisabStandard.toUpperCase()} (${currencySymbol}${zakatCalculations.currentNisab.toLocaleString()})\n`;
    text += `Total Gross Zakatable Assets:      ${currencySymbol}${zakatCalculations.totalGrossAssets.toLocaleString()}\n`;
    text += `Immediate Deductible Debts:        ${currencySymbol}${zakatCalculations.totalDebts.toLocaleString()}\n`;
    text += `Net Zakatable Wealth:              ${currencySymbol}${zakatCalculations.netZakatableWealth.toLocaleString()}\n`;
    text += `Annual 2.5% Zakat Due:             ${currencySymbol}${zakatCalculations.zakatDue.toLocaleString()}\n`;
    text += `Zakat Paid in This Period:         ${currencySymbol}${fiscalSummary.zakat.toLocaleString()}\n`;
    text += `Assessment Status:                 ${zakatCalculations.isNisabReached ? 'Nisab Reached (Obligatory Zakat Due)' : 'Below Nisab Threshold'}\n\n`;

    text += `${subDivider}\n`;
    text += `3. ITEMIZED CONTRIBUTION LEDGER\n`;
    text += `${subDivider}\n`;
    text += `Date        | Category          | Amount        | Recipient / Cause\n`;
    text += `${subDivider}\n`;

    if (fiscalContributions.length === 0) {
      text += `No contributions recorded for this period.\n`;
    } else {
      fiscalContributions.forEach(item => {
        const d = item.date.padEnd(11);
        const cat = (CHARITY_TYPE_LABELS[item.type]?.label || item.type).slice(0, 17).padEnd(18);
        const amt = `${currencySymbol}${item.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`.padEnd(13);
        const details = `${item.recipient} - ${item.cause}${item.notes ? ` ("${item.notes}")` : ''}`;
        text += `${d} | ${cat} | ${amt} | ${details}\n`;
      });
    }

    text += `\n${subDivider}\n`;
    text += `4. SADAQAH JARIYAH (ONGOING PERPETUAL CHARITY) INITIATIVES\n`;
    text += `${subDivider}\n`;
    if (projects.length === 0) {
      text += `No ongoing Sadaqah Jariyah initiatives recorded.\n`;
    } else {
      projects.forEach(p => {
        const pct = Math.min(100, Math.round((p.currentAmount / (p.targetAmount || 1)) * 100));
        text += `• ${p.title} [${p.arabicCategory}]\n`;
        text += `  Target: ${currencySymbol}${p.targetAmount.toLocaleString()} | Raised: ${currencySymbol}${p.currentAmount.toLocaleString()} (${pct}%) | Status: ${p.status.toUpperCase()}\n`;
        text += `  Organization: ${p.organization}\n`;
        if (p.dedication) text += `  Dedication:   ${p.dedication}\n`;
        text += `\n`;
      });
    }

    text += `${divider}\n`;
    text += `« مَّثَلُ الَّذِينَ يُنفِقُونَ أَمْوَالَهُمْ فِي سَبِيلِ اللَّهِ كَمَثَلِ حَبَّةٍ أَنبَتَتْ سَبْعَ سَنَابِلَ »\n`;
    text += `"The example of those who spend their wealth in the way of Allah is like a seed\n`;
    text += ` which grows seven spikes; in each spike is a hundred grains." (Quran 2:261)\n`;
    text += `${divider}\n`;

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Noor_Charity_Report_${reportFiscalYear}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Printable / Downloadable PDF Report Generator
  const handlePrintOrPdf = () => {
    triggerHaptic(20);
    const yrLabel = reportFiscalYear === 'all' ? 'All Fiscal Years' : `Fiscal Year ${reportFiscalYear}`;
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      window.print();
      return;
    }

    const rowsHtml = fiscalContributions.map(c => `
      <tr>
        <td style="font-family: monospace; padding: 8px 10px; border-bottom: 1px solid #e2e8f0;">${c.date}</td>
        <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0;"><span style="font-size: 10px; padding: 2px 6px; border-radius: 4px; font-weight: 600; text-transform: uppercase; background: #fef3c7; color: #92400e;">${CHARITY_TYPE_LABELS[c.type]?.label || c.type}</span></td>
        <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0;"><strong>${c.cause}</strong>${c.notes ? `<br><small style="color: #64748b;">${c.notes}</small>` : ''}</td>
        <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0;">${c.recipient}</td>
        <td style="text-align: right; font-family: monospace; padding: 8px 10px; border-bottom: 1px solid #e2e8f0;"><strong>${currencySymbol}${c.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong></td>
      </tr>
    `).join('');

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Noor Charity Statement - ${yrLabel}</title>
        <meta charset="utf-8">
        <style>
          @page { size: A4; margin: 15mm; }
          body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            color: #1e293b;
            line-height: 1.5;
            padding: 20px;
          }
          .header { text-align: center; border-bottom: 2px solid #d97706; padding-bottom: 16px; margin-bottom: 20px; }
          .bismillah { font-size: 20px; color: #b45309; margin-bottom: 6px; }
          .title { font-size: 22px; font-weight: bold; color: #0f172a; margin: 0; }
          .subtitle { font-size: 13px; color: #64748b; margin-top: 4px; }
          .kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 24px; }
          .kpi-card { background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 12px; text-align: center; }
          .kpi-label { font-size: 11px; text-transform: uppercase; color: #64748b; font-weight: 600; }
          .kpi-val { font-size: 18px; font-weight: bold; color: #0f172a; margin-top: 4px; font-family: monospace; }
          .section-title { font-size: 13px; font-weight: bold; color: #b45309; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; margin-top: 24px; margin-bottom: 12px; text-transform: uppercase; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 12px; }
          th { background: #f1f5f9; text-align: left; padding: 8px 10px; border-bottom: 2px solid #cbd5e1; color: #334155; }
          .footer { margin-top: 36px; border-top: 1px solid #cbd5e1; padding-top: 12px; font-size: 11px; color: #64748b; text-align: center; font-style: italic; }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="bismillah">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>
          <h1 class="title">NOOR — STATEMENT OF CHARITABLE CONTRIBUTIONS</h1>
          <div class="subtitle">${yrLabel} · Official Giving & Zakat Summary Ledger</div>
        </div>

        <div class="kpi-grid">
          <div class="kpi-card">
            <div class="kpi-label">Total Giving</div>
            <div class="kpi-val">${currencySymbol}${fiscalSummary.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">Zakat al-Mal</div>
            <div class="kpi-val" style="color: #b45309;">${currencySymbol}${fiscalSummary.zakat.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">Voluntary Sadaqah</div>
            <div class="kpi-val" style="color: #059669;">${currencySymbol}${fiscalSummary.sadaqah.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">Sadaqah Jariyah</div>
            <div class="kpi-val" style="color: #db2777;">${currencySymbol}${fiscalSummary.waqf.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
          </div>
        </div>

        <div class="section-title">Itemized Donations Ledger</div>
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Category</th>
              <th>Cause / Purpose</th>
              <th>Recipient Organization</th>
              <th style="text-align: right;">Amount</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml || '<tr><td colspan="5" style="text-align: center; padding: 20px; color: #64748b;">No donations recorded for this period.</td></tr>'}
          </tbody>
          <tfoot>
            <tr style="background: #f8fafc; font-weight: bold;">
              <td colspan="4" style="padding: 10px;">TOTAL FOR ${yrLabel.toUpperCase()}</td>
              <td style="text-align: right; font-family: monospace; padding: 10px;">${currencySymbol}${fiscalSummary.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
            </tr>
          </tfoot>
        </table>

        <div class="section-title">Zakat Assessment Baseline</div>
        <p style="font-size: 12px; color: #475569; margin: 4px 0;">
          <strong>Nisab Standard:</strong> ${nisabStandard.toUpperCase()} (${currencySymbol}${zakatCalculations.currentNisab.toLocaleString()}) &nbsp;|&nbsp;
          <strong>Net Zakatable Wealth:</strong> ${currencySymbol}${zakatCalculations.netZakatableWealth.toLocaleString()} &nbsp;|&nbsp;
          <strong>Calculated 2.5% Zakat Due:</strong> ${currencySymbol}${zakatCalculations.zakatDue.toLocaleString()} &nbsp;|&nbsp;
          <strong>Status:</strong> ${zakatCalculations.isNisabReached ? 'Nisab Reached (Obligatory Zakat Discharged)' : 'Below Nisab'}
        </p>

        <div class="footer">
          «مَّثَلُ الَّذِينَ يُنفِقُونَ أَمْوَالَهُمْ فِي سَبِيلِ اللَّهِ كَمَثَلِ حَبَّةٍ أَنبَتَتْ سَبْعَ سَنَابِلَ فِي كُلِّ سُنبُلَةٍ مِّائَةُ حَبَّةٍ»<br>
          "The example of those who spend their wealth in the way of Allah is like a seed of grain which grows seven spikes; in each spike is a hundred grains." (Surah Al-Baqarah 2:261)<br>
          Generated by Noor Islamic Platform on ${new Date().toLocaleDateString()}
        </div>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(htmlContent);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
    }, 400);
  };

  // Save contributions to localStorage and IndexedDB
  useEffect(() => {
    try {
      localStorage.setItem('noor_charity_contributions', JSON.stringify(contributions));
      cacheZakatContributions(contributions);
    } catch (e) {
      console.warn(e);
    }
  }, [contributions]);

  // Load from IndexedDB on startup if needed
  useEffect(() => {
    const loadFromIndexedDB = async () => {
      try {
        const cached = await getCachedZakatContributions();
        if (cached && cached.length > 0) {
          const local = localStorage.getItem('noor_charity_contributions');
          if (!local) {
            setContributions(cached as Contribution[]);
          }
        }
      } catch (err) {
        console.warn('Failed to load Zakat contributions from IndexedDB:', err);
      }
    };
    loadFromIndexedDB();
  }, []);

  // Save assets to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('noor_zakat_assets', JSON.stringify(assets));
    } catch (e) {
      console.warn(e);
    }
  }, [assets]);

  // Save projects to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(JARIYAH_STORAGE_KEY, JSON.stringify(projects));
    } catch (e) {
      console.warn(e);
    }
  }, [projects]);

  // Save annual goal
  const handleSaveGoal = (e: React.FormEvent) => {
    e.preventDefault();
    triggerHaptic(15);
    const parsed = parseFloat(goalInput);
    if (!isNaN(parsed) && parsed > 0) {
      setAnnualGoal(parsed);
      localStorage.setItem('noor_giving_annual_goal', String(parsed));
    }
    setIsEditingGoal(false);
  };

  // Zakat Calculation Details
  const zakatCalculations = useMemo(() => {
    const totalGrossAssets = 
      (assets.cashInHand || 0) +
      (assets.cashInBank || 0) +
      (assets.goldSilverValue || 0) +
      (assets.investments || 0) +
      (assets.businessMerchandise || 0) +
      (assets.loansOwedToYou || 0);

    const totalDebts = assets.immediateDebts || 0;
    const netZakatableWealth = Math.max(0, totalGrossAssets - totalDebts);

    const currentNisab = nisabStandard === 'gold' ? goldNisabValue : silverNisabValue;
    const isNisabReached = netZakatableWealth >= currentNisab;
    const zakatDue = isNisabReached ? Math.round(netZakatableWealth * 0.025 * 100) / 100 : 0;

    return {
      totalGrossAssets,
      totalDebts,
      netZakatableWealth,
      currentNisab,
      isNisabReached,
      zakatDue
    };
  }, [assets, nisabStandard, goldNisabValue, silverNisabValue]);

  // Aggregate Contributions Metrics
  const charityStats = useMemo(() => {
    let totalGiven = 0;
    let zakatPaid = 0;
    let sadaqahPaid = 0;
    let waqfPaid = 0;

    const currentYear = new Date().getFullYear();

    contributions.forEach(item => {
      const year = new Date(item.date).getFullYear();
      if (year === currentYear) {
        totalGiven += item.amount;
        if (item.type === 'zakat') {
          zakatPaid += item.amount;
        } else if (item.type === 'sadaqah') {
          sadaqahPaid += item.amount;
        } else if (item.type === 'waqf') {
          waqfPaid += item.amount;
        }
      }
    });

    const goalProgressPct = Math.min(100, Math.round((totalGiven / (annualGoal || 1)) * 100));
    const zakatRemaining = Math.max(0, zakatCalculations.zakatDue - zakatPaid);
    const zakatProgressPct = zakatCalculations.zakatDue > 0
      ? Math.min(100, Math.round((zakatPaid / zakatCalculations.zakatDue) * 100))
      : 100;

    return {
      totalGiven,
      zakatPaid,
      sadaqahPaid,
      waqfPaid,
      goalProgressPct,
      zakatRemaining,
      zakatProgressPct
    };
  }, [contributions, annualGoal, zakatCalculations.zakatDue]);

  // Aggregate Sadaqah Jariyah Projects Metrics
  const jariyahMetrics = useMemo(() => {
    let totalTarget = 0;
    let totalFunded = 0;
    let completedCount = 0;
    let inProgressCount = 0;

    projects.forEach(p => {
      totalTarget += p.targetAmount;
      totalFunded += p.currentAmount;
      if (p.status === 'completed' || p.currentAmount >= p.targetAmount) {
        completedCount++;
      } else {
        inProgressCount++;
      }
    });

    const overallPct = totalTarget > 0 ? Math.min(100, Math.round((totalFunded / totalTarget) * 100)) : 0;
    const remainingToRaise = Math.max(0, totalTarget - totalFunded);

    return {
      totalTarget,
      totalFunded,
      completedCount,
      inProgressCount,
      overallPct,
      remainingToRaise
    };
  }, [projects]);

  // Monthly Breakdown Data for Recharts
  const monthlyData = useMemo(() => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const currentYear = new Date().getFullYear();

    const monthlyMap: Record<number, { zakat: number; sadaqah: number; waqf: number }> = {};
    for (let i = 0; i < 12; i++) {
      monthlyMap[i] = { zakat: 0, sadaqah: 0, waqf: 0 };
    }

    contributions.forEach(c => {
      const d = new Date(c.date);
      if (d.getFullYear() === currentYear) {
        const m = d.getMonth();
        if (c.type === 'zakat') {
          monthlyMap[m].zakat += c.amount;
        } else if (c.type === 'waqf') {
          monthlyMap[m].waqf += c.amount;
        } else {
          monthlyMap[m].sadaqah += c.amount;
        }
      }
    });

    return months.map((name, index) => ({
      name,
      Zakat: monthlyMap[index].zakat,
      Sadaqah: monthlyMap[index].sadaqah,
      Jariyah: monthlyMap[index].waqf,
      Total: monthlyMap[index].zakat + monthlyMap[index].sadaqah + monthlyMap[index].waqf
    }));
  }, [contributions]);

  // Category Distribution for Pie Chart
  const categoryData = useMemo(() => {
    const map: Record<string, number> = {};
    contributions.forEach(c => {
      const label = CHARITY_TYPE_LABELS[c.type]?.label || 'Other';
      map[label] = (map[label] || 0) + c.amount;
    });

    return Object.entries(map).map(([name, value]) => ({
      name,
      value
    }));
  }, [contributions]);

  // Filtered projects
  const filteredProjects = useMemo(() => {
    if (jariyahFilter === 'in_progress') return projects.filter(p => p.status === 'in_progress' && p.currentAmount < p.targetAmount);
    if (jariyahFilter === 'completed') return projects.filter(p => p.status === 'completed' || p.currentAmount >= p.targetAmount);
    return projects;
  }, [projects, jariyahFilter]);

  // Filtered & Sorted History for Historical Log View
  const filteredContributions = useMemo(() => {
    let result = contributions.filter(c => {
      const matchType = historyFilter === 'all' || c.type === historyFilter;
      const q = historySearch.toLowerCase().trim();
      const projName = c.projectName || c.cause;
      const matchSearch = !q || 
        projName.toLowerCase().includes(q) ||
        c.cause.toLowerCase().includes(q) ||
        c.recipient.toLowerCase().includes(q) ||
        (c.notes && c.notes.toLowerCase().includes(q)) ||
        c.date.includes(q) ||
        String(c.amount).includes(q);

      return matchType && matchSearch;
    });

    return result.sort((a, b) => {
      if (historySort === 'newest') return new Date(b.date).getTime() - new Date(a.date).getTime();
      if (historySort === 'oldest') return new Date(a.date).getTime() - new Date(b.date).getTime();
      if (historySort === 'amount_high') return b.amount - a.amount;
      if (historySort === 'amount_low') return a.amount - b.amount;
      return 0;
    });
  }, [contributions, historyFilter, historySearch, historySort]);

  // Overall Charity Journey Lifetime Statistics
  const journeyStats = useMemo(() => {
    let lifetimeTotal = 0;
    const projectNames = new Set<string>();

    contributions.forEach(c => {
      lifetimeTotal += c.amount;
      projectNames.add(c.projectName || c.cause);
    });

    const sortedByDate = [...contributions].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    const firstDate = sortedByDate[0]?.date;
    const latestDate = sortedByDate[sortedByDate.length - 1]?.date;

    return {
      lifetimeTotal,
      deedsCount: contributions.length,
      projectsCount: projectNames.size,
      firstDate,
      latestDate
    };
  }, [contributions]);

  // Add General Contribution
  const handleAddContribution = (e: React.FormEvent) => {
    e.preventDefault();
    const amountVal = parseFloat(newAmount);
    if (isNaN(amountVal) || amountVal <= 0 || !newCause.trim()) return;

    triggerHaptic(25);

    const record: Contribution = {
      id: `contrib_${Date.now()}`,
      type: newType,
      amount: amountVal,
      currency: currencySymbol,
      cause: newCause.trim(),
      projectName: newProjectName.trim() || newCause.trim(),
      recipient: newRecipient.trim() || 'Charity Organization',
      date: newDate,
      notes: newNotes.trim(),
      timestamp: Date.now()
    };

    setContributions(prev => [record, ...prev]);
    queueRecordForSync(record as any, 'insert');

    setNewAmount('');
    setNewProjectName('');
    setNewCause('');
    setNewRecipient('');
    setNewNotes('');
    setShowAddContributionModal(false);
  };

  // Add New Sadaqah Jariyah Project
  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    const targetVal = parseFloat(projTarget);
    if (!projTitle.trim() || isNaN(targetVal) || targetVal <= 0) return;

    triggerHaptic(25);

    const catConf = JARIYAH_CATEGORIES[projCategory] || JARIYAH_CATEGORIES.custom;

    const newProj: SadaqahJariyahProject = {
      id: `sj_${Date.now()}`,
      title: projTitle.trim(),
      arabicCategory: catConf.arabic,
      category: projCategory,
      targetAmount: targetVal,
      currentAmount: 0,
      currency: currencySymbol,
      organization: projOrg.trim() || 'Charity Endowment Body',
      dedication: projDedication.trim() || undefined,
      startDate: new Date().toISOString().slice(0, 10),
      targetDate: projTargetDate || undefined,
      status: 'in_progress',
      notes: projNotes.trim() || undefined
    };

    setProjects(prev => [newProj, ...prev]);

    // Reset Form
    setProjTitle('');
    setProjCategory('water');
    setProjTarget('1500');
    setProjOrg('');
    setProjDedication('');
    setProjTargetDate('');
    setProjNotes('');
    setShowAddProjectModal(false);
  };

  // Log Contribution specifically to a Sadaqah Jariyah Project
  const handleProjectContribution = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contributeToProject) return;

    const amountVal = parseFloat(projContribAmount);
    if (isNaN(amountVal) || amountVal <= 0) return;

    triggerHaptic(30);

    const updatedCurrent = contributeToProject.currentAmount + amountVal;
    const isNowComplete = updatedCurrent >= contributeToProject.targetAmount;

    // 1. Update Project
    setProjects(prev => prev.map(p => {
      if (p.id === contributeToProject.id) {
        return {
          ...p,
          currentAmount: updatedCurrent,
          status: isNowComplete ? 'completed' : p.status
        };
      }
      return p;
    }));

    // 2. Add to Global Contributions list so it appears in history and totals
    const record: Contribution = {
      id: `contrib_sj_${Date.now()}`,
      type: 'waqf',
      amount: amountVal,
      currency: currencySymbol,
      cause: `${contributeToProject.title} (Sadaqah Jariyah)`,
      projectName: contributeToProject.title,
      recipient: contributeToProject.organization,
      date: projContribDate,
      notes: projContribNotes.trim() || (contributeToProject.dedication ? `Dedication: ${contributeToProject.dedication}` : undefined),
      projectId: contributeToProject.id,
      timestamp: Date.now()
    };

    setContributions(prev => [record, ...prev]);
    queueRecordForSync(record as any, 'insert');

    // Reset & Close
    setProjContribAmount('');
    setProjContribNotes('');
    setContributeToProject(null);
  };

  // Delete project
  const handleDeleteProject = (id: string) => {
    triggerHaptic(20);
    setProjects(prev => prev.filter(p => p.id !== id));
  };

  // Delete contribution
  const handleDeleteContribution = (id: string) => {
    triggerHaptic(20);
    setContributions(prev => prev.filter(c => c.id !== id));
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Top Header */}
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl text-amber-500 font-serif">Zakat & Sadaqah Hub</h2>
            <span className="text-xs font-serif text-slate-400 opacity-80" dir="rtl">
              الزكاة والصدقات والوقف الجاري
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Calculate annual 2.5% Zakat, track perpetual Sadaqah Jariyah projects, and monitor your personal giving goals
          </p>
        </div>

        {/* Currency & Quick Add Contribution Button */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <select
            value={currencySymbol}
            onChange={(e) => setCurrencySymbol(e.target.value)}
            className="bg-slate-900 border border-amber-900/30 text-slate-300 text-xs py-1.5 px-2.5 rounded-xl outline-none focus:border-amber-500"
          >
            {CURRENCIES.map(c => {
              const sym = c.split(' ')[0];
              return <option key={c} value={sym}>{c}</option>;
            })}
          </select>

          <button
            type="button"
            onClick={() => {
              triggerHaptic(15);
              setShowReportModal(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-amber-900/40 hover:border-amber-500/60 text-amber-400 hover:text-amber-300 font-semibold text-xs transition-all shadow-md active:scale-95"
            title="Generate annual fiscal contribution summary (PDF or Text)"
          >
            <FileText size={14} />
            <span className="hidden sm:inline">Fiscal Report</span>
            <span className="sm:hidden">Report</span>
          </button>

          <button
            type="button"
            onClick={() => {
              triggerHaptic(15);
              setShowAddContributionModal(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs transition-all shadow-md shadow-amber-600/20 active:scale-95"
          >
            <Plus size={14} />
            <span>Record Giving</span>
          </button>
        </div>
      </header>

      {/* Background Sync & IndexedDB Status Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-slate-900/90 border border-amber-900/30 rounded-2xl text-xs">
        <div className="flex items-center gap-2">
          {syncStatus.state === 'offline' ? (
            <div className="flex items-center gap-1.5 text-amber-400 font-medium">
              <CloudOff size={15} className="animate-pulse" />
              <span>Offline Mode — {syncStatus.pendingCount} record{syncStatus.pendingCount === 1 ? '' : 's'} queued in IndexedDB</span>
            </div>
          ) : syncStatus.state === 'syncing' ? (
            <div className="flex items-center gap-1.5 text-amber-300 font-medium">
              <RefreshCw size={15} className="animate-spin text-amber-400" />
              <span>Background sync in progress...</span>
            </div>
          ) : syncStatus.pendingCount > 0 ? (
            <div className="flex items-center gap-1.5 text-amber-300 font-medium">
              <Cloud size={15} className="text-amber-400" />
              <span>{syncStatus.pendingCount} record{syncStatus.pendingCount === 1 ? '' : 's'} ready for auto-sync</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
              <CheckCircle2 size={15} className="text-emerald-400" />
              <span>All Zakat & Sadaqah records synchronized (Stored in IndexedDB & Service Worker Ready)</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          {syncStatus.lastSyncedAt && (
            <span className="text-[10px] text-slate-500 font-mono hidden md:inline">
              Last synced: {new Date(syncStatus.lastSyncedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          )}
          <button
            type="button"
            onClick={() => {
              triggerHaptic(15);
              processSyncQueue();
            }}
            disabled={syncStatus.state === 'syncing'}
            className="flex items-center gap-1 px-2.5 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-lg text-xs font-semibold transition active:scale-95 disabled:opacity-50"
          >
            <RefreshCw size={12} className={syncStatus.state === 'syncing' ? 'animate-spin' : ''} />
            <span>Sync Now</span>
          </button>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex bg-slate-900/80 border border-amber-900/30 p-1 rounded-2xl text-xs overflow-x-auto scrollbar-none">
        <button
          type="button"
          onClick={() => {
            triggerHaptic(10);
            setActiveTab('overview');
          }}
          className={`flex-1 min-w-[120px] py-2 rounded-xl font-medium transition-all text-center flex items-center justify-center gap-1.5 whitespace-nowrap ${
            activeTab === 'overview'
              ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <TrendingUp size={14} />
          <span>Giving Overview</span>
        </button>

        <button
          type="button"
          onClick={() => {
            triggerHaptic(10);
            setActiveTab('calculator');
          }}
          className={`flex-1 min-w-[120px] py-2 rounded-xl font-medium transition-all text-center flex items-center justify-center gap-1.5 whitespace-nowrap ${
            activeTab === 'calculator'
              ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Calculator size={14} />
          <span>Zakat Calculator</span>
        </button>

        <button
          type="button"
          onClick={() => {
            triggerHaptic(10);
            setActiveTab('sadaqah_calculator');
          }}
          className={`flex-1 min-w-[140px] py-2 rounded-xl font-medium transition-all text-center flex items-center justify-center gap-1.5 whitespace-nowrap ${
            activeTab === 'sadaqah_calculator'
              ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Heart size={14} className="text-emerald-400" />
          <span>Sadaqah Planner</span>
        </button>

        <button
          type="button"
          onClick={() => {
            triggerHaptic(10);
            setActiveTab('sadaqah_jariyah');
          }}
          className={`flex-1 min-w-[140px] py-2 rounded-xl font-medium transition-all text-center flex items-center justify-center gap-1.5 whitespace-nowrap ${
            activeTab === 'sadaqah_jariyah'
              ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers size={14} />
          <span>Sadaqah Jariyah ({projects.length})</span>
        </button>

        <button
          type="button"
          onClick={() => {
            triggerHaptic(10);
            setActiveTab('history');
          }}
          className={`flex-1 min-w-[120px] py-2 rounded-xl font-medium transition-all text-center flex items-center justify-center gap-1.5 whitespace-nowrap ${
            activeTab === 'history'
              ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Calendar size={14} />
          <span>History ({contributions.length})</span>
        </button>
      </div>

      {/* TAB 1: OVERVIEW & PROGRESS DASHBOARD */}
      {activeTab === 'overview' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Key Goal & Progress Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Card 1: Annual Giving Goal Progress */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 shadow-xl relative overflow-hidden flex flex-col justify-between space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                  <Target size={14} className="text-amber-500" />
                  Annual Giving Goal
                </span>
                <button
                  type="button"
                  onClick={() => setIsEditingGoal(!isEditingGoal)}
                  className="text-[11px] text-amber-500 hover:underline flex items-center gap-1"
                >
                  <Edit2 size={11} /> {isEditingGoal ? 'Cancel' : 'Edit'}
                </button>
              </div>

              {isEditingGoal ? (
                <form onSubmit={handleSaveGoal} className="space-y-2">
                  <div className="flex items-center gap-1">
                    <span className="text-slate-400 text-xs font-mono">{currencySymbol}</span>
                    <input
                      type="number"
                      value={goalInput}
                      onChange={e => setGoalInput(e.target.value)}
                      className="w-full bg-slate-950 border border-amber-500/50 rounded-lg p-1.5 text-xs text-slate-100"
                      placeholder="e.g. 5000"
                      autoFocus
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-amber-600 text-slate-950 font-bold text-xs py-1 rounded-lg"
                  >
                    Save Target
                  </button>
                </form>
              ) : (
                <div>
                  <div className="flex items-baseline justify-between">
                    <span className="text-2xl font-mono font-bold text-slate-100">
                      {currencySymbol}{charityStats.totalGiven.toLocaleString()}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      of {currencySymbol}{annualGoal.toLocaleString()}
                    </span>
                  </div>

                  <div className="w-full bg-slate-800 rounded-full h-2 mt-2 overflow-hidden">
                    <div 
                      className="bg-amber-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${charityStats.goalProgressPct}%` }}
                    />
                  </div>
                  <div className="flex justify-between items-center text-[10px] text-slate-400 mt-1 font-mono">
                    <span>{charityStats.goalProgressPct}% Achieved</span>
                    <span>{currencySymbol}{Math.max(0, annualGoal - charityStats.totalGiven).toLocaleString()} remaining</span>
                  </div>
                </div>
              )}

              <p className="text-[10px] text-slate-400 border-t border-slate-800/80 pt-2">
                All Zakat, Sadaqah, and Waqf given this year.
              </p>
            </div>

            {/* Card 2: Zakat Obligation Fulfillment */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-amber-900/30 rounded-2xl p-5 shadow-xl relative overflow-hidden flex flex-col justify-between space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                  <Coins size={14} className="text-amber-500" />
                  Zakat al-Mal (2.5%)
                </span>
                <button
                  type="button"
                  onClick={() => setActiveTab('calculator')}
                  className="text-[11px] text-amber-500 hover:underline"
                >
                  Adjust →
                </button>
              </div>

              <div>
                <div className="flex items-baseline justify-between">
                  <div>
                    <span className="text-2xl font-mono font-bold text-amber-400">
                      {currencySymbol}{charityStats.zakatPaid.toLocaleString()}
                    </span>
                    <span className="text-[11px] text-slate-400 ml-1">paid</span>
                  </div>
                  <span className="text-xs text-slate-300 font-mono">
                    Due: {currencySymbol}{zakatCalculations.zakatDue.toLocaleString()}
                  </span>
                </div>

                <div className="w-full bg-slate-800 rounded-full h-2 mt-2 overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-500 ${
                      charityStats.zakatRemaining === 0 ? 'bg-emerald-500' : 'bg-amber-500'
                    }`}
                    style={{ width: `${charityStats.zakatProgressPct}%` }}
                  />
                </div>
                <div className="flex justify-between items-center text-[10px] text-slate-400 mt-1 font-mono">
                  <span>{charityStats.zakatProgressPct}% Discharged</span>
                  <span className={charityStats.zakatRemaining === 0 ? 'text-emerald-400 font-semibold' : 'text-amber-400'}>
                    {charityStats.zakatRemaining === 0 ? '✓ Fulfilled' : `${currencySymbol}${charityStats.zakatRemaining.toLocaleString()} rem.`}
                  </span>
                </div>
              </div>

              <div className="border-t border-slate-800/80 pt-2 flex items-center justify-between text-[10px]">
                <span className="text-slate-400">Nisab Threshold:</span>
                <span className="text-slate-200 font-mono">{currencySymbol}{zakatCalculations.currentNisab.toLocaleString()}</span>
              </div>
            </div>

            {/* Card 3: Sadaqah Jariyah Ongoing Projects Summary */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-pink-900/30 rounded-2xl p-5 shadow-xl relative overflow-hidden flex flex-col justify-between space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                  <Layers size={14} className="text-pink-400" />
                  Sadaqah Jariyah
                </span>
                <button
                  type="button"
                  onClick={() => setActiveTab('sadaqah_jariyah')}
                  className="text-[11px] text-pink-400 hover:underline"
                >
                  View All →
                </button>
              </div>

              <div>
                <div className="flex items-baseline justify-between">
                  <span className="text-2xl font-mono font-bold text-pink-400">
                    {currencySymbol}{jariyahMetrics.totalFunded.toLocaleString()}
                  </span>
                  <span className="text-xs text-slate-400 font-mono">
                    of {currencySymbol}{jariyahMetrics.totalTarget.toLocaleString()}
                  </span>
                </div>

                <div className="w-full bg-slate-800 rounded-full h-2 mt-2 overflow-hidden">
                  <div 
                    className="bg-pink-500 h-full rounded-full transition-all duration-500"
                    style={{ width: `${jariyahMetrics.overallPct}%` }}
                  />
                </div>
                <div className="flex justify-between items-center text-[10px] text-slate-400 mt-1 font-mono">
                  <span>{jariyahMetrics.overallPct}% Funded</span>
                  <span className="text-pink-300 font-bold">{jariyahMetrics.completedCount} Complete</span>
                </div>
              </div>

              <div className="border-t border-slate-800/80 pt-2 flex items-center justify-between text-[10px] text-slate-400">
                <span>Active Initiatives:</span>
                <span className="font-mono text-slate-200 font-semibold">{jariyahMetrics.inProgressCount} in progress</span>
              </div>
            </div>

            {/* Card 4: Voluntary Sadaqah */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-emerald-950/40 rounded-2xl p-5 shadow-xl relative overflow-hidden flex flex-col justify-between space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                  <Heart size={14} className="text-emerald-400" />
                  Voluntary Sadaqah
                </span>
                <span className="text-[10px] font-mono uppercase text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-full border border-emerald-800/50">
                  Continuous Barakah
                </span>
              </div>

              <div>
                <span className="text-2xl font-mono font-bold text-emerald-400">
                  {currencySymbol}{charityStats.sadaqahPaid.toLocaleString()}
                </span>
                <p className="text-xs text-slate-400 mt-1">
                  Given purely for the sake of Allah without obligation.
                </p>
              </div>

              <div className="border-t border-slate-800/80 pt-2 flex items-center justify-between text-[10px] text-slate-400">
                <span>Total Contributions:</span>
                <span className="font-mono text-slate-200 font-semibold">{contributions.length} recorded</span>
              </div>
            </div>
          </div>

          {/* Visual Charts: Monthly Giving Timeline + Category Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
            {/* Chart 1: Monthly Giving (8 cols) */}
            <div className="lg:col-span-8 bg-slate-900 border border-amber-900/30 rounded-2xl p-5 space-y-3 shadow-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <BarChart3 size={16} className="text-amber-500" />
                  <h3 className="text-sm font-bold text-slate-100">Monthly Giving Timeline</h3>
                </div>
                <div className="flex items-center gap-3 text-[11px]">
                  <span className="flex items-center gap-1 text-amber-400 font-mono">
                    <span className="w-2.5 h-2.5 rounded-sm bg-amber-500 inline-block" /> Zakat
                  </span>
                  <span className="flex items-center gap-1 text-emerald-400 font-mono">
                    <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500 inline-block" /> Sadaqah
                  </span>
                  <span className="flex items-center gap-1 text-pink-400 font-mono">
                    <span className="w-2.5 h-2.5 rounded-sm bg-pink-500 inline-block" /> Waqf / Jariyah
                  </span>
                </div>
              </div>

              <div className="w-full h-56 min-w-0">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.35} vertical={false} />
                    <XAxis 
                      dataKey="name" 
                      stroke="#64748b" 
                      fontSize={11} 
                      tickLine={false} 
                      axisLine={{ stroke: '#334155' }} 
                    />
                    <YAxis 
                      stroke="#64748b" 
                      fontSize={10} 
                      tickLine={false} 
                      axisLine={{ stroke: '#334155' }} 
                    />
                    <Tooltip 
                      formatter={(val: any) => [`${currencySymbol}${Number(val).toLocaleString()}`, '']}
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#d97706', borderRadius: '12px', fontSize: '11px' }}
                    />
                    <Bar dataKey="Zakat" stackId="a" fill="#f59e0b" maxBarSize={28} />
                    <Bar dataKey="Sadaqah" stackId="a" fill="#10b981" maxBarSize={28} />
                    <Bar dataKey="Jariyah" stackId="a" fill="#ec4899" radius={[4, 4, 0, 0]} maxBarSize={28} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 2: Giving Distribution by Cause (4 cols) */}
            <div className="lg:col-span-4 bg-slate-900 border border-amber-900/30 rounded-2xl p-5 space-y-3 shadow-lg flex flex-col justify-between">
              <div className="flex items-center gap-2">
                <PieChartIcon size={16} className="text-amber-500" />
                <h3 className="text-sm font-bold text-slate-100">Category Distribution</h3>
              </div>

              <div className="w-full h-44 min-w-0 flex items-center justify-center">
                {categoryData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={categoryData}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius={38}
                        outerRadius={62}
                        paddingAngle={4}
                      >
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(val: any) => [`${currencySymbol}${Number(val).toLocaleString()}`, '']}
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#d97706', borderRadius: '12px', fontSize: '11px' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-xs text-slate-500 text-center">No contributions recorded yet</p>
                )}
              </div>

              {/* Legend */}
              <div className="space-y-1.5 border-t border-slate-800 pt-2 text-xs">
                {categoryData.map((item, idx) => (
                  <div key={item.name} className="flex items-center justify-between text-slate-300">
                    <span className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: PIE_COLORS[idx % PIE_COLORS.length] }} />
                      <span className="text-[11px] truncate max-w-[150px]">{item.name}</span>
                    </span>
                    <span className="font-mono text-[11px] font-bold">
                      {currencySymbol}{item.value.toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ZAKAT CALCULATOR */}
      {activeTab === 'calculator' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Nisab Selector Card */}
          <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 space-y-4 shadow-lg">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-100">Nisab Threshold Calibration</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Nisab is the minimum net wealth a Muslim must possess for one full lunar year (Hawl) before Zakat is due.
                </p>
              </div>

              {/* Standard Switcher: Gold vs Silver */}
              <div className="flex bg-slate-950 border border-amber-900/30 p-1 rounded-xl text-xs self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic(10);
                    setNisabStandard('gold');
                  }}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                    nisabStandard === 'gold'
                      ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Gold (85g)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic(10);
                    setNisabStandard('silver');
                  }}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                    nisabStandard === 'silver'
                      ? 'bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-600/20'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Silver (595g)
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-400">Current Gold Nisab Value (~85 grams):</span>
                <div className="flex items-center gap-1 text-slate-200 font-mono text-sm font-bold">
                  <span>{currencySymbol}</span>
                  <input
                    type="number"
                    value={goldNisabValue}
                    onChange={e => setGoldNisabValue(parseFloat(e.target.value) || 0)}
                    className="bg-transparent border-b border-slate-700 focus:border-amber-500 outline-none w-28 px-1"
                  />
                </div>
                <p className="text-[10px] text-slate-500">Standard for modern cash, savings, and gold holdings.</p>
              </div>

              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-400">Current Silver Nisab Value (~595 grams):</span>
                <div className="flex items-center gap-1 text-slate-200 font-mono text-sm font-bold">
                  <span>{currencySymbol}</span>
                  <input
                    type="number"
                    value={silverNisabValue}
                    onChange={e => setSilverNisabValue(parseFloat(e.target.value) || 0)}
                    className="bg-transparent border-b border-slate-700 focus:border-amber-500 outline-none w-28 px-1"
                  />
                </div>
                <p className="text-[10px] text-slate-500">More conservative threshold benefiting more poor recipients.</p>
              </div>
            </div>
          </div>

          {/* Asset Entry Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Left Column: Eligible Assets */}
            <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 space-y-4 shadow-lg">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                  <Coins size={16} className="text-amber-500" />
                  Zakat-Eligible Assets
                </h3>
                <span className="text-[10px] text-amber-400 font-mono">Zakatable</span>
              </div>

              {/* Cash in Hand */}
              <div className="space-y-1">
                <label className="text-xs text-slate-300 font-medium flex justify-between">
                  <span>Cash in Hand & Wallets</span>
                  <span className="text-[10px] text-slate-500">Physical currency</span>
                </label>
                <div className="flex items-center bg-slate-950 border border-slate-700/80 rounded-xl px-3 py-2 text-xs">
                  <span className="text-slate-500 mr-2 font-mono">{currencySymbol}</span>
                  <input
                    type="number"
                    value={assets.cashInHand || ''}
                    onChange={e => setAssets({ ...assets, cashInHand: parseFloat(e.target.value) || 0 })}
                    placeholder="0"
                    className="w-full bg-transparent text-slate-100 outline-none font-mono text-sm"
                  />
                </div>
              </div>

              {/* Cash in Bank */}
              <div className="space-y-1">
                <label className="text-xs text-slate-300 font-medium flex justify-between">
                  <span>Bank Accounts (Checking & Savings)</span>
                  <span className="text-[10px] text-slate-500">Deposits & liquid funds</span>
                </label>
                <div className="flex items-center bg-slate-950 border border-slate-700/80 rounded-xl px-3 py-2 text-xs">
                  <span className="text-slate-500 mr-2 font-mono">{currencySymbol}</span>
                  <input
                    type="number"
                    value={assets.cashInBank || ''}
                    onChange={e => setAssets({ ...assets, cashInBank: parseFloat(e.target.value) || 0 })}
                    placeholder="0"
                    className="w-full bg-transparent text-slate-100 outline-none font-mono text-sm"
                  />
                </div>
              </div>

              {/* Gold & Silver */}
              <div className="space-y-1">
                <label className="text-xs text-slate-300 font-medium flex justify-between">
                  <span>Gold & Silver Value</span>
                  <span className="text-[10px] text-slate-500">Jewelry, coins, bullion</span>
                </label>
                <div className="flex items-center bg-slate-950 border border-slate-700/80 rounded-xl px-3 py-2 text-xs">
                  <span className="text-slate-500 mr-2 font-mono">{currencySymbol}</span>
                  <input
                    type="number"
                    value={assets.goldSilverValue || ''}
                    onChange={e => setAssets({ ...assets, goldSilverValue: parseFloat(e.target.value) || 0 })}
                    placeholder="0"
                    className="w-full bg-transparent text-slate-100 outline-none font-mono text-sm"
                  />
                </div>
              </div>

              {/* Investments */}
              <div className="space-y-1">
                <label className="text-xs text-slate-300 font-medium flex justify-between">
                  <span>Investments, Shares & Crypto</span>
                  <span className="text-[10px] text-slate-500">Trading shares or zakatable portion</span>
                </label>
                <div className="flex items-center bg-slate-950 border border-slate-700/80 rounded-xl px-3 py-2 text-xs">
                  <span className="text-slate-500 mr-2 font-mono">{currencySymbol}</span>
                  <input
                    type="number"
                    value={assets.investments || ''}
                    onChange={e => setAssets({ ...assets, investments: parseFloat(e.target.value) || 0 })}
                    placeholder="0"
                    className="w-full bg-transparent text-slate-100 outline-none font-mono text-sm"
                  />
                </div>
              </div>

              {/* Business Merchandise */}
              <div className="space-y-1">
                <label className="text-xs text-slate-300 font-medium flex justify-between">
                  <span>Business Inventory / Goods for Resale</span>
                  <span className="text-[10px] text-slate-500">Wholesale cost or current market value</span>
                </label>
                <div className="flex items-center bg-slate-950 border border-slate-700/80 rounded-xl px-3 py-2 text-xs">
                  <span className="text-slate-500 mr-2 font-mono">{currencySymbol}</span>
                  <input
                    type="number"
                    value={assets.businessMerchandise || ''}
                    onChange={e => setAssets({ ...assets, businessMerchandise: parseFloat(e.target.value) || 0 })}
                    placeholder="0"
                    className="w-full bg-transparent text-slate-100 outline-none font-mono text-sm"
                  />
                </div>
              </div>

              {/* Loans Owed to You */}
              <div className="space-y-1">
                <label className="text-xs text-slate-300 font-medium flex justify-between">
                  <span>Loans Owed to You</span>
                  <span className="text-[10px] text-slate-500">Reliable debts you expect to collect</span>
                </label>
                <div className="flex items-center bg-slate-950 border border-slate-700/80 rounded-xl px-3 py-2 text-xs">
                  <span className="text-slate-500 mr-2 font-mono">{currencySymbol}</span>
                  <input
                    type="number"
                    value={assets.loansOwedToYou || ''}
                    onChange={e => setAssets({ ...assets, loansOwedToYou: parseFloat(e.target.value) || 0 })}
                    placeholder="0"
                    className="w-full bg-transparent text-slate-100 outline-none font-mono text-sm"
                  />
                </div>
              </div>
            </div>

            {/* Right Column: Liabilities & Calculation Summary */}
            <div className="space-y-4 flex flex-col justify-between">
              <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 space-y-3 shadow-lg">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                    <ShieldCheck size={16} className="text-red-400" />
                    Deductible Liabilities
                  </h3>
                  <span className="text-[10px] text-red-400 font-mono">Deductions</span>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-300 font-medium flex justify-between">
                    <span>Immediate Debts Due Now</span>
                    <span className="text-[10px] text-slate-500">Due within 30 days or overdue</span>
                  </label>
                  <div className="flex items-center bg-slate-950 border border-slate-700/80 rounded-xl px-3 py-2 text-xs">
                    <span className="text-slate-500 mr-2 font-mono">{currencySymbol}</span>
                    <input
                      type="number"
                      value={assets.immediateDebts || ''}
                      onChange={e => setAssets({ ...assets, immediateDebts: parseFloat(e.target.value) || 0 })}
                      placeholder="0"
                      className="w-full bg-transparent text-slate-100 outline-none font-mono text-sm"
                    />
                  </div>
                  <p className="text-[10px] text-slate-500 pt-0.5">
                    Includes credit card balances due, utility bills, and immediate monthly installments.
                  </p>
                </div>
              </div>

              {/* Real-time Calculation Result Card */}
              <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 border border-amber-500/40 rounded-2xl p-5 space-y-4 shadow-2xl relative overflow-hidden">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-400 font-mono">
                    Annual Zakat Assessment
                  </span>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                    zakatCalculations.isNisabReached
                      ? 'bg-emerald-950 text-emerald-400 border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}>
                    {zakatCalculations.isNisabReached ? 'Nisab Reached (Zakat Due)' : 'Below Nisab'}
                  </span>
                </div>

                <div>
                  <span className="text-3xl sm:text-4xl font-mono font-bold text-slate-100 block">
                    {currencySymbol}{zakatCalculations.zakatDue.toLocaleString()}
                  </span>
                  <span className="text-xs text-amber-400 font-medium">
                    Annual Obligatory Zakat (2.5% of Net Wealth)
                  </span>
                </div>

                <div className="space-y-1.5 text-xs border-t border-slate-800 pt-3">
                  <div className="flex justify-between text-slate-300">
                    <span>Total Gross Assets:</span>
                    <span className="font-mono">{currencySymbol}{zakatCalculations.totalGrossAssets.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Minus Immediate Debts:</span>
                    <span className="font-mono text-red-400">-{currencySymbol}{zakatCalculations.totalDebts.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-100 font-semibold border-t border-slate-800 pt-1">
                    <span>Net Zakatable Wealth:</span>
                    <span className="font-mono text-amber-300">{currencySymbol}{zakatCalculations.netZakatableWealth.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-400 text-[11px]">
                    <span>Current Nisab ({nisabStandard}):</span>
                    <span className="font-mono">{currencySymbol}{zakatCalculations.currentNisab.toLocaleString()}</span>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic(15);
                      setNewType('zakat');
                      setNewAmount(String(zakatCalculations.zakatDue));
                      setNewCause('Annual Zakat al-Mal');
                      setShowAddContributionModal(true);
                    }}
                    className="w-full bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs py-2 rounded-xl transition-all shadow-md shadow-amber-600/20 active:scale-95 flex items-center justify-center gap-1.5"
                  >
                    <Plus size={14} />
                    <span>Record Payment Toward This Zakat</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2.5: DEDICATED SADAQAH PLANNER & VOLUNTARY DONATION CALCULATOR */}
      {activeTab === 'sadaqah_calculator' && (() => {
        const presetVal = parseFloat(sadaqahPresetAmount) || 0;
        let annualMultiplier = 52;
        if (sadaqahFrequency === 'daily') annualMultiplier = 365;
        if (sadaqahFrequency === 'monthly') annualMultiplier = 12;
        if (sadaqahFrequency === 'annual') annualMultiplier = 1;

        const projectedAnnual = presetVal * annualMultiplier;
        const projectedMonthly = projectedAnnual / 12;

        const incomeVal = parseFloat(sadaqahMonthlyIncome) || 0;
        const targetPctVal = parseFloat(sadaqahTargetPct) || 0;
        const incomeBasedMonthlyTarget = (incomeVal * targetPctVal) / 100;
        const incomeBasedAnnualTarget = incomeBasedMonthlyTarget * 12;

        const totalVoluntarySoFar = charityStats.sadaqahPaid + charityStats.waqfPaid;
        const totalCharitySoFar = charityStats.totalGiven || 1;
        const voluntaryPctOfTotal = Math.round((totalVoluntarySoFar / totalCharitySoFar) * 100);

        const handleLogPlannerSadaqah = () => {
          if (presetVal <= 0) return;
          triggerHaptic(25);
          const record: Contribution = {
            id: `contrib_sadaqah_${Date.now()}`,
            type: 'sadaqah',
            amount: presetVal,
            currency: currencySymbol,
            cause: sadaqahCause.trim() || 'Voluntary Sadaqah',
            projectName: sadaqahCause.trim() || 'Voluntary Sadaqah',
            recipient: sadaqahRecipient.trim() || 'General Community Relief',
            date: new Date().toISOString().slice(0, 10),
            notes: `Logged via Sadaqah Planner (${sadaqahFrequency})`,
            timestamp: Date.now()
          };
          setContributions(prev => [record, ...prev]);
          queueRecordForSync(record as any, 'insert');
        };

        return (
          <div className="space-y-6 animate-fadeIn">
            {/* Spiritual Hadith Banner on Voluntary Sadaqah */}
            <div className="p-5 bg-gradient-to-r from-emerald-950/40 via-slate-900 to-amber-950/30 border border-emerald-500/30 rounded-2xl relative overflow-hidden space-y-2">
              <div className="flex items-center gap-2">
                <Heart size={16} className="text-emerald-400" />
                <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-300 font-bold">
                  The Blessings of Voluntary Sadaqah (الصدقة المستحبة)
                </span>
              </div>
              <p className="text-base sm:text-lg font-arabic text-amber-200 leading-relaxed text-right" dir="rtl">
                «الصَّدَقَةُ تُطْفِئُ الْخَطِيئَةَ كَمَا يُطْفِئُ الْمَاءُ النَّارَ»
              </p>
              <p className="text-xs text-slate-300 italic">
                "Charity extinguishes sin just as water extinguishes fire."
              </p>
              <span className="text-[10px] text-emerald-400 font-mono block">— Sunan at-Tirmidhi 614</span>
            </div>

            {/* Quick Summary Report Bar */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div className="bg-slate-900 border border-emerald-900/30 rounded-2xl p-4">
                <span className="text-[10px] text-slate-400 block">Voluntary Sadaqah YTD</span>
                <span className="font-mono text-xl font-bold text-emerald-400">{currencySymbol}{charityStats.sadaqahPaid.toLocaleString()}</span>
                <span className="text-[10px] text-slate-500 block">Separate from Zakat</span>
              </div>

              <div className="bg-slate-900 border border-pink-900/30 rounded-2xl p-4">
                <span className="text-[10px] text-slate-400 block">Sadaqah Jariyah YTD</span>
                <span className="font-mono text-xl font-bold text-pink-400">{currencySymbol}{charityStats.waqfPaid.toLocaleString()}</span>
                <span className="text-[10px] text-slate-500 block">Perpetual Endowments</span>
              </div>

              <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-4">
                <span className="text-[10px] text-slate-400 block">Compulsory Zakat YTD</span>
                <span className="font-mono text-xl font-bold text-amber-400">{currencySymbol}{charityStats.zakatPaid.toLocaleString()}</span>
                <span className="text-[10px] text-slate-500 block">Obligatory 2.5%</span>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
                <span className="text-[10px] text-slate-400 block">Voluntary Giving Ratio</span>
                <span className="font-mono text-xl font-bold text-slate-100">{voluntaryPctOfTotal}%</span>
                <span className="text-[10px] text-emerald-400 block">of Total Giving</span>
              </div>
            </div>

            {/* Planner Grid: 2 Columns */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Left Column: Recurring Micro-Donation Planner */}
              <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 space-y-4 shadow-xl">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <Heart size={18} className="text-emerald-400" />
                    <h3 className="text-sm font-bold text-slate-100">Recurring Micro-Donation Planner</h3>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Habit Building
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="text-slate-300 font-medium block mb-1">Recurring Amount ({currencySymbol}):</label>
                    <input
                      type="number"
                      min="0.1"
                      step="0.5"
                      value={sadaqahPresetAmount}
                      onChange={e => setSadaqahPresetAmount(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 p-2.5 text-slate-100 rounded-xl outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 font-medium block mb-1">Donation Frequency:</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => { triggerHaptic(10); setSadaqahFrequency('daily'); }}
                        className={`p-2 rounded-xl text-xs font-semibold border transition ${
                          sadaqahFrequency === 'daily'
                            ? 'bg-amber-600 text-slate-950 border-amber-400'
                            : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                        }`}
                      >
                        ☀️ Daily ($1/day)
                      </button>

                      <button
                        type="button"
                        onClick={() => { triggerHaptic(10); setSadaqahFrequency('weekly_friday'); }}
                        className={`p-2 rounded-xl text-xs font-semibold border transition ${
                          sadaqahFrequency === 'weekly_friday'
                            ? 'bg-amber-600 text-slate-950 border-amber-400'
                            : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                        }`}
                      >
                        🕌 Friday Jumu'ah
                      </button>

                      <button
                        type="button"
                        onClick={() => { triggerHaptic(10); setSadaqahFrequency('monthly'); }}
                        className={`p-2 rounded-xl text-xs font-semibold border transition ${
                          sadaqahFrequency === 'monthly'
                            ? 'bg-amber-600 text-slate-950 border-amber-400'
                            : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                        }`}
                      >
                        📅 Monthly
                      </button>

                      <button
                        type="button"
                        onClick={() => { triggerHaptic(10); setSadaqahFrequency('annual'); }}
                        className={`p-2 rounded-xl text-xs font-semibold border transition ${
                          sadaqahFrequency === 'annual'
                            ? 'bg-amber-600 text-slate-950 border-amber-400'
                            : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                        }`}
                      >
                        🌙 Annual / Ramadan
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="text-slate-300 font-medium block mb-1">Target Cause / Purpose:</label>
                    <input
                      type="text"
                      value={sadaqahCause}
                      onChange={e => setSadaqahCause(e.target.value)}
                      placeholder="e.g. Friday Jumu'ah Box, Water Well, Local Pantry"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 p-2 text-slate-100 rounded-xl outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 font-medium block mb-1">Recipient Organization:</label>
                    <input
                      type="text"
                      value={sadaqahRecipient}
                      onChange={e => setSadaqahRecipient(e.target.value)}
                      placeholder="e.g. Local Masjid, Relief Agency"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 p-2 text-slate-100 rounded-xl outline-none"
                    />
                  </div>
                </div>

                {/* Projection Result Card */}
                <div className="p-3.5 bg-slate-950 border border-emerald-900/40 rounded-xl space-y-2">
                  <span className="text-[10px] text-emerald-400 font-mono uppercase font-bold block">Projected Cumulative Impact</span>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">Monthly Commitment:</span>
                    <span className="font-mono font-bold text-slate-200">{currencySymbol}{projectedMonthly.toFixed(2)} / month</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">Annual Total Impact:</span>
                    <span className="font-mono font-bold text-emerald-400 text-sm">{currencySymbol}{projectedAnnual.toFixed(2)} / year</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleLogPlannerSadaqah}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs rounded-xl transition shadow-md shadow-emerald-600/20 flex items-center justify-center gap-1.5"
                >
                  <Plus size={14} />
                  <span>Log {currencySymbol}{presetVal} Voluntary Sadaqah Today</span>
                </button>
              </div>

              {/* Right Column: Income-Based Voluntary Sadaqah Recommender */}
              <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 space-y-4 shadow-xl flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2">
                      <Calculator size={18} className="text-amber-500" />
                      <h3 className="text-sm font-bold text-slate-100">Income-Based Sadaqah Recommender</h3>
                    </div>
                    <span className="text-[10px] font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                      Budgeting
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed">
                    Set aside a voluntary percentage of monthly disposable income or salary specifically for voluntary Sadaqah beyond mandatory Zakat.
                  </p>

                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="text-slate-300 font-medium block mb-1">Monthly Income / Budget ({currencySymbol}):</label>
                      <input
                        type="number"
                        value={sadaqahMonthlyIncome}
                        onChange={e => setSadaqahMonthlyIncome(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 p-2.5 text-slate-100 rounded-xl outline-none font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 font-medium block mb-1">Voluntary Giving Target Percentage:</label>
                      <div className="flex items-center gap-2">
                        {['1.0', '2.5', '5.0', '10.0'].map(pct => (
                          <button
                            key={pct}
                            type="button"
                            onClick={() => { triggerHaptic(10); setSadaqahTargetPct(pct); }}
                            className={`flex-1 py-1.5 rounded-xl text-xs font-bold border transition ${
                              sadaqahTargetPct === pct
                                ? 'bg-amber-600 text-slate-950 border-amber-400'
                                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                            }`}
                          >
                            {pct}%
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Recommendation Summary */}
                  <div className="p-4 bg-slate-950 border border-amber-900/30 rounded-2xl space-y-2">
                    <span className="text-[10px] font-mono uppercase text-amber-400 font-bold block">Recommended Voluntary Goal</span>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-400">Monthly Voluntary Sadaqah:</span>
                      <span className="font-mono font-bold text-amber-300 text-sm">{currencySymbol}{incomeBasedMonthlyTarget.toFixed(2)} / mo</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-400">Annual Voluntary Sadaqah:</span>
                      <span className="font-mono font-bold text-emerald-400 text-sm">{currencySymbol}{incomeBasedAnnualTarget.toFixed(2)} / yr</span>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-amber-950/20 border border-amber-500/20 rounded-xl text-[11px] text-slate-300 flex items-center gap-2">
                  <Sparkles size={14} className="text-amber-400 shrink-0" />
                  <span>Scholars recommend establishing a consistent routine for voluntary Sadaqah, even if small, as Allah loves deeds that are continuous.</span>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* TAB 3: SADAQAH JARIYAH (ONGOING CHARITY) INITIATIVES */}
      {activeTab === 'sadaqah_jariyah' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Spiritual Hadith Banner on Perpetual Charity */}
          <div className="p-5 bg-gradient-to-r from-pink-950/40 via-slate-900 to-amber-950/30 border border-pink-500/30 rounded-2xl relative overflow-hidden space-y-2">
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-pink-400" />
              <span className="text-[10px] font-mono uppercase tracking-wider text-pink-300 font-bold">
                The Virtue of Ceaseless Charity (الصدقة الجارية)
              </span>
            </div>
            <p className="text-base sm:text-lg font-arabic text-amber-200 leading-relaxed text-right" dir="rtl">
              «إِذَا مَاتَ الإِنْسَانُ انْقَطَعَ عَنْهُ عَمَلُهُ إِلاَّ مِنْ ثَلاَثَةٍ: إِلاَّ مِنْ صَدَقَةٍ جَارِيَةٍ، أَوْ عِلْمٍ يُنْتَفَعُ بِهِ، أَوْ وَلَدٍ صَالِحٍ يَدْعُو لَهُ»
            </p>
            <p className="text-xs text-slate-300 italic">
              "When a human being dies, his deeds come to an end except for three: Sadaqah Jariyah (ongoing charity), knowledge from which benefit is gained, or a righteous child who prays for him."
            </p>
            <span className="text-[10px] text-pink-400 font-mono block">— Sahih Muslim 1631</span>
          </div>

          {/* Quick Metrics Bar & New Project Button */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-900 border border-amber-900/30 rounded-2xl">
            <div className="grid grid-cols-3 gap-4 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 block">Total Funded</span>
                <span className="font-mono text-base font-bold text-pink-400">
                  {currencySymbol}{jariyahMetrics.totalFunded.toLocaleString()}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">Combined Target</span>
                <span className="font-mono text-base font-bold text-slate-200">
                  {currencySymbol}{jariyahMetrics.totalTarget.toLocaleString()}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">Milestones Completed</span>
                <span className="font-mono text-base font-bold text-emerald-400">
                  {jariyahMetrics.completedCount} / {projects.length}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                triggerHaptic(15);
                setShowAddProjectModal(true);
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-pink-600 hover:bg-pink-500 text-slate-950 font-bold text-xs self-start sm:self-auto shadow-md shadow-pink-600/20 active:scale-95 transition-all"
            >
              <Plus size={15} />
              <span>Start New Initiative</span>
            </button>
          </div>

          {/* Filter Pills */}
          <div className="flex gap-2 text-xs">
            <button
              type="button"
              onClick={() => setJariyahFilter('all')}
              className={`px-3 py-1.5 rounded-xl font-medium transition-colors ${
                jariyahFilter === 'all'
                  ? 'bg-pink-600 text-slate-950 font-bold'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              All Initiatives ({projects.length})
            </button>
            <button
              type="button"
              onClick={() => setJariyahFilter('in_progress')}
              className={`px-3 py-1.5 rounded-xl font-medium transition-colors ${
                jariyahFilter === 'in_progress'
                  ? 'bg-pink-600 text-slate-950 font-bold'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              In Progress ({jariyahMetrics.inProgressCount})
            </button>
            <button
              type="button"
              onClick={() => setJariyahFilter('completed')}
              className={`px-3 py-1.5 rounded-xl font-medium transition-colors ${
                jariyahFilter === 'completed'
                  ? 'bg-pink-600 text-slate-950 font-bold'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              Completed ({jariyahMetrics.completedCount})
            </button>
          </div>

          {/* Projects Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredProjects.map(proj => {
              const catConf = JARIYAH_CATEGORIES[proj.category] || JARIYAH_CATEGORIES.custom;
              const IconComp = catConf.icon;
              const pct = Math.min(100, Math.round((proj.currentAmount / (proj.targetAmount || 1)) * 100));
              const isCompleted = proj.status === 'completed' || proj.currentAmount >= proj.targetAmount;
              const remaining = Math.max(0, proj.targetAmount - proj.currentAmount);

              return (
                <div
                  key={proj.id}
                  className={`bg-slate-900 border rounded-2xl p-5 flex flex-col justify-between space-y-4 shadow-xl transition-all duration-300 relative overflow-hidden ${
                    isCompleted
                      ? 'border-emerald-500/40 bg-gradient-to-br from-slate-900 to-emerald-950/20'
                      : 'border-pink-900/30 hover:border-pink-500/50'
                  }`}
                >
                  {/* Top Bar: Icon, Category & Actions */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span 
                        className="p-3 rounded-2xl border"
                        style={{ 
                          backgroundColor: `${catConf.color}15`,
                          borderColor: `${catConf.color}35`,
                          color: catConf.color 
                        }}
                      >
                        <IconComp size={20} />
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <span 
                            className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-md border font-semibold"
                            style={{ 
                              backgroundColor: `${catConf.color}15`,
                              borderColor: `${catConf.color}35`,
                              color: catConf.color 
                            }}
                          >
                            {catConf.label}
                          </span>
                          {isCompleted ? (
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/40 font-bold flex items-center gap-1">
                              <CheckCircle2 size={11} /> Fully Funded
                            </span>
                          ) : (
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                              Active
                            </span>
                          )}
                        </div>
                        <h4 className="text-base font-bold text-slate-100 mt-1">
                          {proj.title}
                        </h4>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDeleteProject(proj.id)}
                      className="p-1.5 text-slate-500 hover:text-red-400 rounded-lg hover:bg-slate-800 transition-colors"
                      title="Delete initiative"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>

                  {/* Dedication or Notes */}
                  {proj.dedication && (
                    <div className="p-2.5 bg-slate-950/60 rounded-xl border border-slate-800/80 text-xs text-amber-200/90 flex items-start gap-2">
                      <Heart size={14} className="text-pink-400 flex-shrink-0 mt-0.5" />
                      <span>Dedicated: <em>"{proj.dedication}"</em></span>
                    </div>
                  )}

                  {proj.notes && (
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {proj.notes}
                    </p>
                  )}

                  {/* Financial Progress Bar */}
                  <div className="space-y-1.5 pt-1">
                    <div className="flex items-baseline justify-between">
                      <span className="text-xl font-mono font-bold text-slate-100">
                        {currencySymbol}{proj.currentAmount.toLocaleString()}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">
                        Target: {currencySymbol}{proj.targetAmount.toLocaleString()}
                      </span>
                    </div>

                    <div className="w-full bg-slate-800 rounded-full h-2.5 overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-500 ${
                          isCompleted ? 'bg-emerald-500' : 'bg-pink-500'
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>

                    <div className="flex justify-between items-center text-[11px] font-mono text-slate-400">
                      <span>{pct}% Raised</span>
                      <span className={isCompleted ? 'text-emerald-400 font-bold' : 'text-slate-300'}>
                        {isCompleted ? '✓ Target Achieved' : `${currencySymbol}${remaining.toLocaleString()} needed`}
                      </span>
                    </div>
                  </div>

                  {/* Organization & Contribute Button */}
                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                    <span className="text-[11px] text-slate-400 truncate max-w-[150px]">
                      Org: <strong className="text-slate-300">{proj.organization}</strong>
                    </span>

                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic(15);
                        setContributeToProject(proj);
                      }}
                      className="px-3.5 py-1.5 rounded-xl bg-pink-600/20 hover:bg-pink-600 text-pink-300 hover:text-slate-950 border border-pink-500/40 text-xs font-bold transition-all active:scale-95 flex items-center gap-1.5"
                    >
                      <Plus size={13} />
                      <span>Log Contribution</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredProjects.length === 0 && (
            <div className="p-10 bg-slate-900/60 border border-slate-800 rounded-2xl text-center space-y-2">
              <Layers size={32} className="mx-auto text-pink-500/50" />
              <p className="text-sm font-semibold text-slate-200">No projects found in this filter</p>
              <p className="text-xs text-slate-400">Click "Start New Initiative" to begin tracking a perpetual charitable project.</p>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: HISTORICAL LOG & CHARITY JOURNEY VIEW */}
      {activeTab === 'history' && (
        <div className="space-y-5 animate-fadeIn">
          {/* Top Charity Journey Lifetime Banner */}
          <div className="bg-gradient-to-r from-amber-950/30 via-slate-900 to-indigo-950/30 border border-amber-900/30 rounded-2xl p-4 sm:p-5 shadow-xl space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                  <Milestone size={18} className="text-amber-500" />
                  Your Charitable Journey Over Time
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Historical log of all donations, zakat disbursements, and long-term project contributions
                </p>
              </div>

              <div className="flex items-center gap-2 self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic(15);
                    setShowReportModal(true);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-amber-900/40 hover:border-amber-500/60 text-amber-400 hover:text-amber-300 font-semibold text-xs shadow-md transition-all active:scale-95"
                >
                  <Download size={14} />
                  <span>Annual Report</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic(15);
                    setShowAddContributionModal(true);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs shadow-md active:scale-95"
                >
                  <Plus size={14} />
                  <span>Record Giving</span>
                </button>
              </div>
            </div>

            {/* Journey Stats Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Lifetime Impact</span>
                <span className="font-mono text-base font-bold text-amber-400">
                  {currencySymbol}{journeyStats.lifetimeTotal.toLocaleString()}
                </span>
              </div>
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Total Deeds Logged</span>
                <span className="font-mono text-base font-bold text-slate-200">
                  {journeyStats.deedsCount} contributions
                </span>
              </div>
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Projects Supported</span>
                <span className="font-mono text-base font-bold text-pink-400">
                  {journeyStats.projectsCount} initiatives
                </span>
              </div>
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Journey Timeline</span>
                <span className="font-mono text-xs font-semibold text-emerald-400 truncate block mt-0.5">
                  {journeyStats.firstDate ? `${journeyStats.firstDate} → Present` : 'Starting Today'}
                </span>
              </div>
            </div>
          </div>

          {/* Search, Filter & View Controls Bar */}
          <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-4 space-y-3 shadow-lg">
            <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
              {/* Search by project name, cause, recipient */}
              <div className="relative flex-1">
                <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={historySearch}
                  onChange={e => setHistorySearch(e.target.value)}
                  placeholder="Search by project name, cause, recipient, or notes..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-500 outline-none focus:border-amber-500 shadow-inner"
                />
              </div>

              {/* View Switcher & Sorting */}
              <div className="flex items-center gap-2 self-end md:self-auto">
                {/* Sort selector */}
                <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl px-2 py-1.5 text-xs text-slate-300">
                  <ArrowUpDown size={13} className="text-amber-500 mr-1.5" />
                  <select
                    value={historySort}
                    onChange={e => setHistorySort(e.target.value as any)}
                    className="bg-transparent outline-none text-xs text-slate-300 font-medium cursor-pointer"
                  >
                    <option value="newest">Newest First</option>
                    <option value="oldest">Oldest First</option>
                    <option value="amount_high">Highest Amount</option>
                    <option value="amount_low">Lowest Amount</option>
                  </select>
                </div>

                {/* View Mode Toggle: Table vs Timeline vs Cards */}
                <div className="flex bg-slate-950 border border-slate-800 rounded-xl p-0.5 text-xs">
                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic(10);
                      setHistoryViewMode('table');
                    }}
                    className={`px-2.5 py-1 rounded-lg font-medium transition-colors flex items-center gap-1 ${
                      historyViewMode === 'table'
                        ? 'bg-amber-600 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                    title="Itemized Table Log View"
                  >
                    <List size={13} />
                    <span className="hidden sm:inline">Table Log</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic(10);
                      setHistoryViewMode('timeline');
                    }}
                    className={`px-2.5 py-1 rounded-lg font-medium transition-colors flex items-center gap-1 ${
                      historyViewMode === 'timeline'
                        ? 'bg-amber-600 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                    title="Journey Timeline View"
                  >
                    <Milestone size={13} />
                    <span className="hidden sm:inline">Timeline</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic(10);
                      setHistoryViewMode('cards');
                    }}
                    className={`px-2.5 py-1 rounded-lg font-medium transition-colors flex items-center gap-1 ${
                      historyViewMode === 'cards'
                        ? 'bg-amber-600 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                    title="Cards View"
                  >
                    <Layers size={13} />
                    <span className="hidden sm:inline">Cards</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Category Filter Pills */}
            <div className="flex gap-1.5 overflow-x-auto pb-0.5 text-xs scrollbar-none">
              <button
                type="button"
                onClick={() => setHistoryFilter('all')}
                className={`px-3 py-1 rounded-xl font-medium transition-colors whitespace-nowrap ${
                  historyFilter === 'all'
                    ? 'bg-amber-600 text-slate-950 font-bold'
                    : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                All Categories ({contributions.length})
              </button>
              {(Object.keys(CHARITY_TYPE_LABELS) as CharityType[]).map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setHistoryFilter(t)}
                  className={`px-3 py-1 rounded-xl font-medium transition-colors whitespace-nowrap ${
                    historyFilter === t
                      ? 'bg-amber-600 text-slate-950 font-bold'
                      : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {CHARITY_TYPE_LABELS[t].label}
                </button>
              ))}
            </div>
          </div>

          {/* VIEW MODE 1: HISTORICAL TABLE LOG VIEW */}
          {historyViewMode === 'table' && (
            <div className="bg-slate-900 border border-amber-900/30 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-950 border-b border-slate-800 text-[11px] font-mono text-slate-400">
                      <th className="p-3.5">Date</th>
                      <th className="p-3.5">Project Name / Initiative</th>
                      <th className="p-3.5">Category</th>
                      <th className="p-3.5">Recipient / Org</th>
                      <th className="p-3.5 text-right">Amount</th>
                      <th className="p-3.5 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {filteredContributions.map(item => {
                      const typeConf = CHARITY_TYPE_LABELS[item.type] || CHARITY_TYPE_LABELS.sadaqah;
                      const projectNameDisplay = item.projectName || item.cause;

                      return (
                        <tr key={item.id} className="hover:bg-slate-950/40 transition-colors">
                          <td className="p-3.5 font-mono text-slate-300 font-semibold whitespace-nowrap">
                            {item.date}
                          </td>
                          <td className="p-3.5">
                            <span className="font-bold text-slate-100 block">
                              {projectNameDisplay}
                            </span>
                            {item.cause !== projectNameDisplay && (
                              <span className="text-[11px] text-slate-400 block">{item.cause}</span>
                            )}
                            {item.notes && (
                              <span className="text-[10px] text-slate-500 italic block mt-0.5">
                                "{item.notes}"
                              </span>
                            )}
                          </td>
                          <td className="p-3.5 whitespace-nowrap">
                            <span 
                              className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-md border font-semibold inline-block"
                              style={{ 
                                backgroundColor: `${typeConf.color}15`, 
                                borderColor: `${typeConf.color}35`, 
                                color: typeConf.color 
                              }}
                            >
                              {typeConf.label}
                            </span>
                          </td>
                          <td className="p-3.5 text-slate-300 whitespace-nowrap">
                            {item.recipient}
                          </td>
                          <td className="p-3.5 text-right whitespace-nowrap">
                            <span className="font-mono text-sm font-bold text-amber-300">
                              {item.currency}{item.amount.toLocaleString()}
                            </span>
                          </td>
                          <td className="p-3.5 text-center whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => handleDeleteContribution(item.id)}
                              className="p-1.5 text-slate-500 hover:text-red-400 hover:bg-slate-800 rounded-lg transition-colors"
                              title="Delete record"
                            >
                              <Trash2 size={14} />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {filteredContributions.length === 0 && (
                <div className="p-8 text-center text-slate-400 space-y-1">
                  <p className="text-sm font-semibold text-slate-200">No contributions match your filters</p>
                  <p className="text-xs text-slate-500">Try adjusting your search query or category filter.</p>
                </div>
              )}
            </div>
          )}

          {/* VIEW MODE 2: CHRONOLOGICAL TIMELINE VIEW */}
          {historyViewMode === 'timeline' && (
            <div className="bg-slate-900 border border-amber-900/30 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6">
              <div className="relative pl-6 sm:pl-8 border-l-2 border-amber-500/30 space-y-6 ml-3 sm:ml-4">
                {filteredContributions.map(item => {
                  const typeConf = CHARITY_TYPE_LABELS[item.type] || CHARITY_TYPE_LABELS.sadaqah;
                  const projectNameDisplay = item.projectName || item.cause;
                  const formattedDate = new Date(item.date).toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric'
                  });

                  return (
                    <div key={item.id} className="relative group">
                      {/* Timeline Node Dot */}
                      <span 
                        className="absolute -left-[31px] sm:-left-[39px] top-1.5 w-4 h-4 rounded-full border-2 border-slate-900 flex items-center justify-center shadow-md"
                        style={{ backgroundColor: typeConf.color }}
                      />

                      {/* Content Card */}
                      <div className="bg-slate-950/70 border border-slate-800 hover:border-amber-700/50 rounded-xl p-4 transition-all space-y-2">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono font-bold text-slate-300">
                              {formattedDate}
                            </span>
                            <span 
                              className="text-[10px] font-mono uppercase px-2 py-0.5 rounded border font-semibold"
                              style={{ 
                                backgroundColor: `${typeConf.color}15`, 
                                borderColor: `${typeConf.color}35`, 
                                color: typeConf.color 
                              }}
                            >
                              {typeConf.label}
                            </span>
                          </div>

                          <span className="font-mono text-base font-bold text-amber-300">
                            {item.currency}{item.amount.toLocaleString()}
                          </span>
                        </div>

                        <div>
                          <h4 className="text-sm font-bold text-slate-100">
                            {projectNameDisplay}
                          </h4>
                          {item.cause !== projectNameDisplay && (
                            <p className="text-xs text-slate-400 mt-0.5">{item.cause}</p>
                          )}
                        </div>

                        <div className="flex items-center justify-between text-xs text-slate-400 pt-1 border-t border-slate-800/80">
                          <span>Recipient: <strong className="text-slate-300">{item.recipient}</strong></span>
                          {item.notes && <span className="italic text-slate-400 truncate max-w-[200px]">"{item.notes}"</span>}
                          <button
                            type="button"
                            onClick={() => handleDeleteContribution(item.id)}
                            className="p-1 text-slate-500 hover:text-red-400 transition-colors"
                            title="Delete"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {filteredContributions.length === 0 && (
                <div className="p-8 text-center text-slate-400 space-y-1">
                  <p className="text-sm font-semibold text-slate-200">No contributions match your filters</p>
                  <p className="text-xs text-slate-500">Try adjusting your search query or category filter.</p>
                </div>
              )}
            </div>
          )}

          {/* VIEW MODE 3: CARDS VIEW */}
          {historyViewMode === 'cards' && (
            <div className="space-y-3">
              {filteredContributions.map(item => {
                const typeConf = CHARITY_TYPE_LABELS[item.type] || CHARITY_TYPE_LABELS.sadaqah;
                const projectNameDisplay = item.projectName || item.cause;
                const formattedDate = new Date(item.date).toLocaleDateString('en-US', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric'
                });

                return (
                  <div
                    key={item.id}
                    className="group bg-slate-900 border border-amber-900/30 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg hover:border-amber-700/50 transition-all"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span 
                          className="w-2.5 h-2.5 rounded-full inline-block" 
                          style={{ backgroundColor: typeConf.color }} 
                        />
                        <span className="text-xs font-mono font-bold uppercase tracking-wider" style={{ color: typeConf.color }}>
                          {typeConf.label}
                        </span>
                        <span className="text-slate-500 text-xs font-mono">· {formattedDate}</span>
                      </div>

                      <h4 className="text-base font-bold text-slate-100">
                        {projectNameDisplay}
                      </h4>

                      <div className="flex items-center gap-2 text-xs text-slate-400">
                        <span>Recipient: <strong className="text-slate-300">{item.recipient}</strong></span>
                        {item.notes && (
                          <>
                            <span>·</span>
                            <span className="italic">"{item.notes}"</span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-4 self-stretch sm:self-auto pt-2 sm:pt-0 border-t sm:border-0 border-slate-800">
                      <div className="text-left sm:text-right">
                        <span className="text-xl sm:text-2xl font-mono font-bold text-slate-100">
                          {item.currency}{item.amount.toLocaleString()}
                        </span>
                        <span className="text-[10px] text-slate-500 block">Recorded Contribution</span>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleDeleteContribution(item.id)}
                        className="p-2 text-slate-500 hover:text-red-400 hover:bg-slate-800 rounded-xl transition-colors"
                        title="Delete contribution record"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                );
              })}

              {filteredContributions.length === 0 && (
                <div className="p-8 bg-slate-900/60 border border-slate-800 rounded-2xl text-center space-y-2">
                  <Coins size={32} className="mx-auto text-amber-500/50" />
                  <p className="text-xs font-semibold text-slate-200">No contributions found</p>
                  <p className="text-[11px] text-slate-400">Try changing your filters or tap "Record Giving".</p>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* MODAL 1: RECORD GENERAL GIVING */}
      {showAddContributionModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-5 sm:p-6 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Coins size={18} className="text-amber-500" />
                Record Charitable Giving
              </h3>
              <button
                type="button"
                onClick={() => setShowAddContributionModal(false)}
                className="text-slate-400 hover:text-slate-200 text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddContribution} className="space-y-3.5 text-xs">
              {/* Type Selection */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Giving Type:</label>
                <div className="grid grid-cols-2 gap-2">
                  {(Object.keys(CHARITY_TYPE_LABELS) as CharityType[]).map(t => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => {
                        triggerHaptic(10);
                        setNewType(t);
                      }}
                      className={`p-2 rounded-xl text-left border transition-all text-xs ${
                        newType === t
                          ? 'bg-amber-600/20 border-amber-500 text-amber-300 font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div>{CHARITY_TYPE_LABELS[t].label}</div>
                      <div className="text-[10px] text-slate-500 font-serif" dir="rtl">{CHARITY_TYPE_LABELS[t].arabic}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Amount */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Amount ({currencySymbol}):</label>
                <div className="flex items-center bg-slate-950 border border-slate-700 rounded-xl px-3 py-2">
                  <span className="text-slate-500 mr-2 font-mono">{currencySymbol}</span>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={newAmount}
                    onChange={e => setNewAmount(e.target.value)}
                    placeholder="e.g. 250"
                    className="w-full bg-transparent text-slate-100 outline-none font-mono text-sm font-bold"
                    autoFocus
                  />
                </div>
              </div>

              {/* Project / Initiative Name */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Project Name / Initiative:</label>
                <input
                  type="text"
                  value={newProjectName}
                  onChange={e => setNewProjectName(e.target.value)}
                  placeholder="e.g. Clean Water Initiative, Orphan Fund, Masjid Project"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 outline-none focus:border-amber-500"
                />
              </div>

              {/* Cause / Purpose */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Cause / Specific Purpose:</label>
                <input
                  type="text"
                  required
                  value={newCause}
                  onChange={e => setNewCause(e.target.value)}
                  placeholder="e.g. Orphan Sponsorship, Water Well, Food Basket"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 outline-none focus:border-amber-500"
                />
              </div>

              {/* Recipient / Charity */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Recipient / Organization:</label>
                <input
                  type="text"
                  value={newRecipient}
                  onChange={e => setNewRecipient(e.target.value)}
                  placeholder="e.g. Local Mosque, Islamic Relief, Needy Neighbor"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 outline-none focus:border-amber-500"
                />
              </div>

              {/* Date */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Date Given:</label>
                <input
                  type="date"
                  value={newDate}
                  onChange={e => setNewDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 outline-none focus:border-amber-500"
                />
              </div>

              {/* Notes */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Personal Note / Intention (Optional):</label>
                <input
                  type="text"
                  value={newNotes}
                  onChange={e => setNewNotes(e.target.value)}
                  placeholder="e.g. In memory of loved ones, Friday blessing"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 outline-none focus:border-amber-500"
                />
              </div>

              {/* Form Buttons */}
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddContributionModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-slate-400 hover:text-slate-200 text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs shadow-md shadow-amber-600/20 active:scale-95"
                >
                  Save Contribution
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: START NEW SADAQAH JARIYAH PROJECT */}
      {showAddProjectModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-pink-500/40 rounded-2xl p-5 sm:p-6 w-full max-w-lg shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Layers size={18} className="text-pink-400" />
                Start Sadaqah Jariyah Initiative
              </h3>
              <button
                type="button"
                onClick={() => setShowAddProjectModal(false)}
                className="text-slate-400 hover:text-slate-200 text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateProject} className="space-y-3.5 text-xs">
              {/* Category Selector Grid */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Initiative Category:</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(Object.keys(JARIYAH_CATEGORIES) as JariyahCategory[]).map(cat => {
                    const c = JARIYAH_CATEGORIES[cat];
                    const Icon = c.icon;
                    const isSel = projCategory === cat;

                    return (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => {
                          triggerHaptic(10);
                          setProjCategory(cat);
                          setProjTarget(String(c.defaultTarget));
                        }}
                        className={`p-2 rounded-xl text-left border transition-all flex flex-col justify-between h-16 ${
                          isSel
                            ? 'bg-pink-600/20 border-pink-500 text-pink-300 font-bold'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        <Icon size={16} style={{ color: c.color }} />
                        <span className="text-[11px] truncate">{c.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Title */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Project Name / Title:</label>
                <input
                  type="text"
                  required
                  value={projTitle}
                  onChange={e => setProjTitle(e.target.value)}
                  placeholder="e.g. Village Solar Water Pump, Quran Printing for Students"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 outline-none focus:border-pink-500"
                />
              </div>

              {/* Target Amount */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Target Amount ({currencySymbol}):</label>
                <div className="flex items-center bg-slate-950 border border-slate-700 rounded-xl px-3 py-2">
                  <span className="text-slate-500 mr-2 font-mono">{currencySymbol}</span>
                  <input
                    type="number"
                    step="1"
                    required
                    value={projTarget}
                    onChange={e => setProjTarget(e.target.value)}
                    placeholder="e.g. 1500"
                    className="w-full bg-transparent text-slate-100 outline-none font-mono text-sm font-bold"
                  />
                </div>
              </div>

              {/* Dedicated For */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Dedication / Intention (Optional):</label>
                <input
                  type="text"
                  value={projDedication}
                  onChange={e => setProjDedication(e.target.value)}
                  placeholder="e.g. In loving memory of my beloved mother (رحمها الله)"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 outline-none focus:border-pink-500"
                />
              </div>

              {/* Organization & Target Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-medium">Implementing Charity / Org:</label>
                  <input
                    type="text"
                    value={projOrg}
                    onChange={e => setProjOrg(e.target.value)}
                    placeholder="e.g. Islamic Relief, Muslim Hands"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 outline-none focus:border-pink-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-300 font-medium">Target Completion Date:</label>
                  <input
                    type="date"
                    value={projTargetDate}
                    onChange={e => setProjTargetDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 outline-none focus:border-pink-500"
                  />
                </div>
              </div>

              {/* Notes */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Beneficiary / Project Details:</label>
                <textarea
                  rows={2}
                  value={projNotes}
                  onChange={e => setProjNotes(e.target.value)}
                  placeholder="e.g. Will provide daily clean drinking water to over 300 families in rural community."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 outline-none focus:border-pink-500"
                />
              </div>

              {/* Buttons */}
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddProjectModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-slate-400 hover:text-slate-200 text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-pink-600 hover:bg-pink-500 text-slate-950 font-bold text-xs shadow-md shadow-pink-600/20 active:scale-95"
                >
                  Create Initiative
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: LOG CONTRIBUTION DIRECTLY TO SADAQAH JARIYAH PROJECT */}
      {contributeToProject && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-pink-500/40 rounded-2xl p-5 sm:p-6 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                  <Layers size={18} className="text-pink-400" />
                  Contribute to Initiative
                </h3>
                <span className="text-xs text-pink-300 block truncate max-w-[280px]">
                  {contributeToProject.title}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setContributeToProject(null)}
                className="text-slate-400 hover:text-slate-200 text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleProjectContribution} className="space-y-3.5 text-xs">
              {/* Target vs Current overview */}
              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl space-y-1">
                <div className="flex justify-between text-slate-400">
                  <span>Current Progress:</span>
                  <span className="font-mono text-slate-200 font-bold">
                    {currencySymbol}{contributeToProject.currentAmount.toLocaleString()} / {currencySymbol}{contributeToProject.targetAmount.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Remaining to Goal:</span>
                  <span className="font-mono text-pink-400 font-bold">
                    {currencySymbol}{Math.max(0, contributeToProject.targetAmount - contributeToProject.currentAmount).toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Amount */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Contribution Amount ({currencySymbol}):</label>
                <div className="flex items-center bg-slate-950 border border-slate-700 rounded-xl px-3 py-2">
                  <span className="text-slate-500 mr-2 font-mono">{currencySymbol}</span>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={projContribAmount}
                    onChange={e => setProjContribAmount(e.target.value)}
                    placeholder="e.g. 100"
                    className="w-full bg-transparent text-slate-100 outline-none font-mono text-sm font-bold"
                    autoFocus
                  />
                </div>
              </div>

              {/* Date */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Date Given:</label>
                <input
                  type="date"
                  value={projContribDate}
                  onChange={e => setProjContribDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 outline-none focus:border-pink-500"
                />
              </div>

              {/* Personal Note */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Note / Specific Installment:</label>
                <input
                  type="text"
                  value={projContribNotes}
                  onChange={e => setProjContribNotes(e.target.value)}
                  placeholder="e.g. Part 2 of family well pledge"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 outline-none focus:border-pink-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setContributeToProject(null)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-slate-400 hover:text-slate-200 text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-pink-600 hover:bg-pink-500 text-slate-950 font-bold text-xs shadow-md shadow-pink-600/20 active:scale-95"
                >
                  Save & Update Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: FISCAL YEAR REPORT & DOWNLOAD SUMMARY */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-5 sm:p-6 w-full max-w-2xl shadow-2xl space-y-4 max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 flex-shrink-0">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  <FileText size={18} />
                </span>
                <div>
                  <h3 className="text-base font-bold text-slate-100">
                    Fiscal Year Charitable Report
                  </h3>
                  <span className="text-xs text-slate-400">
                    Downloadable statement for tax deduction, personal records, and Zakat verification
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowReportModal(false)}
                className="text-slate-400 hover:text-slate-200 text-sm p-1 rounded-lg hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            {/* Fiscal Year Selector & Download Buttons Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-slate-950/80 rounded-xl border border-slate-800 flex-shrink-0">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-300">Fiscal Period:</span>
                <select
                  value={reportFiscalYear}
                  onChange={(e) => {
                    const val = e.target.value === 'all' ? 'all' : parseInt(e.target.value, 10);
                    setReportFiscalYear(val);
                  }}
                  className="bg-slate-900 border border-amber-500/40 text-amber-300 text-xs py-1.5 px-3 rounded-lg outline-none font-mono font-bold"
                >
                  {availableFiscalYears.map(y => (
                    <option key={y} value={y}>Fiscal Year {y}</option>
                  ))}
                  <option value="all">All-Time Cumulative</option>
                </select>
              </div>

              {/* Action Buttons: Download TXT and Print/Save as PDF */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleDownloadTextSummary}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-semibold border border-slate-700 transition-colors active:scale-95"
                  title="Download plain text statement (.txt)"
                >
                  <Download size={14} className="text-amber-500" />
                  <span>Download .TXT</span>
                </button>

                <button
                  type="button"
                  onClick={handlePrintOrPdf}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-bold transition-all shadow-md active:scale-95"
                  title="Print or Save official PDF Statement"
                >
                  <Printer size={14} />
                  <span>Print / Save PDF</span>
                </button>
              </div>
            </div>

            {/* Report Scrollable Preview */}
            <div className="flex-1 overflow-y-auto pr-1 space-y-4 text-xs font-sans">
              {/* Executive Summary Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-center">
                  <span className="text-[10px] uppercase text-slate-400 font-semibold block">Total Giving</span>
                  <span className="font-mono text-base font-bold text-slate-100">
                    {currencySymbol}{fiscalSummary.total.toLocaleString()}
                  </span>
                </div>
                <div className="p-3 bg-slate-950/60 rounded-xl border border-amber-900/30 text-center">
                  <span className="text-[10px] uppercase text-amber-400 font-semibold block">Zakat al-Mal</span>
                  <span className="font-mono text-base font-bold text-amber-400">
                    {currencySymbol}{fiscalSummary.zakat.toLocaleString()}
                  </span>
                </div>
                <div className="p-3 bg-slate-950/60 rounded-xl border border-emerald-950 text-center">
                  <span className="text-[10px] uppercase text-emerald-400 font-semibold block">Sadaqah</span>
                  <span className="font-mono text-base font-bold text-emerald-400">
                    {currencySymbol}{fiscalSummary.sadaqah.toLocaleString()}
                  </span>
                </div>
                <div className="p-3 bg-slate-950/60 rounded-xl border border-pink-950 text-center">
                  <span className="text-[10px] uppercase text-pink-400 font-semibold block">Sadaqah Jariyah</span>
                  <span className="font-mono text-base font-bold text-pink-400">
                    {currencySymbol}{fiscalSummary.waqf.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Zakat Compliance Snapshot */}
              <div className="p-3.5 bg-slate-950/60 rounded-xl border border-amber-900/20 space-y-2">
                <span className="font-bold text-amber-300 block text-xs">
                  Zakat Assessment Baseline:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-slate-300">
                  <div>
                    <span className="text-slate-500 block">Nisab Standard:</span>
                    <span className="font-mono font-semibold">{nisabStandard.toUpperCase()} ({currencySymbol}{zakatCalculations.currentNisab.toLocaleString()})</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Net Zakatable Wealth:</span>
                    <span className="font-mono font-semibold">{currencySymbol}{zakatCalculations.netZakatableWealth.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">2.5% Zakat Due:</span>
                    <span className="font-mono font-semibold text-amber-400">{currencySymbol}{zakatCalculations.zakatDue.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Zakat Status:</span>
                    <span className="font-semibold text-emerald-400">
                      {fiscalSummary.zakat >= zakatCalculations.zakatDue && zakatCalculations.zakatDue > 0 ? '✓ Fulfilled' : 'Discharged'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Itemized Table Preview */}
              <div className="space-y-2">
                <span className="font-bold text-slate-200 block text-xs">
                  Itemized Donations for {reportFiscalYear === 'all' ? 'All Years' : `Fiscal Year ${reportFiscalYear}`} ({fiscalContributions.length})
                </span>

                <div className="border border-slate-800 rounded-xl overflow-hidden">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-950 border-b border-slate-800 text-[11px] font-mono text-slate-400">
                        <th className="p-2.5">Date</th>
                        <th className="p-2.5">Category</th>
                        <th className="p-2.5">Cause & Recipient</th>
                        <th className="p-2.5 text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {fiscalContributions.map(c => (
                        <tr key={c.id} className="hover:bg-slate-950/40">
                          <td className="p-2.5 font-mono text-slate-400 text-[11px]">{c.date}</td>
                          <td className="p-2.5">
                            <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/20">
                              {c.type}
                            </span>
                          </td>
                          <td className="p-2.5 text-slate-200">
                            <strong>{c.cause}</strong>
                            <span className="text-slate-400 block text-[11px]">{c.recipient}</span>
                          </td>
                          <td className="p-2.5 text-right font-mono font-bold text-slate-100">
                            {currencySymbol}{c.amount.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                      {fiscalContributions.length === 0 && (
                        <tr>
                          <td colSpan={4} className="p-6 text-center text-slate-500">
                            No contributions recorded for this fiscal year.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs flex-shrink-0">
              <span className="text-[11px] text-slate-500 italic">
                Suitable for Islamic tax deductibility and annual charitable accounting.
              </span>
              <button
                type="button"
                onClick={() => setShowReportModal(false)}
                className="px-4 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
