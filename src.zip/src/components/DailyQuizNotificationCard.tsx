import React, { useState, useEffect } from 'react';
import { 
  HelpCircle, 
  Bell, 
  Clock, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Check, 
  Send, 
  Award, 
  ShieldCheck, 
  Flame,
  AlertCircle 
} from 'lucide-react';
import { 
  getQuizReminderPreferences, 
  saveQuizReminderPreferences, 
  showDailyQuizNotification,
  QuizReminderPreferences 
} from '../lib/quizScheduler';
import { 
  getNotificationPermission, 
  requestNotificationPermission, 
  isNotificationSupported,
  NotificationPermissionState 
} from '../lib/notifications';
import { triggerHaptic, triggerSuccessHaptic, triggerButtonClickHaptic } from '../lib/haptics';

const TIME_PRESETS = [
  { label: '06:00 PM', value: '18:00', desc: 'After Maghrib' },
  { label: '08:00 PM', value: '20:00', desc: 'Evening (Default)' },
  { label: '09:30 PM', value: '21:30', desc: 'After Isha' },
  { label: '10:30 PM', value: '22:30', desc: 'Night Review' }
];

export default function DailyQuizNotificationCard() {
  const [prefs, setPrefs] = useState<QuizReminderPreferences>(() => getQuizReminderPreferences());
  const [permission, setPermission] = useState<NotificationPermissionState>(getNotificationPermission);
  const [testSent, setTestSent] = useState(false);
  const [feedbackNotice, setFeedbackNotice] = useState<string | null>(null);

  useEffect(() => {
    const handleUpdate = (e: Event) => {
      const customEvent = e as CustomEvent<QuizReminderPreferences>;
      if (customEvent.detail) {
        setPrefs(customEvent.detail);
      } else {
        setPrefs(getQuizReminderPreferences());
      }
    };

    const handlePerm = () => {
      setPermission(getNotificationPermission());
    };

    window.addEventListener('quiz-reminder-prefs-updated', handleUpdate);
    window.addEventListener('notification-permission-changed', handlePerm);
    return () => {
      window.removeEventListener('quiz-reminder-prefs-updated', handleUpdate);
      window.removeEventListener('notification-permission-changed', handlePerm);
    };
  }, []);

  const handleToggleEnabled = async () => {
    triggerButtonClickHaptic();
    const nextState = !prefs.enabled;

    if (nextState && permission !== 'granted') {
      const granted = await requestNotificationPermission();
      setPermission(getNotificationPermission());
      if (!granted) {
        setFeedbackNotice('Please allow browser notifications to receive Quiz reminders.');
        setTimeout(() => setFeedbackNotice(null), 5000);
        return;
      }
    }

    const updated = { ...prefs, enabled: nextState };
    setPrefs(updated);
    saveQuizReminderPreferences(updated);

    if (nextState) {
      setFeedbackNotice(`Daily Islamic Quiz reminder scheduled for ${formatTimeDisplay(updated.time)}`);
      setTimeout(() => setFeedbackNotice(null), 4000);
    }
  };

  const handleTimeChange = (newTime: string) => {
    triggerButtonClickHaptic();
    const updated = { ...prefs, time: newTime };
    setPrefs(updated);
    saveQuizReminderPreferences(updated);
    setFeedbackNotice(`Quiz reminder updated to ${formatTimeDisplay(newTime)}`);
    setTimeout(() => setFeedbackNotice(null), 3000);
  };

  const handleToggleSound = () => {
    triggerButtonClickHaptic();
    const updated = { ...prefs, soundEnabled: !prefs.soundEnabled };
    setPrefs(updated);
    saveQuizReminderPreferences(updated);
  };

  const handleSendTest = async () => {
    triggerButtonClickHaptic();
    if (permission !== 'granted') {
      const granted = await requestNotificationPermission();
      setPermission(getNotificationPermission());
      if (!granted) {
        setFeedbackNotice('Notifications are blocked in your browser. Please enable permissions.');
        setTimeout(() => setFeedbackNotice(null), 5000);
        return;
      }
    }

    const sent = showDailyQuizNotification(prefs.soundEnabled);
    if (sent) {
      triggerSuccessHaptic();
      setTestSent(true);
      setFeedbackNotice('Test Daily Quiz reminder sent! Check your system notification tray.');
      setTimeout(() => setTestSent(false), 3000);
      setTimeout(() => setFeedbackNotice(null), 4000);
    } else {
      setFeedbackNotice('Unable to send notification in this browser environment.');
      setTimeout(() => setFeedbackNotice(null), 4000);
    }
  };

  const formatTimeDisplay = (time24: string) => {
    const [hStr, mStr] = time24.split(':');
    const h = parseInt(hStr, 10);
    const ampm = h >= 12 ? 'PM' : 'AM';
    const h12 = h % 12 || 12;
    return `${h12}:${mStr} ${ampm}`;
  };

  return (
    <section 
      aria-label="Daily Islamic Quiz Notifications"
      className="bg-slate-900/60 border border-amber-900/30 rounded-2xl p-5 space-y-4 relative overflow-hidden shadow-lg"
    >
      {/* Decorative Gradient Flare */}
      <div 
        aria-hidden="true" 
        className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-indigo-500/5 blur-3xl pointer-events-none" 
      />

      {/* Header with Switch */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 mt-0.5">
            <HelpCircle size={20} className="text-indigo-400" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-100 flex items-center gap-1.5">
                <span>Daily Quiz Reminder</span>
                <span className="text-[10px] text-indigo-400 font-serif opacity-80" dir="rtl">
                  تذكير الاختبار اليومي
                </span>
              </h3>
              {prefs.enabled && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/30">
                  {formatTimeDisplay(prefs.time)}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Receive a daily reminder to take the Islamic quiz, keep your streak alive, and test your knowledge.
            </p>
          </div>
        </div>

        {/* Master Toggle */}
        <button
          type="button"
          role="switch"
          aria-checked={prefs.enabled}
          onClick={handleToggleEnabled}
          className={`w-12 h-6 rounded-full transition-colors relative flex items-center px-0.5 shrink-0 focus:outline-none focus:ring-2 focus:ring-amber-500/40 ${
            prefs.enabled ? 'bg-indigo-600' : 'bg-slate-800'
          }`}
        >
          <div 
            className={`w-5 h-5 rounded-full bg-slate-950 transition-transform flex items-center justify-center ${
              prefs.enabled ? 'translate-x-6' : 'translate-x-0'
            }`}
          >
            {prefs.enabled ? (
              <Check size={12} className="text-indigo-400 stroke-[3]" />
            ) : (
              <span className="w-1.5 h-1.5 rounded-full bg-slate-500" />
            )}
          </div>
        </button>
      </div>

      {/* Permission Warning Banner if Denied */}
      {permission === 'denied' && (
        <div className="p-3 bg-rose-950/30 border border-rose-900/40 rounded-xl flex items-center gap-2.5 text-xs text-rose-300">
          <AlertCircle size={16} className="shrink-0 text-rose-400" />
          <span>Notifications are blocked in your browser settings. Please enable permissions to receive reminders.</span>
        </div>
      )}

      {/* Configuration Controls (Shown when Enabled) */}
      {prefs.enabled && (
        <div className="space-y-3.5 pt-1 animate-fadeIn">
          {/* Custom Time Selector & Presets */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium flex items-center gap-1.5">
                <Clock size={13} className="text-indigo-400" />
                <span>Scheduled Reminder Time:</span>
              </span>
              <input
                type="time"
                value={prefs.time}
                onChange={(e) => handleTimeChange(e.target.value)}
                className="bg-slate-950 border border-slate-700 text-slate-100 font-mono text-xs px-2.5 py-1 rounded-lg focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Quick Presets */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {TIME_PRESETS.map((preset) => (
                <button
                  key={preset.value}
                  type="button"
                  onClick={() => handleTimeChange(preset.value)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono transition ${
                    prefs.time === preset.value
                      ? 'bg-indigo-600 text-slate-950 font-bold shadow-sm'
                      : 'bg-slate-950/80 border border-slate-800 text-slate-300 hover:border-indigo-500/40'
                  }`}
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          {/* Sound toggle & Test Notification */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={handleToggleSound}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition ${
                prefs.soundEnabled 
                  ? 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30' 
                  : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}
            >
              {prefs.soundEnabled ? <Volume2 size={14} /> : <VolumeX size={14} />}
              <span>{prefs.soundEnabled ? 'Chime Tone On' : 'Silent Push'}</span>
            </button>

            <button
              type="button"
              onClick={handleSendTest}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-indigo-500/40 text-slate-200 text-xs font-semibold transition active:scale-95"
            >
              <Send size={13} className={testSent ? 'text-emerald-400' : 'text-indigo-400'} />
              <span>{testSent ? 'Sent!' : 'Send Test Alert'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Feedback Toast */}
      {feedbackNotice && (
        <div className="p-2.5 bg-indigo-950/40 border border-indigo-500/30 rounded-xl text-xs text-indigo-200 flex items-center gap-2 animate-fadeIn">
          <ShieldCheck size={14} className="text-indigo-400" />
          <span>{feedbackNotice}</span>
        </div>
      )}
    </section>
  );
}
