import React, { useState, useEffect } from 'react';
import { RotateCcw, Volume2, VolumeX, Sparkles, CheckCircle, RefreshCw } from 'lucide-react';
import { commonAdhkars } from '../data/tasbeeh';
import { triggerTasbeehHaptic, triggerButtonClickHaptic, triggerWarningHaptic } from '../lib/haptics';

export default function Tasbeeh() {
  const [count, setCount] = useState<number>(() => {
    const saved = localStorage.getItem('tasbeehCount');
    return saved ? parseInt(saved, 10) : 0;
  });

  const [selectedDhikr, setSelectedDhikr] = useState<string>(() => {
    return localStorage.getItem('tasbeehDhikr') || commonAdhkars[0];
  });

  const [target, setTarget] = useState<number>(() => {
    const saved = localStorage.getItem('tasbeehTarget');
    return saved ? parseInt(saved, 10) : 33;
  });

  const [laps, setLaps] = useState<number>(() => {
    const saved = localStorage.getItem('tasbeehLaps');
    return saved ? parseInt(saved, 10) : 0;
  });

  const [isVoiceGuided, setIsVoiceGuided] = useState<boolean>(() => {
    try {
      return localStorage.getItem('tasbeeh_voice_guided') === 'true';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    localStorage.setItem('tasbeehCount', count.toString());
    localStorage.setItem('tasbeehDhikr', selectedDhikr);
    localStorage.setItem('tasbeehTarget', target.toString());
    localStorage.setItem('tasbeehLaps', laps.toString());
    localStorage.setItem('tasbeeh_voice_guided', isVoiceGuided.toString());
  }, [count, selectedDhikr, target, laps, isVoiceGuided]);

  const speakDhikr = (phrase: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(phrase);
      utterance.lang = 'ar-SA';
      utterance.rate = 0.9;
      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.warn('[Tasbeeh] Speech error:', err);
    }
  };

  const handleIncrement = () => {
    const nextCount = count + 1;
    setCount(nextCount);

    // If target mode is active and we reached target, increment laps
    if (target > 0 && nextCount % target === 0) {
      setLaps(prev => prev + 1);
    }

    // Voice-Guided Speech Recitation
    if (isVoiceGuided) {
      speakDhikr(selectedDhikr);
    }

    // Trigger mobile-only haptic with milestone pattern
    triggerTasbeehHaptic(nextCount, target);
  };

  const handleReset = () => {
    triggerWarningHaptic();
    setCount(0);
    setLaps(0);
  };

  const handleSelectTarget = (newTarget: number) => {
    triggerButtonClickHaptic();
    setTarget(newTarget);
    setCount(0);
    setLaps(0);
  };

  const progressPct = target > 0 ? Math.min(100, Math.round(((count % target) / target) * 100)) : 100;

  return (
    <div className="space-y-6 max-w-lg mx-auto pb-12">
      <header className="text-center sm:text-left">
        <h2 className="text-2xl text-amber-500 font-serif font-bold">Digital Tasbeeh</h2>
        <p className="text-xs text-slate-400">سبحة إلكترونية مع اهتزاز لمسي</p>
      </header>

      {/* Target Selector Bar */}
      <div className="flex items-center justify-between bg-slate-900/70 border border-amber-900/30 rounded-2xl p-1.5 gap-1.5">
        {[33, 99, 100, 0].map((tVal) => (
          <button
            key={tVal}
            onClick={() => handleSelectTarget(tVal)}
            className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-semibold transition active:scale-95 ${
              target === tVal
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            {tVal === 0 ? 'Free' : `${tVal}`}
          </button>
        ))}
      </div>

      <div className="bg-slate-900 border border-amber-900/30 rounded-3xl p-6 sm:p-8 flex flex-col items-center shadow-2xl relative overflow-hidden">
        {/* Decorative background glow */}
        <div className="absolute top-0 inset-x-0 h-32 bg-gradient-to-b from-amber-500/10 to-transparent pointer-events-none" />

        {/* Dhikr Selector */}
        <div className="w-full relative z-10 mb-6">
          <select
            value={selectedDhikr}
            onChange={(e) => {
              triggerButtonClickHaptic();
              setSelectedDhikr(e.target.value);
              setCount(0);
              setLaps(0);
            }}
            className="bg-slate-950 text-amber-400 border border-amber-900/50 rounded-xl py-3 px-4 w-full text-center font-serif text-lg font-bold shadow-inner focus:outline-none focus:border-amber-500 cursor-pointer"
          >
            {commonAdhkars.map(dhikr => (
              <option key={dhikr} value={dhikr} className="bg-slate-900 text-slate-100 font-sans">
                {dhikr}
              </option>
            ))}
          </select>
        </div>

        {/* Laps / Sets info */}
        {target > 0 && (
          <div className="flex items-center gap-3 mb-4 text-xs text-slate-400 font-medium">
            <span className="px-2.5 py-1 rounded-full bg-slate-800/80 border border-slate-700">
              Completed Sets: <strong className="text-amber-400 font-mono">{laps}</strong>
            </span>
            <span className="px-2.5 py-1 rounded-full bg-slate-800/80 border border-slate-700">
              Target: <strong className="text-amber-400 font-mono">{target}</strong>
            </span>
          </div>
        )}

        {/* Interactive Big Counter Button with Circular Radial Progress */}
        <div 
          onClick={handleIncrement}
          className="relative my-4 cursor-pointer select-none group touch-manipulation active:scale-95 transition transform duration-75"
        >
          <div className="w-56 h-56 rounded-full bg-slate-950 border-4 border-amber-500/30 flex flex-col items-center justify-center shadow-2xl group-hover:border-amber-500/60 group-active:border-amber-400">
            <span className="text-6xl sm:text-7xl font-mono font-bold text-slate-100 tracking-tight">
              {count}
            </span>
            <span className="text-xs text-amber-400/80 font-medium mt-2">
              Tap Anywhere to Count
            </span>
          </div>

          {/* Progress ring indicator */}
          {target > 0 && (
            <div className="absolute inset-0 rounded-full pointer-events-none border-4 border-transparent border-t-amber-500"
              style={{
                transform: `rotate(${(progressPct / 100) * 360}deg)`,
                transition: 'transform 0.15s ease-out'
              }}
            />
          )}
        </div>

        {/* Action Controls */}
        <div className="flex gap-4 w-full mt-6">
          <button
            onClick={handleReset}
            className="flex items-center justify-center gap-2 p-4 bg-slate-800/90 text-slate-400 hover:text-rose-400 hover:bg-slate-800 border border-slate-700/60 rounded-2xl transition active:scale-95"
            title="Reset counter"
          >
            <RotateCcw size={20} />
            <span className="text-xs font-semibold">Reset</span>
          </button>
          
          <button
            onClick={handleIncrement}
            className="flex-grow flex items-center justify-center gap-2 p-4 bg-gradient-to-r from-amber-600 to-amber-500 text-slate-950 font-bold text-xl rounded-2xl shadow-lg shadow-amber-500/20 hover:brightness-110 active:scale-95 transition"
          >
            <Sparkles size={20} className="text-slate-950" />
            <span>+1 Dhikr</span>
          </button>
        </div>
      </div>
    </div>
  );
}
