import React, { useState, useEffect, useCallback } from 'react';
import { Bell, BellOff, Check } from 'lucide-react';
import { 
  getPrayerNotificationPreferences, 
  toggleSpecificPrayerNotification,
  PrayerNotificationPreferences 
} from '../lib/notifications';
import { usePrayerTimes } from '../hooks/usePrayerTimes';
import DailyPrayerProgress from './DailyPrayerProgress.tsx';
import PrayerNotificationManager from './PrayerNotificationManager.tsx';
import PrayerLog from './PrayerLog.tsx';
import PrayerInsights from './PrayerInsights.tsx';
import RecentPrayerActivity from './RecentPrayerActivity.tsx';
import IntelligentPrayerPlanner from './IntelligentPrayerPlanner.tsx';
import AmbientSound from './AmbientSound.tsx';
import NearbyMasjids from './NearbyMasjids.tsx';
import PrayerSpecificDuas from './PrayerSpecificDuas.tsx';
import { getFromDB, saveToDB } from '../lib/db';
import { triggerHaptic } from '../lib/haptics';

const OBLIGATORY_NAMES = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

export default function Prayer() {
  const { times, loading, error, retry, fetchTimesByCity } = usePrayerTimes() as {
    times: Record<string, string> | null;
    loading: boolean;
    error: string | null;
    retry: () => void;
    fetchTimesByCity: (city: string, country: string) => void;
  };

  const today = new Date().toDateString();

  const [notificationPrefs, setNotificationPrefs] = useState<PrayerNotificationPreferences>(
    getPrayerNotificationPreferences
  );

  const [completedPrayers, setCompletedPrayers] = useState<Record<string, boolean>>(() => {
    try {
      const cached = localStorage.getItem(`dailyPrayers_${today}`);
      return cached ? JSON.parse(cached) : {};
    } catch {
      return {};
    }
  });

  // Listen to notification preference updates
  useEffect(() => {
    const handleUpdate = (e: Event) => {
      const customEvent = e as CustomEvent<PrayerNotificationPreferences>;
      if (customEvent.detail) {
        setNotificationPrefs(customEvent.detail);
      } else {
        setNotificationPrefs(getPrayerNotificationPreferences());
      }
    };
    window.addEventListener('prayer-notifications-updated', handleUpdate);
    return () => window.removeEventListener('prayer-notifications-updated', handleUpdate);
  }, []);

  // Load completed prayer status & listen for sync events
  useEffect(() => {
    const loadSaved = async () => {
      try {
        const saved = await getFromDB('prayer', today);
        if (saved && saved.prayers) {
          setCompletedPrayers(saved.prayers);
          localStorage.setItem(`dailyPrayers_${today}`, JSON.stringify(saved.prayers));
        }
      } catch (e) {
        console.warn(e);
      }
    };
    loadSaved();

    const handleSync = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail && customEvent.detail.prayers) {
        setCompletedPrayers(customEvent.detail.prayers);
      }
    };
    window.addEventListener('prayer-status-changed', handleSync);
    return () => window.removeEventListener('prayer-status-changed', handleSync);
  }, [today]);

  const toggleReminder = async (name: string) => {
    triggerHaptic(15);
    await toggleSpecificPrayerNotification(name);
  };

  const togglePrayerCompletion = useCallback(async (prayerName: string) => {
    if (!OBLIGATORY_NAMES.includes(prayerName)) return;
    triggerHaptic(25);

    const isDone = !!completedPrayers[prayerName];
    const updated = {
      ...completedPrayers,
      [prayerName]: !isDone
    };

    setCompletedPrayers(updated);
    localStorage.setItem(`dailyPrayers_${today}`, JSON.stringify(updated));

    try {
      await saveToDB('prayer', { date: today, prayers: updated });
      if (!isDone) {
        const history = (await getFromDB('prayer', 'history')) || [];
        const historyList = Array.isArray(history) ? history : (history.history || []);
        await saveToDB('prayer', {
          date: 'history',
          history: [...historyList, { prayer: prayerName, timestamp: new Date().toISOString() }]
        });
      }
    } catch (e) {
      console.warn(e);
    }

    window.dispatchEvent(
      new CustomEvent('prayer-status-changed', {
        detail: { date: today, prayers: updated, prayer: prayerName, completed: !isDone }
      })
    );
  }, [completedPrayers, today]);

  const [city, setCity] = useState('');
  const [country, setCountry] = useState('');

  const handleLocationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (city && country) {
      fetchTimesByCity(city, country);
    }
  };

  if (loading) return (
    <div className="space-y-4 animate-pulse">
      <div className="h-8 bg-slate-800 rounded w-1/3"></div>
      <div className="h-44 bg-slate-900 border border-amber-900/30 rounded-2xl"></div>
      <div className="h-64 bg-slate-900 border border-amber-900/30 rounded-2xl"></div>
    </div>
  );

  if (error) return (
    <div className="text-center p-6 space-y-4 bg-slate-900 border border-amber-900/30 rounded-2xl">
      <p className="text-amber-500 font-medium">{error}</p>
      <button onClick={retry} className="bg-amber-600 text-slate-950 font-bold px-4 py-2 rounded-xl">
        Retry GPS
      </button>
      <form onSubmit={handleLocationSubmit} className="space-y-2 max-w-sm mx-auto pt-2">
        <input 
          type="text" 
          placeholder="City (e.g. Cairo, London)" 
          value={city} 
          onChange={e => setCity(e.target.value)} 
          className="w-full p-2 bg-slate-800 border border-slate-700 rounded-xl text-slate-200" 
          required 
        />
        <input 
          type="text" 
          placeholder="Country (e.g. Egypt, UK)" 
          value={country} 
          onChange={e => setCountry(e.target.value)} 
          className="w-full p-2 bg-slate-800 border border-slate-700 rounded-xl text-slate-200" 
          required 
        />
        <button type="submit" className="w-full bg-amber-600/30 hover:bg-amber-600/40 text-amber-400 border border-amber-500/40 font-semibold py-2 px-4 rounded-xl">
          Set Location
        </button>
      </form>
    </div>
  );

  return (
    <div className="space-y-6 pb-6">
      <header>
        <h2 className="text-2xl text-amber-500 font-serif">Prayer Times</h2>
        <p className="text-xs text-slate-400 mt-1">Daily prayer schedule, visual completion progress, and push notifications</p>
      </header>

      {/* Visual Progress Component showing completed prayers for the current day */}
      <DailyPrayerProgress times={times} />

      {/* Interactive Push Notification Manager Component */}
      <PrayerNotificationManager times={times} compact={true} />

      {/* Daily Prayer Times Schedule with completion checks & individual reminder toggles */}
      <section aria-label="Daily Schedule" className="space-y-3">
        <div className="flex items-center justify-between pb-1">
          <h3 className="text-sm font-semibold tracking-wide uppercase text-amber-500">
            Prayer Schedule
          </h3>
          <span className="text-xs text-slate-400">
            Check off prayers · Toggle push notifications
          </span>
        </div>

        {times && Object.entries(times).filter(([name]) => ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].includes(name)).map(([name, time]) => {
          const isObligatory = OBLIGATORY_NAMES.includes(name);
          const isDone = isObligatory && !!completedPrayers[name];
          const isReminderOn = !!notificationPrefs.enabledPrayers[name];

          return (
            <div 
              key={name} 
              className={`flex justify-between items-center p-3.5 sm:p-4 rounded-xl border transition-all ${
                isDone 
                  ? 'bg-amber-950/20 border-amber-500/40 text-slate-200' 
                  : 'bg-slate-900 border-amber-900/30 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-3">
                {/* One-tap completion check button for obligatory prayers */}
                {isObligatory ? (
                  <button
                    type="button"
                    onClick={() => togglePrayerCompletion(name)}
                    aria-label={`Mark ${name} as ${isDone ? 'incomplete' : 'completed'}`}
                    className={`w-7 h-7 rounded-full flex items-center justify-center border transition-all duration-200 active:scale-95 ${
                      isDone
                        ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-sm shadow-amber-500/30'
                        : 'border-slate-600 hover:border-amber-400 text-transparent'
                    }`}
                  >
                    <Check size={16} strokeWidth={3} className={isDone ? 'block' : 'hidden'} />
                  </button>
                ) : (
                  <div className="w-7 h-7 flex items-center justify-center text-slate-600 text-xs">
                    •
                  </div>
                )}

                <div>
                  <span className={`font-semibold text-sm sm:text-base ${isDone ? 'text-amber-300 line-through opacity-85' : 'text-slate-100'}`}>
                    {name}
                  </span>
                  {name === 'Sunrise' && (
                    <span className="text-[11px] text-slate-400 ml-2 italic">Shuruq</span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-3 sm:gap-4">
                <span className={`font-mono text-base sm:text-lg font-medium ${isDone ? 'text-amber-400/80' : 'text-amber-400'}`}>
                  {time}
                </span>

                {/* Specific Prayer Push Notification Toggle */}
                <button 
                  type="button"
                  onClick={() => toggleReminder(name)}
                  title={isReminderOn ? `Push notification enabled for ${name}` : `Turn on push notification for ${name}`}
                  aria-label={`Toggle push notification for ${name}`}
                  className={`p-2 rounded-lg transition-colors ${
                    isReminderOn
                      ? 'text-amber-400 bg-amber-500/15 ring-1 ring-amber-500/30'
                      : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {isReminderOn ? <Bell size={18} className="fill-amber-400/30" /> : <BellOff size={18} />}
                </button>
              </div>
            </div>
          );
        })}
      </section>

      {/* Recommended Post-Salah Duas for Each Daily Prayer */}
      <PrayerSpecificDuas />

      {/* Weekly Prayer Log & Consistency Bar Chart */}
      <PrayerLog />

      {/* 30-Day Prayer Consistency Insights & Analytics with Recharts */}
      <PrayerInsights />

      {/* Recent Prayer Activity Log */}
      <RecentPrayerActivity />

      {/* Intelligent Nawafil Prayer Planner */}
      <IntelligentPrayerPlanner times={times} />

      {/* Ambient Soundscapes for Focus & Khushoo */}
      <AmbientSound />

      {/* Nearby Masjids Finder Map & List */}
      <NearbyMasjids />
    </div>
  );
}
