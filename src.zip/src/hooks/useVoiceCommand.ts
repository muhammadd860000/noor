import { useEffect, useState } from 'react';

type Command = 'play' | 'pause';

export const useVoiceCommand = (onCommand: (command: Command) => void) => {
  const [isListening, setIsListening] = useState(false);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event: any) => {
      const transcript = event.results[event.results.length - 1][0].transcript.toLowerCase().trim();
      if (transcript.includes('play')) onCommand('play');
      else if (transcript.includes('pause')) onCommand('pause');
    };

    if (isListening) recognition.start();
    else recognition.stop();

    return () => recognition.stop();
  }, [isListening, onCommand]);

  return { isListening, setIsListening };
};
