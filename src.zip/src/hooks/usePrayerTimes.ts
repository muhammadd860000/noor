import React, { useState, useEffect, useCallback } from 'react';

interface PrayerTimes {
  [key: string]: string;
}

export const usePrayerTimes = () => {
  const [times, setTimes] = useState<PrayerTimes | null>(() => {
    try {
      const cached = localStorage.getItem('cachedPrayerTimes');
      return cached ? JSON.parse(cached) : null;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(() => {
    return !localStorage.getItem('cachedPrayerTimes');
  });
  const [error, setError] = useState<string | null>(null);
  const [nextPrayer, setNextPrayer] = useState<{ name: string; time: string; remaining: string } | null>(null);

  const fetchTimes = useCallback((latitude: number, longitude: number) => {
    setError(null);
    const date = new Date().toISOString().slice(0, 10);
    fetch(`https://api.aladhan.com/v1/timings/${date}?latitude=${latitude}&longitude=${longitude}&method=2`)
      .then(res => res.json())
      .then(data => {
        setTimes(data.data.timings);
        localStorage.setItem('cachedPrayerTimes', JSON.stringify(data.data.timings));
        setLoading(false);
      })
      .catch(e => {
        console.error('Failed to fetch prayer times:', e);
        setError('Unable to load prayer times.');
        setLoading(false);
      });
  }, []);

  const fetchTimesByCity = useCallback((city: string, country: string) => {
    setError(null);
    const date = new Date().toISOString().slice(0, 10);
    fetch(`https://api.aladhan.com/v1/timingsByCity/${date}?city=${city}&country=${country}&method=2`)
      .then(res => res.json())
      .then(data => {
        if (data.code !== 200) throw new Error(data.message);
        setTimes(data.data.timings);
        localStorage.setItem('cachedPrayerTimes', JSON.stringify(data.data.timings));
        setLoading(false);
        localStorage.setItem('prayerLocation', JSON.stringify({ city, country }));
      })
      .catch(e => {
        console.error('Failed to fetch prayer times by city:', e);
        setError('Unable to load prayer times for the specified location.');
        setLoading(false);
      });
  }, []);

  const requestLocation = useCallback(() => {
    const savedLocation = localStorage.getItem('prayerLocation');
    if (savedLocation) {
      const { city, country } = JSON.parse(savedLocation);
      fetchTimesByCity(city, country);
      return;
    }

    if (!navigator.geolocation) {
      setError('Geolocation not supported.');
      setLoading(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        fetchTimes(latitude, longitude);
      },
      (err) => {
        let message = 'Location access denied or unavailable.';
        if (err && err.code) {
          if (err.code === 1) message = 'Location access denied.';
          else if (err.code === 2) message = 'Location unavailable.';
          else if (err.code === 3) message = 'Location request timed out.';
        }
        
        console.warn('Geolocation error:', err);
        setError(message);
        setLoading(false);
      },
      { timeout: 10000 }
    );
  }, [fetchTimes, fetchTimesByCity]);

  useEffect(() => {
    requestLocation();
  }, [requestLocation]);

  useEffect(() => {
    if (!times) return;

    const calculateNext = () => {
      const now = new Date();
      const currentMinutes = now.getHours() * 60 + now.getMinutes();

      const prayerList = ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
      for (const prayer of prayerList) {
        const [hours, minutes] = times[prayer].split(':').map(Number);
        const prayerMinutes = hours * 60 + minutes;

        if (prayerMinutes > currentMinutes) {
          const diff = prayerMinutes - currentMinutes;
          setNextPrayer({
            name: prayer,
            time: times[prayer],
            remaining: `${Math.floor(diff / 60)}h ${diff % 60}m`
          });
          return;
        }
      }
      setNextPrayer(null);
    };

    const interval = setInterval(calculateNext, 60000);
    calculateNext();
    return () => clearInterval(interval);
  }, [times]);

  return { nextPrayer, times, loading, error, retry: requestLocation, fetchTimesByCity };
};
