import { useEffect } from 'react';
import { 
  isNotificationSupported, 
  getNotificationPermission, 
  requestNotificationPermission, 
  showPrayerNotification,
  getPrayerNotificationPreferences
} from '../lib/notifications';

export const usePrayerNotifications = (times?: Record<string, string> | null, enabledPrayers?: Record<string, boolean>) => {
  useEffect(() => {
    if (!isNotificationSupported()) return;

    if (getNotificationPermission() === 'default') {
      // Gentle check
    }
  }, []);

  useEffect(() => {
    if (!times || getNotificationPermission() !== 'granted') return;

    const prayerList = ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
    const notifiedThisMinute: Record<string, string> = {};

    const checkTimes = () => {
      const prefs = getPrayerNotificationPreferences();
      const activePrayers = enabledPrayers || prefs.enabledPrayers;

      const now = new Date();
      const currentHours = now.getHours().toString().padStart(2, '0');
      const currentMinutes = now.getMinutes().toString().padStart(2, '0');
      const currentTime = `${currentHours}:${currentMinutes}`;
      const todayDate = now.toDateString();

      for (const prayer of prayerList) {
        if (activePrayers[prayer] && times[prayer] && times[prayer].startsWith(currentTime)) {
          const key = `${todayDate}_${prayer}_${currentTime}`;
          if (!notifiedThisMinute[key]) {
            notifiedThisMinute[key] = 'true';
            showPrayerNotification(prayer, times[prayer], false);
          }
        }
      }
    };

    const intervalId = setInterval(checkTimes, 30000);
    return () => clearInterval(intervalId);
  }, [times, enabledPrayers]);
};
