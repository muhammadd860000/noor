import { useCallback } from 'react';
import { triggerHaptic, triggerButtonClickHaptic, triggerSuccessHaptic, triggerWarningHaptic } from '../lib/haptics';

export function useHaptic() {
  const trigger = useCallback((pattern: number | number[] = 15) => {
    return triggerHaptic(pattern);
  }, []);

  const triggerClick = useCallback(() => {
    return triggerButtonClickHaptic();
  }, []);

  const triggerSuccess = useCallback(() => {
    return triggerSuccessHaptic();
  }, []);

  const triggerError = useCallback(() => {
    return triggerWarningHaptic();
  }, []);

  const handleInteraction = useCallback(<T extends React.SyntheticEvent>(callback?: (e: T) => void) => {
    return (e: T) => {
      triggerButtonClickHaptic();
      if (callback) {
        callback(e);
      }
    };
  }, []);

  return {
    trigger,
    triggerClick,
    triggerSuccess,
    triggerError,
    handleInteraction
  };
}
