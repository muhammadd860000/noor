import { useEffect } from 'react';
import { 
  getQuizReminderPreferences, 
  evaluateQuizReminderTrigger, 
  showDailyQuizNotification, 
  quizNotifiedMap 
} from '../lib/quizScheduler';
import { getNotificationPermission } from '../lib/notifications';

export function useQuizNotifications() {
  useEffect(() => {
    const checkSchedule = () => {
      const prefs = getQuizReminderPreferences();
      if (!prefs.enabled) return;
      if (getNotificationPermission() !== 'granted') return;

      const now = new Date();
      const todayDateStr = now.toISOString().split('T')[0];
      const currentTotalMinutes = now.getHours() * 60 + now.getMinutes();
      const hasNotifiedToday = quizNotifiedMap[todayDateStr] === prefs.time;

      if (evaluateQuizReminderTrigger({
        targetTimeStr: prefs.time,
        currentTotalMinutes,
        isEnabled: prefs.enabled,
        hasNotifiedToday
      })) {
        const sent = showDailyQuizNotification(prefs.soundEnabled);
        if (sent) {
          quizNotifiedMap[todayDateStr] = prefs.time;
        }
      }
    };

    // Check immediately and then every 30 seconds
    checkSchedule();
    const interval = setInterval(checkSchedule, 30000);
    return () => clearInterval(interval);
  }, []);
}
